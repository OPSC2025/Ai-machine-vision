#!/usr/bin/env python3
"""
Test script for the OPSC Sandwich Quality Inspection System.

This script tests various components of the system to ensure they are functioning correctly.

Version: 1.0.0
Last Updated: 2025-04-21
"""

import os
import sys
import time
import logging
import argparse
import yaml
import unittest
import cv2
import numpy as np
from pathlib import Path

# Add project root to path
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if project_root not in sys.path:
    sys.path.append(project_root)

# Import core components
try:
    from src.utils.config import ConfigManager
    from src.utils.logging import setup_logging
    from src.core.inference.model_manager import ModelManager
    from src.core.data.database import DatabaseManager
    from src.core.hardware.jetson_monitor import HardwareVerification
except ImportError as e:
    print(f"Error importing components: {e}")
    print("Make sure you're running this script from the project root directory.")
    sys.exit(1)

# Setup logging
logger = setup_logging(level=logging.INFO)

class ConfigTest(unittest.TestCase):
    """Test configuration loading and management."""
    
    def setUp(self):
        """Set up test case."""
        self.config_path = "config/app.yaml"
    
    def test_config_loading(self):
        """Test loading configuration from file."""
        config_manager = ConfigManager(self.config_path)
        config = config_manager.get_config()
        
        # Check if config is loaded
        self.assertIsNotNone(config)
        self.assertIsInstance(config, dict)
        
        # Check if required sections exist
        self.assertIn("app", config)
        self.assertIn("cameras", config)
        self.assertIn("model", config)
        self.assertIn("database", config)
        
        # Check specific values
        self.assertEqual(config["app"]["name"], "OPSC Sandwich Quality Inspection System")
        self.assertEqual(config["cameras"]["num_cameras"], 4)
    
    def test_config_value_access(self):
        """Test accessing configuration values."""
        config_manager = ConfigManager(self.config_path)
        
        # Test get_value method
        app_name = config_manager.get_value("app.name")
        self.assertEqual(app_name, "OPSC Sandwich Quality Inspection System")
        
        # Test default value
        non_existent = config_manager.get_value("non.existent.key", "default")
        self.assertEqual(non_existent, "default")
    
    def test_sub_config_loading(self):
        """Test loading sub-configuration files."""
        config_manager = ConfigManager(self.config_path)
        
        # Load cameras config
        cameras_config = config_manager.load_sub_config("cameras.yaml")
        self.assertIsNotNone(cameras_config)
        self.assertIsInstance(cameras_config, dict)
        self.assertIn("cameras", cameras_config)
        
        # Load models config
        models_config = config_manager.load_sub_config("models.yaml")
        self.assertIsNotNone(models_config)
        self.assertIsInstance(models_config, dict)
        self.assertIn("roboflow", models_config)


class DatabaseTest(unittest.TestCase):
    """Test database operations."""
    
    def setUp(self):
        """Set up test case."""
        # Use in-memory database for testing
        self.db_path = ":memory:"
        self.db_manager = DatabaseManager(
            db_path=self.db_path,
            enable_backup=False
        )
        self.db_manager.initialize_schema()
    
    def tearDown(self):
        """Tear down test case."""
        self.db_manager.close()
    
    def test_schema_initialization(self):
        """Test database schema initialization."""
        # Check if tables exist
        self.db_manager.cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = [row[0] for row in self.db_manager.cursor.fetchall()]
        
        self.assertIn("detections", tables)
        self.assertIn("defects", tables)
        self.assertIn("system_logs", tables)
        self.assertIn("statistics", tables)
    
    def test_save_detection(self):
        """Test saving detection results."""
        # Create test image
        image = np.zeros((480, 640, 3), dtype=np.uint8)
        
        # Create test detections
        from src.models.roboflow.sandwich_defect_model import DetectionResult
        detections = [
            DetectionResult(
                defect_type="improper_sealing",
                confidence=0.85,
                bbox=(0.2, 0.3, 0.1, 0.1)
            ),
            DetectionResult(
                defect_type="filling_leakage",
                confidence=0.92,
                bbox=(0.6, 0.4, 0.15, 0.2)
            )
        ]
        
        # Save detection
        detection_id = self.db_manager.save_detections(
            camera_id="test_camera",
            image=image,
            detections=detections,
            save_image=False
        )
        
        # Check if detection was saved
        self.assertIsNotNone(detection_id)
        self.assertGreater(detection_id, 0)
        
        # Get detection
        detection = self.db_manager.get_detection(detection_id)
        
        # Check detection data
        self.assertEqual(detection["camera_id"], "test_camera")
        self.assertEqual(detection["num_defects"], 2)
        self.assertEqual(detection["inspection_result"], "FAIL")
        self.assertEqual(len(detection["defects"]), 2)
        
        # Check defect data
        defect1 = detection["defects"][0]
        self.assertEqual(defect1["defect_type"], "improper_sealing")
        self.assertAlmostEqual(defect1["confidence"], 0.85)
        
        defect2 = detection["defects"][1]
        self.assertEqual(defect2["defect_type"], "filling_leakage")
        self.assertAlmostEqual(defect2["confidence"], 0.92)
    
    def test_get_recent_detections(self):
        """Test getting recent detection records."""
        # Create test image
        image = np.zeros((480, 640, 3), dtype=np.uint8)
        
        # Create test detections
        from src.models.roboflow.sandwich_defect_model import DetectionResult
        detections = [
            DetectionResult(
                defect_type="improper_sealing",
                confidence=0.85,
                bbox=(0.2, 0.3, 0.1, 0.1)
            )
        ]
        
        # Save multiple detections
        for i in range(5):
            self.db_manager.save_detections(
                camera_id=f"camera_{i % 2 + 1}",
                image=image,
                detections=detections if i % 2 == 0 else [],
                save_image=False
            )
        
        # Get recent detections (all)
        recent = self.db_manager.get_recent_detections(limit=10)
        self.assertEqual(len(recent), 5)
        
        # Get recent detections (limited)
        recent = self.db_manager.get_recent_detections(limit=3)
        self.assertEqual(len(recent), 3)
        
        # Get recent detections (filtered by camera)
        recent = self.db_manager.get_recent_detections(camera_id="camera_1")
        self.assertEqual(len(recent), 3)
        
        # Get recent detections (filtered by result)
        recent = self.db_manager.get_recent_detections(result="PASS")
        self.assertEqual(len(recent), 2)
        
        recent = self.db_manager.get_recent_detections(result="FAIL")
        self.assertEqual(len(recent), 3)
    
    def test_system_logging(self):
        """Test system event logging."""
        # Log system event
        self.db_manager.log_system_event(
            log_level="INFO",
            component="test",
            message="Test event",
            details={"test_key": "test_value"}
        )
        
        # Check if event was logged
        self.db_manager.cursor.execute("SELECT * FROM system_logs")
        logs = self.db_manager.cursor.fetchall()
        
        self.assertEqual(len(logs), 1)
        log = dict(logs[0])
        
        self.assertEqual(log["log_level"], "INFO")
        self.assertEqual(log["component"], "test")
        self.assertEqual(log["message"], "Test event")
        self.assertIsNotNone(log["details"])


class ModelTest(unittest.TestCase):
    """Test model loading and inference."""
    
    def setUp(self):
        """Set up test case."""
        # Skip tests if no GPU is available
        try:
            import torch
            self.has_gpu = torch.cuda.is_available()
        except ImportError:
            self.has_gpu = False
        
        if not self.has_gpu:
            self.skipTest("No GPU available for testing")
        
        # Create test image
        self.test_image = np.zeros((640, 640, 3), dtype=np.uint8)
        
        # Draw a simple sandwich shape
        cv2.rectangle(self.test_image, (220, 220), (420, 420), (200, 200, 200), -1)
        cv2.rectangle(self.test_image, (200, 200), (440, 440), (150, 150, 150), 2)
        
        # Add a "defect"
        cv2.circle(self.test_image, (320, 320), 30, (0, 0, 255), -1)
    
    def test_model_initialization(self):
        """Test model initialization."""
        try:
            # Initialize model manager with API mode (no local model needed)
            model_manager = ModelManager(
                model_type="roboflow",
                use_local_inference=False,
                confidence_threshold=0.5
            )
            
            # Check if model is initialized
            self.assertIsNotNone(model_manager.model)
            self.assertTrue(model_manager.initialized)
            
            print("Model initialization successful")
        except Exception as e:
            self.fail(f"Model initialization failed: {e}")
    
    def test_model_prediction(self):
        """Test model prediction."""
        # Skip this test in CI environment
        if os.environ.get("CI") == "true":
            self.skipTest("Skipping prediction test in CI environment")
        
        try:
            # Initialize model manager with API mode
            model_manager = ModelManager(
                model_type="roboflow",
                use_local_inference=False,
                confidence_threshold=0.5
            )
            
            # Perform prediction
            detections = model_manager.predict(self.test_image)
            
            # We can't assert specific results since we're using a test image,
            # but we can check that the prediction runs without errors
            self.assertIsInstance(detections, list)
            
            print(f"Model prediction returned {len(detections)} detections")
        except Exception as e:
            self.fail(f"Model prediction failed: {e}")


class HardwareTest(unittest.TestCase):
    """Test hardware verification and monitoring."""
    
    def test_hardware_verification(self):
        """Test hardware verification."""
        try:
            # Initialize hardware verification
            verification = HardwareVerification()
            
            # Verify host PC
            host_result = verification.verify_host()
            
            # Check if verification ran without errors
            self.assertIsInstance(host_result, dict)
            self.assertIn("status", host_result)
            
            print(f"Host verification status: {host_result['status']}")
            
            # We can't assert specific results since hardware varies,
            # but we can check that the verification runs without errors
        except Exception as e:
            self.fail(f"Hardware verification failed: {e}")
    
    def test_jetson_monitor(self):
        """Test Jetson monitoring."""
        from src.core.hardware.jetson_monitor import JetsonMonitor
        
        try:
            # Initialize Jetson monitor
            monitor = JetsonMonitor(update_interval=1.0)
            
            # Start monitoring
            monitor.start_monitoring()
            
            # Wait for a moment
            time.sleep(2)
            
            # Get hardware status
            status = monitor.get_hardware_status()
            
            # Check if status is returned
            self.assertIsInstance(status, dict)
            self.assertIn("timestamp", status)
            
            # Stop monitoring
            monitor.stop_monitoring()
            
            print("Jetson monitoring test completed")
        except Exception as e:
            # Don't fail the test if we're not on a Jetson device
            print(f"Jetson monitoring test skipped: {e}")


def run_tests():
    """Run all tests."""
    # Create test suite
    suite = unittest.TestSuite()
    
    # Add test cases
    suite.addTest(unittest.makeSuite(ConfigTest))
    suite.addTest(unittest.makeSuite(DatabaseTest))
    suite.addTest(unittest.makeSuite(ModelTest))
    suite.addTest(unittest.makeSuite(HardwareTest))
    
    # Run tests
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    return result.wasSuccessful()


if __name__ == "__main__":
    # Parse arguments
    parser = argparse.ArgumentParser(description="Test OPSC Sandwich Quality Inspection System")
    parser.add_argument("--verbose", action="store_true", help="Enable verbose output")
    args = parser.parse_args()
    
    # Set log level
    log_level = logging.DEBUG if args.verbose else logging.INFO
    logger.setLevel(log_level)
    
    # Run tests
    success = run_tests()
    
    # Exit with appropriate code
    sys.exit(0 if success else 1)
