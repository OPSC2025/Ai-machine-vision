"""
UI Enhancement Documentation for the OPSC Sandwich Quality Inspection System

This document provides comprehensive documentation for all UI enhancements implemented
in the OPSC Sandwich Quality Inspection System, including design framework, components,
responsive design, and backend integration.
"""

# UI Enhancement Documentation
# OPSC Sandwich Quality Inspection System
# Version 1.0.0
# April 2025

## Table of Contents

1. [Introduction](#introduction)
2. [Design System](#design-system)
3. [Material UI Components](#material-ui-components)
4. [Responsive Layout System](#responsive-layout-system)
5. [Interactive Dashboard](#interactive-dashboard)
6. [Enhanced Camera Views](#enhanced-camera-views)
7. [User Experience Improvements](#user-experience-improvements)
8. [Dark Mode Support](#dark-mode-support)
9. [Mobile Responsive Design](#mobile-responsive-design)
10. [Backend Integration](#backend-integration)
11. [Testing](#testing)
12. [Future Enhancements](#future-enhancements)

## 1. Introduction <a name="introduction"></a>

The OPSC Sandwich Quality Inspection System UI has been completely redesigned and enhanced to provide a modern, responsive, and user-friendly interface. The new UI is built on a comprehensive design system that ensures consistency across all components and pages, with full support for different screen sizes, dark mode, and touch devices.

### Key Enhancements

- **Modern Design Framework**: A comprehensive design system based on Material Design principles
- **Responsive Layout**: Adaptive layouts that work seamlessly across desktop, tablet, and mobile devices
- **Interactive Dashboard**: Real-time data visualization with interactive controls
- **Enhanced Camera Views**: Improved camera monitoring with advanced controls and visualization
- **User Experience Improvements**: Intuitive navigation, guided workflows, and contextual help
- **Dark Mode Support**: Full dark theme support with automatic detection and manual toggle
- **Mobile Responsive Design**: Touch-friendly controls and mobile-optimized layouts
- **Backend Integration**: Seamless integration with backend systems for real-time data

### Technology Stack

- **Streamlit**: Base framework for the UI
- **Material Design**: Design language and component styling
- **CSS**: Custom styling and responsive design
- **JavaScript**: Enhanced interactivity and device detection
- **Python**: Backend integration and data processing

## 2. Design System <a name="design-system"></a>

The design system provides a consistent foundation for all UI components, ensuring visual harmony and usability across the application.

### Color System

The color system is based on a primary and secondary color palette with supporting colors for feedback states (success, error, warning, info). Each color has multiple shades for different use cases.

```python
# Color palette definition
PRIMARY_COLOR = {
    'main': '#1976d2',
    'light': '#42a5f5',
    'dark': '#1565c0',
    'contrast_text': '#ffffff',
}

SECONDARY_COLOR = {
    'main': '#9c27b0',
    'light': '#ba68c8',
    'dark': '#7b1fa2',
    'contrast_text': '#ffffff',
}

ERROR_COLOR = {
    'main': '#d32f2f',
    'light': '#ef5350',
    'dark': '#c62828',
    'contrast_text': '#ffffff',
}

WARNING_COLOR = {
    'main': '#ed6c02',
    'light': '#ff9800',
    'dark': '#e65100',
    'contrast_text': '#ffffff',
}

INFO_COLOR = {
    'main': '#0288d1',
    'light': '#03a9f4',
    'dark': '#01579b',
    'contrast_text': '#ffffff',
}

SUCCESS_COLOR = {
    'main': '#2e7d32',
    'light': '#4caf50',
    'dark': '#1b5e20',
    'contrast_text': '#ffffff',
}
```

### Typography

The typography system defines a hierarchy of text styles for different purposes, ensuring readability and visual hierarchy.

```python
# Typography definition
TYPOGRAPHY = {
    'h1': {
        'font_family': '"Roboto", "Helvetica", "Arial", sans-serif',
        'font_weight': 300,
        'font_size': '2.5rem',
        'line_height': 1.2,
        'letter_spacing': '-0.01562em',
    },
    'h2': {
        'font_family': '"Roboto", "Helvetica", "Arial", sans-serif',
        'font_weight': 300,
        'font_size': '2rem',
        'line_height': 1.2,
        'letter_spacing': '-0.00833em',
    },
    'h3': {
        'font_family': '"Roboto", "Helvetica", "Arial", sans-serif',
        'font_weight': 400,
        'font_size': '1.75rem',
        'line_height': 1.2,
        'letter_spacing': '0em',
    },
    'h4': {
        'font_family': '"Roboto", "Helvetica", "Arial", sans-serif',
        'font_weight': 400,
        'font_size': '1.5rem',
        'line_height': 1.2,
        'letter_spacing': '0.00735em',
    },
    'h5': {
        'font_family': '"Roboto", "Helvetica", "Arial", sans-serif',
        'font_weight': 400,
        'font_size': '1.25rem',
        'line_height': 1.2,
        'letter_spacing': '0em',
    },
    'h6': {
        'font_family': '"Roboto", "Helvetica", "Arial", sans-serif',
        'font_weight': 500,
        'font_size': '1.125rem',
        'line_height': 1.2,
        'letter_spacing': '0.0075em',
    },
    'subtitle1': {
        'font_family': '"Roboto", "Helvetica", "Arial", sans-serif',
        'font_weight': 400,
        'font_size': '1rem',
        'line_height': 1.75,
        'letter_spacing': '0.00938em',
    },
    'subtitle2': {
        'font_family': '"Roboto", "Helvetica", "Arial", sans-serif',
        'font_weight': 500,
        'font_size': '0.875rem',
        'line_height': 1.57,
        'letter_spacing': '0.00714em',
    },
    'body1': {
        'font_family': '"Roboto", "Helvetica", "Arial", sans-serif',
        'font_weight': 400,
        'font_size': '1rem',
        'line_height': 1.5,
        'letter_spacing': '0.00938em',
    },
    'body2': {
        'font_family': '"Roboto", "Helvetica", "Arial", sans-serif',
        'font_weight': 400,
        'font_size': '0.875rem',
        'line_height': 1.43,
        'letter_spacing': '0.01071em',
    },
    'button': {
        'font_family': '"Roboto", "Helvetica", "Arial", sans-serif',
        'font_weight': 500,
        'font_size': '0.875rem',
        'line_height': 1.75,
        'letter_spacing': '0.02857em',
        'text_transform': 'uppercase',
    },
    'caption': {
        'font_family': '"Roboto", "Helvetica", "Arial", sans-serif',
        'font_weight': 400,
        'font_size': '0.75rem',
        'line_height': 1.66,
        'letter_spacing': '0.03333em',
    },
    'overline': {
        'font_family': '"Roboto", "Helvetica", "Arial", sans-serif',
        'font_weight': 400,
        'font_size': '0.75rem',
        'line_height': 2.66,
        'letter_spacing': '0.08333em',
        'text_transform': 'uppercase',
    },
}
```

### Spacing

The spacing system provides consistent spacing values for margins, padding, and layout.

```python
# Spacing definition
SPACING = {
    'xs': '0.25rem',  # 4px
    'sm': '0.5rem',   # 8px
    'md': '1rem',     # 16px
    'lg': '1.5rem',   # 24px
    'xl': '2rem',     # 32px
    'xxl': '3rem',    # 48px
}
```

### Shadows

The shadow system provides elevation effects for components.

```python
# Shadow definition
SHADOWS = {
    0: 'none',
    1: '0px 2px 1px -1px rgba(0,0,0,0.2), 0px 1px 1px 0px rgba(0,0,0,0.14), 0px 1px 3px 0px rgba(0,0,0,0.12)',
    2: '0px 3px 1px -2px rgba(0,0,0,0.2), 0px 2px 2px 0px rgba(0,0,0,0.14), 0px 1px 5px 0px rgba(0,0,0,0.12)',
    3: '0px 3px 3px -2px rgba(0,0,0,0.2), 0px 3px 4px 0px rgba(0,0,0,0.14), 0px 1px 8px 0px rgba(0,0,0,0.12)',
    4: '0px 2px 4px -1px rgba(0,0,0,0.2), 0px 4px 5px 0px rgba(0,0,0,0.14), 0px 1px 10px 0px rgba(0,0,0,0.12)',
    6: '0px 3px 5px -1px rgba(0,0,0,0.2), 0px 6px 10px 0px rgba(0,0,0,0.14), 0px 1px 18px 0px rgba(0,0,0,0.12)',
    8: '0px 5px 5px -3px rgba(0,0,0,0.2), 0px 8px 10px 1px rgba(0,0,0,0.14), 0px 3px 14px 2px rgba(0,0,0,0.12)',
    12: '0px 7px 8px -4px rgba(0,0,0,0.2), 0px 12px 17px 2px rgba(0,0,0,0.14), 0px 5px 22px 4px rgba(0,0,0,0.12)',
    16: '0px 8px 10px -5px rgba(0,0,0,0.2), 0px 16px 24px 2px rgba(0,0,0,0.14), 0px 6px 30px 5px rgba(0,0,0,0.12)',
    24: '0px 11px 15px -7px rgba(0,0,0,0.2), 0px 24px 38px 3px rgba(0,0,0,0.14), 0px 9px 46px 8px rgba(0,0,0,0.12)',
}
```

### Border Radius

The border radius system provides consistent rounding for components.

```python
# Border radius definition
BORDER_RADIUS = {
    'none': '0',
    'sm': '0.125rem',  # 2px
    'md': '0.25rem',   # 4px
    'lg': '0.5rem',    # 8px
    'xl': '1rem',      # 16px
    'pill': '9999px',
}
```

### Theme Provider

The theme provider applies the design system to the entire application, ensuring consistent styling across all pages and components.

```python
def apply_design_system_to_page(page_title):
    """
    Apply the design system to the current page.
    
    Parameters:
    - page_title: Title of the page
    """
    # Set page config
    st.set_page_config(
        page_title=f"OPSC Vision System - {page_title}",
        page_icon="🥪",
        layout="wide",
        initial_sidebar_state="expanded"
    )
    
    # Apply design system CSS
    colors = get_theme_colors()
    typography = get_typography()
    spacing = get_spacing()
    shadows = get_shadows()
    border_radius = get_border_radius()
    
    # Generate CSS variables
    css_variables = ":root {\n"
    
    # Add color variables
    for category, values in colors.items():
        if isinstance(values, dict):
            for shade, color in values.items():
                css_variables += f"  --color-{category}-{shade}: {color};\n"
        else:
            css_variables += f"  --color-{category}: {values};\n"
    
    # Add typography variables
    for style, props in typography.items():
        for prop, value in props.items():
            css_variables += f"  --typography-{style}-{prop.replace('_', '-')}: {value};\n"
    
    # Add spacing variables
    for size, value in spacing.items():
        css_variables += f"  --spacing-{size}: {value};\n"
    
    # Add shadow variables
    for level, value in shadows.items():
        css_variables += f"  --shadow-{level}: {value};\n"
    
    # Add border radius variables
    for size, value in border_radius.items():
        css_variables += f"  --border-radius-{size}: {value};\n"
    
    css_variables += "}\n"
    
    # Apply base styles
    css = f"""
    {css_variables}
    
    /* Base styles */
    body {{
        font-family: var(--typography-body1-font-family);
        font-size: var(--typography-body1-font-size);
        line-height: var(--typography-body1-line-height);
        color: var(--color-text-primary);
        background-color: var(--color-background-default);
        margin: 0;
        padding: 0;
    }}
    
    /* Typography styles */
    h1 {{
        font-family: var(--typography-h1-font-family);
        font-weight: var(--typography-h1-font-weight);
        font-size: var(--typography-h1-font-size);
        line-height: var(--typography-h1-line-height);
        letter-spacing: var(--typography-h1-letter-spacing);
        margin-top: var(--spacing-lg);
        margin-bottom: var(--spacing-md);
    }}
    
    h2 {{
        font-family: var(--typography-h2-font-family);
        font-weight: var(--typography-h2-font-weight);
        font-size: var(--typography-h2-font-size);
        line-height: var(--typography-h2-line-height);
        letter-spacing: var(--typography-h2-letter-spacing);
        margin-top: var(--spacing-lg);
        margin-bottom: var(--spacing-md);
    }}
    
    h3 {{
        font-family: var(--typography-h3-font-family);
        font-weight: var(--typography-h3-font-weight);
        font-size: var(--typography-h3-font-size);
        line-height: var(--typography-h3-line-height);
        letter-spacing: var(--typography-h3-letter-spacing);
        margin-top: var(--spacing-md);
        margin-bottom: var(--spacing-sm);
    }}
    
    /* Add more styles as needed */
    """
    
    # Apply CSS
    st.markdown(f"<style>{css}</style>", unsafe_allow_html=True)
```

## 3. Material UI Components <a name="material-ui-components"></a>

The Material UI components provide a comprehensive set of UI elements that follow Material Design principles, ensuring a consistent and modern look and feel across the application.

### Component List

- **Buttons**: Primary, secondary, text, and icon buttons with various states
- **Cards**: Content containers with headers, content, and actions
- **Text Fields**: Input fields with labels, placeholders, and validation
- **Selects**: Dropdown selects with single and multiple selection
- **Checkboxes**: Checkboxes with labels and states
- **Radio Buttons**: Radio button groups with labels and states
- **Sliders**: Range sliders with labels and values
- **Tabs**: Tabbed navigation with indicators
- **Data Tables**: Tables with sorting, pagination, and row selection
- **Metrics**: Numeric displays with labels and trends
- **Progress Indicators**: Linear and circular progress indicators
- **Alerts**: Information, success, warning, and error alerts
- **Badges**: Numeric badges for notifications
- **Chips**: Compact elements for attributes and actions
- **Dividers**: Horizontal and vertical dividers
- **Icons**: Material Icons integration
- **Tooltips**: Informational tooltips for UI elements

### Example Components

#### Buttons

```python
def material_button(label, variant="primary", icon=None, disabled=False, key=None):
    """
    Create a Material Design button.
    
    Parameters:
    - label: Button text
    - variant: Button variant ('primary', 'secondary', 'text')
    - icon: Optional icon name from Material Icons
    - disabled: Whether the button is disabled
    - key: Unique key for the button
    
    Returns:
    - Button click state (True if clicked, False otherwise)
    """
    # Define button styles based on variant
    if variant == "primary":
        button_style = f"""
        background-color: var(--color-primary-main);
        color: var(--color-primary-contrast-text);
        border: none;
        border-radius: var(--border-radius-md);
        padding: 0.5rem 1rem;
        font-family: var(--typography-button-font-family);
        font-weight: var(--typography-button-font-weight);
        font-size: var(--typography-button-font-size);
        letter-spacing: var(--typography-button-letter-spacing);
        text-transform: var(--typography-button-text-transform);
        box-shadow: var(--shadow-2);
        transition: background-color 0.3s, box-shadow 0.3s;
        """
        hover_style = """
        background-color: var(--color-primary-dark);
        box-shadow: var(--shadow-4);
        """
    elif variant == "secondary":
        button_style = f"""
        background-color: var(--color-secondary-main);
        color: var(--color-secondary-contrast-text);
        border: none;
        border-radius: var(--border-radius-md);
        padding: 0.5rem 1rem;
        font-family: var(--typography-button-font-family);
        font-weight: var(--typography-button-font-weight);
        font-size: var(--typography-button-font-size);
        letter-spacing: var(--typography-button-letter-spacing);
        text-transform: var(--typography-button-text-transform);
        box-shadow: var(--shadow-2);
        transition: background-color 0.3s, box-shadow 0.3s;
        """
        hover_style = """
        background-color: var(--color-secondary-dark);
        box-shadow: var(--shadow-4);
        """
    elif variant == "text":
        button_style = f"""
        background-color: transparent;
        color: var(--color-primary-main);
        border: none;
        border-radius: var(--border-radius-md);
        padding: 0.5rem 1rem;
        font-family: var(--typography-button-font-family);
        font-weight: var(--typography-button-font-weight);
        font-size: var(--typography-button-font-size);
        letter-spacing: var(--typography-button-letter-spacing);
        text-transform: var(--typography-button-text-transform);
        transition: background-color 0.3s;
        """
        hover_style = """
        background-color: rgba(25, 118, 210, 0.04);
        """
    else:
        # Default to primary
        button_style = f"""
        background-color: var(--color-primary-main);
        color: var(--color-primary-contrast-text);
        border: none;
        border-radius: var(--border-radius-md);
        padding: 0.5rem 1rem;
        font-family: var(--typography-button-font-family);
        font-weight: var(--typography-button-font-weight);
        font-size: var(--typography-button-font-size);
        letter-spacing: var(--typography-button-letter-spacing);
        text-transform: var(--typography-button-text-transform);
        box-shadow: var(--shadow-2);
        transition: background-color 0.3s, box-shadow 0.3s;
        """
        hover_style = """
        background-color: var(--color-primary-dark);
        box-shadow: var(--shadow-4);
        """
    
    # Add disabled styles if needed
    if disabled:
        button_style += """
        opacity: 0.5;
        cursor: not-allowed;
        box-shadow: none;
        """
        hover_style = ""
    
    # Create button HTML
    button_html = f"""
    <style>
    .material-button-{key} {{
        {button_style}
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        position: relative;
        outline: none;
        user-select: none;
        overflow: hidden;
    }}
    
    .material-button-{key}:hover {{
        {hover_style}
    }}
    
    .material-button-{key}:active {{
        transform: scale(0.98);
    }}
    
    .material-button-{key} .material-button-icon {{
        margin-right: 0.5rem;
    }}
    </style>
    """
    
    # Use Streamlit's button with custom styling
    if icon:
        button_label = f'<span class="material-icons material-button-icon">{icon}</span> {label}'
    else:
        button_label = label
    
    return st.button(
        button_label,
        key=key,
        disabled=disabled,
        use_container_width=False
    )
```

#### Cards

```python
def material_card(title=None, elevation=1, padding="medium"):
    """
    Create a Material Design card container.
    
    Parameters:
    - title: Optional card title
    - elevation: Card elevation level (1-5)
    - padding: Card padding ('small', 'medium', 'large')
    
    Returns:
    - Card container context manager
    """
    # Map padding values to actual padding
    padding_map = {
        "small": "var(--spacing-sm)",
        "medium": "var(--spacing-md)",
        "large": "var(--spacing-lg)",
    }
    
    padding_value = padding_map.get(padding, "var(--spacing-md)")
    
    # Generate a unique ID for this card
    card_id = f"card_{id(title)}_{elevation}"
    
    # Create card HTML
    card_html = f"""
    <style>
    .material-card-{card_id} {{
        background-color: var(--color-background-paper);
        border-radius: var(--border-radius-md);
        box-shadow: var(--shadow-{elevation});
        padding: {padding_value};
        margin-bottom: var(--spacing-md);
        overflow: hidden;
    }}
    
    .material-card-header-{card_id} {{
        margin: calc(-1 * {padding_value}) calc(-1 * {padding_value}) 0;
        padding: {padding_value};
        background-color: var(--color-background-secondary);
        border-bottom: 1px solid var(--color-border-light);
        margin-bottom: {padding_value};
    }}
    
    .material-card-title-{card_id} {{
        font-family: var(--typography-h6-font-family);
        font-weight: var(--typography-h6-font-weight);
        font-size: var(--typography-h6-font-size);
        line-height: var(--typography-h6-line-height);
        letter-spacing: var(--typography-h6-letter-spacing);
        margin: 0;
        color: var(--color-text-primary);
    }}
    </style>
    
    <div class="material-card-{card_id}">
    """
    
    if title:
        card_html += f"""
        <div class="material-card-header-{card_id}">
            <h3 class="material-card-title-{card_id}">{title}</h3>
        </div>
        """
    
    # Start the card
    st.markdown(card_html, unsafe_allow_html=True)
    
    # Create a container for the card content
    container = st.container()
    
    # Return the container as a context manager
    class CardContextManager:
        def __init__(self, container):
            self.container = container
        
        def __enter__(self):
            return self.container
        
        def __exit__(self, exc_type, exc_val, exc_tb):
            # Close the card
            st.markdown("</div>", unsafe_allow_html=True)
    
    return CardContextManager(container)
```

#### Metrics

```python
def material_metric(label, value, delta=None, delta_color="normal"):
    """
    Create a Material Design metric display.
    
    Parameters:
    - label: Metric label
    - value: Metric value
    - delta: Optional delta value
    - delta_color: Color of the delta ('normal', 'good', 'bad')
    
    Returns:
    - None
    """
    # Map delta colors to actual colors
    delta_color_map = {
        "normal": None,
        "good": "success",
        "bad": "error",
    }
    
    # Use Streamlit's metric with custom styling
    st.metric(
        label=label,
        value=value,
        delta=delta,
        delta_color=delta_color_map.get(delta_color, None)
    )
```

## 4. Responsive Layout System <a name="responsive-layout-system"></a>

The responsive layout system provides a flexible grid-based layout that adapts to different screen sizes, ensuring a consistent user experience across desktop, tablet, and mobile devices.

### Layout Components

- **Responsive Container**: A container that adapts its width based on screen size
- **Responsive Grid**: A grid layout that adjusts the number of columns based on screen size
- **Responsive Columns**: Columns that adjust their width based on screen size
- **Responsive Card**: A card that adapts its layout based on screen size
- **Responsive Sidebar**: A sidebar that collapses to a mobile menu on smaller screens
- **Responsive Table**: A table that adapts its display based on screen size
- **Responsive Tabs**: Tabs that transform to a dropdown on smaller screens
- **Responsive Image**: An image that scales appropriately for different screen sizes
- **Responsive Menu**: A navigation menu that adapts to different screen sizes

### Example Components

#### Responsive Container

```python
def responsive_container(max_width="large"):
    """
    Create a responsive container that adapts its width based on screen size.
    
    Parameters:
    - max_width: Maximum width of the container ('small', 'medium', 'large', 'xlarge')
    
    Returns:
    - Container context manager
    """
    # Map max width values to actual widths
    max_width_map = {
        "small": "600px",
        "medium": "960px",
        "large": "1280px",
        "xlarge": "1920px",
    }
    
    max_width_value = max_width_map.get(max_width, "1280px")
    
    # Generate a unique ID for this container
    container_id = f"container_{id(max_width)}"
    
    # Create container HTML
    container_html = f"""
    <style>
    .responsive-container-{container_id} {{
        width: 100%;
        max-width: {max_width_value};
        margin: 0 auto;
        padding: var(--spacing-md);
        box-sizing: border-box;
    }}
    
    @media (max-width: 600px) {{
        .responsive-container-{container_id} {{
            padding: var(--spacing-sm);
        }}
    }}
    </style>
    
    <div class="responsive-container-{container_id}">
    """
    
    # Start the container
    st.markdown(container_html, unsafe_allow_html=True)
    
    # Create a container for the content
    container = st.container()
    
    # Return the container as a context manager
    class ContainerContextManager:
        def __init__(self, container):
            self.container = container
        
        def __enter__(self):
            return self.container
        
        def __exit__(self, exc_type, exc_val, exc_tb):
            # Close the container
            st.markdown("</div>", unsafe_allow_html=True)
    
    return ContainerContextManager(container)
```

#### Responsive Grid

```python
def responsive_grid(items, columns=3, columns_tablet=2, columns_mobile=1):
    """
    Create a responsive grid layout that adapts to different screen sizes.
    
    Parameters:
    - items: List of content items to display in the grid
    - columns: Number of columns on desktop
    - columns_tablet: Number of columns on tablet
    - columns_mobile: Number of columns on mobile
    
    Returns:
    - None (renders the grid directly)
    """
    # Generate a unique ID for this grid
    grid_id = f"grid_{id(items)}"
    
    # Create grid HTML
    grid_html = f"""
    <style>
    .responsive-grid-{grid_id} {{
        display: grid;
        grid-template-columns: repeat({columns}, 1fr);
        gap: var(--spacing-md);
        margin-bottom: var(--spacing-md);
    }}
    
    @media (max-width: 960px) {{
        .responsive-grid-{grid_id} {{
            grid-template-columns: repeat({columns_tablet}, 1fr);
        }}
    }}
    
    @media (max-width: 600px) {{
        .responsive-grid-{grid_id} {{
            grid-template-columns: repeat({columns_mobile}, 1fr);
            gap: var(--spacing-sm);
        }}
    }}
    </style>
    
    <div class="responsive-grid-{grid_id}">
    """
    
    # Add items to the grid
    for item in items:
        grid_html += f"""
        <div class="responsive-grid-item-{grid_id}">
            {item}
        </div>
        """
    
    grid_html += "</div>"
    
    # Render the grid
    st.markdown(grid_html, unsafe_allow_html=True)
```

#### Responsive Columns

```python
def responsive_columns(count, ratio=None):
    """
    Create responsive columns that adjust their width based on screen size.
    
    Parameters:
    - count: Number of columns
    - ratio: Optional list of width ratios for the columns
    
    Returns:
    - List of column objects
    """
    # Create columns using Streamlit's columns
    if ratio:
        return st.columns(ratio)
    else:
        return st.columns(count)
```

## 5. Interactive Dashboard <a name="interactive-dashboard"></a>

The interactive dashboard provides a comprehensive overview of the system status, production metrics, and defect detection results with real-time updates and interactive controls.

### Dashboard Features

- **Real-time Metrics**: Production rate, defect rate, quality score, and system status
- **Production Trends**: Interactive charts showing production and defect trends over time
- **Defect Distribution**: Breakdown of defect types with distribution charts
- **Camera Status**: Real-time status of all cameras with performance metrics
- **System Health**: Host system, Jetson, database, and network status monitoring
- **Recent Defects**: List of recently detected defects with images and details
- **Interactive Controls**: Filters, date range selectors, and refresh controls
- **Quick Actions**: One-click access to common tasks like camera calibration and report generation

### Implementation

The dashboard is implemented using a combination of Streamlit components, Material UI components, and custom visualizations. It is fully responsive and adapts to different screen sizes.

```python
def render_dashboard():
    """Render the interactive dashboard."""
    # Apply design system to the page
    apply_design_system_to_page("Dashboard")
    
    # Load Material Icons
    load_material_icons()
    
    # Initialize backend integration
    backend = init_backend()
    
    # Start real-time updates
    backend.start_realtime_updates()
    
    # Page header
    st.markdown("# Dashboard")
    
    # Top metrics
    metrics = backend.dashboard.get_dashboard_metrics()
    
    col1, col2, col3, col4 = responsive_columns(4)
    
    with col1:
        material_metric("Total Sandwiches", metrics['total_sandwiches'], "+2.5%", "good")
    
    with col2:
        material_metric("Defect Rate", f"{metrics['defect_rate']}%", "-0.3%", "good")
    
    with col3:
        material_metric("Production Rate", f"{metrics['production_rate']}/hr", "+5%", "good")
    
    with col4:
        material_metric("Quality Score", f"{metrics['quality_score']}%", "+0.8%", "good")
    
    # Main content
    col1, col2 = responsive_columns(2)
    
    with col1:
        # Production trends
        with material_card("Production Trends", elevation=2):
            # Time range selector
            time_range = st.selectbox(
                "Time Range",
                ["Day", "Week", "Month", "Year"],
                index=0,
                key="production_time_range"
            )
            
            # Get production trends data
            trends = backend.dashboard.get_production_trends(time_range.lower())
            
            # Convert to DataFrame
            trends_df = pd.DataFrame(trends)
            
            # Plot chart
            st.line_chart(
                trends_df,
                x="timestamp",
                y=["production", "defects"],
                height=300
            )
        
        # System status
        with material_card("System Status", elevation=2):
            system_status = backend.dashboard.get_system_status()
            
            # Host system status
            st.markdown("### Host System")
            
            host_col1, host_col2 = responsive_columns(2)
            
            with host_col1:
                material_metric("CPU Usage", f"{system_status['host']['cpu_usage']}%")
                material_metric("Memory Usage", f"{system_status['host']['memory_usage']}%")
            
            with host_col2:
                material_metric("Disk Usage", f"{system_status['host']['disk_usage']}%")
                material_metric("Temperature", f"{system_status['host']['temperature']}°C")
            
            # Jetson status
            st.markdown("### ADLINK Jetson")
            
            jetson_col1, jetson_col2 = responsive_columns(2)
            
            with jetson_col1:
                material_metric("CPU Usage", f"{system_status['jetson']['cpu_usage']}%")
                material_metric("GPU Usage", f"{system_status['jetson']['gpu_usage']}%")
            
            with jetson_col2:
                material_metric("Memory Usage", f"{system_status['jetson']['memory_usage']}%")
                material_metric("Temperature", f"{system_status['jetson']['temperature']}°C")
    
    with col2:
        # Defect distribution
        with material_card("Defect Distribution", elevation=2):
            # Time range selector
            time_range = st.selectbox(
                "Time Range",
                ["Day", "Week", "Month", "Year"],
                index=0,
                key="defect_time_range"
            )
            
            # Get defect distribution data
            distribution = backend.dashboard.get_defect_distribution(time_range.lower())
            
            # Convert to DataFrame
            distribution_df = pd.DataFrame(distribution)
            
            # Plot chart
            st.bar_chart(
                distribution_df,
                x="defect_type",
                y="count",
                height=300
            )
        
        # Camera status
        with material_card("Camera Status", elevation=2):
            camera_status = backend.dashboard.get_camera_status()
            
            for camera in camera_status['cameras']:
                # Create status indicator
                status_color = {
                    'online': 'success',
                    'warning': 'warning',
                    'offline': 'error'
                }.get(camera['status'], 'info')
                
                st.markdown(
                    f"""
                    <div style="display: flex; align-items: center; margin-bottom: 0.5rem;">
                        <div style="width: 12px; height: 12px; border-radius: 50%; background-color: var(--color-{status_color}-main); margin-right: 0.5rem;"></div>
                        <div style="flex-grow: 1;">{camera['name']}</div>
                        <div>{camera['fps']} FPS</div>
                    </div>
                    """,
                    unsafe_allow_html=True
                )
    
    # Recent defects
    with material_card("Recent Defects", elevation=2):
        # Get recent defects
        recent_defects = backend.dashboard.get_recent_defects(limit=5)
        
        # Create table
        if recent_defects:
            # Convert to DataFrame
            defects_df = pd.DataFrame(recent_defects)
            
            # Display table
            material_data_table(defects_df)
        else:
            st.info("No recent defects found.")
    
    # Process any pending updates
    backend.process_updates()
```

## 6. Enhanced Camera Views <a name="enhanced-camera-views"></a>

The enhanced camera views provide comprehensive monitoring and control capabilities for all cameras in the system, with real-time visualization of defect detection and advanced camera settings.

### Camera View Features

- **Multiple Viewing Modes**: Live Feed, Defect Detection, Calibration, and Thermal View
- **Real-time Camera Controls**: Exposure, gain, brightness, contrast, and white balance
- **Camera Calibration Tools**: Visual markers and alignment guides
- **Performance Analytics**: FPS, temperature, and connection quality monitoring
- **Defect Detection Visualization**: Highlighting of detected defects with confidence scores
- **Image History**: Gallery of recent images with defect annotations
- **Event Logging**: Comprehensive event tracking for camera operations
- **Camera Actions**: Calibration, diagnostics, and video recording

### Implementation

The camera views are implemented using a combination of Streamlit components, Material UI components, and custom visualizations. They are fully responsive and adapt to different screen sizes.

```python
def render_camera_view():
    """Render the enhanced camera view."""
    # Apply design system to the page
    apply_design_system_to_page("Camera View")
    
    # Load Material Icons
    load_material_icons()
    
    # Initialize backend integration
    backend = init_backend()
    
    # Start real-time updates
    backend.start_realtime_updates()
    
    # Page header
    st.markdown("# Camera View")
    
    # Camera selector
    cameras = backend.camera.get_cameras()
    
    camera_options = [camera['name'] for camera in cameras]
    selected_camera = st.selectbox("Select Camera", camera_options)
    
    # Get selected camera ID
    selected_camera_id = next(
        (camera['id'] for camera in cameras if camera['name'] == selected_camera),
        None
    )
    
    if selected_camera_id is None:
        st.error("No camera selected.")
        return
    
    # View mode selector
    view_mode = st.radio(
        "View Mode",
        ["Live Feed", "Defect Detection", "Calibration", "Thermal View"],
        horizontal=True
    )
    
    # Main content
    col1, col2 = responsive_columns([7, 3])
    
    with col1:
        # Camera feed
        with material_card("Camera Feed", elevation=2):
            # Get camera frame
            try:
                frame = backend.camera.get_camera_frame(selected_camera_id)
                
                # Apply visualization based on view mode
                if view_mode == "Defect Detection":
                    # Add defect detection visualization
                    # This would be implemented in the backend
                    pass
                elif view_mode == "Calibration":
                    # Add calibration markers
                    # This would be implemented in the backend
                    pass
                elif view_mode == "Thermal View":
                    # Apply thermal visualization
                    # This would be implemented in the backend
                    pass
                
                # Display the frame
                st.image(frame, use_column_width=True)
            except Exception as e:
                st.error(f"Error loading camera feed: {str(e)}")
        
        # Camera performance
        with material_card("Camera Performance", elevation=2):
            # Get camera performance data
            performance = backend.camera.get_camera_performance(selected_camera_id)
            
            # Convert to DataFrame
            performance_df = pd.DataFrame(performance)
            
            # Plot chart
            st.line_chart(
                performance_df,
                x="timestamp",
                y=["fps", "temperature", "connection_quality"],
                height=200
            )
    
    with col2:
        # Camera status
        with material_card("Camera Status", elevation=2):
            # Get camera status
            status = backend.camera.get_camera_status(selected_camera_id)
            
            # Display status metrics
            material_metric("Status", status['status'].capitalize())
            material_metric("FPS", status['fps'])
            material_metric("Temperature", f"{status['temperature']}°C")
            material_metric("Connection Quality", f"{status['connection_quality'] * 100:.1f}%")
        
        # Camera settings
        with material_card("Camera Settings", elevation=2):
            # Get camera settings
            settings = backend.camera.get_camera_settings(selected_camera_id)
            
            # Create settings form
            with st.form("camera_settings_form"):
                # Exposure
                exposure = st.slider(
                    "Exposure",
                    min_value=0,
                    max_value=100,
                    value=settings['exposure']
                )
                
                # Gain
                gain = st.slider(
                    "Gain",
                    min_value=0,
                    max_value=100,
                    value=settings['gain']
                )
                
                # Brightness
                brightness = st.slider(
                    "Brightness",
                    min_value=0,
                    max_value=100,
                    value=settings['brightness']
                )
                
                # Contrast
                contrast = st.slider(
                    "Contrast",
                    min_value=0,
                    max_value=100,
                    value=settings['contrast']
                )
                
                # White balance
                white_balance = st.slider(
                    "White Balance",
                    min_value=0,
                    max_value=100,
                    value=settings['white_balance']
                )
                
                # Submit button
                submit = st.form_submit_button("Apply Settings")
                
                if submit:
                    # Update camera settings
                    updated_settings = {
                        'exposure': exposure,
                        'gain': gain,
                        'brightness': brightness,
                        'contrast': contrast,
                        'white_balance': white_balance
                    }
                    
                    try:
                        backend.camera.update_camera_settings(selected_camera_id, updated_settings)
                        st.success("Settings updated successfully.")
                    except Exception as e:
                        st.error(f"Error updating settings: {str(e)}")
        
        # Camera actions
        with material_card("Camera Actions", elevation=2):
            # Calibrate camera
            if st.button("Calibrate Camera"):
                try:
                    result = backend.camera.calibrate_camera(selected_camera_id)
                    st.success("Camera calibrated successfully.")
                except Exception as e:
                    st.error(f"Error calibrating camera: {str(e)}")
            
            # Reset settings
            if st.button("Reset Settings"):
                try:
                    result = backend.camera.reset_camera_settings(selected_camera_id)
                    st.success("Settings reset successfully.")
                except Exception as e:
                    st.error(f"Error resetting settings: {str(e)}")
            
            # Capture image
            if st.button("Capture Image"):
                try:
                    result = backend.camera.capture_image(selected_camera_id)
                    st.success("Image captured successfully.")
                    st.markdown(f"[View Image]({result['image_url']})")
                except Exception as e:
                    st.error(f"Error capturing image: {str(e)}")
    
    # Recent defects
    with material_card("Recent Defects", elevation=2):
        # Get camera defects
        defects = backend.camera.get_camera_defects(selected_camera_id)
        
        # Create table
        if defects:
            # Convert to DataFrame
            defects_df = pd.DataFrame(defects)
            
            # Display table
            material_data_table(defects_df)
        else:
            st.info("No recent defects found for this camera.")
    
    # Process any pending updates
    backend.process_updates()
```

## 7. User Experience Improvements <a name="user-experience-improvements"></a>

The user experience improvements make the application more intuitive and efficient to use, with guided workflows, contextual help, and personalized settings.

### User Experience Features

- **Guided Onboarding**: Step-by-step introduction for new users
- **User Preferences**: Customizable settings for theme, layout, and notifications
- **Keyboard Shortcuts**: Efficient navigation with keyboard commands
- **Notification System**: Real-time alerts with priority levels
- **Search Functionality**: System-wide search with categorized results
- **Context-Sensitive Help**: Relevant guidance based on the current page
- **Interactive Tutorials**: Guided walkthroughs of key features
- **User Menu**: Centralized access to preferences, help, and account settings

### Implementation

The user experience improvements are implemented using a combination of Streamlit components, Material UI components, and custom JavaScript. They are fully integrated with the rest of the application.

```python
def render_user_experience():
    """Render the user experience improvements."""
    # Apply design system to the page
    apply_design_system_to_page("User Experience")
    
    # Load Material Icons
    load_material_icons()
    
    # Initialize backend integration
    backend = init_backend()
    
    # Page header
    st.markdown("# User Experience")
    
    # Guided onboarding
    if 'onboarding_completed' not in st.session_state:
        st.session_state.onboarding_completed = False
        st.session_state.onboarding_step = 0
    
    if not st.session_state.onboarding_completed:
        with material_card("Welcome to OPSC Sandwich Quality Inspection System", elevation=3):
            onboarding_steps = [
                {
                    'title': "Welcome",
                    'content': "Welcome to the OPSC Sandwich Quality Inspection System. This guided tour will help you get started with the system.",
                    'image': None
                },
                {
                    'title': "Dashboard",
                    'content': "The dashboard provides a comprehensive overview of the system status, production metrics, and defect detection results.",
                    'image': "dashboard.png"
                },
                {
                    'title': "Camera Views",
                    'content': "The camera views allow you to monitor and control all cameras in the system, with real-time visualization of defect detection.",
                    'image': "camera_view.png"
                },
                {
                    'title': "Analytics",
                    'content': "The analytics page provides detailed insights into production trends, defect patterns, and quality metrics.",
                    'image': "analytics.png"
                },
                {
                    'title': "Settings",
                    'content': "The settings page allows you to customize the system to your specific needs, including camera settings, detection parameters, and user preferences.",
                    'image': "settings.png"
                },
                {
                    'title': "Ready to Start",
                    'content': "You're now ready to start using the OPSC Sandwich Quality Inspection System. You can access this tour again from the help menu at any time.",
                    'image': None
                }
            ]
            
            current_step = onboarding_steps[st.session_state.onboarding_step]
            
            st.markdown(f"### {current_step['title']}")
            st.markdown(current_step['content'])
            
            if current_step['image']:
                st.image(current_step['image'], use_column_width=True)
            
            col1, col2, col3 = responsive_columns([1, 1, 1])
            
            with col1:
                if st.session_state.onboarding_step > 0:
                    if st.button("Previous"):
                        st.session_state.onboarding_step -= 1
                        st.rerun()
            
            with col2:
                progress = (st.session_state.onboarding_step + 1) / len(onboarding_steps)
                st.progress(progress)
            
            with col3:
                if st.session_state.onboarding_step < len(onboarding_steps) - 1:
                    if st.button("Next"):
                        st.session_state.onboarding_step += 1
                        st.rerun()
                else:
                    if st.button("Complete"):
                        st.session_state.onboarding_completed = True
                        st.rerun()
    
    # User preferences
    with material_card("User Preferences", elevation=2):
        # Get user settings
        user_settings = backend.settings.get_user_settings()
        
        # Create settings form
        with st.form("user_preferences_form"):
            # Theme
            theme = st.selectbox(
                "Theme",
                ["Light", "Dark", "System"],
                index=["light", "dark", "system"].index(user_settings['theme'])
            )
            
            # Notification settings
            st.markdown("### Notifications")
            
            # Defect alerts
            defect_alerts = st.checkbox(
                "Defect Alerts",
                value=user_settings['notifications']['defect_alerts']
            )
            
            # System alerts
            system_alerts = st.checkbox(
                "System Alerts",
                value=user_settings['notifications']['system_alerts']
            )
            
            # Production alerts
            production_alerts = st.checkbox(
                "Production Alerts",
                value=user_settings['notifications']['production_alerts']
            )
            
            # Layout settings
            st.markdown("### Layout")
            
            # Sidebar position
            sidebar_position = st.selectbox(
                "Sidebar Position",
                ["Left", "Right"],
                index=["left", "right"].index(user_settings['layout']['sidebar_position'])
            )
            
            # Compact mode
            compact_mode = st.checkbox(
                "Compact Mode",
                value=user_settings['layout']['compact_mode']
            )
            
            # Submit button
            submit = st.form_submit_button("Save Preferences")
            
            if submit:
                # Update user settings
                updated_settings = {
                    'theme': theme.lower(),
                    'notifications': {
                        'defect_alerts': defect_alerts,
                        'system_alerts': system_alerts,
                        'production_alerts': production_alerts
                    },
                    'layout': {
                        'sidebar_position': sidebar_position.lower(),
                        'compact_mode': compact_mode
                    }
                }
                
                try:
                    backend.settings.update_user_settings(updated_settings)
                    st.success("Preferences saved successfully.")
                except Exception as e:
                    st.error(f"Error saving preferences: {str(e)}")
    
    # Keyboard shortcuts
    with material_card("Keyboard Shortcuts", elevation=2):
        st.markdown("### Navigation")
        
        shortcuts_data = {
            "Shortcut": ["D", "C", "A", "S", "H", "F", "Esc"],
            "Action": [
                "Go to Dashboard",
                "Go to Camera View",
                "Go to Analytics",
                "Go to Settings",
                "Open Help",
                "Toggle Fullscreen",
                "Close Dialog"
            ]
        }
        
        shortcuts_df = pd.DataFrame(shortcuts_data)
        material_data_table(shortcuts_df)
        
        # Add keyboard shortcut JavaScript
        st.markdown(
            """
            <script>
            document.addEventListener('keydown', function(e) {
                // Check if no input is focused
                if (document.activeElement.tagName !== 'INPUT' && document.activeElement.tagName !== 'TEXTAREA') {
                    switch (e.key.toUpperCase()) {
                        case 'D':
                            window.location.href = '/';
                            break;
                        case 'C':
                            window.location.href = '/camera_view';
                            break;
                        case 'A':
                            window.location.href = '/analytics';
                            break;
                        case 'S':
                            window.location.href = '/settings';
                            break;
                        case 'H':
                            // Open help dialog
                            break;
                        case 'F':
                            // Toggle fullscreen
                            break;
                    }
                }
            });
            </script>
            """,
            unsafe_allow_html=True
        )
    
    # Notification system
    with material_card("Notification System", elevation=2):
        # Create sample notifications
        notifications = [
            {
                'id': 1,
                'type': 'defect',
                'message': 'High defect rate detected on Top Camera',
                'timestamp': '2025-04-21T10:15:30Z',
                'priority': 'high',
                'read': False
            },
            {
                'id': 2,
                'type': 'system',
                'message': 'Jetson temperature above threshold',
                'timestamp': '2025-04-21T09:45:12Z',
                'priority': 'medium',
                'read': False
            },
            {
                'id': 3,
                'type': 'production',
                'message': 'Production target reached',
                'timestamp': '2025-04-21T08:30:00Z',
                'priority': 'low',
                'read': True
            }
        ]
        
        # Display notifications
        st.markdown("### Recent Notifications")
        
        for notification in notifications:
            # Determine notification color based on priority
            color = {
                'high': 'error',
                'medium': 'warning',
                'low': 'info'
            }.get(notification['priority'], 'info')
            
            # Create notification card
            notification_html = f"""
            <div style="
                display: flex;
                align-items: center;
                padding: 0.75rem;
                margin-bottom: 0.5rem;
                background-color: var(--color-background-paper);
                border-left: 4px solid var(--color-{color}-main);
                border-radius: var(--border-radius-md);
                box-shadow: var(--shadow-1);
            ">
                <div style="margin-right: 0.75rem;">
                    <span class="material-icons" style="color: var(--color-{color}-main);">
                        {{'defect': 'warning', 'system': 'computer', 'production': 'insights'}.get(notification['type'], 'notifications')}
                    </span>
                </div>
                <div style="flex-grow: 1;">
                    <div style="font-weight: 500;">{notification['message']}</div>
                    <div style="font-size: 0.75rem; color: var(--color-text-secondary);">
                        {notification['timestamp']}
                    </div>
                </div>
                <div>
                    <span class="material-icons" style="color: var(--color-text-secondary);">
                        {{'true': 'check_circle', 'false': 'circle'}.get(str(notification['read']).lower(), 'circle')}
                    </span>
                </div>
            </div>
            """
            
            st.markdown(notification_html, unsafe_allow_html=True)
    
    # Context-sensitive help
    with material_card("Context-Sensitive Help", elevation=2):
        st.markdown("### Help Topics")
        
        # Create help topics based on current page
        help_topics = [
            {
                'title': "Getting Started",
                'content': "Learn the basics of the OPSC Sandwich Quality Inspection System."
            },
            {
                'title': "User Preferences",
                'content': "Customize the system to your specific needs."
            },
            {
                'title': "Keyboard Shortcuts",
                'content': "Navigate the system efficiently with keyboard shortcuts."
            },
            {
                'title': "Notification System",
                'content': "Stay informed about important events in the system."
            }
        ]
        
        # Display help topics
        for i, topic in enumerate(help_topics):
            with st.expander(topic['title']):
                st.markdown(topic['content'])
                
                # Add a "Learn More" button
                if st.button("Learn More", key=f"learn_more_{i}"):
                    st.session_state.selected_help_topic = topic['title']
                    st.rerun()
        
        # Display selected help topic
        if 'selected_help_topic' in st.session_state:
            topic = next(
                (t for t in help_topics if t['title'] == st.session_state.selected_help_topic),
                None
            )
            
            if topic:
                with material_card(f"{topic['title']} - Help", elevation=3):
                    st.markdown(topic['content'])
                    
                    # Add detailed help content
                    st.markdown("""
                    ## Detailed Help Content
                    
                    This is a placeholder for detailed help content. In a real implementation, this would contain comprehensive documentation for the selected help topic.
                    
                    ### Key Points
                    
                    - Point 1
                    - Point 2
                    - Point 3
                    
                    ### Related Topics
                    
                    - Related Topic 1
                    - Related Topic 2
                    - Related Topic 3
                    """)
                    
                    # Add a "Close" button
                    if st.button("Close"):
                        del st.session_state.selected_help_topic
                        st.rerun()
```

## 8. Dark Mode Support <a name="dark-mode-support"></a>

The dark mode support provides a complete dark theme for the application, improving visual comfort and reducing eye strain in low-light environments.

### Dark Mode Features

- **Complete Dark Theme**: Dark background with light text and appropriate contrast
- **Theme Switching**: Ability to switch between light, dark, and system-based themes
- **System Detection**: Automatic detection of the user's system theme preference
- **Theme Persistence**: User theme preferences are saved and persist between sessions
- **Component Adaptation**: All UI components are specially styled for dark mode

### Implementation

The dark mode support is implemented using CSS variables and JavaScript for theme detection and switching. It is fully integrated with the rest of the application.

```python
def apply_theme():
    """
    Apply the current theme to the page.
    
    Returns:
    - Current theme ('light', 'dark', or 'system')
    """
    # Get theme from session state or default to light
    theme = st.session_state.get('theme', 'light')
    
    # If theme is 'system', detect system preference
    if theme == 'system':
        # Inject JavaScript to detect system preference
        st.markdown(
            """
            <script>
            // Detect system color scheme preference
            const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
            
            // Store the preference in localStorage
            localStorage.setItem('system_theme', prefersDark ? 'dark' : 'light');
            
            // Update the theme input
            const themeInput = window.parent.document.querySelector('input[id="system_theme"]');
            if (themeInput) {
                themeInput.value = prefersDark ? 'dark' : 'light';
                themeInput.dispatchEvent(new Event('input'));
            }
            </script>
            """,
            unsafe_allow_html=True
        )
        
        # Get system theme from input
        system_theme = st.text_input("System Theme", value="light", key="system_theme", label_visibility="collapsed")
        theme = system_theme
    
    # Apply light theme CSS variables
    if theme == 'light':
        st.markdown(
            """
            <style>
            :root {
                /* Background colors */
                --color-background-default: #f5f5f5;
                --color-background-paper: #ffffff;
                --color-background-secondary: #f0f0f0;
                --color-background-tertiary: #e0e0e0;
                
                /* Text colors */
                --color-text-primary: rgba(0, 0, 0, 0.87);
                --color-text-secondary: rgba(0, 0, 0, 0.6);
                --color-text-disabled: rgba(0, 0, 0, 0.38);
                
                /* Border colors */
                --color-border-light: rgba(0, 0, 0, 0.12);
                --color-border-medium: rgba(0, 0, 0, 0.23);
                --color-border-dark: rgba(0, 0, 0, 0.38);
                
                /* Other colors */
                --color-divider: rgba(0, 0, 0, 0.12);
                --color-overlay: rgba(0, 0, 0, 0.5);
            }
            </style>
            """,
            unsafe_allow_html=True
        )
    # Apply dark theme CSS variables
    else:
        st.markdown(
            """
            <style>
            :root {
                /* Background colors */
                --color-background-default: #121212;
                --color-background-paper: #1e1e1e;
                --color-background-secondary: #2c2c2c;
                --color-background-tertiary: #383838;
                
                /* Text colors */
                --color-text-primary: rgba(255, 255, 255, 0.87);
                --color-text-secondary: rgba(255, 255, 255, 0.6);
                --color-text-disabled: rgba(255, 255, 255, 0.38);
                
                /* Border colors */
                --color-border-light: rgba(255, 255, 255, 0.12);
                --color-border-medium: rgba(255, 255, 255, 0.23);
                --color-border-dark: rgba(255, 255, 255, 0.38);
                
                /* Other colors */
                --color-divider: rgba(255, 255, 255, 0.12);
                --color-overlay: rgba(0, 0, 0, 0.7);
            }
            
            /* Override Streamlit styles for dark mode */
            .stApp {
                background-color: var(--color-background-default);
            }
            
            .stTextInput > div > div > input,
            .stSelectbox > div > div > div,
            .stMultiselect > div > div > div {
                background-color: var(--color-background-paper);
                color: var(--color-text-primary);
                border-color: var(--color-border-medium);
            }
            
            .stTextInput > div > div > input:focus,
            .stSelectbox > div > div > div:focus,
            .stMultiselect > div > div > div:focus {
                border-color: var(--color-primary-main);
            }
            
            .stSlider > div > div > div > div {
                background-color: var(--color-primary-main);
            }
            
            .stSlider > div > div > div > div > div {
                color: var(--color-text-primary);
            }
            
            .stDataFrame {
                background-color: var(--color-background-paper);
            }
            
            .stDataFrame td,
            .stDataFrame th {
                color: var(--color-text-primary);
                border-color: var(--color-border-light);
            }
            
            .stDataFrame th {
                background-color: var(--color-background-secondary);
            }
            
            /* Add more Streamlit component overrides as needed */
            </style>
            """,
            unsafe_allow_html=True
        )
    
    return theme

def get_effective_theme():
    """
    Get the effective theme (light or dark).
    
    Returns:
    - Effective theme ('light' or 'dark')
    """
    # Get theme from session state or default to light
    theme = st.session_state.get('theme', 'light')
    
    # If theme is 'system', detect system preference
    if theme == 'system':
        # Inject JavaScript to detect system preference
        st.markdown(
            """
            <script>
            // Detect system color scheme preference
            const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
            
            // Store the preference in localStorage
            localStorage.setItem('system_theme', prefersDark ? 'dark' : 'light');
            
            // Update the theme input
            const themeInput = window.parent.document.querySelector('input[id="system_theme"]');
            if (themeInput) {
                themeInput.value = prefersDark ? 'dark' : 'light';
                themeInput.dispatchEvent(new Event('input'));
            }
            </script>
            """,
            unsafe_allow_html=True
        )
        
        # Get system theme from input
        system_theme = st.text_input("System Theme", value="light", key="system_theme", label_visibility="collapsed")
        return system_theme
    
    return theme

def toggle_theme():
    """Toggle between light and dark themes."""
    # Get current theme
    current_theme = st.session_state.get('theme', 'light')
    
    # Toggle theme
    if current_theme == 'light':
        st.session_state.theme = 'dark'
    else:
        st.session_state.theme = 'light'
```

## 9. Mobile Responsive Design <a name="mobile-responsive-design"></a>

The mobile responsive design ensures that the application works seamlessly across all device sizes, from desktop to mobile, with touch-friendly controls and optimized layouts.

### Mobile Responsive Features

- **Device Detection**: Automatic detection of device type, screen size, and orientation
- **Responsive Layouts**: Layouts that adapt to different screen sizes
- **Touch-Friendly Controls**: Larger touch targets and appropriate spacing for touch devices
- **Adaptive Content**: Content that adjusts based on available screen space
- **Responsive Navigation**: Navigation that changes format based on device type
- **Orientation Handling**: Support for both portrait and landscape orientations

### Implementation

The mobile responsive design is implemented using CSS media queries, JavaScript for device detection, and responsive layout components. It is fully integrated with the rest of the application.

```python
def detect_device_type():
    """
    Detect the user's device type using JavaScript.
    Returns 'mobile', 'tablet', or 'desktop'.
    """
    # Inject JavaScript to detect device type
    detect_device_js = """
    <script>
    // Function to detect device type
    function detectDeviceType() {
        const width = window.innerWidth;
        if (width < 768) {
            return 'mobile';
        } else if (width < 1024) {
            return 'tablet';
        } else {
            return 'desktop';
        }
    }
    
    // Store the detected device type in localStorage
    localStorage.setItem('device_type', detectDeviceType());
    
    // Listen for window resize events
    window.addEventListener('resize', function() {
        localStorage.setItem('device_type', detectDeviceType());
        // Only reload if the device type has changed
        const currentType = localStorage.getItem('device_type');
        const previousType = localStorage.getItem('previous_device_type');
        
        if (currentType !== previousType) {
            localStorage.setItem('previous_device_type', currentType);
            // Reload after a short delay to avoid multiple reloads during resizing
            clearTimeout(window.resizeTimer);
            window.resizeTimer = setTimeout(function() {
                window.location.reload();
            }, 500);
        }
    });
    </script>
    """
    
    # Inject the JavaScript
    st.markdown(detect_device_js, unsafe_allow_html=True)
    
    # Read the detected device type from localStorage using JavaScript
    read_device_js = """
    <script>
    // Function to send the detected device type to Streamlit
    function sendDeviceTypeToStreamlit() {
        const deviceType = localStorage.getItem('device_type') || 'desktop';
        localStorage.setItem('previous_device_type', deviceType);
        const deviceTypeInput = window.parent.document.querySelector('input[id="device_type"]');
        if (deviceTypeInput) {
            deviceTypeInput.value = deviceType;
            deviceTypeInput.dispatchEvent(new Event('input'));
        }
    }
    
    // Call the function when the page loads
    window.addEventListener('load', sendDeviceTypeToStreamlit);
    </script>
    """
    
    # Create a hidden input to receive the device type
    device_type = st.text_input("Device Type", value="desktop", key="device_type", label_visibility="collapsed")
    
    # Inject the JavaScript to read the device type
    st.markdown(read_device_js, unsafe_allow_html=True)
    
    return device_type

def optimize_for_mobile():
    """
    Apply mobile-specific optimizations using CSS and JavaScript.
    """
    # Mobile-specific CSS
    mobile_css = """
    <style>
    @media (max-width: 767px) {
        /* Increase touch target sizes */
        button, .stButton > button, .stSelectbox > div > div > div {
            min-height: 44px;
            min-width: 44px;
        }
        
        /* Increase font sizes for readability */
        body {
            font-size: 16px;
        }
        
        h1 {
            font-size: 24px;
        }
        
        h2 {
            font-size: 20px;
        }
        
        h3 {
            font-size: 18px;
        }
        
        /* Reduce padding to maximize content area */
        .stApp {
            padding: 1rem 0.5rem;
        }
        
        /* Make sidebar full-width when open */
        section[data-testid="stSidebar"] {
            width: 100% !important;
            min-width: 100% !important;
            max-width: 100% !important;
        }
        
        /* Adjust metrics for mobile */
        [data-testid="metric-container"] {
            padding: 0.5rem;
        }
        
        /* Adjust charts for mobile */
        [data-testid="stChart"] {
            height: auto !important;
        }
        
        /* Adjust dataframes for mobile */
        [data-testid="stDataFrame"] {
            overflow-x: auto;
        }
        
        /* Custom component adjustments */
        .material-card {
            padding: 0.75rem;
        }
        
        .material-card-header {
            padding-bottom: 0.5rem;
            margin-bottom: 0.5rem;
        }
        
        .material-button {
            padding: 0.5rem 0.75rem;
        }
        
        .material-tabs {
            overflow-x: auto;
            white-space: nowrap;
        }
        
        .material-tab {
            padding: 0.5rem 0.75rem;
        }
        
        .material-data-table {
            overflow-x: auto;
        }
        
        /* Hide certain elements on mobile */
        .hide-on-mobile {
            display: none !important;
        }
        
        /* Show mobile-only elements */
        .show-on-mobile {
            display: block !important;
        }
    }
    </style>
    """
    
    # Inject the CSS
    st.markdown(mobile_css, unsafe_allow_html=True)
    
    # Mobile-specific JavaScript
    mobile_js = """
    <script>
    // Function to apply mobile optimizations
    function applyMobileOptimizations() {
        // Detect if mobile
        const isMobile = window.innerWidth < 768;
        
        if (isMobile) {
            // Add mobile class to body
            document.body.classList.add('mobile');
            
            // Disable hover effects for better touch experience
            const style = document.createElement('style');
            style.innerHTML = `
                @media (max-width: 767px) {
                    * {
                        -webkit-tap-highlight-color: rgba(0,0,0,0);
                    }
                    
                    *:hover {
                        transition: none !important;
                    }
                }
            `;
            document.head.appendChild(style);
            
            // Add viewport meta tag if not present
            if (!document.querySelector('meta[name="viewport"]')) {
                const meta = document.createElement('meta');
                meta.name = 'viewport';
                meta.content = 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no';
                document.head.appendChild(meta);
            }
            
            // Add touch event handlers for better responsiveness
            document.addEventListener('touchstart', function() {}, {passive: true});
        }
    }
    
    // Call the function when the page loads
    window.addEventListener('load', applyMobileOptimizations);
    </script>
    """
    
    # Inject the JavaScript
    st.markdown(mobile_js, unsafe_allow_html=True)

def apply_responsive_design():
    """
    Apply responsive design to the application.
    """
    # Detect device information
    device_type = detect_device_type()
    touch_capability = detect_touch_capability()
    screen_dimensions = detect_screen_dimensions()
    orientation = detect_orientation()
    browser = detect_browser()
    
    # Apply device-specific optimizations
    if device_type == 'mobile':
        optimize_for_mobile()
    elif device_type == 'tablet':
        optimize_for_tablet()
    else:
        optimize_for_desktop()
    
    # Apply touch-friendly controls if device has touch capability
    if touch_capability:
        apply_touch_friendly_controls()
    
    # Handle orientation changes
    handle_orientation_change()
    
    # Apply theme
    effective_theme = apply_theme()
    
    # Return device information for use in the application
    return {
        'device_type': device_type,
        'touch_capability': touch_capability,
        'screen_dimensions': screen_dimensions,
        'orientation': orientation,
        'browser': browser,
        'theme': effective_theme
    }
```

## 10. Backend Integration <a name="backend-integration"></a>

The backend integration provides seamless communication between the UI components and the backend systems, with support for API requests, data caching, real-time updates, and error handling.

### Backend Integration Features

- **API Client**: Client for communicating with the backend API
- **Data Fetching and Caching**: Caching of API responses to reduce requests
- **Real-time Updates**: Subscription-based system for real-time data updates
- **Authentication**: User authentication and permission management
- **Form Submission**: Form submission with validation and error handling
- **Error Handling**: Consistent error handling and user-friendly error display
- **Component-specific Backends**: Specialized backends for different UI components

### Implementation

The backend integration is implemented using Python classes for API communication, data caching, and real-time updates. It is fully integrated with the rest of the application.

```python
class APIClient:
    """Client for communicating with the backend API."""
    
    def __init__(self, base_url=None):
        """
        Initialize the API client.
        
        Parameters:
        - base_url: Base URL for the API. If None, will use the URL from session state or environment.
        """
        self.base_url = base_url or self._get_base_url()
        self.session = requests.Session()
        self.auth_token = self._get_auth_token()
        
        if self.auth_token:
            self.session.headers.update({
                'Authorization': f'Bearer {self.auth_token}'
            })
        
        self.session.headers.update({
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        })
    
    def _get_base_url(self):
        """Get the base URL from session state or environment."""
        if 'api_base_url' in st.session_state:
            return st.session_state.api_base_url
        
        # Default to localhost if not specified
        return os.environ.get('API_BASE_URL', 'http://localhost:8000/api')
    
    def _get_auth_token(self):
        """Get the authentication token from session state."""
        if 'auth_token' in st.session_state:
            return st.session_state.auth_token
        
        return None
    
    def set_auth_token(self, token):
        """
        Set the authentication token.
        
        Parameters:
        - token: JWT token for authentication
        """
        self.auth_token = token
        st.session_state.auth_token = token
        
        self.session.headers.update({
            'Authorization': f'Bearer {token}'
        })
    
    def clear_auth_token(self):
        """Clear the authentication token."""
        self.auth_token = None
        
        if 'auth_token' in st.session_state:
            del st.session_state.auth_token
        
        if 'Authorization' in self.session.headers:
            del self.session.headers['Authorization']
    
    def get(self, endpoint, params=None, timeout=10):
        """
        Make a GET request to the API.
        
        Parameters:
        - endpoint: API endpoint (without base URL)
        - params: Query parameters
        - timeout: Request timeout in seconds
        
        Returns:
        - Response data as dictionary
        
        Raises:
        - APIError: If the request fails
        """
        url = f"{self.base_url}/{endpoint.lstrip('/')}"
        
        try:
            response = self.session.get(url, params=params, timeout=timeout)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"API GET request failed: {str(e)}")
            raise APIError(f"API request failed: {str(e)}", response=getattr(e, 'response', None))
    
    def post(self, endpoint, data=None, json=None, timeout=10):
        """
        Make a POST request to the API.
        
        Parameters:
        - endpoint: API endpoint (without base URL)
        - data: Form data
        - json: JSON data
        - timeout: Request timeout in seconds
        
        Returns:
        - Response data as dictionary
        
        Raises:
        - APIError: If the request fails
        """
        url = f"{self.base_url}/{endpoint.lstrip('/')}"
        
        try:
            response = self.session.post(url, data=data, json=json, timeout=timeout)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"API POST request failed: {str(e)}")
            raise APIError(f"API request failed: {str(e)}", response=getattr(e, 'response', None))
```

## 11. Testing <a name="testing"></a>

The UI enhancements are thoroughly tested to ensure they work correctly and integrate properly with the backend systems.

### Testing Approach

- **Unit Tests**: Tests for individual components and functions
- **Integration Tests**: Tests for component interactions and backend integration
- **Responsive Tests**: Tests for responsive design across different screen sizes
- **Cross-Browser Tests**: Tests for compatibility with different browsers
- **Accessibility Tests**: Tests for accessibility compliance

### Test Implementation

The tests are implemented using Python's unittest framework with mocking to isolate components and test them independently.

```python
class TestMaterialUIComponents(unittest.TestCase):
    """Test cases for Material UI components."""
    
    def setUp(self):
        """Set up test environment."""
        # Mock Streamlit
        self.st_mock = MagicMock()
        self.markdown_mock = MagicMock()
        self.button_mock = MagicMock()
        self.metric_mock = MagicMock()
        self.columns_mock = MagicMock()
        
        # Patch Streamlit functions
        self.st_patch = patch('ui.components.material_ui.st', self.st_mock)
        self.markdown_patch = patch('ui.components.material_ui.st.markdown', self.markdown_mock)
        self.button_patch = patch('ui.components.material_ui.st.button', self.button_mock)
        self.metric_patch = patch('ui.components.material_ui.st.metric', self.metric_mock)
        self.columns_patch = patch('ui.components.material_ui.st.columns', self.columns_mock)
        
        # Start patches
        self.st_patch.start()
        self.markdown_patch.start()
        self.button_patch.start()
        self.metric_patch.start()
        self.columns_patch.start()
    
    def tearDown(self):
        """Clean up after tests."""
        # Stop patches
        self.st_patch.stop()
        self.markdown_patch.stop()
        self.button_patch.stop()
        self.metric_patch.stop()
        self.columns_patch.stop()
    
    def test_load_material_icons(self):
        """Test loading Material Icons."""
        load_material_icons()
        self.markdown_mock.assert_called_once()
        call_args = self.markdown_mock.call_args[0][0]
        self.assertIn('<link href="https://fonts.googleapis.com/icon?family=Material+Icons"', call_args)
    
    def test_material_button(self):
        """Test Material Button component."""
        # Set up button mock to return True (clicked)
        self.button_mock.return_value = True
        
        # Test primary button
        result = material_button("Test Button", variant="primary")
        self.button_mock.assert_called_once()
        self.assertTrue(result)
```

## 12. Future Enhancements <a name="future-enhancements"></a>

The UI enhancements implemented in this version provide a solid foundation for future improvements. Here are some potential areas for future enhancement:

### Potential Future Enhancements

- **Advanced Visualizations**: More sophisticated data visualizations using libraries like Plotly and D3.js
- **AI-Powered Insights**: Integration with AI models for predictive analytics and anomaly detection
- **Augmented Reality**: AR overlays for camera views to highlight defects and provide guidance
- **Voice Commands**: Voice control for hands-free operation in production environments
- **Offline Mode**: Support for offline operation with data synchronization when online
- **Multi-Language Support**: Internationalization for global deployment
- **Advanced User Management**: Role-based access control and user activity tracking
- **Integration with IoT Devices**: Support for additional sensors and devices
- **Mobile Companion App**: Native mobile app for on-the-go monitoring and alerts
- **Advanced Reporting**: Customizable reports with export to various formats

### Implementation Roadmap

1. **Q3 2025**: Advanced Visualizations and AI-Powered Insights
2. **Q4 2025**: Offline Mode and Multi-Language Support
3. **Q1 2026**: Advanced User Management and Integration with IoT Devices
4. **Q2 2026**: Mobile Companion App and Advanced Reporting
5. **Q3 2026**: Augmented Reality and Voice Commands

## Conclusion

The UI enhancements implemented in the OPSC Sandwich Quality Inspection System provide a modern, responsive, and user-friendly interface that significantly improves the user experience and operational efficiency. The comprehensive design system, responsive layout, and backend integration ensure a consistent and seamless experience across all devices and use cases.

These enhancements lay the groundwork for future improvements and ensure that the system remains adaptable to changing requirements and technologies.
