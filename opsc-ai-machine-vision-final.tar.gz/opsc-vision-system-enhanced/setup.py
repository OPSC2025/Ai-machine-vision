#!/usr/bin/env python3
"""
Setup script for the OPSC Sandwich Quality Inspection System.

This script installs the OPSC Sandwich Quality Inspection System as a Python package.

Version: 1.0.0
Last Updated: 2025-04-21
"""

import os
import sys
from setuptools import setup, find_packages

# Read requirements from requirements.txt
with open('requirements.txt') as f:
    requirements = f.read().splitlines()

# Read long description from README.md
with open('README.md', 'r', encoding='utf-8') as f:
    long_description = f.read()

setup(
    name="opsc-vision-system",
    version="1.0.0",
    description="OPSC Sandwich Quality Inspection System",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="OPSC Vision Team",
    author_email="vision@opsc.com",
    url="https://github.com/opsc/vision-system",
    packages=find_packages(),
    package_data={
        "": ["*.yaml", "*.json", "*.trt", "*.onnx", "*.pt"],
    },
    include_package_data=True,
    install_requires=requirements,
    python_requires=">=3.8",
    entry_points={
        "console_scripts": [
            "opsc-vision=src.main:main",
        ],
    },
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Manufacturing",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Scientific/Engineering :: Image Processing",
        "Topic :: Scientific/Engineering :: Image Recognition",
    ],
    keywords="computer vision, machine learning, quality control, sandwich inspection",
    project_urls={
        "Documentation": "https://github.com/opsc/vision-system/docs",
        "Source": "https://github.com/opsc/vision-system",
        "Tracker": "https://github.com/opsc/vision-system/issues",
    },
)
