"""
Database optimization module for OPSC Sandwich Quality Inspection System.
Provides functionality for optimizing database operations, including query optimization,
indexing, connection pooling, and caching.

Version: 1.0.0
Last Updated: 2025-04-21
"""

import os
import sys
import time
import json
import logging
import datetime
import threading
import queue
import functools
import hashlib
from typing import Dict, List, Optional, Tuple, Union, Any, Callable, TypeVar, Generic
from dataclasses import dataclass, field
from enum import Enum, auto
import sqlite3
import sqlalchemy
from sqlalchemy import create_engine, text, Column, Integer, String, Float, DateTime, Boolean, ForeignKey, Index
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, scoped_session, relationship, Query
from sqlalchemy.pool import QueuePool, NullPool, StaticPool
from sqlalchemy.sql import func
from sqlalchemy.exc import SQLAlchemyError
import pandas as pd
import numpy as np

# Setup logging
logger = logging.getLogger(__name__)

# Type variables for generic types
T = TypeVar('T')
K = TypeVar('K')
V = TypeVar('V')

class QueryType(Enum):
    """Query type enum."""
    SELECT = auto()
    INSERT = auto()
    UPDATE = auto()
    DELETE = auto()
    JOIN = auto()
    AGGREGATE = auto()
    CUSTOM = auto()


@dataclass
class QueryMetrics:
    """Query metrics data class."""
    query_id: str
    query_type: QueryType
    query_text: str
    execution_time: float
    rows_affected: int
    timestamp: datetime.datetime = field(default_factory=datetime.datetime.now)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "query_id": self.query_id,
            "query_type": self.query_type.name,
            "query_text": self.query_text,
            "execution_time": self.execution_time,
            "rows_affected": self.rows_affected,
            "timestamp": self.timestamp.isoformat()
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'QueryMetrics':
        """Create from dictionary."""
        query_type_str = data.get("query_type", "CUSTOM")
        try:
            query_type = QueryType[query_type_str]
        except KeyError:
            query_type = QueryType.CUSTOM
            logger.warning(f"Invalid query type: {query_type_str}, defaulting to CUSTOM")
        
        timestamp_str = data.get("timestamp")
        if timestamp_str:
            try:
                timestamp = datetime.datetime.fromisoformat(timestamp_str)
            except ValueError:
                timestamp = datetime.datetime.now()
                logger.warning(f"Invalid timestamp format: {timestamp_str}, using current time")
        else:
            timestamp = datetime.datetime.now()
        
        return cls(
            query_id=data.get("query_id", ""),
            query_type=query_type,
            query_text=data.get("query_text", ""),
            execution_time=data.get("execution_time", 0.0),
            rows_affected=data.get("rows_affected", 0),
            timestamp=timestamp
        )


@dataclass
class DatabaseMetrics:
    """Database metrics data class."""
    connection_count: int
    active_connection_count: int
    query_count: int
    total_query_time: float
    avg_query_time: float
    slow_query_count: int
    error_count: int
    timestamp: datetime.datetime = field(default_factory=datetime.datetime.now)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "connection_count": self.connection_count,
            "active_connection_count": self.active_connection_count,
            "query_count": self.query_count,
            "total_query_time": self.total_query_time,
            "avg_query_time": self.avg_query_time,
            "slow_query_count": self.slow_query_count,
            "error_count": self.error_count,
            "timestamp": self.timestamp.isoformat()
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'DatabaseMetrics':
        """Create from dictionary."""
        timestamp_str = data.get("timestamp")
        if timestamp_str:
            try:
                timestamp = datetime.datetime.fromisoformat(timestamp_str)
            except ValueError:
                timestamp = datetime.datetime.now()
                logger.warning(f"Invalid timestamp format: {timestamp_str}, using current time")
        else:
            timestamp = datetime.datetime.now()
        
        return cls(
            connection_count=data.get("connection_count", 0),
            active_connection_count=data.get("active_connection_count", 0),
            query_count=data.get("query_count", 0),
            total_query_time=data.get("total_query_time", 0.0),
            avg_query_time=data.get("avg_query_time", 0.0),
            slow_query_count=data.get("slow_query_count", 0),
            error_count=data.get("error_count", 0),
            timestamp=timestamp
        )


class LRUCache(Generic[K, V]):
    """
    LRU (Least Recently Used) cache implementation.
    
    Provides a fixed-size cache that evicts the least recently used items when full.
    """
    
    def __init__(self, capacity: int):
        """
        Initialize LRU cache.
        
        Args:
            capacity: Maximum cache capacity
        """
        self.capacity = capacity
        self.cache: Dict[K, V] = {}
        self.usage_queue: List[K] = []
        self.lock = threading.Lock()
        self.hits = 0
        self.misses = 0
    
    def get(self, key: K) -> Optional[V]:
        """
        Get item from cache.
        
        Args:
            key: Cache key
        
        Returns:
            Cached value or None if not found
        """
        with self.lock:
            if key in self.cache:
                # Move key to end of usage queue (most recently used)
                self.usage_queue.remove(key)
                self.usage_queue.append(key)
                
                # Increment hit count
                self.hits += 1
                
                return self.cache[key]
            
            # Increment miss count
            self.misses += 1
            
            return None
    
    def put(self, key: K, value: V) -> None:
        """
        Put item in cache.
        
        Args:
            key: Cache key
            value: Value to cache
        """
        with self.lock:
            if key in self.cache:
                # Update existing item
                self.cache[key] = value
                
                # Move key to end of usage queue (most recently used)
                self.usage_queue.remove(key)
                self.usage_queue.append(key)
            else:
                # Check if cache is full
                if len(self.cache) >= self.capacity:
                    # Remove least recently used item
                    lru_key = self.usage_queue.pop(0)
                    del self.cache[lru_key]
                
                # Add new item
                self.cache[key] = value
                self.usage_queue.append(key)
    
    def remove(self, key: K) -> bool:
        """
        Remove item from cache.
        
        Args:
            key: Cache key
        
        Returns:
            True if item was removed, False if not found
        """
        with self.lock:
            if key in self.cache:
                # Remove item
                del self.cache[key]
                self.usage_queue.remove(key)
                return True
            
            return False
    
    def clear(self) -> None:
        """Clear cache."""
        with self.lock:
            self.cache.clear()
            self.usage_queue.clear()
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Get cache statistics.
        
        Returns:
            Dictionary with cache statistics
        """
        with self.lock:
            total_requests = self.hits + self.misses
            hit_rate = self.hits / total_requests if total_requests > 0 else 0.0
            
            return {
                "capacity": self.capacity,
                "size": len(self.cache),
                "hits": self.hits,
                "misses": self.misses,
                "hit_rate": hit_rate
            }


class QueryCache:
    """
    Query cache for database queries.
    
    Provides caching for database query results.
    """
    
    def __init__(self, capacity: int = 100, ttl: int = 60):
        """
        Initialize query cache.
        
        Args:
            capacity: Maximum cache capacity
            ttl: Time-to-live in seconds
        """
        self.cache = LRUCache[str, Tuple[Any, datetime.datetime]](capacity)
        self.ttl = ttl
    
    def get(self, query: str, params: Optional[Dict[str, Any]] = None) -> Optional[Any]:
        """
        Get query result from cache.
        
        Args:
            query: SQL query
            params: Query parameters
        
        Returns:
            Cached result or None if not found or expired
        """
        # Generate cache key
        key = self._generate_key(query, params)
        
        # Get from cache
        cached_item = self.cache.get(key)
        if cached_item is None:
            return None
        
        result, timestamp = cached_item
        
        # Check if expired
        if (datetime.datetime.now() - timestamp).total_seconds() > self.ttl:
            # Remove expired item
            self.cache.remove(key)
            return None
        
        return result
    
    def put(self, query: str, params: Optional[Dict[str, Any]], result: Any) -> None:
        """
        Put query result in cache.
        
        Args:
            query: SQL query
            params: Query parameters
            result: Query result
        """
        # Generate cache key
        key = self._generate_key(query, params)
        
        # Put in cache
        self.cache.put(key, (result, datetime.datetime.now()))
    
    def invalidate(self, table_name: str) -> None:
        """
        Invalidate cache entries for a specific table.
        
        Args:
            table_name: Table name
        """
        # This is a simplified implementation that clears the entire cache
        # A more sophisticated implementation would track which tables are used in each query
        self.cache.clear()
    
    def clear(self) -> None:
        """Clear cache."""
        self.cache.clear()
    
    def _generate_key(self, query: str, params: Optional[Dict[str, Any]]) -> str:
        """
        Generate cache key.
        
        Args:
            query: SQL query
            params: Query parameters
        
        Returns:
            Cache key
        """
        # Normalize query
        normalized_query = ' '.join(query.strip().split())
        
        # Create key components
        key_components = [normalized_query]
        
        # Add parameters if provided
        if params:
            # Sort parameters by key to ensure consistent order
            sorted_params = sorted(params.items())
            
            # Add each parameter to key components
            for key, value in sorted_params:
                key_components.append(f"{key}={value}")
        
        # Join components and hash
        key_string = '|'.join(key_components)
        return hashlib.md5(key_string.encode()).hexdigest()
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Get cache statistics.
        
        Returns:
            Dictionary with cache statistics
        """
        return {
            "ttl": self.ttl,
            **self.cache.get_stats()
        }


class ConnectionPool:
    """
    Database connection pool.
    
    Provides pooling for database connections.
    """
    
    def __init__(self, db_url: str, min_connections: int = 1, max_connections: int = 10, timeout: int = 30):
        """
        Initialize connection pool.
        
        Args:
            db_url: Database URL
            min_connections: Minimum number of connections
            max_connections: Maximum number of connections
            timeout: Connection timeout in seconds
        """
        self.db_url = db_url
        self.min_connections = min_connections
        self.max_connections = max_connections
        self.timeout = timeout
        
        # Create engine with connection pooling
        self.engine = create_engine(
            db_url,
            poolclass=QueuePool,
            pool_size=min_connections,
            max_overflow=max_connections - min_connections,
            pool_timeout=timeout,
            pool_recycle=3600,  # Recycle connections after 1 hour
            pool_pre_ping=True  # Check connection validity before using
        )
        
        # Create session factory
        self.session_factory = sessionmaker(bind=self.engine)
        
        # Create scoped session
        self.Session = scoped_session(self.session_factory)
        
        # Initialize metrics
        self.connection_count = 0
        self.active_connection_count = 0
        self.query_count = 0
        self.total_query_time = 0.0
        self.slow_query_count = 0
        self.error_count = 0
        self.slow_query_threshold = 1.0  # 1 second
        
        # Initialize locks
        self.metrics_lock = threading.Lock()
    
    def get_session(self) -> sqlalchemy.orm.Session:
        """
        Get database session.
        
        Returns:
            Database session
        """
        with self.metrics_lock:
            self.connection_count += 1
            self.active_connection_count += 1
        
        return self.Session()
    
    def release_session(self, session: sqlalchemy.orm.Session) -> None:
        """
        Release database session.
        
        Args:
            session: Database session
        """
        session.close()
        
        with self.metrics_lock:
            self.active_connection_count -= 1
    
    def execute_query(self, query: str, params: Optional[Dict[str, Any]] = None) -> Tuple[Any, float]:
        """
        Execute SQL query.
        
        Args:
            query: SQL query
            params: Query parameters
        
        Returns:
            Tuple of query result and execution time
        """
        session = self.get_session()
        
        try:
            # Start timer
            start_time = time.time()
            
            # Execute query
            if params:
                result = session.execute(text(query), params)
            else:
                result = session.execute(text(query))
            
            # Commit if not a SELECT query
            if not query.strip().upper().startswith("SELECT"):
                session.commit()
            
            # Calculate execution time
            execution_time = time.time() - start_time
            
            # Update metrics
            with self.metrics_lock:
                self.query_count += 1
                self.total_query_time += execution_time
                
                if execution_time > self.slow_query_threshold:
                    self.slow_query_count += 1
            
            return result, execution_time
        except Exception as e:
            # Rollback on error
            session.rollback()
            
            # Update metrics
            with self.metrics_lock:
                self.error_count += 1
            
            # Re-raise exception
            raise
        finally:
            # Release session
            self.release_session(session)
    
    def get_metrics(self) -> DatabaseMetrics:
        """
        Get database metrics.
        
        Returns:
            Database metrics
        """
        with self.metrics_lock:
            avg_query_time = self.total_query_time / self.query_count if self.query_count > 0 else 0.0
            
            return DatabaseMetrics(
                connection_count=self.connection_count,
                active_connection_count=self.active_connection_count,
                query_count=self.query_count,
                total_query_time=self.total_query_time,
                avg_query_time=avg_query_time,
                slow_query_count=self.slow_query_count,
                error_count=self.error_count
            )
    
    def reset_metrics(self) -> None:
        """Reset database metrics."""
        with self.metrics_lock:
            self.connection_count = 0
            self.active_connection_count = 0
            self.query_count = 0
            self.total_query_time = 0.0
            self.slow_query_count = 0
            self.error_count = 0
    
    def close(self) -> None:
        """Close connection pool."""
        self.engine.dispose()


class QueryOptimizer:
    """
    Query optimizer for database queries.
    
    Provides functionality for optimizing database queries.
    """
    
    def __init__(self, connection_pool: ConnectionPool):
        """
        Initialize query optimizer.
        
        Args:
            connection_pool: Database connection pool
        """
        self.connection_pool = connection_pool
        
        # Initialize query metrics
        self.query_metrics: Dict[str, List[QueryMetrics]] = {}
        self.query_metrics_lock = threading.Lock()
        
        # Initialize query cache
        self.query_cache = QueryCache(capacity=100, ttl=60)
    
    def optimize_query(self, query: str, params: Optional[Dict[str, Any]] = None) -> str:
        """
        Optimize SQL query.
        
        Args:
            query: SQL query
            params: Query parameters
        
        Returns:
            Optimized SQL query
        """
        # Normalize query
        normalized_query = ' '.join(query.strip().split())
        
        # Determine query type
        query_type = self._determine_query_type(normalized_query)
        
        # Apply optimizations based on query type
        if query_type == QueryType.SELECT:
            return self._optimize_select_query(normalized_query)
        elif query_type == QueryType.JOIN:
            return self._optimize_join_query(normalized_query)
        elif query_type == QueryType.AGGREGATE:
            return self._optimize_aggregate_query(normalized_query)
        else:
            # No optimization for other query types
            return normalized_query
    
    def _determine_query_type(self, query: str) -> QueryType:
        """
        Determine query type.
        
        Args:
            query: SQL query
        
        Returns:
            Query type
        """
        query_upper = query.upper()
        
        if query_upper.startswith("SELECT"):
            if "JOIN" in query_upper:
                return QueryType.JOIN
            elif any(func in query_upper for func in ["COUNT(", "SUM(", "AVG(", "MIN(", "MAX(", "GROUP BY"]):
                return QueryType.AGGREGATE
            else:
                return QueryType.SELECT
        elif query_upper.startswith("INSERT"):
            return QueryType.INSERT
        elif query_upper.startswith("UPDATE"):
            return QueryType.UPDATE
        elif query_upper.startswith("DELETE"):
            return QueryType.DELETE
        else:
            return QueryType.CUSTOM
    
    def _optimize_select_query(self, query: str) -> str:
        """
        Optimize SELECT query.
        
        Args:
            query: SELECT query
        
        Returns:
            Optimized SELECT query
        """
        # This is a simplified implementation
        # A more sophisticated implementation would analyze the query and apply various optimizations
        
        # Check if query has a LIMIT clause
        if "LIMIT" not in query.upper():
            # Add LIMIT clause to prevent returning too many rows
            return f"{query} LIMIT 1000"
        
        return query
    
    def _optimize_join_query(self, query: str) -> str:
        """
        Optimize JOIN query.
        
        Args:
            query: JOIN query
        
        Returns:
            Optimized JOIN query
        """
        # This is a simplified implementation
        # A more sophisticated implementation would analyze the query and optimize join order
        
        # Check if query has a LIMIT clause
        if "LIMIT" not in query.upper():
            # Add LIMIT clause to prevent returning too many rows
            return f"{query} LIMIT 1000"
        
        return query
    
    def _optimize_aggregate_query(self, query: str) -> str:
        """
        Optimize aggregate query.
        
        Args:
            query: Aggregate query
        
        Returns:
            Optimized aggregate query
        """
        # This is a simplified implementation
        # A more sophisticated implementation would analyze the query and optimize aggregation
        
        return query
    
    def execute_query(self, query: str, params: Optional[Dict[str, Any]] = None, use_cache: bool = True) -> Any:
        """
        Execute SQL query with optimization and caching.
        
        Args:
            query: SQL query
            params: Query parameters
            use_cache: Whether to use query cache
        
        Returns:
            Query result
        """
        # Generate query ID
        query_id = hashlib.md5(query.encode()).hexdigest()
        
        # Determine query type
        query_type = self._determine_query_type(query)
        
        # Check cache if enabled and query is cacheable
        if use_cache and query_type in [QueryType.SELECT, QueryType.JOIN, QueryType.AGGREGATE]:
            cached_result = self.query_cache.get(query, params)
            if cached_result is not None:
                return cached_result
        
        # Optimize query
        optimized_query = self.optimize_query(query, params)
        
        # Execute query
        result, execution_time = self.connection_pool.execute_query(optimized_query, params)
        
        # Convert result to list of dictionaries for SELECT queries
        if query_type in [QueryType.SELECT, QueryType.JOIN, QueryType.AGGREGATE]:
            result_list = [dict(row) for row in result]
            
            # Cache result if enabled and query is cacheable
            if use_cache:
                self.query_cache.put(query, params, result_list)
            
            result = result_list
        else:
            # For non-SELECT queries, get rowcount
            result = result.rowcount
        
        # Record query metrics
        self._record_query_metrics(query_id, query_type, query, execution_time, result if isinstance(result, int) else len(result))
        
        return result
    
    def _record_query_metrics(self, query_id: str, query_type: QueryType, query_text: str, execution_time: float, rows_affected: int) -> None:
        """
        Record query metrics.
        
        Args:
            query_id: Query ID
            query_type: Query type
            query_text: Query text
            execution_time: Execution time in seconds
            rows_affected: Number of rows affected
        """
        metrics = QueryMetrics(
            query_id=query_id,
            query_type=query_type,
            query_text=query_text,
            execution_time=execution_time,
            rows_affected=rows_affected
        )
        
        with self.query_metrics_lock:
            if query_id not in self.query_metrics:
                self.query_metrics[query_id] = []
            
            self.query_metrics[query_id].append(metrics)
            
            # Limit metrics history
            max_history = 100
            if len(self.query_metrics[query_id]) > max_history:
                self.query_metrics[query_id] = self.query_metrics[query_id][-max_history:]
    
    def get_query_metrics(self, query_id: Optional[str] = None) -> Union[List[QueryMetrics], Dict[str, List[QueryMetrics]]]:
        """
        Get query metrics.
        
        Args:
            query_id: Query ID or None for all metrics
        
        Returns:
            Query metrics
        """
        with self.query_metrics_lock:
            if query_id is not None:
                return self.query_metrics.get(query_id, [])
            else:
                return self.query_metrics.copy()
    
    def analyze_query_performance(self, query_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Analyze query performance.
        
        Args:
            query_id: Query ID or None for all queries
        
        Returns:
            Query performance analysis
        """
        with self.query_metrics_lock:
            if query_id is not None:
                # Analyze specific query
                metrics = self.query_metrics.get(query_id, [])
                if not metrics:
                    return {"error": f"No metrics found for query ID: {query_id}"}
                
                # Calculate statistics
                execution_times = [m.execution_time for m in metrics]
                rows_affected = [m.rows_affected for m in metrics]
                
                return {
                    "query_id": query_id,
                    "query_type": metrics[0].query_type.name,
                    "query_text": metrics[0].query_text,
                    "execution_count": len(metrics),
                    "avg_execution_time": sum(execution_times) / len(execution_times),
                    "min_execution_time": min(execution_times),
                    "max_execution_time": max(execution_times),
                    "avg_rows_affected": sum(rows_affected) / len(rows_affected),
                    "last_execution": metrics[-1].timestamp.isoformat()
                }
            else:
                # Analyze all queries
                analysis = {}
                
                for qid, metrics in self.query_metrics.items():
                    if not metrics:
                        continue
                    
                    # Calculate statistics
                    execution_times = [m.execution_time for m in metrics]
                    rows_affected = [m.rows_affected for m in metrics]
                    
                    analysis[qid] = {
                        "query_type": metrics[0].query_type.name,
                        "query_text": metrics[0].query_text,
                        "execution_count": len(metrics),
                        "avg_execution_time": sum(execution_times) / len(execution_times),
                        "min_execution_time": min(execution_times),
                        "max_execution_time": max(execution_times),
                        "avg_rows_affected": sum(rows_affected) / len(rows_affected),
                        "last_execution": metrics[-1].timestamp.isoformat()
                    }
                
                return analysis
    
    def get_slow_queries(self, threshold: float = 1.0) -> List[Dict[str, Any]]:
        """
        Get slow queries.
        
        Args:
            threshold: Execution time threshold in seconds
        
        Returns:
            List of slow queries
        """
        slow_queries = []
        
        with self.query_metrics_lock:
            for qid, metrics in self.query_metrics.items():
                for metric in metrics:
                    if metric.execution_time >= threshold:
                        slow_queries.append({
                            "query_id": qid,
                            "query_type": metric.query_type.name,
                            "query_text": metric.query_text,
                            "execution_time": metric.execution_time,
                            "rows_affected": metric.rows_affected,
                            "timestamp": metric.timestamp.isoformat()
                        })
        
        # Sort by execution time (descending)
        slow_queries.sort(key=lambda q: q["execution_time"], reverse=True)
        
        return slow_queries
    
    def invalidate_cache(self, table_name: str) -> None:
        """
        Invalidate cache entries for a specific table.
        
        Args:
            table_name: Table name
        """
        self.query_cache.invalidate(table_name)
    
    def clear_cache(self) -> None:
        """Clear query cache."""
        self.query_cache.clear()
    
    def get_cache_stats(self) -> Dict[str, Any]:
        """
        Get cache statistics.
        
        Returns:
            Dictionary with cache statistics
        """
        return self.query_cache.get_stats()


class IndexManager:
    """
    Index manager for database tables.
    
    Provides functionality for managing database indexes.
    """
    
    def __init__(self, connection_pool: ConnectionPool):
        """
        Initialize index manager.
        
        Args:
            connection_pool: Database connection pool
        """
        self.connection_pool = connection_pool
        
        # Initialize index metrics
        self.index_metrics: Dict[str, Dict[str, Any]] = {}
        self.index_metrics_lock = threading.Lock()
    
    def create_index(self, table_name: str, column_names: List[str], index_name: Optional[str] = None, unique: bool = False) -> bool:
        """
        Create database index.
        
        Args:
            table_name: Table name
            column_names: Column names
            index_name: Index name or None for auto-generated name
            unique: Whether index should be unique
        
        Returns:
            True if index was created, False otherwise
        """
        try:
            # Generate index name if not provided
            if index_name is None:
                index_name = f"idx_{table_name}_{'_'.join(column_names)}"
            
            # Create index query
            unique_str = "UNIQUE" if unique else ""
            columns_str = ", ".join(column_names)
            query = f"CREATE {unique_str} INDEX IF NOT EXISTS {index_name} ON {table_name} ({columns_str})"
            
            # Execute query
            result, execution_time = self.connection_pool.execute_query(query)
            
            # Record index metrics
            self._record_index_metrics(index_name, table_name, column_names, unique, execution_time)
            
            return True
        except Exception as e:
            logger.error(f"Error creating index: {e}")
            return False
    
    def drop_index(self, index_name: str) -> bool:
        """
        Drop database index.
        
        Args:
            index_name: Index name
        
        Returns:
            True if index was dropped, False otherwise
        """
        try:
            # Drop index query
            query = f"DROP INDEX IF EXISTS {index_name}"
            
            # Execute query
            result, execution_time = self.connection_pool.execute_query(query)
            
            # Remove index metrics
            with self.index_metrics_lock:
                if index_name in self.index_metrics:
                    del self.index_metrics[index_name]
            
            return True
        except Exception as e:
            logger.error(f"Error dropping index: {e}")
            return False
    
    def get_indexes(self, table_name: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Get database indexes.
        
        Args:
            table_name: Table name or None for all indexes
        
        Returns:
            List of indexes
        """
        try:
            # Get indexes query
            if table_name is not None:
                query = f"SELECT * FROM sqlite_master WHERE type = 'index' AND tbl_name = '{table_name}'"
            else:
                query = "SELECT * FROM sqlite_master WHERE type = 'index'"
            
            # Execute query
            result, _ = self.connection_pool.execute_query(query)
            
            # Convert result to list of dictionaries
            indexes = [dict(row) for row in result]
            
            return indexes
        except Exception as e:
            logger.error(f"Error getting indexes: {e}")
            return []
    
    def analyze_index_usage(self, table_name: Optional[str] = None) -> Dict[str, Any]:
        """
        Analyze index usage.
        
        Args:
            table_name: Table name or None for all tables
        
        Returns:
            Index usage analysis
        """
        try:
            # Get indexes
            indexes = self.get_indexes(table_name)
            
            # Get index metrics
            with self.index_metrics_lock:
                metrics = self.index_metrics.copy()
            
            # Analyze index usage
            analysis = {}
            
            for index in indexes:
                index_name = index["name"]
                
                if index_name in metrics:
                    analysis[index_name] = metrics[index_name]
                else:
                    analysis[index_name] = {
                        "table_name": index["tbl_name"],
                        "creation_time": 0.0,
                        "usage_count": 0,
                        "last_used": None
                    }
            
            return analysis
        except Exception as e:
            logger.error(f"Error analyzing index usage: {e}")
            return {}
    
    def _record_index_metrics(self, index_name: str, table_name: str, column_names: List[str], unique: bool, creation_time: float) -> None:
        """
        Record index metrics.
        
        Args:
            index_name: Index name
            table_name: Table name
            column_names: Column names
            unique: Whether index is unique
            creation_time: Index creation time in seconds
        """
        with self.index_metrics_lock:
            self.index_metrics[index_name] = {
                "table_name": table_name,
                "column_names": column_names,
                "unique": unique,
                "creation_time": creation_time,
                "usage_count": 0,
                "last_used": None
            }
    
    def record_index_usage(self, index_name: str) -> None:
        """
        Record index usage.
        
        Args:
            index_name: Index name
        """
        with self.index_metrics_lock:
            if index_name in self.index_metrics:
                self.index_metrics[index_name]["usage_count"] += 1
                self.index_metrics[index_name]["last_used"] = datetime.datetime.now().isoformat()


class PartitionManager:
    """
    Partition manager for database tables.
    
    Provides functionality for managing database partitions.
    """
    
    def __init__(self, connection_pool: ConnectionPool):
        """
        Initialize partition manager.
        
        Args:
            connection_pool: Database connection pool
        """
        self.connection_pool = connection_pool
        
        # Initialize partition metrics
        self.partition_metrics: Dict[str, Dict[str, Any]] = {}
        self.partition_metrics_lock = threading.Lock()
    
    def create_partition(self, table_name: str, partition_column: str, partition_value: Any, partition_name: Optional[str] = None) -> bool:
        """
        Create database partition.
        
        Note: SQLite does not support partitioning natively, so this is a simulated implementation
        using separate tables for each partition.
        
        Args:
            table_name: Table name
            partition_column: Partition column name
            partition_value: Partition value
            partition_name: Partition name or None for auto-generated name
        
        Returns:
            True if partition was created, False otherwise
        """
        try:
            # Generate partition name if not provided
            if partition_name is None:
                partition_name = f"{table_name}_{partition_column}_{partition_value}"
            
            # Get table schema
            schema_query = f"SELECT sql FROM sqlite_master WHERE type = 'table' AND name = '{table_name}'"
            schema_result, _ = self.connection_pool.execute_query(schema_query)
            
            # Check if table exists
            if not schema_result:
                logger.error(f"Table not found: {table_name}")
                return False
            
            # Get table schema
            table_schema = schema_result[0][0]
            
            # Create partition table with same schema
            create_query = table_schema.replace(f"CREATE TABLE {table_name}", f"CREATE TABLE IF NOT EXISTS {partition_name}")
            self.connection_pool.execute_query(create_query)
            
            # Record partition metrics
            self._record_partition_metrics(partition_name, table_name, partition_column, partition_value)
            
            return True
        except Exception as e:
            logger.error(f"Error creating partition: {e}")
            return False
    
    def drop_partition(self, partition_name: str) -> bool:
        """
        Drop database partition.
        
        Args:
            partition_name: Partition name
        
        Returns:
            True if partition was dropped, False otherwise
        """
        try:
            # Drop partition table
            query = f"DROP TABLE IF EXISTS {partition_name}"
            self.connection_pool.execute_query(query)
            
            # Remove partition metrics
            with self.partition_metrics_lock:
                if partition_name in self.partition_metrics:
                    del self.partition_metrics[partition_name]
            
            return True
        except Exception as e:
            logger.error(f"Error dropping partition: {e}")
            return False
    
    def get_partitions(self, table_name: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Get database partitions.
        
        Args:
            table_name: Table name or None for all partitions
        
        Returns:
            List of partitions
        """
        with self.partition_metrics_lock:
            partitions = []
            
            for partition_name, metrics in self.partition_metrics.items():
                if table_name is None or metrics["table_name"] == table_name:
                    partitions.append({
                        "partition_name": partition_name,
                        **metrics
                    })
            
            return partitions
    
    def insert_into_partition(self, partition_name: str, data: Dict[str, Any]) -> bool:
        """
        Insert data into partition.
        
        Args:
            partition_name: Partition name
            data: Data to insert
        
        Returns:
            True if data was inserted, False otherwise
        """
        try:
            # Generate column names and placeholders
            columns = list(data.keys())
            placeholders = [f":{col}" for col in columns]
            
            # Create insert query
            query = f"INSERT INTO {partition_name} ({', '.join(columns)}) VALUES ({', '.join(placeholders)})"
            
            # Execute query
            self.connection_pool.execute_query(query, data)
            
            # Record partition usage
            self._record_partition_usage(partition_name)
            
            return True
        except Exception as e:
            logger.error(f"Error inserting into partition: {e}")
            return False
    
    def query_partition(self, partition_name: str, where_clause: Optional[str] = None, params: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """
        Query partition.
        
        Args:
            partition_name: Partition name
            where_clause: WHERE clause or None for all rows
            params: Query parameters
        
        Returns:
            Query result
        """
        try:
            # Create query
            query = f"SELECT * FROM {partition_name}"
            
            if where_clause:
                query += f" WHERE {where_clause}"
            
            # Execute query
            result, _ = self.connection_pool.execute_query(query, params)
            
            # Convert result to list of dictionaries
            result_list = [dict(row) for row in result]
            
            # Record partition usage
            self._record_partition_usage(partition_name)
            
            return result_list
        except Exception as e:
            logger.error(f"Error querying partition: {e}")
            return []
    
    def _record_partition_metrics(self, partition_name: str, table_name: str, partition_column: str, partition_value: Any) -> None:
        """
        Record partition metrics.
        
        Args:
            partition_name: Partition name
            table_name: Table name
            partition_column: Partition column name
            partition_value: Partition value
        """
        with self.partition_metrics_lock:
            self.partition_metrics[partition_name] = {
                "table_name": table_name,
                "partition_column": partition_column,
                "partition_value": partition_value,
                "row_count": 0,
                "usage_count": 0,
                "last_used": None,
                "created_at": datetime.datetime.now().isoformat()
            }
    
    def _record_partition_usage(self, partition_name: str) -> None:
        """
        Record partition usage.
        
        Args:
            partition_name: Partition name
        """
        with self.partition_metrics_lock:
            if partition_name in self.partition_metrics:
                self.partition_metrics[partition_name]["usage_count"] += 1
                self.partition_metrics[partition_name]["last_used"] = datetime.datetime.now().isoformat()
    
    def update_partition_row_count(self, partition_name: str) -> None:
        """
        Update partition row count.
        
        Args:
            partition_name: Partition name
        """
        try:
            # Count rows
            query = f"SELECT COUNT(*) FROM {partition_name}"
            result, _ = self.connection_pool.execute_query(query)
            
            # Update metrics
            with self.partition_metrics_lock:
                if partition_name in self.partition_metrics:
                    self.partition_metrics[partition_name]["row_count"] = result[0][0]
        except Exception as e:
            logger.error(f"Error updating partition row count: {e}")


class DatabaseOptimizer:
    """
    Database optimizer for OPSC Sandwich Quality Inspection System.
    
    Provides functionality for optimizing database operations, including query optimization,
    indexing, connection pooling, and caching.
    """
    
    def __init__(self, db_url: str, min_connections: int = 1, max_connections: int = 10):
        """
        Initialize database optimizer.
        
        Args:
            db_url: Database URL
            min_connections: Minimum number of connections
            max_connections: Maximum number of connections
        """
        # Create connection pool
        self.connection_pool = ConnectionPool(db_url, min_connections, max_connections)
        
        # Create query optimizer
        self.query_optimizer = QueryOptimizer(self.connection_pool)
        
        # Create index manager
        self.index_manager = IndexManager(self.connection_pool)
        
        # Create partition manager
        self.partition_manager = PartitionManager(self.connection_pool)
    
    def execute_query(self, query: str, params: Optional[Dict[str, Any]] = None, use_cache: bool = True) -> Any:
        """
        Execute SQL query with optimization and caching.
        
        Args:
            query: SQL query
            params: Query parameters
            use_cache: Whether to use query cache
        
        Returns:
            Query result
        """
        return self.query_optimizer.execute_query(query, params, use_cache)
    
    def create_index(self, table_name: str, column_names: List[str], index_name: Optional[str] = None, unique: bool = False) -> bool:
        """
        Create database index.
        
        Args:
            table_name: Table name
            column_names: Column names
            index_name: Index name or None for auto-generated name
            unique: Whether index should be unique
        
        Returns:
            True if index was created, False otherwise
        """
        return self.index_manager.create_index(table_name, column_names, index_name, unique)
    
    def create_partition(self, table_name: str, partition_column: str, partition_value: Any, partition_name: Optional[str] = None) -> bool:
        """
        Create database partition.
        
        Args:
            table_name: Table name
            partition_column: Partition column name
            partition_value: Partition value
            partition_name: Partition name or None for auto-generated name
        
        Returns:
            True if partition was created, False otherwise
        """
        return self.partition_manager.create_partition(table_name, partition_column, partition_value, partition_name)
    
    def optimize_database(self) -> bool:
        """
        Optimize database.
        
        Returns:
            True if database was optimized, False otherwise
        """
        try:
            # Vacuum database
            self.connection_pool.execute_query("VACUUM")
            
            # Analyze database
            self.connection_pool.execute_query("ANALYZE")
            
            return True
        except Exception as e:
            logger.error(f"Error optimizing database: {e}")
            return False
    
    def get_database_metrics(self) -> Dict[str, Any]:
        """
        Get database metrics.
        
        Returns:
            Dictionary with database metrics
        """
        # Get connection pool metrics
        pool_metrics = self.connection_pool.get_metrics()
        
        # Get query cache stats
        cache_stats = self.query_optimizer.get_cache_stats()
        
        # Get slow queries
        slow_queries = self.query_optimizer.get_slow_queries()
        
        # Get index usage
        index_usage = self.index_manager.analyze_index_usage()
        
        # Get partitions
        partitions = self.partition_manager.get_partitions()
        
        return {
            "pool_metrics": pool_metrics.to_dict(),
            "cache_stats": cache_stats,
            "slow_queries": slow_queries,
            "index_usage": index_usage,
            "partitions": partitions
        }
    
    def get_optimization_recommendations(self) -> List[Dict[str, Any]]:
        """
        Get optimization recommendations.
        
        Returns:
            List of optimization recommendations
        """
        recommendations = []
        
        # Check slow queries
        slow_queries = self.query_optimizer.get_slow_queries()
        if slow_queries:
            for query in slow_queries:
                # Check if query is a SELECT query
                if query["query_type"] == "SELECT":
                    # Extract table and column names from query
                    # This is a simplified implementation
                    query_text = query["query_text"]
                    from_pos = query_text.upper().find("FROM")
                    where_pos = query_text.upper().find("WHERE")
                    
                    if from_pos > 0 and where_pos > from_pos:
                        table_name = query_text[from_pos + 5:where_pos].strip()
                        where_clause = query_text[where_pos + 6:].strip()
                        
                        # Extract column names from WHERE clause
                        # This is a simplified implementation
                        column_names = []
                        for part in where_clause.split("AND"):
                            eq_pos = part.find("=")
                            if eq_pos > 0:
                                column_name = part[:eq_pos].strip()
                                column_names.append(column_name)
                        
                        if column_names:
                            recommendations.append({
                                "type": "CREATE_INDEX",
                                "table_name": table_name,
                                "column_names": column_names,
                                "reason": f"Slow query: {query_text}",
                                "execution_time": query["execution_time"]
                            })
        
        # Check index usage
        index_usage = self.index_manager.analyze_index_usage()
        for index_name, usage in index_usage.items():
            if usage["usage_count"] == 0:
                recommendations.append({
                    "type": "DROP_INDEX",
                    "index_name": index_name,
                    "reason": "Unused index"
                })
        
        # Check partition usage
        partitions = self.partition_manager.get_partitions()
        for partition in partitions:
            if partition["usage_count"] == 0:
                recommendations.append({
                    "type": "DROP_PARTITION",
                    "partition_name": partition["partition_name"],
                    "reason": "Unused partition"
                })
        
        return recommendations
    
    def apply_optimization_recommendations(self, recommendations: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Apply optimization recommendations.
        
        Args:
            recommendations: List of optimization recommendations
        
        Returns:
            Dictionary with results
        """
        results = {
            "success": [],
            "failure": []
        }
        
        for recommendation in recommendations:
            try:
                if recommendation["type"] == "CREATE_INDEX":
                    success = self.create_index(
                        recommendation["table_name"],
                        recommendation["column_names"]
                    )
                    
                    if success:
                        results["success"].append(recommendation)
                    else:
                        results["failure"].append(recommendation)
                elif recommendation["type"] == "DROP_INDEX":
                    success = self.index_manager.drop_index(recommendation["index_name"])
                    
                    if success:
                        results["success"].append(recommendation)
                    else:
                        results["failure"].append(recommendation)
                elif recommendation["type"] == "DROP_PARTITION":
                    success = self.partition_manager.drop_partition(recommendation["partition_name"])
                    
                    if success:
                        results["success"].append(recommendation)
                    else:
                        results["failure"].append(recommendation)
                else:
                    results["failure"].append(recommendation)
            except Exception as e:
                logger.error(f"Error applying recommendation: {e}")
                results["failure"].append(recommendation)
        
        return results
    
    def close(self) -> None:
        """Close database optimizer."""
        self.connection_pool.close()


# Example usage
if __name__ == "__main__":
    # Setup logging
    logging.basicConfig(level=logging.INFO)
    
    # Create database optimizer
    db_url = "sqlite:///data/database/sandwich_inspection.db"
    optimizer = DatabaseOptimizer(db_url, min_connections=1, max_connections=5)
    
    # Create test table
    create_table_query = """
    CREATE TABLE IF NOT EXISTS sandwich_defects (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp DATETIME NOT NULL,
        camera_id TEXT NOT NULL,
        defect_type TEXT NOT NULL,
        confidence REAL NOT NULL,
        x INTEGER NOT NULL,
        y INTEGER NOT NULL,
        width INTEGER NOT NULL,
        height INTEGER NOT NULL,
        image_path TEXT NOT NULL
    )
    """
    optimizer.execute_query(create_table_query, use_cache=False)
    
    # Insert test data
    for i in range(10):
        insert_query = """
        INSERT INTO sandwich_defects (
            timestamp, camera_id, defect_type, confidence, x, y, width, height, image_path
        ) VALUES (
            :timestamp, :camera_id, :defect_type, :confidence, :x, :y, :width, :height, :image_path
        )
        """
        params = {
            "timestamp": datetime.datetime.now().isoformat(),
            "camera_id": f"camera{i % 4 + 1}",
            "defect_type": f"defect_type{i % 3 + 1}",
            "confidence": 0.8 + (i % 10) / 100,
            "x": i * 10,
            "y": i * 10,
            "width": 100,
            "height": 100,
            "image_path": f"/path/to/image_{i}.jpg"
        }
        optimizer.execute_query(insert_query, params, use_cache=False)
    
    # Create index
    optimizer.create_index("sandwich_defects", ["camera_id", "defect_type"])
    
    # Create partition
    optimizer.create_partition("sandwich_defects", "camera_id", "camera1")
    
    # Execute query with caching
    select_query = "SELECT * FROM sandwich_defects WHERE camera_id = :camera_id"
    params = {"camera_id": "camera1"}
    result = optimizer.execute_query(select_query, params)
    print(f"Query result: {result}")
    
    # Execute same query again (should use cache)
    result = optimizer.execute_query(select_query, params)
    print(f"Query result (cached): {result}")
    
    # Get database metrics
    metrics = optimizer.get_database_metrics()
    print(f"Database metrics: {metrics}")
    
    # Get optimization recommendations
    recommendations = optimizer.get_optimization_recommendations()
    print(f"Optimization recommendations: {recommendations}")
    
    # Apply optimization recommendations
    results = optimizer.apply_optimization_recommendations(recommendations)
    print(f"Applied recommendations: {results}")
    
    # Optimize database
    optimizer.optimize_database()
    
    # Close optimizer
    optimizer.close()
