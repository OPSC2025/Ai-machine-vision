"""
Database migration scripts for OPSC Sandwich Quality Inspection System.
Contains SQL migration scripts for database schema evolution.

Version: 1.0.0
Last Updated: 2025-04-21
"""

# Migration V1__Create_inspection_results_table.sql
V1__CREATE_INSPECTION_RESULTS_TABLE = """-- Migration: Create inspection results table
-- Version: 1
-- Created: 2025-04-21

CREATE TABLE IF NOT EXISTS inspection_results (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT NOT NULL,
    camera_id TEXT NOT NULL,
    image_path TEXT NOT NULL,
    defect_type TEXT,
    confidence REAL,
    bbox_x REAL,
    bbox_y REAL,
    bbox_width REAL,
    bbox_height REAL,
    processed BOOLEAN DEFAULT 0,
    rejected BOOLEAN DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_inspection_results_timestamp ON inspection_results(timestamp);
CREATE INDEX IF NOT EXISTS idx_inspection_results_camera_id ON inspection_results(camera_id);
CREATE INDEX IF NOT EXISTS idx_inspection_results_defect_type ON inspection_results(defect_type);
CREATE INDEX IF NOT EXISTS idx_inspection_results_processed ON inspection_results(processed);
CREATE INDEX IF NOT EXISTS idx_inspection_results_rejected ON inspection_results(rejected);
"""

# Migration V2__Create_production_runs_table.sql
V2__CREATE_PRODUCTION_RUNS_TABLE = """-- Migration: Create production runs table
-- Version: 2
-- Created: 2025-04-21

CREATE TABLE IF NOT EXISTS production_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id TEXT UNIQUE NOT NULL,
    start_time TEXT NOT NULL,
    end_time TEXT,
    product_type TEXT NOT NULL,
    batch_number TEXT,
    operator TEXT,
    status TEXT NOT NULL,
    total_inspected INTEGER DEFAULT 0,
    total_rejected INTEGER DEFAULT 0,
    notes TEXT
);

CREATE INDEX IF NOT EXISTS idx_production_runs_run_id ON production_runs(run_id);
CREATE INDEX IF NOT EXISTS idx_production_runs_start_time ON production_runs(start_time);
CREATE INDEX IF NOT EXISTS idx_production_runs_product_type ON production_runs(product_type);
CREATE INDEX IF NOT EXISTS idx_production_runs_status ON production_runs(status);

-- Add run_id to inspection_results
ALTER TABLE inspection_results ADD COLUMN run_id TEXT;
CREATE INDEX IF NOT EXISTS idx_inspection_results_run_id ON inspection_results(run_id);
"""

# Migration V3__Create_camera_calibration_table.sql
V3__CREATE_CAMERA_CALIBRATION_TABLE = """-- Migration: Create camera calibration table
-- Version: 3
-- Created: 2025-04-21

CREATE TABLE IF NOT EXISTS camera_calibrations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    camera_id TEXT NOT NULL,
    calibration_date TEXT NOT NULL,
    intrinsic_matrix TEXT NOT NULL,
    distortion_coefficients TEXT NOT NULL,
    resolution_width INTEGER NOT NULL,
    resolution_height INTEGER NOT NULL,
    pixel_size_mm REAL,
    focal_length_mm REAL,
    working_distance_mm REAL,
    notes TEXT,
    active BOOLEAN DEFAULT 1
);

CREATE INDEX IF NOT EXISTS idx_camera_calibrations_camera_id ON camera_calibrations(camera_id);
CREATE INDEX IF NOT EXISTS idx_camera_calibrations_calibration_date ON camera_calibrations(calibration_date);
CREATE INDEX IF NOT EXISTS idx_camera_calibrations_active ON camera_calibrations(active);
"""

# Migration V4__Create_system_logs_table.sql
V4__CREATE_SYSTEM_LOGS_TABLE = """-- Migration: Create system logs table
-- Version: 4
-- Created: 2025-04-21

CREATE TABLE IF NOT EXISTS system_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT NOT NULL,
    level TEXT NOT NULL,
    component TEXT NOT NULL,
    message TEXT NOT NULL,
    details TEXT
);

CREATE INDEX IF NOT EXISTS idx_system_logs_timestamp ON system_logs(timestamp);
CREATE INDEX IF NOT EXISTS idx_system_logs_level ON system_logs(level);
CREATE INDEX IF NOT EXISTS idx_system_logs_component ON system_logs(component);
"""

# Migration V5__Create_model_performance_table.sql
V5__CREATE_MODEL_PERFORMANCE_TABLE = """-- Migration: Create model performance table
-- Version: 5
-- Created: 2025-04-21

CREATE TABLE IF NOT EXISTS model_performance (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT NOT NULL,
    model_id TEXT NOT NULL,
    model_version TEXT NOT NULL,
    run_id TEXT,
    inference_time_ms REAL NOT NULL,
    memory_usage_mb REAL,
    cpu_usage_percent REAL,
    gpu_usage_percent REAL,
    temperature_celsius REAL,
    batch_size INTEGER,
    precision TEXT,
    device TEXT
);

CREATE INDEX IF NOT EXISTS idx_model_performance_timestamp ON model_performance(timestamp);
CREATE INDEX IF NOT EXISTS idx_model_performance_model_id ON model_performance(model_id);
CREATE INDEX IF NOT EXISTS idx_model_performance_run_id ON model_performance(run_id);
"""

# Migration V6__Create_hardware_telemetry_table.sql
V6__CREATE_HARDWARE_TELEMETRY_TABLE = """-- Migration: Create hardware telemetry table
-- Version: 6
-- Created: 2025-04-21

CREATE TABLE IF NOT EXISTS hardware_telemetry (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT NOT NULL,
    device_id TEXT NOT NULL,
    device_type TEXT NOT NULL,
    cpu_usage_percent REAL,
    memory_usage_percent REAL,
    disk_usage_percent REAL,
    temperature_celsius REAL,
    network_rx_bytes INTEGER,
    network_tx_bytes INTEGER,
    power_usage_watts REAL,
    uptime_seconds INTEGER
);

CREATE INDEX IF NOT EXISTS idx_hardware_telemetry_timestamp ON hardware_telemetry(timestamp);
CREATE INDEX IF NOT EXISTS idx_hardware_telemetry_device_id ON hardware_telemetry(device_id);
"""

# Migration V7__Create_defect_types_table.sql
V7__CREATE_DEFECT_TYPES_TABLE = """-- Migration: Create defect types table
-- Version: 7
-- Created: 2025-04-21

CREATE TABLE IF NOT EXISTS defect_types (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    defect_code TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    description TEXT,
    severity TEXT NOT NULL,
    auto_reject BOOLEAN DEFAULT 1,
    color_code TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_defect_types_defect_code ON defect_types(defect_code);
CREATE INDEX IF NOT EXISTS idx_defect_types_severity ON defect_types(severity);

-- Insert default defect types
INSERT INTO defect_types (defect_code, name, description, severity, auto_reject, color_code, created_at, updated_at)
VALUES 
    ('MISSING_INGREDIENT', 'Missing Ingredient', 'One or more ingredients are missing from the sandwich', 'HIGH', 1, '#FF0000', datetime('now'), datetime('now')),
    ('MISALIGNED', 'Misaligned Components', 'Sandwich components are not properly aligned', 'MEDIUM', 1, '#FFA500', datetime('now'), datetime('now')),
    ('FOREIGN_OBJECT', 'Foreign Object', 'Foreign object detected in the sandwich', 'CRITICAL', 1, '#800000', datetime('now'), datetime('now')),
    ('INCORRECT_SIZE', 'Incorrect Size', 'Sandwich size does not meet specifications', 'MEDIUM', 1, '#FFFF00', datetime('now'), datetime('now')),
    ('DAMAGED_PACKAGING', 'Damaged Packaging', 'Packaging is damaged or compromised', 'HIGH', 1, '#FF00FF', datetime('now'), datetime('now')),
    ('DISCOLORATION', 'Discoloration', 'Abnormal color detected in sandwich components', 'MEDIUM', 1, '#00FFFF', datetime('now'), datetime('now')),
    ('CONTAMINATION', 'Contamination', 'Contamination detected on sandwich', 'CRITICAL', 1, '#800080', datetime('now'), datetime('now')),
    ('INCORRECT_ASSEMBLY', 'Incorrect Assembly', 'Sandwich is not assembled according to specifications', 'HIGH', 1, '#008000', datetime('now'), datetime('now'));
"""

# Migration V8__Create_reports_table.sql
V8__CREATE_REPORTS_TABLE = """-- Migration: Create reports table
-- Version: 8
-- Created: 2025-04-21

CREATE TABLE IF NOT EXISTS reports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    report_id TEXT UNIQUE NOT NULL,
    report_type TEXT NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    parameters TEXT,
    created_at TEXT NOT NULL,
    created_by TEXT,
    file_path TEXT,
    status TEXT NOT NULL,
    error_message TEXT
);

CREATE INDEX IF NOT EXISTS idx_reports_report_id ON reports(report_id);
CREATE INDEX IF NOT EXISTS idx_reports_report_type ON reports(report_type);
CREATE INDEX IF NOT EXISTS idx_reports_created_at ON reports(created_at);
CREATE INDEX IF NOT EXISTS idx_reports_status ON reports(status);
"""

# Migration V9__Create_cloud_sync_table.sql
V9__CREATE_CLOUD_SYNC_TABLE = """-- Migration: Create cloud sync table
-- Version: 9
-- Created: 2025-04-21

CREATE TABLE IF NOT EXISTS cloud_sync (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    entity_type TEXT NOT NULL,
    entity_id INTEGER NOT NULL,
    sync_status TEXT NOT NULL,
    last_sync_attempt TEXT,
    last_successful_sync TEXT,
    error_message TEXT,
    retry_count INTEGER DEFAULT 0,
    azure_blob_url TEXT,
    azure_table_entity TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_cloud_sync_entity_type_id ON cloud_sync(entity_type, entity_id);
CREATE INDEX IF NOT EXISTS idx_cloud_sync_sync_status ON cloud_sync(sync_status);
CREATE INDEX IF NOT EXISTS idx_cloud_sync_last_sync_attempt ON cloud_sync(last_sync_attempt);
"""

# Migration V10__Create_alerts_table.sql
V10__CREATE_ALERTS_TABLE = """-- Migration: Create alerts table
-- Version: 10
-- Created: 2025-04-21

CREATE TABLE IF NOT EXISTS alerts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    alert_id TEXT UNIQUE NOT NULL,
    timestamp TEXT NOT NULL,
    alert_type TEXT NOT NULL,
    severity TEXT NOT NULL,
    source TEXT NOT NULL,
    message TEXT NOT NULL,
    details TEXT,
    acknowledged BOOLEAN DEFAULT 0,
    acknowledged_by TEXT,
    acknowledged_at TEXT,
    resolved BOOLEAN DEFAULT 0,
    resolved_by TEXT,
    resolved_at TEXT,
    actions_taken TEXT
);

CREATE INDEX IF NOT EXISTS idx_alerts_alert_id ON alerts(alert_id);
CREATE INDEX IF NOT EXISTS idx_alerts_timestamp ON alerts(timestamp);
CREATE INDEX IF NOT EXISTS idx_alerts_alert_type ON alerts(alert_type);
CREATE INDEX IF NOT EXISTS idx_alerts_severity ON alerts(severity);
CREATE INDEX IF NOT EXISTS idx_alerts_acknowledged ON alerts(acknowledged);
CREATE INDEX IF NOT EXISTS idx_alerts_resolved ON alerts(resolved);
"""

# Dictionary of all migrations
MIGRATIONS = {
    1: V1__CREATE_INSPECTION_RESULTS_TABLE,
    2: V2__CREATE_PRODUCTION_RUNS_TABLE,
    3: V3__CREATE_CAMERA_CALIBRATION_TABLE,
    4: V4__CREATE_SYSTEM_LOGS_TABLE,
    5: V5__CREATE_MODEL_PERFORMANCE_TABLE,
    6: V6__CREATE_HARDWARE_TELEMETRY_TABLE,
    7: V7__CREATE_DEFECT_TYPES_TABLE,
    8: V8__CREATE_REPORTS_TABLE,
    9: V9__CREATE_CLOUD_SYNC_TABLE,
    10: V10__CREATE_ALERTS_TABLE
}

def initialize_migrations(migrations_dir):
    """
    Initialize migration files in the specified directory.
    
    Args:
        migrations_dir: Directory to create migration files in
    """
    import os
    
    # Create directory if it doesn't exist
    os.makedirs(migrations_dir, exist_ok=True)
    
    # Create migration files
    for version, sql in MIGRATIONS.items():
        # Extract description from SQL comment
        description = sql.split('\n')[0].replace('-- Migration: ', '')
        
        # Create filename
        filename = f"V{version}__{description.replace(' ', '_')}.sql"
        filepath = os.path.join(migrations_dir, filename)
        
        # Write migration file if it doesn't exist
        if not os.path.exists(filepath):
            with open(filepath, "w") as f:
                f.write(sql)
            
            print(f"Created migration file: {filepath}")
        else:
            print(f"Migration file already exists: {filepath}")


# Example usage
if __name__ == "__main__":
    import os
    
    # Initialize migrations
    migrations_dir = os.path.join("data", "database", "migrations")
    initialize_migrations(migrations_dir)
