"""
API module for OPSC Sandwich Quality Inspection System.
Provides FastAPI endpoints for frontend integration.

Version: 1.0.0
Last Updated: 2025-04-20
"""

import os
import sys
import time
import json
import logging
import threading
import queue
from typing import Dict, List, Optional, Tuple, Union, Any, Callable, Iterator
import numpy as np
from dataclasses import dataclass, field
from enum import Enum
import uuid
from pathlib import Path
import concurrent.futures
import datetime
import base64
import io
import cv2
import tempfile
import shutil
import asyncio
from contextlib import asynccontextmanager

# Import FastAPI
try:
    import fastapi
    from fastapi import FastAPI, APIRouter, Depends, HTTPException, status, File, UploadFile, Form, Query, Body
    from fastapi.responses import JSONResponse, StreamingResponse, FileResponse
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
    from pydantic import BaseModel, Field, validator
except ImportError:
    # Install FastAPI if not available
    import subprocess
    subprocess.check_call([sys.executable, "-m", "pip", "install", "fastapi==0.103.1", "uvicorn==0.23.2", "python-multipart==0.0.6", "pydantic==2.3.0"])
    import fastapi
    from fastapi import FastAPI, APIRouter, Depends, HTTPException, status, File, UploadFile, Form, Query, Body
    from fastapi.responses import JSONResponse, StreamingResponse, FileResponse
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
    from pydantic import BaseModel, Field, validator

# Import JWT for authentication
try:
    import jwt
except ImportError:
    # Install PyJWT if not available
    import subprocess
    subprocess.check_call([sys.executable, "-m", "pip", "install", "pyjwt==2.8.0"])
    import jwt

from ...utils.config import get_config
from ...utils.logging import setup_logging, log_exception
from ...utils.security import generate_token, verify_token
from ...core.data.database import (
    get_database_manager, 
    DatabaseError, 
    QueryError, 
    DefectType, 
    SeverityLevel, 
    ProductionStatus, 
    EventType
)
from ...core.camera.basler_manager import get_camera_manager
from ...core.inference.model_manager import get_model_manager
from ...core.inference.jetson_client import get_jetson_client

# Setup logging
logger = setup_logging(__name__)

# Load configuration
config = get_config("api", {})

# JWT settings
JWT_SECRET = config.get("jwt_secret", "your-secret-key")  # Should be loaded from environment in production
JWT_ALGORITHM = config.get("jwt_algorithm", "HS256")
JWT_EXPIRATION = config.get("jwt_expiration", 3600)  # 1 hour by default

# OAuth2 scheme
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

# API version
API_VERSION = "v1"

# Base URL
BASE_URL = f"/api/{API_VERSION}"

# Create API router
router = APIRouter(prefix=BASE_URL)


# Pydantic models for request/response validation
class Token(BaseModel):
    """Token model for authentication."""
    access_token: str
    token_type: str


class TokenData(BaseModel):
    """Token data model."""
    username: Optional[str] = None
    role: Optional[str] = None


class UserLogin(BaseModel):
    """User login model."""
    username: str
    password: str


class UserCreate(BaseModel):
    """User creation model."""
    username: str
    password: str
    email: str
    role: str
    first_name: Optional[str] = None
    last_name: Optional[str] = None


class UserUpdate(BaseModel):
    """User update model."""
    email: Optional[str] = None
    role: Optional[str] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    is_active: Optional[bool] = None


class PasswordChange(BaseModel):
    """Password change model."""
    current_password: str
    new_password: str


class ProductionRunCreate(BaseModel):
    """Production run creation model."""
    lot_number: str
    product_name: str
    target_quantity: Optional[int] = None
    operator_id: Optional[str] = None
    notes: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None


class ProductionRunUpdate(BaseModel):
    """Production run update model."""
    status: Optional[str] = None
    end_time: Optional[datetime.datetime] = None
    actual_quantity: Optional[int] = None
    notes: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None


class InspectionCreate(BaseModel):
    """Inspection creation model."""
    production_run_id: str
    camera_id: str
    model_id: str
    processing_time: Optional[float] = None
    passed: bool = True
    confidence: Optional[float] = None
    metadata: Optional[Dict[str, Any]] = None


class DefectCreate(BaseModel):
    """Defect creation model."""
    inspection_id: str
    defect_type: str
    x: float
    y: float
    width: float
    height: float
    confidence: float
    severity: Optional[str] = None
    description: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None


class SystemEventCreate(BaseModel):
    """System event creation model."""
    event_type: str
    component: str
    message: str
    details: Optional[Dict[str, Any]] = None


class ConfigurationCreate(BaseModel):
    """Configuration creation model."""
    name: str
    value: str
    description: Optional[str] = None


class AzurePushRequest(BaseModel):
    """Azure push request model."""
    days_to_keep: int = 30


class ExportRequest(BaseModel):
    """Export request model."""
    start_date: Optional[datetime.datetime] = None
    end_date: Optional[datetime.datetime] = None
    include_images: bool = False


class CameraConfig(BaseModel):
    """Camera configuration model."""
    camera_id: str
    parameter: str
    value: Any


class ModelConfig(BaseModel):
    """Model configuration model."""
    model_id: str
    parameter: str
    value: Any


class LiveInspectionRequest(BaseModel):
    """Live inspection request model."""
    camera_id: str
    model_id: str
    production_run_id: Optional[str] = None


class SystemStatusResponse(BaseModel):
    """System status response model."""
    status: str
    version: str
    uptime: float
    database_size: int
    image_storage_size: int
    camera_status: Dict[str, str]
    model_status: Dict[str, str]
    jetson_status: str


# Authentication functions
def create_access_token(data: dict, expires_delta: Optional[int] = None) -> str:
    """
    Create JWT access token.
    
    Args:
        data: Data to encode in token.
        expires_delta: Token expiration time in seconds.
        
    Returns:
        JWT token.
    """
    to_encode = data.copy()
    
    if expires_delta:
        expire = datetime.datetime.utcnow() + datetime.timedelta(seconds=expires_delta)
    else:
        expire = datetime.datetime.utcnow() + datetime.timedelta(seconds=JWT_EXPIRATION)
    
    to_encode.update({"exp": expire})
    
    encoded_jwt = jwt.encode(to_encode, JWT_SECRET, algorithm=JWT_ALGORITHM)
    
    return encoded_jwt


async def get_current_user(token: str = Depends(oauth2_scheme)) -> Dict[str, Any]:
    """
    Get current user from token.
    
    Args:
        token: JWT token.
        
    Returns:
        User information.
        
    Raises:
        HTTPException: If token is invalid or user not found.
    """
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    
    try:
        # Decode token
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        username: str = payload.get("sub")
        
        if username is None:
            raise credentials_exception
        
        token_data = TokenData(username=username, role=payload.get("role"))
    except jwt.PyJWTError:
        raise credentials_exception
    
    # Get user from database
    db = get_database_manager()
    
    try:
        # Get user by username
        users = db.list_users()
        user = next((u for u in users if u["username"] == token_data.username), None)
        
        if user is None:
            raise credentials_exception
        
        if not user["is_active"]:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="User is inactive",
                headers={"WWW-Authenticate": "Bearer"},
            )
        
        return user
    except Exception as e:
        logger.error(f"Error getting user: {e}")
        raise credentials_exception


async def get_current_active_user(current_user: Dict[str, Any] = Depends(get_current_user)) -> Dict[str, Any]:
    """
    Get current active user.
    
    Args:
        current_user: Current user information.
        
    Returns:
        User information.
        
    Raises:
        HTTPException: If user is inactive.
    """
    if not current_user["is_active"]:
        raise HTTPException(status_code=400, detail="Inactive user")
    
    return current_user


def check_admin_role(current_user: Dict[str, Any] = Depends(get_current_user)) -> Dict[str, Any]:
    """
    Check if user has admin role.
    
    Args:
        current_user: Current user information.
        
    Returns:
        User information.
        
    Raises:
        HTTPException: If user is not admin.
    """
    if current_user["role"] != "admin":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions",
        )
    
    return current_user


# Authentication endpoints
@router.post("/token", response_model=Token)
async def login_for_access_token(form_data: OAuth2PasswordRequestForm = Depends()):
    """
    Login endpoint to get access token.
    
    Args:
        form_data: Form data with username and password.
        
    Returns:
        Access token.
        
    Raises:
        HTTPException: If authentication fails.
    """
    db = get_database_manager()
    
    try:
        # Authenticate user
        user = db.authenticate_user(form_data.username, form_data.password)
        
        if not user:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Incorrect username or password",
                headers={"WWW-Authenticate": "Bearer"},
            )
        
        # Create access token
        access_token = create_access_token(
            data={"sub": user["username"], "role": user["role"]}
        )
        
        return {"access_token": access_token, "token_type": "bearer"}
    except Exception as e:
        logger.error(f"Error during login: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error",
        )


@router.post("/login", response_model=Token)
async def login(user_data: UserLogin):
    """
    Login endpoint to get access token.
    
    Args:
        user_data: User login data.
        
    Returns:
        Access token.
        
    Raises:
        HTTPException: If authentication fails.
    """
    db = get_database_manager()
    
    try:
        # Authenticate user
        user = db.authenticate_user(user_data.username, user_data.password)
        
        if not user:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Incorrect username or password",
                headers={"WWW-Authenticate": "Bearer"},
            )
        
        # Create access token
        access_token = create_access_token(
            data={"sub": user["username"], "role": user["role"]}
        )
        
        return {"access_token": access_token, "token_type": "bearer"}
    except Exception as e:
        logger.error(f"Error during login: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error",
        )


# User endpoints
@router.get("/users/me", response_model=Dict[str, Any])
async def read_users_me(current_user: Dict[str, Any] = Depends(get_current_active_user)):
    """
    Get current user information.
    
    Args:
        current_user: Current user information.
        
    Returns:
        User information.
    """
    return current_user


@router.post("/users", response_model=Dict[str, Any])
async def create_user(user: UserCreate, current_user: Dict[str, Any] = Depends(check_admin_role)):
    """
    Create a new user.
    
    Args:
        user: User creation data.
        current_user: Current user information.
        
    Returns:
        User information.
        
    Raises:
        HTTPException: If user creation fails.
    """
    db = get_database_manager()
    
    try:
        # Create user
        user_id = db.create_user(
            username=user.username,
            password=user.password,
            email=user.email,
            role=user.role,
            first_name=user.first_name,
            last_name=user.last_name
        )
        
        # Get user information
        user_info = db.get_user(user_id)
        
        return user_info
    except QueryError as e:
        logger.error(f"Error creating user: {e}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )
    except Exception as e:
        logger.error(f"Error creating user: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error",
        )


@router.get("/users", response_model=List[Dict[str, Any]])
async def list_users(current_user: Dict[str, Any] = Depends(check_admin_role)):
    """
    List all users.
    
    Args:
        current_user: Current user information.
        
    Returns:
        List of users.
        
    Raises:
        HTTPException: If listing users fails.
    """
    db = get_database_manager()
    
    try:
        # List users
        users = db.list_users()
        
        return users
    except Exception as e:
        logger.error(f"Error listing users: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error",
        )


@router.get("/users/{user_id}", response_model=Dict[str, Any])
async def get_user(user_id: str, current_user: Dict[str, Any] = Depends(check_admin_role)):
    """
    Get user information.
    
    Args:
        user_id: User ID.
        current_user: Current user information.
        
    Returns:
        User information.
        
    Raises:
        HTTPException: If user not found.
    """
    db = get_database_manager()
    
    try:
        # Get user
        user = db.get_user(user_id)
        
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User not found",
            )
        
        return user
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting user: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error",
        )


@router.put("/users/{user_id}", response_model=Dict[str, Any])
async def update_user(
    user_id: str,
    user_update: UserUpdate,
    current_user: Dict[str, Any] = Depends(check_admin_role)
):
    """
    Update user information.
    
    Args:
        user_id: User ID.
        user_update: User update data.
        current_user: Current user information.
        
    Returns:
        Updated user information.
        
    Raises:
        HTTPException: If update fails.
    """
    db = get_database_manager()
    
    try:
        # Update user
        db.update_user(
            user_id=user_id,
            email=user_update.email,
            role=user_update.role,
            first_name=user_update.first_name,
            last_name=user_update.last_name,
            is_active=user_update.is_active
        )
        
        # Get updated user information
        user = db.get_user(user_id)
        
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User not found",
            )
        
        return user
    except QueryError as e:
        logger.error(f"Error updating user: {e}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating user: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error",
        )


@router.post("/users/change-password", response_model=Dict[str, str])
async def change_password(
    password_change: PasswordChange,
    current_user: Dict[str, Any] = Depends(get_current_active_user)
):
    """
    Change user password.
    
    Args:
        password_change: Password change data.
        current_user: Current user information.
        
    Returns:
        Success message.
        
    Raises:
        HTTPException: If password change fails.
    """
    db = get_database_manager()
    
    try:
        # Verify current password
        user = db.authenticate_user(current_user["username"], password_change.current_password)
        
        if not user:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Incorrect current password",
            )
        
        # Change password
        db.change_password(current_user["user_id"], password_change.new_password)
        
        return {"message": "Password changed successfully"}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error changing password: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error",
        )


# Production run endpoints
@router.post("/production-runs", response_model=Dict[str, Any])
async def create_production_run(
    production_run: ProductionRunCreate,
    current_user: Dict[str, Any] = Depends(get_current_active_user)
):
    """
    Create a new production run.
    
    Args:
        production_run: Production run creation data.
        current_user: Current user information.
        
    Returns:
        Production run information.
        
    Raises:
        HTTPException: If creation fails.
    """
    db = get_database_manager()
    
    try:
        # Create production run
        run_id = db.create_production_run(
            lot_number=production_run.lot_number,
            product_name=production_run.product_name,
            target_quantity=production_run.target_quantity,
            operator_id=production_run.operator_id or current_user["user_id"],
            notes=production_run.notes,
            metadata=production_run.metadata
        )
        
        # Get production run information
        run_info = db.get_production_run(run_id)
        
        return run_info
    except QueryError as e:
        logger.error(f"Error creating production run: {e}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )
    except Exception as e:
        logger.error(f"Error creating production run: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error",
        )


@router.get("/production-runs", response_model=List[Dict[str, Any]])
async def list_production_runs(
    limit: Optional[int] = None,
    offset: Optional[int] = None,
    status: Optional[str] = None,
    start_date: Optional[datetime.datetime] = None,
    end_date: Optional[datetime.datetime] = None,
    lot_number: Optional[str] = None,
    current_user: Dict[str, Any] = Depends(get_current_active_user)
):
    """
    List production runs.
    
    Args:
        limit: Maximum number of results.
        offset: Offset for pagination.
        status: Filter by status.
        start_date: Filter by start date.
        end_date: Filter by end date.
        lot_number: Filter by lot number.
        current_user: Current user information.
        
    Returns:
        List of production runs.
        
    Raises:
        HTTPException: If listing fails.
    """
    db = get_database_manager()
    
    try:
        # Convert status string to enum if provided
        status_enum = None
        if status:
            try:
                status_enum = ProductionStatus[status.upper()]
            except KeyError:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Invalid status: {status}",
                )
        
        # List production runs
        runs = db.list_production_runs(
            limit=limit,
            offset=offset,
            status=status_enum,
            start_date=start_date,
            end_date=end_date,
            lot_number=lot_number
        )
        
        return runs
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error listing production runs: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error",
        )


@router.get("/production-runs/{run_id}", response_model=Dict[str, Any])
async def get_production_run(
    run_id: str,
    current_user: Dict[str, Any] = Depends(get_current_active_user)
):
    """
    Get production run information.
    
    Args:
        run_id: Production run ID.
        current_user: Current user information.
        
    Returns:
        Production run information.
        
    Raises:
        HTTPException: If production run not found.
    """
    db = get_database_manager()
    
    try:
        # Get production run
        run = db.get_production_run(run_id)
        
        return run
    except QueryError as e:
        logger.error(f"Error getting production run: {e}")
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e),
        )
    except Exception as e:
        logger.error(f"Error getting production run: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error",
        )


@router.put("/production-runs/{run_id}", response_model=Dict[str, Any])
async def update_production_run(
    run_id: str,
    production_run: ProductionRunUpdate,
    current_user: Dict[str, Any] = Depends(get_current_active_user)
):
    """
    Update production run.
    
    Args:
        run_id: Production run ID.
        production_run: Production run update data.
        current_user: Current user information.
        
    Returns:
        Updated production run information.
        
    Raises:
        HTTPException: If update fails.
    """
    db = get_database_manager()
    
    try:
        # Convert status string to enum if provided
        status_enum = None
        if production_run.status:
            try:
                status_enum = ProductionStatus[production_run.status.upper()]
            except KeyError:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Invalid status: {production_run.status}",
                )
        
        # Update production run
        db.update_production_run(
            run_id=run_id,
            status=status_enum,
            end_time=production_run.end_time,
            actual_quantity=production_run.actual_quantity,
            notes=production_run.notes,
            metadata=production_run.metadata
        )
        
        # Get updated production run information
        run = db.get_production_run(run_id)
        
        return run
    except QueryError as e:
        logger.error(f"Error updating production run: {e}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )
    except Exception as e:
        logger.error(f"Error updating production run: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error",
        )


# Inspection endpoints
@router.post("/inspections", response_model=Dict[str, str])
async def create_inspection(
    inspection: InspectionCreate,
    current_user: Dict[str, Any] = Depends(get_current_active_user)
):
    """
    Create a new inspection.
    
    Args:
        inspection: Inspection creation data.
        current_user: Current user information.
        
    Returns:
        Inspection ID.
        
    Raises:
        HTTPException: If creation fails.
    """
    db = get_database_manager()
    
    try:
        # Create inspection
        inspection_id = db.add_inspection(
            production_run_id=inspection.production_run_id,
            camera_id=inspection.camera_id,
            model_id=inspection.model_id,
            processing_time=inspection.processing_time,
            passed=inspection.passed,
            confidence=inspection.confidence,
            metadata=inspection.metadata
        )
        
        return {"inspection_id": inspection_id}
    except QueryError as e:
        logger.error(f"Error creating inspection: {e}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )
    except Exception as e:
        logger.error(f"Error creating inspection: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error",
        )


@router.post("/inspections/with-image", response_model=Dict[str, str])
async def create_inspection_with_image(
    production_run_id: str = Form(...),
    camera_id: str = Form(...),
    model_id: str = Form(...),
    processing_time: Optional[float] = Form(None),
    passed: bool = Form(True),
    confidence: Optional[float] = Form(None),
    metadata: Optional[str] = Form(None),
    image: UploadFile = File(...),
    current_user: Dict[str, Any] = Depends(get_current_active_user)
):
    """
    Create a new inspection with image.
    
    Args:
        production_run_id: Production run ID.
        camera_id: Camera ID.
        model_id: Model ID.
        processing_time: Processing time in milliseconds.
        passed: Whether inspection passed.
        confidence: Confidence score.
        metadata: Additional metadata as JSON string.
        image: Image file.
        current_user: Current user information.
        
    Returns:
        Inspection ID.
        
    Raises:
        HTTPException: If creation fails.
    """
    db = get_database_manager()
    
    try:
        # Parse metadata if provided
        metadata_dict = None
        if metadata:
            try:
                metadata_dict = json.loads(metadata)
            except json.JSONDecodeError:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Invalid metadata JSON",
                )
        
        # Read image
        image_data = await image.read()
        
        # Convert to numpy array
        nparr = np.frombuffer(image_data, np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        
        if img is None:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid image format",
            )
        
        # Create inspection
        inspection_id = db.add_inspection(
            production_run_id=production_run_id,
            camera_id=camera_id,
            model_id=model_id,
            image=img,
            processing_time=processing_time,
            passed=passed,
            confidence=confidence,
            metadata=metadata_dict
        )
        
        return {"inspection_id": inspection_id}
    except QueryError as e:
        logger.error(f"Error creating inspection: {e}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error creating inspection: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error",
        )


@router.get("/inspections", response_model=List[Dict[str, Any]])
async def list_inspections(
    production_run_id: Optional[str] = None,
    camera_id: Optional[str] = None,
    passed: Optional[bool] = None,
    start_time: Optional[datetime.datetime] = None,
    end_time: Optional[datetime.datetime] = None,
    limit: Optional[int] = None,
    offset: Optional[int] = None,
    current_user: Dict[str, Any] = Depends(get_current_active_user)
):
    """
    List inspections.
    
    Args:
        production_run_id: Filter by production run ID.
        camera_id: Filter by camera ID.
        passed: Filter by passed status.
        start_time: Filter by start time.
        end_time: Filter by end time.
        limit: Maximum number of results.
        offset: Offset for pagination.
        current_user: Current user information.
        
    Returns:
        List of inspections.
        
    Raises:
        HTTPException: If listing fails.
    """
    db = get_database_manager()
    
    try:
        # List inspections
        inspections = db.list_inspections(
            production_run_id=production_run_id,
            camera_id=camera_id,
            passed=passed,
            start_time=start_time,
            end_time=end_time,
            limit=limit,
            offset=offset
        )
        
        return inspections
    except Exception as e:
        logger.error(f"Error listing inspections: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error",
        )


@router.get("/inspections/{inspection_id}", response_model=Dict[str, Any])
async def get_inspection(
    inspection_id: str,
    current_user: Dict[str, Any] = Depends(get_current_active_user)
):
    """
    Get inspection information.
    
    Args:
        inspection_id: Inspection ID.
        current_user: Current user information.
        
    Returns:
        Inspection information.
        
    Raises:
        HTTPException: If inspection not found.
    """
    db = get_database_manager()
    
    try:
        # Get inspection
        inspection = db.get_inspection(inspection_id)
        
        return inspection
    except QueryError as e:
        logger.error(f"Error getting inspection: {e}")
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e),
        )
    except Exception as e:
        logger.error(f"Error getting inspection: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error",
        )


@router.get("/inspections/{inspection_id}/defects", response_model=List[Dict[str, Any]])
async def get_inspection_defects(
    inspection_id: str,
    current_user: Dict[str, Any] = Depends(get_current_active_user)
):
    """
    Get defects for inspection.
    
    Args:
        inspection_id: Inspection ID.
        current_user: Current user information.
        
    Returns:
        List of defects.
        
    Raises:
        HTTPException: If getting defects fails.
    """
    db = get_database_manager()
    
    try:
        # Get defects
        defects = db.get_inspection_defects(inspection_id)
        
        return defects
    except Exception as e:
        logger.error(f"Error getting inspection defects: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error",
        )


@router.get("/inspections/{inspection_id}/image")
async def get_inspection_image(
    inspection_id: str,
    current_user: Dict[str, Any] = Depends(get_current_active_user)
):
    """
    Get image for inspection.
    
    Args:
        inspection_id: Inspection ID.
        current_user: Current user information.
        
    Returns:
        Image data.
        
    Raises:
        HTTPException: If image not found.
    """
    db = get_database_manager()
    
    try:
        # Get inspection
        inspection = db.get_inspection(inspection_id)
        
        if not inspection["image_path"]:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Image not found",
            )
        
        # Check if file exists
        if not os.path.exists(inspection["image_path"]):
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Image file not found",
            )
        
        # Return file response
        return FileResponse(
            inspection["image_path"],
            media_type="image/jpeg",
            filename=os.path.basename(inspection["image_path"])
        )
    except QueryError as e:
        logger.error(f"Error getting inspection: {e}")
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e),
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting inspection image: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error",
        )


# Defect endpoints
@router.post("/defects", response_model=Dict[str, str])
async def create_defect(
    defect: DefectCreate,
    current_user: Dict[str, Any] = Depends(get_current_active_user)
):
    """
    Create a new defect.
    
    Args:
        defect: Defect creation data.
        current_user: Current user information.
        
    Returns:
        Defect ID.
        
    Raises:
        HTTPException: If creation fails.
    """
    db = get_database_manager()
    
    try:
        # Convert defect type string to enum
        try:
            defect_type_enum = DefectType[defect.defect_type.upper()]
        except KeyError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Invalid defect type: {defect.defect_type}",
            )
        
        # Convert severity string to enum if provided
        severity_enum = None
        if defect.severity:
            try:
                severity_enum = SeverityLevel[defect.severity.upper()]
            except KeyError:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Invalid severity level: {defect.severity}",
                )
        
        # Create defect
        defect_id = db.add_defect(
            inspection_id=defect.inspection_id,
            defect_type=defect_type_enum,
            x=defect.x,
            y=defect.y,
            width=defect.width,
            height=defect.height,
            confidence=defect.confidence,
            severity=severity_enum,
            description=defect.description,
            metadata=defect.metadata
        )
        
        return {"defect_id": defect_id}
    except QueryError as e:
        logger.error(f"Error creating defect: {e}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error creating defect: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error",
        )


@router.get("/defects", response_model=List[Dict[str, Any]])
async def list_defects(
    production_run_id: Optional[str] = None,
    defect_type: Optional[str] = None,
    severity: Optional[str] = None,
    min_confidence: Optional[float] = None,
    start_time: Optional[datetime.datetime] = None,
    end_time: Optional[datetime.datetime] = None,
    limit: Optional[int] = None,
    offset: Optional[int] = None,
    current_user: Dict[str, Any] = Depends(get_current_active_user)
):
    """
    List defects.
    
    Args:
        production_run_id: Filter by production run ID.
        defect_type: Filter by defect type.
        severity: Filter by severity level.
        min_confidence: Filter by minimum confidence.
        start_time: Filter by start time.
        end_time: Filter by end time.
        limit: Maximum number of results.
        offset: Offset for pagination.
        current_user: Current user information.
        
    Returns:
        List of defects.
        
    Raises:
        HTTPException: If listing fails.
    """
    db = get_database_manager()
    
    try:
        # Convert defect type string to enum if provided
        defect_type_enum = None
        if defect_type:
            try:
                defect_type_enum = DefectType[defect_type.upper()]
            except KeyError:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Invalid defect type: {defect_type}",
                )
        
        # Convert severity string to enum if provided
        severity_enum = None
        if severity:
            try:
                severity_enum = SeverityLevel[severity.upper()]
            except KeyError:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Invalid severity level: {severity}",
                )
        
        # List defects
        defects = db.list_defects(
            production_run_id=production_run_id,
            defect_type=defect_type_enum,
            severity=severity_enum,
            min_confidence=min_confidence,
            start_time=start_time,
            end_time=end_time,
            limit=limit,
            offset=offset
        )
        
        return defects
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error listing defects: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error",
        )


@router.get("/defects/counts", response_model=Dict[str, int])
async def get_defect_counts(
    production_run_id: Optional[str] = None,
    start_time: Optional[datetime.datetime] = None,
    end_time: Optional[datetime.datetime] = None,
    group_by: str = "defect_type",
    current_user: Dict[str, Any] = Depends(get_current_active_user)
):
    """
    Get defect counts.
    
    Args:
        production_run_id: Filter by production run ID.
        start_time: Filter by start time.
        end_time: Filter by end time.
        group_by: Field to group by ("defect_type", "severity", "camera_id").
        current_user: Current user information.
        
    Returns:
        Dictionary of defect counts.
        
    Raises:
        HTTPException: If getting counts fails.
    """
    db = get_database_manager()
    
    try:
        # Validate group_by
        if group_by not in ["defect_type", "severity", "camera_id"]:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Invalid group_by field: {group_by}",
            )
        
        # Get defect counts
        counts = db.get_defect_counts(
            production_run_id=production_run_id,
            start_time=start_time,
            end_time=end_time,
            group_by=group_by
        )
        
        return counts
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting defect counts: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error",
        )


@router.get("/defects/trend", response_model=Dict[str, int])
async def get_defect_trend(
    production_run_id: Optional[str] = None,
    defect_type: Optional[str] = None,
    interval: str = "hour",
    start_time: Optional[datetime.datetime] = None,
    end_time: Optional[datetime.datetime] = None,
    current_user: Dict[str, Any] = Depends(get_current_active_user)
):
    """
    Get defect trend over time.
    
    Args:
        production_run_id: Filter by production run ID.
        defect_type: Filter by defect type.
        interval: Time interval ("minute", "hour", "day", "week", "month").
        start_time: Filter by start time.
        end_time: Filter by end time.
        current_user: Current user information.
        
    Returns:
        Dictionary of defect counts by time interval.
        
    Raises:
        HTTPException: If getting trend fails.
    """
    db = get_database_manager()
    
    try:
        # Convert defect type string to enum if provided
        defect_type_enum = None
        if defect_type:
            try:
                defect_type_enum = DefectType[defect_type.upper()]
            except KeyError:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Invalid defect type: {defect_type}",
                )
        
        # Validate interval
        if interval not in ["minute", "hour", "day", "week", "month"]:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Invalid interval: {interval}",
            )
        
        # Get defect trend
        trend = db.get_defect_trend(
            production_run_id=production_run_id,
            defect_type=defect_type_enum,
            interval=interval,
            start_time=start_time,
            end_time=end_time
        )
        
        return trend
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting defect trend: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error",
        )


# System event endpoints
@router.post("/system-events", response_model=Dict[str, str])
async def create_system_event(
    event: SystemEventCreate,
    current_user: Dict[str, Any] = Depends(get_current_active_user)
):
    """
    Create a new system event.
    
    Args:
        event: System event creation data.
        current_user: Current user information.
        
    Returns:
        Event ID.
        
    Raises:
        HTTPException: If creation fails.
    """
    db = get_database_manager()
    
    try:
        # Convert event type string to enum
        try:
            event_type_enum = EventType[event.event_type.upper()]
        except KeyError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Invalid event type: {event.event_type}",
            )
        
        # Create system event
        event_id = db.add_system_event(
            event_type=event_type_enum,
            component=event.component,
            message=event.message,
            details=event.details,
            user_id=current_user["user_id"]
        )
        
        return {"event_id": event_id}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error creating system event: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error",
        )


@router.get("/system-events", response_model=List[Dict[str, Any]])
async def list_system_events(
    event_type: Optional[str] = None,
    component: Optional[str] = None,
    user_id: Optional[str] = None,
    start_time: Optional[datetime.datetime] = None,
    end_time: Optional[datetime.datetime] = None,
    limit: Optional[int] = None,
    offset: Optional[int] = None,
    current_user: Dict[str, Any] = Depends(get_current_active_user)
):
    """
    List system events.
    
    Args:
        event_type: Filter by event type.
        component: Filter by component.
        user_id: Filter by user ID.
        start_time: Filter by start time.
        end_time: Filter by end time.
        limit: Maximum number of results.
        offset: Offset for pagination.
        current_user: Current user information.
        
    Returns:
        List of system events.
        
    Raises:
        HTTPException: If listing fails.
    """
    db = get_database_manager()
    
    try:
        # Convert event type string to enum if provided
        event_type_enum = None
        if event_type:
            try:
                event_type_enum = EventType[event_type.upper()]
            except KeyError:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Invalid event type: {event_type}",
                )
        
        # List system events
        events = db.list_system_events(
            event_type=event_type_enum,
            component=component,
            user_id=user_id,
            start_time=start_time,
            end_time=end_time,
            limit=limit,
            offset=offset
        )
        
        return events
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error listing system events: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error",
        )


# Configuration endpoints
@router.post("/configurations", response_model=Dict[str, str])
async def set_configuration(
    configuration: ConfigurationCreate,
    current_user: Dict[str, Any] = Depends(check_admin_role)
):
    """
    Set configuration value.
    
    Args:
        configuration: Configuration creation data.
        current_user: Current user information.
        
    Returns:
        Configuration ID.
        
    Raises:
        HTTPException: If setting configuration fails.
    """
    db = get_database_manager()
    
    try:
        # Set configuration
        config_id = db.set_configuration(
            name=configuration.name,
            value=configuration.value,
            description=configuration.description
        )
        
        return {"config_id": config_id}
    except Exception as e:
        logger.error(f"Error setting configuration: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error",
        )


@router.get("/configurations", response_model=List[Dict[str, Any]])
async def list_configurations(
    current_user: Dict[str, Any] = Depends(get_current_active_user)
):
    """
    List all configurations.
    
    Args:
        current_user: Current user information.
        
    Returns:
        List of configurations.
        
    Raises:
        HTTPException: If listing fails.
    """
    db = get_database_manager()
    
    try:
        # List configurations
        configs = db.list_configurations()
        
        return configs
    except Exception as e:
        logger.error(f"Error listing configurations: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error",
        )


@router.get("/configurations/{name}", response_model=Dict[str, str])
async def get_configuration(
    name: str,
    current_user: Dict[str, Any] = Depends(get_current_active_user)
):
    """
    Get configuration value.
    
    Args:
        name: Configuration name.
        current_user: Current user information.
        
    Returns:
        Configuration value.
        
    Raises:
        HTTPException: If configuration not found.
    """
    db = get_database_manager()
    
    try:
        # Get configuration
        value = db.get_configuration(name)
        
        if value is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Configuration not found: {name}",
            )
        
        return {"name": name, "value": value}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting configuration: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error",
        )


# Database management endpoints
@router.post("/database/backup", response_model=Dict[str, str])
async def backup_database(
    current_user: Dict[str, Any] = Depends(check_admin_role)
):
    """
    Create a backup of the database.
    
    Args:
        current_user: Current user information.
        
    Returns:
        Path to backup file.
        
    Raises:
        HTTPException: If backup fails.
    """
    db = get_database_manager()
    
    try:
        # Create backup
        backup_path = db.backup_database()
        
        return {"backup_path": backup_path}
    except DatabaseError as e:
        logger.error(f"Error backing up database: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e),
        )
    except Exception as e:
        logger.error(f"Error backing up database: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error",
        )


@router.post("/database/restore", response_model=Dict[str, str])
async def restore_database(
    backup_path: str = Body(..., embed=True),
    current_user: Dict[str, Any] = Depends(check_admin_role)
):
    """
    Restore database from backup.
    
    Args:
        backup_path: Path to backup file.
        current_user: Current user information.
        
    Returns:
        Success message.
        
    Raises:
        HTTPException: If restore fails.
    """
    db = get_database_manager()
    
    try:
        # Restore database
        db.restore_database(backup_path)
        
        return {"message": "Database restored successfully"}
    except DatabaseError as e:
        logger.error(f"Error restoring database: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e),
        )
    except Exception as e:
        logger.error(f"Error restoring database: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error",
        )


@router.post("/database/vacuum", response_model=Dict[str, str])
async def vacuum_database(
    current_user: Dict[str, Any] = Depends(check_admin_role)
):
    """
    Vacuum database to optimize storage.
    
    Args:
        current_user: Current user information.
        
    Returns:
        Success message.
        
    Raises:
        HTTPException: If vacuum fails.
    """
    db = get_database_manager()
    
    try:
        # Vacuum database
        db.vacuum_database()
        
        return {"message": "Database vacuumed successfully"}
    except DatabaseError as e:
        logger.error(f"Error vacuuming database: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e),
        )
    except Exception as e:
        logger.error(f"Error vacuuming database: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error",
        )


@router.get("/database/size", response_model=Dict[str, int])
async def get_database_size(
    current_user: Dict[str, Any] = Depends(get_current_active_user)
):
    """
    Get database and image storage size.
    
    Args:
        current_user: Current user information.
        
    Returns:
        Database and image storage size in bytes.
        
    Raises:
        HTTPException: If getting size fails.
    """
    db = get_database_manager()
    
    try:
        # Get database size
        db_size = db.get_database_size()
        
        # Get image storage size
        img_size = db.get_image_storage_size()
        
        return {"database_size": db_size, "image_storage_size": img_size}
    except DatabaseError as e:
        logger.error(f"Error getting database size: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e),
        )
    except Exception as e:
        logger.error(f"Error getting database size: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error",
        )


@router.post("/database/export", response_model=Dict[str, str])
async def export_data(
    export_request: ExportRequest,
    current_user: Dict[str, Any] = Depends(get_current_active_user)
):
    """
    Export data to CSV files.
    
    Args:
        export_request: Export request data.
        current_user: Current user information.
        
    Returns:
        Path to export directory.
        
    Raises:
        HTTPException: If export fails.
    """
    db = get_database_manager()
    
    try:
        # Generate export path
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        export_path = f"data/export/export_{timestamp}"
        
        # Export data
        export_path = db.export_data(
            export_path=export_path,
            start_date=export_request.start_date,
            end_date=export_request.end_date,
            include_images=export_request.include_images
        )
        
        return {"export_path": export_path}
    except DatabaseError as e:
        logger.error(f"Error exporting data: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e),
        )
    except Exception as e:
        logger.error(f"Error exporting data: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error",
        )


@router.post("/database/push-to-azure", response_model=Dict[str, int])
async def push_to_azure(
    push_request: AzurePushRequest,
    current_user: Dict[str, Any] = Depends(check_admin_role)
):
    """
    Push images to Azure Blob Storage and remove local copies of old images.
    
    Args:
        push_request: Azure push request data.
        current_user: Current user information.
        
    Returns:
        Number of images pushed.
        
    Raises:
        HTTPException: If push fails.
    """
    db = get_database_manager()
    
    try:
        # Push to Azure
        count = db.push_to_azure(days_to_keep=push_request.days_to_keep)
        
        return {"count": count}
    except DatabaseError as e:
        logger.error(f"Error pushing to Azure: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e),
        )
    except Exception as e:
        logger.error(f"Error pushing to Azure: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error",
        )


# Camera endpoints
@router.get("/cameras", response_model=List[Dict[str, Any]])
async def list_cameras(
    current_user: Dict[str, Any] = Depends(get_current_active_user)
):
    """
    List available cameras.
    
    Args:
        current_user: Current user information.
        
    Returns:
        List of cameras.
        
    Raises:
        HTTPException: If listing fails.
    """
    try:
        # Get camera manager
        camera_manager = get_camera_manager()
        
        # List cameras
        cameras = camera_manager.list_cameras()
        
        return cameras
    except Exception as e:
        logger.error(f"Error listing cameras: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error",
        )


@router.get("/cameras/{camera_id}", response_model=Dict[str, Any])
async def get_camera(
    camera_id: str,
    current_user: Dict[str, Any] = Depends(get_current_active_user)
):
    """
    Get camera information.
    
    Args:
        camera_id: Camera ID.
        current_user: Current user information.
        
    Returns:
        Camera information.
        
    Raises:
        HTTPException: If camera not found.
    """
    try:
        # Get camera manager
        camera_manager = get_camera_manager()
        
        # Get camera
        camera = camera_manager.get_camera(camera_id)
        
        if not camera:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Camera not found: {camera_id}",
            )
        
        return camera
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting camera: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error",
        )


@router.post("/cameras/{camera_id}/configure", response_model=Dict[str, str])
async def configure_camera(
    camera_id: str,
    config: CameraConfig,
    current_user: Dict[str, Any] = Depends(check_admin_role)
):
    """
    Configure camera parameter.
    
    Args:
        camera_id: Camera ID.
        config: Camera configuration data.
        current_user: Current user information.
        
    Returns:
        Success message.
        
    Raises:
        HTTPException: If configuration fails.
    """
    try:
        # Get camera manager
        camera_manager = get_camera_manager()
        
        # Configure camera
        camera_manager.configure_camera(camera_id, config.parameter, config.value)
        
        return {"message": f"Camera {camera_id} configured successfully"}
    except Exception as e:
        logger.error(f"Error configuring camera: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error",
        )


@router.get("/cameras/{camera_id}/snapshot")
async def get_camera_snapshot(
    camera_id: str,
    current_user: Dict[str, Any] = Depends(get_current_active_user)
):
    """
    Get snapshot from camera.
    
    Args:
        camera_id: Camera ID.
        current_user: Current user information.
        
    Returns:
        Camera snapshot.
        
    Raises:
        HTTPException: If getting snapshot fails.
    """
    try:
        # Get camera manager
        camera_manager = get_camera_manager()
        
        # Get snapshot
        image = camera_manager.get_snapshot(camera_id)
        
        if image is None:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to get snapshot",
            )
        
        # Encode image
        _, buffer = cv2.imencode(".jpg", image)
        
        # Return image
        return StreamingResponse(
            io.BytesIO(buffer.tobytes()),
            media_type="image/jpeg"
        )
    except Exception as e:
        logger.error(f"Error getting camera snapshot: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error",
        )


# Model endpoints
@router.get("/models", response_model=List[Dict[str, Any]])
async def list_models(
    current_user: Dict[str, Any] = Depends(get_current_active_user)
):
    """
    List available models.
    
    Args:
        current_user: Current user information.
        
    Returns:
        List of models.
        
    Raises:
        HTTPException: If listing fails.
    """
    try:
        # Get model manager
        model_manager = get_model_manager()
        
        # List models
        models = model_manager.list_models()
        
        return models
    except Exception as e:
        logger.error(f"Error listing models: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error",
        )


@router.get("/models/{model_id}", response_model=Dict[str, Any])
async def get_model(
    model_id: str,
    current_user: Dict[str, Any] = Depends(get_current_active_user)
):
    """
    Get model information.
    
    Args:
        model_id: Model ID.
        current_user: Current user information.
        
    Returns:
        Model information.
        
    Raises:
        HTTPException: If model not found.
    """
    try:
        # Get model manager
        model_manager = get_model_manager()
        
        # Get model
        model = model_manager.get_model(model_id)
        
        if not model:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Model not found: {model_id}",
            )
        
        return model
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting model: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error",
        )


@router.post("/models/{model_id}/configure", response_model=Dict[str, str])
async def configure_model(
    model_id: str,
    config: ModelConfig,
    current_user: Dict[str, Any] = Depends(check_admin_role)
):
    """
    Configure model parameter.
    
    Args:
        model_id: Model ID.
        config: Model configuration data.
        current_user: Current user information.
        
    Returns:
        Success message.
        
    Raises:
        HTTPException: If configuration fails.
    """
    try:
        # Get model manager
        model_manager = get_model_manager()
        
        # Configure model
        model_manager.configure_model(model_id, config.parameter, config.value)
        
        return {"message": f"Model {model_id} configured successfully"}
    except Exception as e:
        logger.error(f"Error configuring model: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error",
        )


@router.post("/models/{model_id}/update", response_model=Dict[str, str])
async def update_model(
    model_id: str,
    current_user: Dict[str, Any] = Depends(check_admin_role)
):
    """
    Update model to latest version.
    
    Args:
        model_id: Model ID.
        current_user: Current user information.
        
    Returns:
        Success message.
        
    Raises:
        HTTPException: If update fails.
    """
    try:
        # Get model manager
        model_manager = get_model_manager()
        
        # Update model
        model_manager.update_model(model_id)
        
        return {"message": f"Model {model_id} updated successfully"}
    except Exception as e:
        logger.error(f"Error updating model: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error",
        )


# Live inspection endpoints
@router.post("/live-inspection", response_model=Dict[str, Any])
async def run_live_inspection(
    request: LiveInspectionRequest,
    current_user: Dict[str, Any] = Depends(get_current_active_user)
):
    """
    Run live inspection with camera and model.
    
    Args:
        request: Live inspection request data.
        current_user: Current user information.
        
    Returns:
        Inspection results.
        
    Raises:
        HTTPException: If inspection fails.
    """
    try:
        # Get camera manager
        camera_manager = get_camera_manager()
        
        # Get model manager
        model_manager = get_model_manager()
        
        # Get Jetson client
        jetson_client = get_jetson_client()
        
        # Get snapshot from camera
        image = camera_manager.get_snapshot(request.camera_id)
        
        if image is None:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to get snapshot from camera",
            )
        
        # Run inference
        start_time = time.time()
        results = jetson_client.run_inference(image, request.model_id)
        processing_time = (time.time() - start_time) * 1000  # Convert to milliseconds
        
        # Check if production run ID is provided
        if request.production_run_id:
            # Get database manager
            db = get_database_manager()
            
            # Add inspection to database
            inspection_id = db.add_inspection(
                production_run_id=request.production_run_id,
                camera_id=request.camera_id,
                model_id=request.model_id,
                image=image,
                processing_time=processing_time,
                passed=len(results["detections"]) == 0,
                confidence=results.get("confidence")
            )
            
            # Add defects to database
            for detection in results["detections"]:
                db.add_defect(
                    inspection_id=inspection_id,
                    defect_type=DefectType[detection["class"].upper()],
                    x=detection["x"],
                    y=detection["y"],
                    width=detection["width"],
                    height=detection["height"],
                    confidence=detection["confidence"],
                    severity=SeverityLevel.MEDIUM,
                    description=f"Detected {detection['class']}"
                )
            
            # Add inspection ID to results
            results["inspection_id"] = inspection_id
        
        # Add processing time to results
        results["processing_time"] = processing_time
        
        return results
    except Exception as e:
        logger.error(f"Error running live inspection: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error",
        )


@router.post("/live-inspection/with-image", response_model=Dict[str, Any])
async def run_live_inspection_with_image(
    model_id: str = Form(...),
    production_run_id: Optional[str] = Form(None),
    image: UploadFile = File(...),
    current_user: Dict[str, Any] = Depends(get_current_active_user)
):
    """
    Run live inspection with uploaded image and model.
    
    Args:
        model_id: Model ID.
        production_run_id: Production run ID.
        image: Image file.
        current_user: Current user information.
        
    Returns:
        Inspection results.
        
    Raises:
        HTTPException: If inspection fails.
    """
    try:
        # Read image
        image_data = await image.read()
        
        # Convert to numpy array
        nparr = np.frombuffer(image_data, np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        
        if img is None:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid image format",
            )
        
        # Get model manager
        model_manager = get_model_manager()
        
        # Get Jetson client
        jetson_client = get_jetson_client()
        
        # Run inference
        start_time = time.time()
        results = jetson_client.run_inference(img, model_id)
        processing_time = (time.time() - start_time) * 1000  # Convert to milliseconds
        
        # Check if production run ID is provided
        if production_run_id:
            # Get database manager
            db = get_database_manager()
            
            # Add inspection to database
            inspection_id = db.add_inspection(
                production_run_id=production_run_id,
                camera_id="uploaded",
                model_id=model_id,
                image=img,
                processing_time=processing_time,
                passed=len(results["detections"]) == 0,
                confidence=results.get("confidence")
            )
            
            # Add defects to database
            for detection in results["detections"]:
                db.add_defect(
                    inspection_id=inspection_id,
                    defect_type=DefectType[detection["class"].upper()],
                    x=detection["x"],
                    y=detection["y"],
                    width=detection["width"],
                    height=detection["height"],
                    confidence=detection["confidence"],
                    severity=SeverityLevel.MEDIUM,
                    description=f"Detected {detection['class']}"
                )
            
            # Add inspection ID to results
            results["inspection_id"] = inspection_id
        
        # Add processing time to results
        results["processing_time"] = processing_time
        
        return results
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error running live inspection with image: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error",
        )


# System status endpoint
@router.get("/system/status", response_model=SystemStatusResponse)
async def get_system_status(
    current_user: Dict[str, Any] = Depends(get_current_active_user)
):
    """
    Get system status.
    
    Args:
        current_user: Current user information.
        
    Returns:
        System status.
        
    Raises:
        HTTPException: If getting status fails.
    """
    try:
        # Get database manager
        db = get_database_manager()
        
        # Get camera manager
        camera_manager = get_camera_manager()
        
        # Get model manager
        model_manager = get_model_manager()
        
        # Get Jetson client
        jetson_client = get_jetson_client()
        
        # Get database size
        db_size = db.get_database_size()
        
        # Get image storage size
        img_size = db.get_image_storage_size()
        
        # Get camera status
        camera_status = {}
        for camera in camera_manager.list_cameras():
            camera_status[camera["id"]] = camera["status"]
        
        # Get model status
        model_status = {}
        for model in model_manager.list_models():
            model_status[model["id"]] = model["status"]
        
        # Get Jetson status
        jetson_status = jetson_client.get_status()
        
        # Get uptime
        uptime = time.time() - START_TIME
        
        return {
            "status": "running",
            "version": "1.0.0",
            "uptime": uptime,
            "database_size": db_size,
            "image_storage_size": img_size,
            "camera_status": camera_status,
            "model_status": model_status,
            "jetson_status": jetson_status
        }
    except Exception as e:
        logger.error(f"Error getting system status: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error",
        )


# Create FastAPI app
app = FastAPI(
    title="OPSC Sandwich Quality Inspection API",
    description="API for Crustless Creations sandwich quality inspection system",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, replace with specific origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include router
app.include_router(router)

# Start time for uptime calculation
START_TIME = time.time()


# Startup event
@app.on_event("startup")
async def startup_event():
    """Startup event handler."""
    logger.info("Starting API server")


# Shutdown event
@app.on_event("shutdown")
async def shutdown_event():
    """Shutdown event handler."""
    logger.info("Shutting down API server")
    
    # Close database connection
    db = get_database_manager()
    db.close()


# Root endpoint
@app.get("/")
async def root():
    """Root endpoint."""
    return {
        "message": "OPSC Sandwich Quality Inspection API",
        "version": "1.0.0",
        "docs_url": "/docs"
    }


# Health check endpoint
@app.get("/health")
async def health_check():
    """Health check endpoint."""
    return {"status": "ok"}


if __name__ == "__main__":
    import uvicorn
    
    # Run server
    uvicorn.run(
        "api:app",
        host="0.0.0.0",
        port=8000,
        reload=True
    )
