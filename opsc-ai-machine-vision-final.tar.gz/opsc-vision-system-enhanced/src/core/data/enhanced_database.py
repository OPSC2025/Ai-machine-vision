import os
import json
import sqlite3
import logging
import datetime
import threading
import pandas as pd
from typing import Dict, List, Any, Optional, Tuple, Union
from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, Boolean, ForeignKey, Text, LargeBinary, Index, func, desc, asc
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship, scoped_session
from sqlalchemy.pool import QueuePool
from sqlalchemy.sql import text
from sqlalchemy.exc import SQLAlchemyError
from contextlib import contextmanager

from src.utils.config import Config
from src.utils.logging import get_logger
from src.core.data.schema_manager import SchemaManager
from src.core.data.migrations import MigrationManager
from src.core.cloud.azure_sync import AzureSyncManager

Base = declarative_base()

# Define database models with proper relationships and indexes
class ProductionRun(Base):
    __tablename__ = 'production_runs'
    
    id = Column(Integer, primary_key=True)
    run_id = Column(String(50), unique=True, index=True, nullable=False)
    start_time = Column(DateTime, nullable=False, index=True)
    end_time = Column(DateTime, index=True)
    product_type = Column(String(100), nullable=False, index=True)
    lot_number = Column(String(50), nullable=False, index=True)
    operator_id = Column(String(50), index=True)
    line_id = Column(String(50), index=True)
    status = Column(String(20), nullable=False, index=True)
    total_items = Column(Integer, default=0)
    defect_items = Column(Integer, default=0)
    rejected_items = Column(Integer, default=0)
    notes = Column(Text)
    
    # Relationships
    defects = relationship("DefectRecord", back_populates="production_run", cascade="all, delete-orphan")
    events = relationship("SystemEvent", back_populates="production_run", cascade="all, delete-orphan")
    
    # Indexes
    __table_args__ = (
        Index('idx_run_lot_product', 'run_id', 'lot_number', 'product_type'),
        Index('idx_run_time_range', 'start_time', 'end_time'),
    )

class DefectRecord(Base):
    __tablename__ = 'defect_records'
    
    id = Column(Integer, primary_key=True)
    production_run_id = Column(Integer, ForeignKey('production_runs.id', ondelete='CASCADE'), nullable=False, index=True)
    timestamp = Column(DateTime, nullable=False, index=True)
    defect_type = Column(String(50), nullable=False, index=True)
    defect_location = Column(String(50), index=True)
    confidence = Column(Float, nullable=False)
    severity = Column(String(20), index=True)
    camera_id = Column(String(20), index=True)
    image_path = Column(String(255))
    thumbnail_path = Column(String(255))
    rejected = Column(Boolean, default=False, index=True)
    rejection_timestamp = Column(DateTime, index=True)
    plc_response_time = Column(Float)  # in milliseconds
    model_version = Column(String(50), index=True)
    inference_time = Column(Float)  # in milliseconds
    metadata = Column(Text)  # JSON string for additional metadata
    
    # Relationships
    production_run = relationship("ProductionRun", back_populates="defects")
    
    # Indexes
    __table_args__ = (
        Index('idx_defect_type_confidence', 'defect_type', 'confidence'),
        Index('idx_defect_timestamp_camera', 'timestamp', 'camera_id'),
        Index('idx_defect_rejected_severity', 'rejected', 'severity'),
    )

class SystemEvent(Base):
    __tablename__ = 'system_events'
    
    id = Column(Integer, primary_key=True)
    production_run_id = Column(Integer, ForeignKey('production_runs.id', ondelete='CASCADE'), nullable=True, index=True)
    timestamp = Column(DateTime, nullable=False, index=True)
    event_type = Column(String(50), nullable=False, index=True)
    component = Column(String(50), index=True)
    severity = Column(String(20), nullable=False, index=True)
    message = Column(Text, nullable=False)
    details = Column(Text)  # JSON string for additional details
    acknowledged = Column(Boolean, default=False, index=True)
    acknowledged_by = Column(String(50))
    acknowledged_time = Column(DateTime)
    
    # Relationships
    production_run = relationship("ProductionRun", back_populates="events")
    
    # Indexes
    __table_args__ = (
        Index('idx_event_type_severity', 'event_type', 'severity'),
        Index('idx_event_timestamp_component', 'timestamp', 'component'),
    )

class ModelVersion(Base):
    __tablename__ = 'model_versions'
    
    id = Column(Integer, primary_key=True)
    model_id = Column(String(100), nullable=False, index=True)
    version = Column(String(50), nullable=False, index=True)
    created_at = Column(DateTime, nullable=False, index=True)
    deployed_at = Column(DateTime, index=True)
    active = Column(Boolean, default=False, index=True)
    model_type = Column(String(50), nullable=False, index=True)
    framework = Column(String(50))
    accuracy = Column(Float)
    precision = Column(Float)
    recall = Column(Float)
    f1_score = Column(Float)
    training_dataset = Column(String(255))
    training_parameters = Column(Text)  # JSON string
    model_path = Column(String(255))
    metadata = Column(Text)  # JSON string
    
    # Indexes
    __table_args__ = (
        Index('idx_model_version_active', 'model_id', 'version', 'active', unique=True),
    )

class PerformanceMetric(Base):
    __tablename__ = 'performance_metrics'
    
    id = Column(Integer, primary_key=True)
    timestamp = Column(DateTime, nullable=False, index=True)
    metric_type = Column(String(50), nullable=False, index=True)
    component = Column(String(50), nullable=False, index=True)
    value = Column(Float, nullable=False)
    unit = Column(String(20))
    context = Column(Text)  # JSON string for additional context
    
    # Indexes
    __table_args__ = (
        Index('idx_metric_type_component', 'metric_type', 'component'),
        Index('idx_metric_timestamp', 'timestamp'),
    )

class EnhancedDatabaseManager:
    """
    Enhanced database manager for the OPSC Sandwich Quality Inspection System.
    Provides optimized database operations, transaction management, connection pooling,
    and data archiving capabilities.
    """
    
    def __init__(self, config: Config):
        """
        Initialize the database manager with configuration.
        
        Args:
            config: Application configuration object
        """
        self.config = config
        self.logger = get_logger("EnhancedDatabaseManager")
        self.db_path = os.path.expanduser(config.get("database.path", "~/opsc-vision-system/data/database/opsc.db"))
        self.db_dir = os.path.dirname(self.db_path)
        self.archive_path = os.path.join(self.db_dir, "archive")
        self.connection_string = f"sqlite:///{self.db_path}"
        self.engine = None
        self.Session = None
        self._session_factory = None
        self._lock = threading.RLock()
        self.schema_manager = SchemaManager(self)
        self.migration_manager = MigrationManager(self)
        self.azure_sync = AzureSyncManager(config)
        
        # Initialize database
        self._initialize_database()
    
    def _initialize_database(self):
        """Initialize the database, create directories if needed, and set up connection pool."""
        try:
            # Create database directory if it doesn't exist
            os.makedirs(self.db_dir, exist_ok=True)
            os.makedirs(self.archive_path, exist_ok=True)
            
            # Create database engine with connection pooling
            self.engine = create_engine(
                self.connection_string,
                poolclass=QueuePool,
                pool_size=self.config.get("database.pool_size", 10),
                max_overflow=self.config.get("database.max_overflow", 20),
                pool_timeout=self.config.get("database.pool_timeout", 30),
                pool_recycle=self.config.get("database.pool_recycle", 3600),
                connect_args={"check_same_thread": False}
            )
            
            # Create session factory
            self._session_factory = sessionmaker(bind=self.engine)
            self.Session = scoped_session(self._session_factory)
            
            # Create tables if they don't exist
            Base.metadata.create_all(self.engine)
            
            # Run migrations if needed
            self.migration_manager.run_migrations()
            
            self.logger.info("Database initialized successfully")
        except Exception as e:
            self.logger.error(f"Failed to initialize database: {str(e)}")
            raise
    
    @contextmanager
    def session_scope(self):
        """
        Provide a transactional scope around a series of operations.
        
        Yields:
            SQLAlchemy session object
        """
        session = self.Session()
        try:
            yield session
            session.commit()
        except Exception as e:
            session.rollback()
            self.logger.error(f"Database transaction error: {str(e)}")
            raise
        finally:
            session.close()
    
    def optimize_database(self):
        """
        Optimize the database by running VACUUM and analyzing tables.
        """
        try:
            with self._lock:
                # Connect directly to SQLite for VACUUM operation
                conn = sqlite3.connect(self.db_path)
                cursor = conn.cursor()
                
                # Run VACUUM to rebuild the database file
                self.logger.info("Running VACUUM on database")
                cursor.execute("VACUUM")
                
                # Analyze tables for query optimization
                self.logger.info("Analyzing database tables")
                cursor.execute("ANALYZE")
                
                # Optimize indexes
                self.logger.info("Optimizing database indexes")
                cursor.execute("PRAGMA optimize")
                
                conn.close()
                self.logger.info("Database optimization completed")
        except Exception as e:
            self.logger.error(f"Database optimization failed: {str(e)}")
            raise
    
    def create_production_run(self, run_data: Dict[str, Any]) -> str:
        """
        Create a new production run record.
        
        Args:
            run_data: Dictionary containing production run data
            
        Returns:
            run_id: The ID of the created production run
        """
        try:
            with self.session_scope() as session:
                # Generate a unique run ID if not provided
                if 'run_id' not in run_data:
                    timestamp = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
                    run_data['run_id'] = f"RUN-{timestamp}-{run_data.get('product_type', 'UNKNOWN')[:3].upper()}"
                
                # Ensure start_time is set
                if 'start_time' not in run_data:
                    run_data['start_time'] = datetime.datetime.now()
                
                # Set initial status if not provided
                if 'status' not in run_data:
                    run_data['status'] = 'ACTIVE'
                
                # Create production run record
                production_run = ProductionRun(**run_data)
                session.add(production_run)
                session.flush()  # Flush to get the ID
                
                # Log the event
                event = SystemEvent(
                    production_run_id=production_run.id,
                    timestamp=datetime.datetime.now(),
                    event_type='PRODUCTION_RUN_STARTED',
                    component='DATABASE',
                    severity='INFO',
                    message=f"Production run {run_data['run_id']} started",
                    details=json.dumps(run_data)
                )
                session.add(event)
                
                return run_data['run_id']
        except Exception as e:
            self.logger.error(f"Failed to create production run: {str(e)}")
            raise
    
    def end_production_run(self, run_id: str) -> bool:
        """
        End a production run by setting its end time and status.
        
        Args:
            run_id: The ID of the production run to end
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            with self.session_scope() as session:
                # Find the production run
                production_run = session.query(ProductionRun).filter(ProductionRun.run_id == run_id).first()
                
                if not production_run:
                    self.logger.warning(f"Production run {run_id} not found")
                    return False
                
                # Set end time and status
                production_run.end_time = datetime.datetime.now()
                production_run.status = 'COMPLETED'
                
                # Log the event
                event = SystemEvent(
                    production_run_id=production_run.id,
                    timestamp=datetime.datetime.now(),
                    event_type='PRODUCTION_RUN_COMPLETED',
                    component='DATABASE',
                    severity='INFO',
                    message=f"Production run {run_id} completed",
                    details=json.dumps({
                        'total_items': production_run.total_items,
                        'defect_items': production_run.defect_items,
                        'rejected_items': production_run.rejected_items,
                        'duration_minutes': (production_run.end_time - production_run.start_time).total_seconds() / 60
                    })
                )
                session.add(event)
                
                return True
        except Exception as e:
            self.logger.error(f"Failed to end production run: {str(e)}")
            raise
    
    def record_defect(self, defect_data: Dict[str, Any]) -> int:
        """
        Record a defect detection.
        
        Args:
            defect_data: Dictionary containing defect data
            
        Returns:
            int: The ID of the created defect record
        """
        try:
            with self.session_scope() as session:
                # Find the production run by run_id
                run_id = defect_data.pop('run_id', None)
                if not run_id:
                    raise ValueError("Production run ID (run_id) is required")
                
                production_run = session.query(ProductionRun).filter(ProductionRun.run_id == run_id).first()
                if not production_run:
                    raise ValueError(f"Production run {run_id} not found")
                
                # Set production run ID
                defect_data['production_run_id'] = production_run.id
                
                # Ensure timestamp is set
                if 'timestamp' not in defect_data:
                    defect_data['timestamp'] = datetime.datetime.now()
                
                # Create defect record
                defect_record = DefectRecord(**defect_data)
                session.add(defect_record)
                session.flush()  # Flush to get the ID
                
                # Update production run statistics
                production_run.defect_items += 1
                if defect_data.get('rejected', False):
                    production_run.rejected_items += 1
                
                # Increment total items if this is a new item
                production_run.total_items += 1
                
                return defect_record.id
        except Exception as e:
            self.logger.error(f"Failed to record defect: {str(e)}")
            raise
    
    def update_defect_rejection(self, defect_id: int, rejected: bool, plc_response_time: float = None) -> bool:
        """
        Update a defect record with rejection information.
        
        Args:
            defect_id: The ID of the defect record
            rejected: Whether the item was rejected
            plc_response_time: PLC response time in milliseconds
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            with self.session_scope() as session:
                # Find the defect record
                defect_record = session.query(DefectRecord).filter(DefectRecord.id == defect_id).first()
                
                if not defect_record:
                    self.logger.warning(f"Defect record {defect_id} not found")
                    return False
                
                # Update rejection information
                defect_record.rejected = rejected
                if rejected:
                    defect_record.rejection_timestamp = datetime.datetime.now()
                if plc_response_time is not None:
                    defect_record.plc_response_time = plc_response_time
                
                # Update production run statistics if rejection status changed
                production_run = defect_record.production_run
                if rejected and not defect_record.rejected:
                    production_run.rejected_items += 1
                elif not rejected and defect_record.rejected:
                    production_run.rejected_items -= 1
                
                return True
        except Exception as e:
            self.logger.error(f"Failed to update defect rejection: {str(e)}")
            raise
    
    def record_system_event(self, event_data: Dict[str, Any]) -> int:
        """
        Record a system event.
        
        Args:
            event_data: Dictionary containing event data
            
        Returns:
            int: The ID of the created event record
        """
        try:
            with self.session_scope() as session:
                # Find the production run by run_id if provided
                run_id = event_data.pop('run_id', None)
                if run_id:
                    production_run = session.query(ProductionRun).filter(ProductionRun.run_id == run_id).first()
                    if production_run:
                        event_data['production_run_id'] = production_run.id
                
                # Ensure timestamp is set
                if 'timestamp' not in event_data:
                    event_data['timestamp'] = datetime.datetime.now()
                
                # Create event record
                event = SystemEvent(**event_data)
                session.add(event)
                session.flush()  # Flush to get the ID
                
                return event.id
        except Exception as e:
            self.logger.error(f"Failed to record system event: {str(e)}")
            raise
    
    def register_model_version(self, model_data: Dict[str, Any]) -> int:
        """
        Register a new model version.
        
        Args:
            model_data: Dictionary containing model version data
            
        Returns:
            int: The ID of the created model version record
        """
        try:
            with self.session_scope() as session:
                # Ensure created_at is set
                if 'created_at' not in model_data:
                    model_data['created_at'] = datetime.datetime.now()
                
                # Create model version record
                model_version = ModelVersion(**model_data)
                session.add(model_version)
                session.flush()  # Flush to get the ID
                
                # Log the event
                event = SystemEvent(
                    timestamp=datetime.datetime.now(),
                    event_type='MODEL_VERSION_REGISTERED',
                    component='MODEL_MANAGER',
                    severity='INFO',
                    message=f"Model version {model_data['model_id']} v{model_data['version']} registered",
                    details=json.dumps({
                        'model_id': model_data['model_id'],
                        'version': model_data['version'],
                        'model_type': model_data['model_type'],
                        'accuracy': model_data.get('accuracy'),
                        'precision': model_data.get('precision'),
                        'recall': model_data.get('recall'),
                        'f1_score': model_data.get('f1_score')
                    })
                )
                session.add(event)
                
                return model_version.id
        except Exception as e:
            self.logger.error(f"Failed to register model version: {str(e)}")
            raise
    
    def activate_model_version(self, model_id: str, version: str) -> bool:
        """
        Activate a specific model version and deactivate others of the same model.
        
        Args:
            model_id: The ID of the model
            version: The version to activate
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            with self.session_scope() as session:
                # Deactivate all versions of this model
                session.query(ModelVersion).filter(
                    ModelVersion.model_id == model_id,
                    ModelVersion.active == True
                ).update({'active': False})
                
                # Find and activate the specified version
                model_version = session.query(ModelVersion).filter(
                    ModelVersion.model_id == model_id,
                    ModelVersion.version == version
                ).first()
                
                if not model_version:
                    self.logger.warning(f"Model version {model_id} v{version} not found")
                    return False
                
                model_version.active = True
                model_version.deployed_at = datetime.datetime.now()
                
                # Log the event
                event = SystemEvent(
                    timestamp=datetime.datetime.now(),
                    event_type='MODEL_VERSION_ACTIVATED',
                    component='MODEL_MANAGER',
                    severity='INFO',
                    message=f"Model version {model_id} v{version} activated",
                    details=json.dumps({
                        'model_id': model_id,
                        'version': version,
                        'model_type': model_version.model_type,
                        'accuracy': model_version.accuracy,
                        'precision': model_version.precision,
                        'recall': model_version.recall,
                        'f1_score': model_version.f1_score
                    })
                )
                session.add(event)
                
                return True
        except Exception as e:
            self.logger.error(f"Failed to activate model version: {str(e)}")
            raise
    
    def get_active_model_version(self, model_id: str) -> Optional[Dict[str, Any]]:
        """
        Get the active version of a model.
        
        Args:
            model_id: The ID of the model
            
        Returns:
            Optional[Dict[str, Any]]: Model version data if found, None otherwise
        """
        try:
            with self.session_scope() as session:
                model_version = session.query(ModelVersion).filter(
                    ModelVersion.model_id == model_id,
                    ModelVersion.active == True
                ).first()
                
                if not model_version:
                    return None
                
                # Convert to dictionary
                model_data = {c.name: getattr(model_version, c.name) for c in model_version.__table__.columns}
                
                # Parse JSON fields
                if model_data.get('training_parameters'):
                    model_data['training_parameters'] = json.loads(model_data['training_parameters'])
                if model_data.get('metadata'):
                    model_data['metadata'] = json.loads(model_data['metadata'])
                
                return model_data
        except Exception as e:
            self.logger.error(f"Failed to get active model version: {str(e)}")
            raise
    
    def record_performance_metric(self, metric_data: Dict[str, Any]) -> int:
        """
        Record a performance metric.
        
        Args:
            metric_data: Dictionary containing metric data
            
        Returns:
            int: The ID of the created metric record
        """
        try:
            with self.session_scope() as session:
                # Ensure timestamp is set
                if 'timestamp' not in metric_data:
                    metric_data['timestamp'] = datetime.datetime.now()
                
                # Create metric record
                metric = PerformanceMetric(**metric_data)
                session.add(metric)
                session.flush()  # Flush to get the ID
                
                return metric.id
        except Exception as e:
            self.logger.error(f"Failed to record performance metric: {str(e)}")
            raise
    
    def get_production_run_statistics(self, run_id: str) -> Optional[Dict[str, Any]]:
        """
        Get statistics for a production run.
        
        Args:
            run_id: The ID of the production run
            
        Returns:
            Optional[Dict[str, Any]]: Statistics if found, None otherwise
        """
        try:
            with self.session_scope() as session:
                production_run = session.query(ProductionRun).filter(ProductionRun.run_id == run_id).first()
                
                if not production_run:
                    return None
                
                # Get defect statistics
                defect_stats = session.query(
                    DefectRecord.defect_type,
                    func.count(DefectRecord.id).label('count'),
                    func.avg(DefectRecord.confidence).label('avg_confidence'),
                    func.sum(DefectRecord.rejected.cast(Integer)).label('rejected_count')
                ).filter(
                    DefectRecord.production_run_id == production_run.id
                ).group_by(
                    DefectRecord.defect_type
                ).all()
                
                # Convert to dictionary
                defect_stats_dict = {
                    stat.defect_type: {
                        'count': stat.count,
                        'avg_confidence': float(stat.avg_confidence) if stat.avg_confidence else 0,
                        'rejected_count': stat.rejected_count
                    }
                    for stat in defect_stats
                }
                
                # Calculate duration if run is completed
                duration_minutes = None
                if production_run.end_time:
                    duration_minutes = (production_run.end_time - production_run.start_time).total_seconds() / 60
                
                # Compile statistics
                statistics = {
                    'run_id': production_run.run_id,
                    'product_type': production_run.product_type,
                    'lot_number': production_run.lot_number,
                    'start_time': production_run.start_time,
                    'end_time': production_run.end_time,
                    'status': production_run.status,
                    'duration_minutes': duration_minutes,
                    'total_items': production_run.total_items,
                    'defect_items': production_run.defect_items,
                    'rejected_items': production_run.rejected_items,
                    'defect_rate': (production_run.defect_items / production_run.total_items * 100) if production_run.total_items > 0 else 0,
                    'rejection_rate': (production_run.rejected_items / production_run.total_items * 100) if production_run.total_items > 0 else 0,
                    'defect_types': defect_stats_dict
                }
                
                return statistics
        except Exception as e:
            self.logger.error(f"Failed to get production run statistics: {str(e)}")
            raise
    
    def get_defects_by_criteria(self, criteria: Dict[str, Any], limit: int = 100, offset: int = 0) -> Tuple[List[Dict[str, Any]], int]:
        """
        Get defect records by criteria.
        
        Args:
            criteria: Dictionary containing search criteria
            limit: Maximum number of records to return
            offset: Offset for pagination
            
        Returns:
            Tuple[List[Dict[str, Any]], int]: List of defect records and total count
        """
        try:
            with self.session_scope() as session:
                # Build query
                query = session.query(DefectRecord)
                
                # Apply filters
                if 'run_id' in criteria:
                    production_run = session.query(ProductionRun).filter(ProductionRun.run_id == criteria['run_id']).first()
                    if production_run:
                        query = query.filter(DefectRecord.production_run_id == production_run.id)
                
                if 'defect_type' in criteria:
                    query = query.filter(DefectRecord.defect_type == criteria['defect_type'])
                
                if 'severity' in criteria:
                    query = query.filter(DefectRecord.severity == criteria['severity'])
                
                if 'camera_id' in criteria:
                    query = query.filter(DefectRecord.camera_id == criteria['camera_id'])
                
                if 'rejected' in criteria:
                    query = query.filter(DefectRecord.rejected == criteria['rejected'])
                
                if 'confidence_min' in criteria:
                    query = query.filter(DefectRecord.confidence >= criteria['confidence_min'])
                
                if 'confidence_max' in criteria:
                    query = query.filter(DefectRecord.confidence <= criteria['confidence_max'])
                
                if 'start_date' in criteria:
                    query = query.filter(DefectRecord.timestamp >= criteria['start_date'])
                
                if 'end_date' in criteria:
                    query = query.filter(DefectRecord.timestamp <= criteria['end_date'])
                
                if 'model_version' in criteria:
                    query = query.filter(DefectRecord.model_version == criteria['model_version'])
                
                # Get total count
                total_count = query.count()
                
                # Apply sorting
                sort_field = criteria.get('sort_field', 'timestamp')
                sort_direction = criteria.get('sort_direction', 'desc')
                
                if hasattr(DefectRecord, sort_field):
                    sort_column = getattr(DefectRecord, sort_field)
                    if sort_direction.lower() == 'asc':
                        query = query.order_by(asc(sort_column))
                    else:
                        query = query.order_by(desc(sort_column))
                
                # Apply pagination
                query = query.limit(limit).offset(offset)
                
                # Execute query
                defect_records = query.all()
                
                # Convert to dictionaries
                result = []
                for record in defect_records:
                    record_dict = {c.name: getattr(record, c.name) for c in record.__table__.columns}
                    
                    # Get production run information
                    production_run = record.production_run
                    record_dict['run_id'] = production_run.run_id
                    record_dict['product_type'] = production_run.product_type
                    record_dict['lot_number'] = production_run.lot_number
                    
                    # Parse JSON fields
                    if record_dict.get('metadata'):
                        try:
                            record_dict['metadata'] = json.loads(record_dict['metadata'])
                        except:
                            pass
                    
                    result.append(record_dict)
                
                return result, total_count
        except Exception as e:
            self.logger.error(f"Failed to get defects by criteria: {str(e)}")
            raise
    
    def archive_data(self, older_than_days: int = 90, archive_type: str = 'sqlite') -> str:
        """
        Archive old data to reduce database size.
        
        Args:
            older_than_days: Archive data older than this many days
            archive_type: Type of archive ('sqlite' or 'csv')
            
        Returns:
            str: Path to the archive file
        """
        try:
            cutoff_date = datetime.datetime.now() - datetime.timedelta(days=older_than_days)
            archive_timestamp = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
            
            if archive_type == 'sqlite':
                # Create a new SQLite database for the archive
                archive_path = os.path.join(self.archive_path, f"archive_{archive_timestamp}.db")
                archive_engine = create_engine(f"sqlite:///{archive_path}")
                
                # Create tables in the archive database
                Base.metadata.create_all(archive_engine)
                archive_session_factory = sessionmaker(bind=archive_engine)
                
                with self.session_scope() as session, archive_session_factory() as archive_session:
                    # Find old production runs
                    old_runs = session.query(ProductionRun).filter(
                        ProductionRun.start_time < cutoff_date,
                        ProductionRun.status == 'COMPLETED'
                    ).all()
                    
                    for run in old_runs:
                        # Copy production run to archive
                        archive_run = ProductionRun(**{c.name: getattr(run, c.name) for c in run.__table__.columns if c.name != 'id'})
                        archive_session.add(archive_run)
                        archive_session.flush()
                        
                        # Copy defects to archive
                        for defect in run.defects:
                            defect_dict = {c.name: getattr(defect, c.name) for c in defect.__table__.columns if c.name != 'id' and c.name != 'production_run_id'}
                            defect_dict['production_run_id'] = archive_run.id
                            archive_defect = DefectRecord(**defect_dict)
                            archive_session.add(archive_defect)
                        
                        # Copy events to archive
                        for event in run.events:
                            event_dict = {c.name: getattr(event, c.name) for c in event.__table__.columns if c.name != 'id' and c.name != 'production_run_id'}
                            event_dict['production_run_id'] = archive_run.id
                            archive_event = SystemEvent(**event_dict)
                            archive_session.add(archive_event)
                    
                    # Commit the archive
                    archive_session.commit()
                    
                    # Delete archived data from main database
                    for run in old_runs:
                        # Defects and events will be deleted automatically due to cascade
                        session.delete(run)
                
                # Optimize the main database after archiving
                self.optimize_database()
                
                # Log the archiving
                self.record_system_event({
                    'event_type': 'DATA_ARCHIVED',
                    'component': 'DATABASE',
                    'severity': 'INFO',
                    'message': f"Archived data older than {older_than_days} days",
                    'details': json.dumps({
                        'archive_type': 'sqlite',
                        'archive_path': archive_path,
                        'cutoff_date': cutoff_date.isoformat(),
                        'runs_archived': len(old_runs)
                    })
                })
                
                return archive_path
                
            elif archive_type == 'csv':
                # Create a directory for CSV archives
                archive_dir = os.path.join(self.archive_path, f"archive_{archive_timestamp}")
                os.makedirs(archive_dir, exist_ok=True)
                
                with self.session_scope() as session:
                    # Find old production runs
                    old_runs = session.query(ProductionRun).filter(
                        ProductionRun.start_time < cutoff_date,
                        ProductionRun.status == 'COMPLETED'
                    ).all()
                    
                    # Export production runs to CSV
                    runs_data = [{c.name: getattr(run, c.name) for c in run.__table__.columns} for run in old_runs]
                    if runs_data:
                        runs_df = pd.DataFrame(runs_data)
                        runs_df.to_csv(os.path.join(archive_dir, "production_runs.csv"), index=False)
                    
                    # Export defects to CSV
                    defects_data = []
                    for run in old_runs:
                        for defect in run.defects:
                            defect_dict = {c.name: getattr(defect, c.name) for c in defect.__table__.columns}
                            defect_dict['run_id'] = run.run_id
                            defects_data.append(defect_dict)
                    
                    if defects_data:
                        defects_df = pd.DataFrame(defects_data)
                        defects_df.to_csv(os.path.join(archive_dir, "defect_records.csv"), index=False)
                    
                    # Export events to CSV
                    events_data = []
                    for run in old_runs:
                        for event in run.events:
                            event_dict = {c.name: getattr(event, c.name) for c in event.__table__.columns}
                            event_dict['run_id'] = run.run_id
                            events_data.append(event_dict)
                    
                    if events_data:
                        events_df = pd.DataFrame(events_data)
                        events_df.to_csv(os.path.join(archive_dir, "system_events.csv"), index=False)
                    
                    # Delete archived data from main database
                    for run in old_runs:
                        # Defects and events will be deleted automatically due to cascade
                        session.delete(run)
                
                # Optimize the main database after archiving
                self.optimize_database()
                
                # Log the archiving
                self.record_system_event({
                    'event_type': 'DATA_ARCHIVED',
                    'component': 'DATABASE',
                    'severity': 'INFO',
                    'message': f"Archived data older than {older_than_days} days",
                    'details': json.dumps({
                        'archive_type': 'csv',
                        'archive_dir': archive_dir,
                        'cutoff_date': cutoff_date.isoformat(),
                        'runs_archived': len(old_runs)
                    })
                })
                
                return archive_dir
            else:
                raise ValueError(f"Unsupported archive type: {archive_type}")
        except Exception as e:
            self.logger.error(f"Failed to archive data: {str(e)}")
            raise
    
    def sync_to_azure(self, days_to_sync: int = 30) -> bool:
        """
        Sync recent data to Azure cloud storage.
        
        Args:
            days_to_sync: Sync data from the last N days
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            cutoff_date = datetime.datetime.now() - datetime.timedelta(days=days_to_sync)
            
            with self.session_scope() as session:
                # Get recent production runs
                recent_runs = session.query(ProductionRun).filter(
                    ProductionRun.start_time >= cutoff_date
                ).all()
                
                # Prepare data for sync
                runs_data = []
                defects_data = []
                events_data = []
                
                for run in recent_runs:
                    # Add production run data
                    run_dict = {c.name: getattr(run, c.name) for c in run.__table__.columns}
                    runs_data.append(run_dict)
                    
                    # Add defect data
                    for defect in run.defects:
                        defect_dict = {c.name: getattr(defect, c.name) for c in defect.__table__.columns}
                        defect_dict['run_id'] = run.run_id
                        defects_data.append(defect_dict)
                    
                    # Add event data
                    for event in run.events:
                        event_dict = {c.name: getattr(event, c.name) for c in event.__table__.columns}
                        event_dict['run_id'] = run.run_id
                        events_data.append(event_dict)
                
                # Convert to DataFrames
                runs_df = pd.DataFrame(runs_data) if runs_data else pd.DataFrame()
                defects_df = pd.DataFrame(defects_data) if defects_data else pd.DataFrame()
                events_df = pd.DataFrame(events_data) if events_data else pd.DataFrame()
                
                # Sync to Azure
                sync_result = self.azure_sync.sync_dataframes({
                    'production_runs': runs_df,
                    'defect_records': defects_df,
                    'system_events': events_df
                })
                
                # Log the sync
                self.record_system_event({
                    'event_type': 'DATA_SYNCED_TO_AZURE',
                    'component': 'DATABASE',
                    'severity': 'INFO',
                    'message': f"Synced data from the last {days_to_sync} days to Azure",
                    'details': json.dumps({
                        'cutoff_date': cutoff_date.isoformat(),
                        'runs_synced': len(runs_data),
                        'defects_synced': len(defects_data),
                        'events_synced': len(events_data),
                        'sync_result': sync_result
                    })
                })
                
                return True
        except Exception as e:
            self.logger.error(f"Failed to sync data to Azure: {str(e)}")
            self.record_system_event({
                'event_type': 'DATA_SYNC_FAILED',
                'component': 'DATABASE',
                'severity': 'ERROR',
                'message': f"Failed to sync data to Azure: {str(e)}",
                'details': json.dumps({
                    'error': str(e)
                })
            })
            return False
    
    def get_database_statistics(self) -> Dict[str, Any]:
        """
        Get statistics about the database.
        
        Returns:
            Dict[str, Any]: Database statistics
        """
        try:
            with self.session_scope() as session:
                # Get table counts
                production_run_count = session.query(func.count(ProductionRun.id)).scalar()
                defect_record_count = session.query(func.count(DefectRecord.id)).scalar()
                system_event_count = session.query(func.count(SystemEvent.id)).scalar()
                model_version_count = session.query(func.count(ModelVersion.id)).scalar()
                performance_metric_count = session.query(func.count(PerformanceMetric.id)).scalar()
                
                # Get database file size
                db_size_bytes = os.path.getsize(self.db_path) if os.path.exists(self.db_path) else 0
                db_size_mb = db_size_bytes / (1024 * 1024)
                
                # Get date ranges
                oldest_run = session.query(func.min(ProductionRun.start_time)).scalar()
                newest_run = session.query(func.max(ProductionRun.start_time)).scalar()
                
                # Get defect statistics
                defect_type_stats = session.query(
                    DefectRecord.defect_type,
                    func.count(DefectRecord.id).label('count')
                ).group_by(
                    DefectRecord.defect_type
                ).all()
                
                defect_type_counts = {stat.defect_type: stat.count for stat in defect_type_stats}
                
                # Get rejection statistics
                rejected_count = session.query(func.sum(DefectRecord.rejected.cast(Integer))).scalar() or 0
                rejection_rate = rejected_count / defect_record_count if defect_record_count > 0 else 0
                
                # Compile statistics
                statistics = {
                    'database_size_mb': db_size_mb,
                    'table_counts': {
                        'production_runs': production_run_count,
                        'defect_records': defect_record_count,
                        'system_events': system_event_count,
                        'model_versions': model_version_count,
                        'performance_metrics': performance_metric_count
                    },
                    'date_range': {
                        'oldest_run': oldest_run,
                        'newest_run': newest_run
                    },
                    'defect_statistics': {
                        'total_defects': defect_record_count,
                        'defect_type_counts': defect_type_counts,
                        'rejected_count': rejected_count,
                        'rejection_rate': rejection_rate
                    }
                }
                
                return statistics
        except Exception as e:
            self.logger.error(f"Failed to get database statistics: {str(e)}")
            raise
    
    def backup_database(self, backup_path: str = None) -> str:
        """
        Create a backup of the database.
        
        Args:
            backup_path: Path to save the backup, if None, a default path will be used
            
        Returns:
            str: Path to the backup file
        """
        try:
            if backup_path is None:
                timestamp = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
                backup_path = os.path.join(self.db_dir, f"backup_{timestamp}.db")
            
            # Ensure the backup directory exists
            os.makedirs(os.path.dirname(backup_path), exist_ok=True)
            
            # Connect to the database
            conn = sqlite3.connect(self.db_path)
            
            # Create a backup
            backup_conn = sqlite3.connect(backup_path)
            conn.backup(backup_conn)
            
            # Close connections
            backup_conn.close()
            conn.close()
            
            # Log the backup
            self.record_system_event({
                'event_type': 'DATABASE_BACKUP_CREATED',
                'component': 'DATABASE',
                'severity': 'INFO',
                'message': f"Database backup created at {backup_path}",
                'details': json.dumps({
                    'backup_path': backup_path,
                    'timestamp': datetime.datetime.now().isoformat(),
                    'database_size_mb': os.path.getsize(backup_path) / (1024 * 1024)
                })
            })
            
            return backup_path
        except Exception as e:
            self.logger.error(f"Failed to backup database: {str(e)}")
            self.record_system_event({
                'event_type': 'DATABASE_BACKUP_FAILED',
                'component': 'DATABASE',
                'severity': 'ERROR',
                'message': f"Failed to backup database: {str(e)}",
                'details': json.dumps({
                    'error': str(e)
                })
            })
            raise
