"""
Database manager for the OPSC Sandwich Quality Inspection System.

This module provides utilities for database operations, including storing
detection results, inspection data, and system logs.

Version: 1.0.0
Last Updated: 2025-04-21
"""

import os
import sys
import time
import sqlite3
import logging
import threading
import json
import shutil
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Union, Any
import numpy as np
import cv2
from pathlib import Path

# Import detection result class
try:
    from ..models.roboflow.sandwich_defect_model import DetectionResult
except ImportError:
    # Define a minimal version for standalone usage
    from dataclasses import dataclass, field
    
    @dataclass
    class DetectionResult:
        defect_type: str
        confidence: float
        bbox: Tuple[float, float, float, float]
        image_id: str = ""
        timestamp: float = field(default_factory=time.time)

# Setup logging
logger = logging.getLogger(__name__)

class DatabaseManager:
    """
    Database manager for the OPSC Sandwich Quality Inspection System.
    
    This class provides methods for database operations, including storing
    detection results, inspection data, and system logs.
    """
    
    def __init__(
        self,
        db_path: str = "data/database/sandwich_inspection.db",
        enable_backup: bool = True,
        backup_interval: int = 86400,  # 24 hours
        backup_dir: Optional[str] = None,
        max_backups: int = 7
    ):
        """
        Initialize the database manager.
        
        Args:
            db_path: Path to SQLite database file
            enable_backup: Whether to enable automatic backups
            backup_interval: Backup interval in seconds
            backup_dir: Directory for database backups (if None, will use db_path directory)
            max_backups: Maximum number of backup files to keep
        """
        self.db_path = db_path
        self.enable_backup = enable_backup
        self.backup_interval = backup_interval
        self.max_backups = max_backups
        
        # Set backup directory
        if backup_dir is None:
            self.backup_dir = os.path.dirname(db_path)
        else:
            self.backup_dir = backup_dir
        
        # Create database directory if it doesn't exist
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        
        # Create backup directory if it doesn't exist and backups are enabled
        if self.enable_backup:
            os.makedirs(self.backup_dir, exist_ok=True)
        
        # Initialize database connection
        self.conn = None
        self.cursor = None
        self._connect()
        
        # Initialize backup thread
        self.backup_thread = None
        self.backup_stop_event = threading.Event()
        
        # Start backup thread if enabled
        if self.enable_backup:
            self._start_backup_thread()
    
    def _connect(self):
        """Connect to the database."""
        try:
            self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
            self.conn.row_factory = sqlite3.Row  # Return rows as dictionaries
            self.cursor = self.conn.cursor()
            logger.info(f"Connected to database: {self.db_path}")
        except Exception as e:
            logger.error(f"Error connecting to database: {e}")
            raise
    
    def initialize_schema(self):
        """Initialize database schema."""
        try:
            # Create detections table
            self.cursor.execute('''
                CREATE TABLE IF NOT EXISTS detections (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    camera_id TEXT NOT NULL,
                    timestamp REAL NOT NULL,
                    image_path TEXT,
                    num_defects INTEGER NOT NULL,
                    inspection_result TEXT NOT NULL
                )
            ''')
            
            # Create defects table
            self.cursor.execute('''
                CREATE TABLE IF NOT EXISTS defects (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    detection_id INTEGER NOT NULL,
                    defect_type TEXT NOT NULL,
                    confidence REAL NOT NULL,
                    bbox_x REAL NOT NULL,
                    bbox_y REAL NOT NULL,
                    bbox_width REAL NOT NULL,
                    bbox_height REAL NOT NULL,
                    FOREIGN KEY (detection_id) REFERENCES detections (id)
                )
            ''')
            
            # Create system_logs table
            self.cursor.execute('''
                CREATE TABLE IF NOT EXISTS system_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp REAL NOT NULL,
                    log_level TEXT NOT NULL,
                    component TEXT NOT NULL,
                    message TEXT NOT NULL,
                    details TEXT
                )
            ''')
            
            # Create statistics table
            self.cursor.execute('''
                CREATE TABLE IF NOT EXISTS statistics (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp REAL NOT NULL,
                    period_start REAL NOT NULL,
                    period_end REAL NOT NULL,
                    total_inspections INTEGER NOT NULL,
                    total_defects INTEGER NOT NULL,
                    defect_types TEXT NOT NULL,
                    defect_counts TEXT NOT NULL
                )
            ''')
            
            # Commit changes
            self.conn.commit()
            
            logger.info("Database schema initialized")
        except Exception as e:
            logger.error(f"Error initializing database schema: {e}")
            raise
    
    def save_detections(
        self,
        camera_id: str,
        image: np.ndarray,
        detections: List[DetectionResult],
        save_image: bool = True,
        image_dir: str = "data/images"
    ) -> int:
        """
        Save detection results to database.
        
        Args:
            camera_id: Camera identifier
            image: Image as numpy array
            detections: List of detection results
            save_image: Whether to save the image
            image_dir: Directory for saving images
        
        Returns:
            Detection ID
        """
        try:
            # Get current timestamp
            timestamp = time.time()
            
            # Save image if requested
            image_path = None
            if save_image and len(detections) > 0:
                # Create image directory if it doesn't exist
                os.makedirs(image_dir, exist_ok=True)
                
                # Generate image filename
                date_str = datetime.fromtimestamp(timestamp).strftime("%Y%m%d_%H%M%S")
                image_filename = f"{camera_id}_{date_str}.jpg"
                image_path = os.path.join(image_dir, image_filename)
                
                # Save image
                cv2.imwrite(image_path, image)
            
            # Determine inspection result
            inspection_result = "FAIL" if len(detections) > 0 else "PASS"
            
            # Insert detection record
            self.cursor.execute(
                '''
                INSERT INTO detections (
                    camera_id, timestamp, image_path, num_defects, inspection_result
                ) VALUES (?, ?, ?, ?, ?)
                ''',
                (camera_id, timestamp, image_path, len(detections), inspection_result)
            )
            
            # Get detection ID
            detection_id = self.cursor.lastrowid
            
            # Insert defect records
            for detection in detections:
                x, y, w, h = detection.bbox
                self.cursor.execute(
                    '''
                    INSERT INTO defects (
                        detection_id, defect_type, confidence,
                        bbox_x, bbox_y, bbox_width, bbox_height
                    ) VALUES (?, ?, ?, ?, ?, ?, ?)
                    ''',
                    (
                        detection_id, detection.defect_type, detection.confidence,
                        x, y, w, h
                    )
                )
            
            # Commit changes
            self.conn.commit()
            
            logger.info(f"Saved detection results: camera={camera_id}, defects={len(detections)}")
            
            return detection_id
        except Exception as e:
            logger.error(f"Error saving detection results: {e}")
            self.conn.rollback()
            raise
    
    def get_detection(self, detection_id: int) -> Dict[str, Any]:
        """
        Get detection record by ID.
        
        Args:
            detection_id: Detection ID
        
        Returns:
            Detection record as dictionary
        """
        try:
            # Get detection record
            self.cursor.execute(
                '''
                SELECT * FROM detections WHERE id = ?
                ''',
                (detection_id,)
            )
            detection = dict(self.cursor.fetchone())
            
            # Get defect records
            self.cursor.execute(
                '''
                SELECT * FROM defects WHERE detection_id = ?
                ''',
                (detection_id,)
            )
            defects = [dict(row) for row in self.cursor.fetchall()]
            
            # Add defects to detection record
            detection['defects'] = defects
            
            return detection
        except Exception as e:
            logger.error(f"Error getting detection record: {e}")
            raise
    
    def get_recent_detections(
        self,
        limit: int = 100,
        offset: int = 0,
        camera_id: Optional[str] = None,
        result: Optional[str] = None,
        start_time: Optional[float] = None,
        end_time: Optional[float] = None
    ) -> List[Dict[str, Any]]:
        """
        Get recent detection records.
        
        Args:
            limit: Maximum number of records to return
            offset: Offset for pagination
            camera_id: Filter by camera ID
            result: Filter by inspection result (PASS/FAIL)
            start_time: Filter by start time (timestamp)
            end_time: Filter by end time (timestamp)
        
        Returns:
            List of detection records
        """
        try:
            # Build query
            query = "SELECT * FROM detections"
            params = []
            
            # Add filters
            filters = []
            if camera_id is not None:
                filters.append("camera_id = ?")
                params.append(camera_id)
            if result is not None:
                filters.append("inspection_result = ?")
                params.append(result)
            if start_time is not None:
                filters.append("timestamp >= ?")
                params.append(start_time)
            if end_time is not None:
                filters.append("timestamp <= ?")
                params.append(end_time)
            
            # Add WHERE clause if filters exist
            if filters:
                query += " WHERE " + " AND ".join(filters)
            
            # Add ORDER BY, LIMIT, and OFFSET
            query += " ORDER BY timestamp DESC LIMIT ? OFFSET ?"
            params.extend([limit, offset])
            
            # Execute query
            self.cursor.execute(query, params)
            detections = [dict(row) for row in self.cursor.fetchall()]
            
            # Get defects for each detection
            for detection in detections:
                self.cursor.execute(
                    '''
                    SELECT * FROM defects WHERE detection_id = ?
                    ''',
                    (detection['id'],)
                )
                defects = [dict(row) for row in self.cursor.fetchall()]
                detection['defects'] = defects
            
            return detections
        except Exception as e:
            logger.error(f"Error getting recent detection records: {e}")
            raise
    
    def get_statistics(
        self,
        period: str = "day",
        start_time: Optional[float] = None,
        end_time: Optional[float] = None
    ) -> Dict[str, Any]:
        """
        Get statistics for a time period.
        
        Args:
            period: Time period (day, week, month, year)
            start_time: Custom start time (timestamp)
            end_time: Custom end time (timestamp)
        
        Returns:
            Statistics as dictionary
        """
        try:
            # Set time range based on period
            if start_time is None or end_time is None:
                now = datetime.now()
                if period == "day":
                    start_time = datetime(now.year, now.month, now.day).timestamp()
                    end_time = (datetime(now.year, now.month, now.day) + timedelta(days=1)).timestamp()
                elif period == "week":
                    start_time = (now - timedelta(days=now.weekday())).timestamp()
                    end_time = (now + timedelta(days=7 - now.weekday())).timestamp()
                elif period == "month":
                    start_time = datetime(now.year, now.month, 1).timestamp()
                    if now.month == 12:
                        end_time = datetime(now.year + 1, 1, 1).timestamp()
                    else:
                        end_time = datetime(now.year, now.month + 1, 1).timestamp()
                elif period == "year":
                    start_time = datetime(now.year, 1, 1).timestamp()
                    end_time = datetime(now.year + 1, 1, 1).timestamp()
                else:
                    raise ValueError(f"Invalid period: {period}")
            
            # Get total inspections
            self.cursor.execute(
                '''
                SELECT COUNT(*) as count FROM detections
                WHERE timestamp >= ? AND timestamp < ?
                ''',
                (start_time, end_time)
            )
            total_inspections = self.cursor.fetchone()['count']
            
            # Get total defects
            self.cursor.execute(
                '''
                SELECT COUNT(*) as count FROM defects
                INNER JOIN detections ON defects.detection_id = detections.id
                WHERE detections.timestamp >= ? AND detections.timestamp < ?
                ''',
                (start_time, end_time)
            )
            total_defects = self.cursor.fetchone()['count']
            
            # Get defect types and counts
            self.cursor.execute(
                '''
                SELECT defect_type, COUNT(*) as count FROM defects
                INNER JOIN detections ON defects.detection_id = detections.id
                WHERE detections.timestamp >= ? AND detections.timestamp < ?
                GROUP BY defect_type
                ORDER BY count DESC
                ''',
                (start_time, end_time)
            )
            defect_stats = [dict(row) for row in self.cursor.fetchall()]
            
            # Format statistics
            defect_types = [stat['defect_type'] for stat in defect_stats]
            defect_counts = [stat['count'] for stat in defect_stats]
            
            # Create statistics record
            statistics = {
                'period': period,
                'start_time': start_time,
                'end_time': end_time,
                'total_inspections': total_inspections,
                'total_defects': total_defects,
                'defect_types': defect_types,
                'defect_counts': defect_counts,
                'defect_stats': defect_stats
            }
            
            return statistics
        except Exception as e:
            logger.error(f"Error getting statistics: {e}")
            raise
    
    def log_system_event(
        self,
        log_level: str,
        component: str,
        message: str,
        details: Optional[Dict[str, Any]] = None
    ):
        """
        Log system event to database.
        
        Args:
            log_level: Log level (INFO, WARNING, ERROR, etc.)
            component: System component
            message: Log message
            details: Additional details as dictionary
        """
        try:
            # Get current timestamp
            timestamp = time.time()
            
            # Convert details to JSON if provided
            details_json = None
            if details is not None:
                details_json = json.dumps(details)
            
            # Insert log record
            self.cursor.execute(
                '''
                INSERT INTO system_logs (
                    timestamp, log_level, component, message, details
                ) VALUES (?, ?, ?, ?, ?)
                ''',
                (timestamp, log_level, component, message, details_json)
            )
            
            # Commit changes
            self.conn.commit()
        except Exception as e:
            logger.error(f"Error logging system event: {e}")
            self.conn.rollback()
    
    def _start_backup_thread(self):
        """Start database backup thread."""
        self.backup_thread = threading.Thread(target=self._backup_worker, daemon=True)
        self.backup_thread.start()
        logger.info("Started database backup thread")
    
    def _backup_worker(self):
        """Database backup worker thread."""
        while not self.backup_stop_event.is_set():
            try:
                # Perform backup
                self._backup_database()
                
                # Clean up old backups
                self._cleanup_old_backups()
                
                # Wait for next backup
                self.backup_stop_event.wait(self.backup_interval)
            except Exception as e:
                logger.error(f"Error in backup worker: {e}")
                # Wait a shorter time before retrying
                self.backup_stop_event.wait(60)
    
    def _backup_database(self):
        """Backup database to file."""
        try:
            # Generate backup filename
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_filename = f"backup_{timestamp}.db"
            backup_path = os.path.join(self.backup_dir, backup_filename)
            
            # Create backup
            shutil.copy2(self.db_path, backup_path)
            
            logger.info(f"Database backup created: {backup_path}")
        except Exception as e:
            logger.error(f"Error backing up database: {e}")
    
    def _cleanup_old_backups(self):
        """Clean up old database backups."""
        try:
            # Get list of backup files
            backup_files = []
            for filename in os.listdir(self.backup_dir):
                if filename.startswith("backup_") and filename.endswith(".db"):
                    file_path = os.path.join(self.backup_dir, filename)
                    backup_files.append((file_path, os.path.getmtime(file_path)))
            
            # Sort by modification time (newest first)
            backup_files.sort(key=lambda x: x[1], reverse=True)
            
            # Remove old backups
            if len(backup_files) > self.max_backups:
                for file_path, _ in backup_files[self.max_backups:]:
                    os.remove(file_path)
                    logger.info(f"Removed old database backup: {file_path}")
        except Exception as e:
            logger.error(f"Error cleaning up old backups: {e}")
    
    def close(self):
        """Close database connection and stop backup thread."""
        try:
            # Stop backup thread
            if self.backup_thread is not None:
                self.backup_stop_event.set()
                self.backup_thread.join(timeout=1.0)
            
            # Close database connection
            if self.conn is not None:
                self.conn.close()
                self.conn = None
                self.cursor = None
                logger.info("Database connection closed")
        except Exception as e:
            logger.error(f"Error closing database connection: {e}")


# Example usage
if __name__ == "__main__":
    # Setup logging
    logging.basicConfig(level=logging.INFO)
    
    # Create database manager
    db_manager = DatabaseManager(
        db_path="data/database/test.db",
        enable_backup=True,
        backup_interval=3600  # 1 hour
    )
    
    # Initialize schema
    db_manager.initialize_schema()
    
    # Create test detection
    camera_id = "cam1"
    image = np.zeros((480, 640, 3), dtype=np.uint8)
    detections = [
        DetectionResult(
            defect_type="improper_sealing",
            confidence=0.85,
            bbox=(0.2, 0.3, 0.1, 0.1)
        ),
        DetectionResult(
            defect_type="filling_leakage",
            confidence=0.92,
            bbox=(0.6, 0.4, 0.15, 0.2)
        )
    ]
    
    # Save detection
    detection_id = db_manager.save_detections(camera_id, image, detections)
    
    # Get detection
    detection = db_manager.get_detection(detection_id)
    print(f"Detection: {detection}")
    
    # Get recent detections
    recent = db_manager.get_recent_detections(limit=10)
    print(f"Recent detections: {len(recent)}")
    
    # Get statistics
    stats = db_manager.get_statistics(period="day")
    print(f"Statistics: {stats}")
    
    # Log system event
    db_manager.log_system_event(
        log_level="INFO",
        component="test",
        message="Test event",
        details={"test_key": "test_value"}
    )
    
    # Close database
    db_manager.close()
