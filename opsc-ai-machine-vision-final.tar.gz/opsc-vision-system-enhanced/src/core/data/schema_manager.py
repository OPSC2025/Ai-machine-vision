"""
Database schema management for OPSC Sandwich Quality Inspection System.
Provides database initialization, migration, and maintenance functionality.

Version: 1.0.0
Last Updated: 2025-04-21
"""

import os
import sys
import time
import json
import logging
import sqlite3
import datetime
from typing import Dict, List, Optional, Tuple, Union, Any
from pathlib import Path
import shutil

# Setup logging
logger = logging.getLogger(__name__)

class SchemaManager:
    """
    Database schema manager for OPSC Sandwich Quality Inspection System.
    
    Provides database initialization, migration, and maintenance functionality.
    """
    
    def __init__(self, db_path: str, migrations_dir: str, backup_dir: Optional[str] = None):
        """
        Initialize schema manager.
        
        Args:
            db_path: Path to SQLite database file
            migrations_dir: Path to directory containing migration scripts
            backup_dir: Path to directory for database backups (optional)
        """
        self.db_path = db_path
        self.migrations_dir = migrations_dir
        self.backup_dir = backup_dir
        
        # Create directories if they don't exist
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        os.makedirs(migrations_dir, exist_ok=True)
        if backup_dir:
            os.makedirs(backup_dir, exist_ok=True)
        
        # Initialize schema version table
        self._init_schema_version()
    
    def _init_schema_version(self):
        """Initialize schema version table."""
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Create schema_version table if it doesn't exist
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS schema_version (
                version INTEGER PRIMARY KEY,
                applied_at TEXT,
                description TEXT
            )
            ''')
            
            # Commit changes
            conn.commit()
            
            # Close connection
            conn.close()
            
            logger.info("Schema version table initialized")
        except Exception as e:
            logger.error(f"Error initializing schema version table: {e}")
            raise
    
    def get_current_version(self) -> int:
        """
        Get current schema version.
        
        Returns:
            Current schema version (0 if no migrations have been applied)
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Get current version
            cursor.execute("SELECT MAX(version) FROM schema_version")
            version = cursor.fetchone()[0]
            
            # Close connection
            conn.close()
            
            return version or 0
        except Exception as e:
            logger.error(f"Error getting current schema version: {e}")
            return 0
    
    def get_available_migrations(self) -> List[Tuple[int, str, str]]:
        """
        Get available migrations.
        
        Returns:
            List of tuples (version, filename, description)
        """
        try:
            migrations = []
            
            # Get migration files
            for filename in os.listdir(self.migrations_dir):
                if filename.endswith(".sql"):
                    # Parse version and description from filename
                    # Format: V{version}__{description}.sql
                    parts = filename.split("__", 1)
                    if len(parts) == 2 and parts[0].startswith("V"):
                        try:
                            version = int(parts[0][1:])
                            description = parts[1].replace(".sql", "").replace("_", " ")
                            migrations.append((version, filename, description))
                        except ValueError:
                            logger.warning(f"Invalid migration filename format: {filename}")
            
            # Sort migrations by version
            migrations.sort(key=lambda m: m[0])
            
            return migrations
        except Exception as e:
            logger.error(f"Error getting available migrations: {e}")
            return []
    
    def get_pending_migrations(self) -> List[Tuple[int, str, str]]:
        """
        Get pending migrations.
        
        Returns:
            List of tuples (version, filename, description) for migrations that have not been applied
        """
        try:
            # Get current version
            current_version = self.get_current_version()
            
            # Get available migrations
            migrations = self.get_available_migrations()
            
            # Filter pending migrations
            pending_migrations = [m for m in migrations if m[0] > current_version]
            
            return pending_migrations
        except Exception as e:
            logger.error(f"Error getting pending migrations: {e}")
            return []
    
    def get_applied_migrations(self) -> List[Dict[str, Any]]:
        """
        Get applied migrations.
        
        Returns:
            List of dictionaries with migration information
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Get applied migrations
            cursor.execute("SELECT version, applied_at, description FROM schema_version ORDER BY version")
            rows = cursor.fetchall()
            
            # Close connection
            conn.close()
            
            # Create migration dictionaries
            migrations = []
            for row in rows:
                migrations.append({
                    "version": row[0],
                    "applied_at": row[1],
                    "description": row[2]
                })
            
            return migrations
        except Exception as e:
            logger.error(f"Error getting applied migrations: {e}")
            return []
    
    def create_migration(self, description: str) -> str:
        """
        Create a new migration file.
        
        Args:
            description: Migration description
        
        Returns:
            Path to created migration file
        """
        try:
            # Get next version
            next_version = self.get_current_version() + 1
            
            # Create filename
            filename = f"V{next_version}__{description.replace(' ', '_')}.sql"
            filepath = os.path.join(self.migrations_dir, filename)
            
            # Create migration file
            with open(filepath, "w") as f:
                f.write(f"-- Migration: {description}\n")
                f.write(f"-- Version: {next_version}\n")
                f.write(f"-- Created: {datetime.datetime.now().isoformat()}\n\n")
                f.write("-- Write your SQL statements here\n\n")
            
            logger.info(f"Created migration file: {filepath}")
            
            return filepath
        except Exception as e:
            logger.error(f"Error creating migration: {e}")
            raise
    
    def apply_migration(self, version: int, filename: str, description: str) -> bool:
        """
        Apply a single migration.
        
        Args:
            version: Migration version
            filename: Migration filename
            description: Migration description
        
        Returns:
            True if successful, False otherwise
        """
        try:
            # Get migration file path
            filepath = os.path.join(self.migrations_dir, filename)
            
            # Check if file exists
            if not os.path.exists(filepath):
                logger.error(f"Migration file not found: {filepath}")
                return False
            
            # Read migration SQL
            with open(filepath, "r") as f:
                sql = f.read()
            
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            try:
                # Begin transaction
                cursor.execute("BEGIN TRANSACTION")
                
                # Execute migration SQL
                cursor.executescript(sql)
                
                # Update schema version
                cursor.execute('''
                INSERT INTO schema_version (version, applied_at, description)
                VALUES (?, ?, ?)
                ''', (
                    version,
                    datetime.datetime.now().isoformat(),
                    description
                ))
                
                # Commit transaction
                cursor.execute("COMMIT")
                
                logger.info(f"Applied migration: {filename}")
                
                return True
            except Exception as e:
                # Rollback transaction
                cursor.execute("ROLLBACK")
                
                logger.error(f"Error applying migration {filename}: {e}")
                return False
            finally:
                # Close connection
                conn.close()
        except Exception as e:
            logger.error(f"Error applying migration: {e}")
            return False
    
    def migrate(self, target_version: Optional[int] = None) -> bool:
        """
        Apply pending migrations.
        
        Args:
            target_version: Target schema version (if None, apply all pending migrations)
        
        Returns:
            True if successful, False otherwise
        """
        try:
            # Get current version
            current_version = self.get_current_version()
            
            # Get pending migrations
            pending_migrations = self.get_pending_migrations()
            
            if not pending_migrations:
                logger.info("No pending migrations")
                return True
            
            # Filter migrations by target version
            if target_version is not None:
                pending_migrations = [m for m in pending_migrations if m[0] <= target_version]
            
            if not pending_migrations:
                logger.info(f"No migrations to apply up to version {target_version}")
                return True
            
            # Create backup before migration
            if self.backup_dir:
                self.backup_database()
            
            # Apply migrations
            for version, filename, description in pending_migrations:
                logger.info(f"Applying migration {version}: {description}")
                
                if not self.apply_migration(version, filename, description):
                    logger.error(f"Migration failed: {filename}")
                    return False
            
            logger.info(f"Migrations completed. Schema version: {self.get_current_version()}")
            
            return True
        except Exception as e:
            logger.error(f"Error applying migrations: {e}")
            return False
    
    def backup_database(self) -> Optional[str]:
        """
        Create a backup of the database.
        
        Returns:
            Path to backup file if successful, None otherwise
        """
        try:
            if not self.backup_dir:
                logger.error("Backup directory not specified")
                return None
            
            # Create backup filename with timestamp
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_filename = f"backup_{timestamp}.db"
            backup_path = os.path.join(self.backup_dir, backup_filename)
            
            # Copy database file
            shutil.copy2(self.db_path, backup_path)
            
            logger.info(f"Created database backup: {backup_path}")
            
            return backup_path
        except Exception as e:
            logger.error(f"Error creating database backup: {e}")
            return None
    
    def restore_database(self, backup_path: str) -> bool:
        """
        Restore database from backup.
        
        Args:
            backup_path: Path to backup file
        
        Returns:
            True if successful, False otherwise
        """
        try:
            # Check if backup file exists
            if not os.path.exists(backup_path):
                logger.error(f"Backup file not found: {backup_path}")
                return False
            
            # Create backup of current database
            current_backup = self.backup_database()
            
            # Copy backup file to database path
            shutil.copy2(backup_path, self.db_path)
            
            logger.info(f"Restored database from backup: {backup_path}")
            
            return True
        except Exception as e:
            logger.error(f"Error restoring database: {e}")
            return False
    
    def vacuum_database(self) -> bool:
        """
        Vacuum database to optimize storage.
        
        Returns:
            True if successful, False otherwise
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Execute VACUUM
            cursor.execute("VACUUM")
            
            # Close connection
            conn.close()
            
            logger.info("Database vacuum completed")
            
            return True
        except Exception as e:
            logger.error(f"Error vacuuming database: {e}")
            return False
    
    def analyze_database(self) -> bool:
        """
        Analyze database to optimize query planning.
        
        Returns:
            True if successful, False otherwise
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Execute ANALYZE
            cursor.execute("ANALYZE")
            
            # Close connection
            conn.close()
            
            logger.info("Database analysis completed")
            
            return True
        except Exception as e:
            logger.error(f"Error analyzing database: {e}")
            return False
    
    def get_database_info(self) -> Dict[str, Any]:
        """
        Get database information.
        
        Returns:
            Dictionary with database information
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Get database size
            db_size = os.path.getsize(self.db_path)
            
            # Get table information
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
            tables = [row[0] for row in cursor.fetchall()]
            
            # Get row counts for each table
            table_info = {}
            for table in tables:
                if table != "sqlite_sequence":
                    cursor.execute(f"SELECT COUNT(*) FROM {table}")
                    row_count = cursor.fetchone()[0]
                    table_info[table] = {"rows": row_count}
            
            # Close connection
            conn.close()
            
            # Create info dictionary
            info = {
                "path": self.db_path,
                "size_bytes": db_size,
                "size_human": self._format_size(db_size),
                "tables": table_info,
                "schema_version": self.get_current_version(),
                "applied_migrations": self.get_applied_migrations(),
                "pending_migrations": len(self.get_pending_migrations())
            }
            
            return info
        except Exception as e:
            logger.error(f"Error getting database info: {e}")
            return {}
    
    def _format_size(self, size_bytes: int) -> str:
        """
        Format size in bytes to human-readable format.
        
        Args:
            size_bytes: Size in bytes
        
        Returns:
            Human-readable size string
        """
        for unit in ["B", "KB", "MB", "GB", "TB"]:
            if size_bytes < 1024 or unit == "TB":
                return f"{size_bytes:.2f} {unit}"
            size_bytes /= 1024


# Example usage
if __name__ == "__main__":
    # Setup logging
    logging.basicConfig(level=logging.INFO)
    
    # Create schema manager
    schema_manager = SchemaManager(
        db_path="data/database/sandwich_inspection.db",
        migrations_dir="data/database/migrations",
        backup_dir="data/database/backups"
    )
    
    # Create a test migration
    migration_path = schema_manager.create_migration("Create inspection results table")
    
    # Write migration SQL
    with open(migration_path, "w") as f:
        f.write("""-- Migration: Create inspection results table
-- Version: 1
-- Created: 2025-04-21

CREATE TABLE IF NOT EXISTS inspection_results (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT,
    camera_id TEXT,
    image_path TEXT,
    defect_type TEXT,
    confidence REAL,
    bbox_x REAL,
    bbox_y REAL,
    bbox_width REAL,
    bbox_height REAL
);

CREATE INDEX IF NOT EXISTS idx_inspection_results_timestamp ON inspection_results(timestamp);
CREATE INDEX IF NOT EXISTS idx_inspection_results_camera_id ON inspection_results(camera_id);
CREATE INDEX IF NOT EXISTS idx_inspection_results_defect_type ON inspection_results(defect_type);
""")
    
    # Apply migrations
    schema_manager.migrate()
    
    # Get database info
    db_info = schema_manager.get_database_info()
    print(json.dumps(db_info, indent=2))
