"""
Scalability module for OPSC Sandwich Quality Inspection System.
Provides functionality for scaling the application across multiple nodes,
load balancing, and distributed processing.

Version: 1.0.0
Last Updated: 2025-04-21
"""

import os
import sys
import time
import json
import logging
import datetime
import threading
import queue
import socket
import uuid
import multiprocessing
import concurrent.futures
from typing import Dict, List, Optional, Tuple, Union, Any, Callable, Set
from dataclasses import dataclass, field
from enum import Enum, auto
import numpy as np
import cv2
import requests
import zmq

# Setup logging
logger = logging.getLogger(__name__)

class NodeRole(Enum):
    """Node role enum."""
    MASTER = auto()
    WORKER = auto()
    HYBRID = auto()


class NodeStatus(Enum):
    """Node status enum."""
    ONLINE = auto()
    OFFLINE = auto()
    BUSY = auto()
    IDLE = auto()
    ERROR = auto()


class TaskPriority(Enum):
    """Task priority enum."""
    LOW = 0
    NORMAL = 1
    HIGH = 2
    CRITICAL = 3


class TaskStatus(Enum):
    """Task status enum."""
    PENDING = auto()
    ASSIGNED = auto()
    RUNNING = auto()
    COMPLETED = auto()
    FAILED = auto()
    CANCELED = auto()


@dataclass
class NodeConfig:
    """Node configuration data class."""
    node_id: str
    node_name: str
    node_role: NodeRole
    host: str
    port: int
    max_tasks: int = 10
    max_workers: int = multiprocessing.cpu_count()
    heartbeat_interval: int = 5
    task_timeout: int = 300
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "node_id": self.node_id,
            "node_name": self.node_name,
            "node_role": self.node_role.name,
            "host": self.host,
            "port": self.port,
            "max_tasks": self.max_tasks,
            "max_workers": self.max_workers,
            "heartbeat_interval": self.heartbeat_interval,
            "task_timeout": self.task_timeout
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'NodeConfig':
        """Create from dictionary."""
        node_role_str = data.get("node_role", "WORKER")
        try:
            node_role = NodeRole[node_role_str]
        except KeyError:
            node_role = NodeRole.WORKER
            logger.warning(f"Invalid node role: {node_role_str}, defaulting to WORKER")
        
        return cls(
            node_id=data.get("node_id", ""),
            node_name=data.get("node_name", ""),
            node_role=node_role,
            host=data.get("host", ""),
            port=data.get("port", 0),
            max_tasks=data.get("max_tasks", 10),
            max_workers=data.get("max_workers", multiprocessing.cpu_count()),
            heartbeat_interval=data.get("heartbeat_interval", 5),
            task_timeout=data.get("task_timeout", 300)
        )


@dataclass
class NodeInfo:
    """Node information data class."""
    node_id: str
    node_name: str
    node_role: NodeRole
    host: str
    port: int
    status: NodeStatus
    cpu_count: int
    cpu_percent: float
    memory_total: int
    memory_available: int
    memory_percent: float
    disk_total: int
    disk_available: int
    disk_percent: float
    active_tasks: int
    completed_tasks: int
    failed_tasks: int
    uptime_seconds: int
    last_heartbeat: datetime.datetime
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "node_id": self.node_id,
            "node_name": self.node_name,
            "node_role": self.node_role.name,
            "host": self.host,
            "port": self.port,
            "status": self.status.name,
            "cpu_count": self.cpu_count,
            "cpu_percent": self.cpu_percent,
            "memory_total": self.memory_total,
            "memory_available": self.memory_available,
            "memory_percent": self.memory_percent,
            "disk_total": self.disk_total,
            "disk_available": self.disk_available,
            "disk_percent": self.disk_percent,
            "active_tasks": self.active_tasks,
            "completed_tasks": self.completed_tasks,
            "failed_tasks": self.failed_tasks,
            "uptime_seconds": self.uptime_seconds,
            "last_heartbeat": self.last_heartbeat.isoformat()
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'NodeInfo':
        """Create from dictionary."""
        node_role_str = data.get("node_role", "WORKER")
        try:
            node_role = NodeRole[node_role_str]
        except KeyError:
            node_role = NodeRole.WORKER
            logger.warning(f"Invalid node role: {node_role_str}, defaulting to WORKER")
        
        status_str = data.get("status", "OFFLINE")
        try:
            status = NodeStatus[status_str]
        except KeyError:
            status = NodeStatus.OFFLINE
            logger.warning(f"Invalid node status: {status_str}, defaulting to OFFLINE")
        
        last_heartbeat_str = data.get("last_heartbeat")
        if last_heartbeat_str:
            try:
                last_heartbeat = datetime.datetime.fromisoformat(last_heartbeat_str)
            except ValueError:
                last_heartbeat = datetime.datetime.now()
                logger.warning(f"Invalid last heartbeat format: {last_heartbeat_str}, using current time")
        else:
            last_heartbeat = datetime.datetime.now()
        
        return cls(
            node_id=data.get("node_id", ""),
            node_name=data.get("node_name", ""),
            node_role=node_role,
            host=data.get("host", ""),
            port=data.get("port", 0),
            status=status,
            cpu_count=data.get("cpu_count", 0),
            cpu_percent=data.get("cpu_percent", 0.0),
            memory_total=data.get("memory_total", 0),
            memory_available=data.get("memory_available", 0),
            memory_percent=data.get("memory_percent", 0.0),
            disk_total=data.get("disk_total", 0),
            disk_available=data.get("disk_available", 0),
            disk_percent=data.get("disk_percent", 0.0),
            active_tasks=data.get("active_tasks", 0),
            completed_tasks=data.get("completed_tasks", 0),
            failed_tasks=data.get("failed_tasks", 0),
            uptime_seconds=data.get("uptime_seconds", 0),
            last_heartbeat=last_heartbeat
        )


@dataclass
class Task:
    """Task data class."""
    task_id: str
    task_type: str
    priority: TaskPriority
    status: TaskStatus
    data: Dict[str, Any]
    result: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    created_at: datetime.datetime = field(default_factory=datetime.datetime.now)
    assigned_at: Optional[datetime.datetime] = None
    started_at: Optional[datetime.datetime] = None
    completed_at: Optional[datetime.datetime] = None
    assigned_to: Optional[str] = None
    timeout_seconds: int = 300
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "task_id": self.task_id,
            "task_type": self.task_type,
            "priority": self.priority.name,
            "status": self.status.name,
            "data": self.data,
            "result": self.result,
            "error": self.error,
            "created_at": self.created_at.isoformat(),
            "assigned_at": self.assigned_at.isoformat() if self.assigned_at else None,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "assigned_to": self.assigned_to,
            "timeout_seconds": self.timeout_seconds
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Task':
        """Create from dictionary."""
        priority_str = data.get("priority", "NORMAL")
        try:
            priority = TaskPriority[priority_str]
        except KeyError:
            priority = TaskPriority.NORMAL
            logger.warning(f"Invalid task priority: {priority_str}, defaulting to NORMAL")
        
        status_str = data.get("status", "PENDING")
        try:
            status = TaskStatus[status_str]
        except KeyError:
            status = TaskStatus.PENDING
            logger.warning(f"Invalid task status: {status_str}, defaulting to PENDING")
        
        created_at_str = data.get("created_at")
        if created_at_str:
            try:
                created_at = datetime.datetime.fromisoformat(created_at_str)
            except ValueError:
                created_at = datetime.datetime.now()
                logger.warning(f"Invalid created at format: {created_at_str}, using current time")
        else:
            created_at = datetime.datetime.now()
        
        assigned_at_str = data.get("assigned_at")
        if assigned_at_str:
            try:
                assigned_at = datetime.datetime.fromisoformat(assigned_at_str)
            except ValueError:
                assigned_at = None
                logger.warning(f"Invalid assigned at format: {assigned_at_str}")
        else:
            assigned_at = None
        
        started_at_str = data.get("started_at")
        if started_at_str:
            try:
                started_at = datetime.datetime.fromisoformat(started_at_str)
            except ValueError:
                started_at = None
                logger.warning(f"Invalid started at format: {started_at_str}")
        else:
            started_at = None
        
        completed_at_str = data.get("completed_at")
        if completed_at_str:
            try:
                completed_at = datetime.datetime.fromisoformat(completed_at_str)
            except ValueError:
                completed_at = None
                logger.warning(f"Invalid completed at format: {completed_at_str}")
        else:
            completed_at = None
        
        return cls(
            task_id=data.get("task_id", ""),
            task_type=data.get("task_type", ""),
            priority=priority,
            status=status,
            data=data.get("data", {}),
            result=data.get("result"),
            error=data.get("error"),
            created_at=created_at,
            assigned_at=assigned_at,
            started_at=started_at,
            completed_at=completed_at,
            assigned_to=data.get("assigned_to"),
            timeout_seconds=data.get("timeout_seconds", 300)
        )


class TaskHandler:
    """
    Task handler interface.
    
    Defines the interface for task handlers.
    """
    
    def can_handle(self, task_type: str) -> bool:
        """
        Check if handler can handle task type.
        
        Args:
            task_type: Task type
        
        Returns:
            True if handler can handle task type, False otherwise
        """
        raise NotImplementedError("Subclasses must implement can_handle")
    
    def handle(self, task: Task) -> Tuple[bool, Optional[Dict[str, Any]], Optional[str]]:
        """
        Handle task.
        
        Args:
            task: Task to handle
        
        Returns:
            Tuple of (success, result, error)
        """
        raise NotImplementedError("Subclasses must implement handle")


class ImageProcessingTaskHandler(TaskHandler):
    """
    Image processing task handler.
    
    Handles image processing tasks.
    """
    
    def can_handle(self, task_type: str) -> bool:
        """
        Check if handler can handle task type.
        
        Args:
            task_type: Task type
        
        Returns:
            True if handler can handle task type, False otherwise
        """
        return task_type.startswith("image_processing.")
    
    def handle(self, task: Task) -> Tuple[bool, Optional[Dict[str, Any]], Optional[str]]:
        """
        Handle task.
        
        Args:
            task: Task to handle
        
        Returns:
            Tuple of (success, result, error)
        """
        try:
            # Get task type
            task_type = task.task_type
            
            # Get task data
            data = task.data
            
            # Check if task type is supported
            if task_type == "image_processing.resize":
                return self._handle_resize(data)
            elif task_type == "image_processing.crop":
                return self._handle_crop(data)
            elif task_type == "image_processing.filter":
                return self._handle_filter(data)
            else:
                return False, None, f"Unsupported task type: {task_type}"
        except Exception as e:
            logger.error(f"Error handling task: {e}")
            return False, None, str(e)
    
    def _handle_resize(self, data: Dict[str, Any]) -> Tuple[bool, Optional[Dict[str, Any]], Optional[str]]:
        """
        Handle resize task.
        
        Args:
            data: Task data
        
        Returns:
            Tuple of (success, result, error)
        """
        try:
            # Get image data
            image_data = data.get("image")
            if not image_data:
                return False, None, "Image data not provided"
            
            # Convert base64 to image
            import base64
            image_bytes = base64.b64decode(image_data)
            nparr = np.frombuffer(image_bytes, np.uint8)
            image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            
            # Get resize parameters
            width = data.get("width")
            height = data.get("height")
            if not width or not height:
                return False, None, "Width and height not provided"
            
            # Resize image
            resized = cv2.resize(image, (width, height))
            
            # Convert image to base64
            _, buffer = cv2.imencode(".jpg", resized)
            resized_base64 = base64.b64encode(buffer).decode("utf-8")
            
            # Return result
            return True, {"image": resized_base64, "width": width, "height": height}, None
        except Exception as e:
            logger.error(f"Error handling resize task: {e}")
            return False, None, str(e)
    
    def _handle_crop(self, data: Dict[str, Any]) -> Tuple[bool, Optional[Dict[str, Any]], Optional[str]]:
        """
        Handle crop task.
        
        Args:
            data: Task data
        
        Returns:
            Tuple of (success, result, error)
        """
        try:
            # Get image data
            image_data = data.get("image")
            if not image_data:
                return False, None, "Image data not provided"
            
            # Convert base64 to image
            import base64
            image_bytes = base64.b64decode(image_data)
            nparr = np.frombuffer(image_bytes, np.uint8)
            image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            
            # Get crop parameters
            x = data.get("x")
            y = data.get("y")
            width = data.get("width")
            height = data.get("height")
            if x is None or y is None or not width or not height:
                return False, None, "Crop parameters not provided"
            
            # Crop image
            cropped = image[y:y+height, x:x+width]
            
            # Convert image to base64
            _, buffer = cv2.imencode(".jpg", cropped)
            cropped_base64 = base64.b64encode(buffer).decode("utf-8")
            
            # Return result
            return True, {"image": cropped_base64, "x": x, "y": y, "width": width, "height": height}, None
        except Exception as e:
            logger.error(f"Error handling crop task: {e}")
            return False, None, str(e)
    
    def _handle_filter(self, data: Dict[str, Any]) -> Tuple[bool, Optional[Dict[str, Any]], Optional[str]]:
        """
        Handle filter task.
        
        Args:
            data: Task data
        
        Returns:
            Tuple of (success, result, error)
        """
        try:
            # Get image data
            image_data = data.get("image")
            if not image_data:
                return False, None, "Image data not provided"
            
            # Convert base64 to image
            import base64
            image_bytes = base64.b64decode(image_data)
            nparr = np.frombuffer(image_bytes, np.uint8)
            image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            
            # Get filter type
            filter_type = data.get("filter_type")
            if not filter_type:
                return False, None, "Filter type not provided"
            
            # Apply filter
            filtered = None
            if filter_type == "blur":
                kernel_size = data.get("kernel_size", 5)
                filtered = cv2.GaussianBlur(image, (kernel_size, kernel_size), 0)
            elif filter_type == "sharpen":
                kernel = np.array([[-1, -1, -1], [-1, 9, -1], [-1, -1, -1]])
                filtered = cv2.filter2D(image, -1, kernel)
            elif filter_type == "edge":
                filtered = cv2.Canny(image, 100, 200)
                filtered = cv2.cvtColor(filtered, cv2.COLOR_GRAY2BGR)
            else:
                return False, None, f"Unsupported filter type: {filter_type}"
            
            # Convert image to base64
            _, buffer = cv2.imencode(".jpg", filtered)
            filtered_base64 = base64.b64encode(buffer).decode("utf-8")
            
            # Return result
            return True, {"image": filtered_base64, "filter_type": filter_type}, None
        except Exception as e:
            logger.error(f"Error handling filter task: {e}")
            return False, None, str(e)


class InferenceTaskHandler(TaskHandler):
    """
    Inference task handler.
    
    Handles inference tasks.
    """
    
    def __init__(self, model_manager=None):
        """
        Initialize inference task handler.
        
        Args:
            model_manager: Model manager
        """
        self.model_manager = model_manager
    
    def can_handle(self, task_type: str) -> bool:
        """
        Check if handler can handle task type.
        
        Args:
            task_type: Task type
        
        Returns:
            True if handler can handle task type, False otherwise
        """
        return task_type.startswith("inference.")
    
    def handle(self, task: Task) -> Tuple[bool, Optional[Dict[str, Any]], Optional[str]]:
        """
        Handle task.
        
        Args:
            task: Task to handle
        
        Returns:
            Tuple of (success, result, error)
        """
        try:
            # Get task type
            task_type = task.task_type
            
            # Get task data
            data = task.data
            
            # Check if model manager is available
            if not self.model_manager:
                return False, None, "Model manager not available"
            
            # Check if task type is supported
            if task_type == "inference.detect":
                return self._handle_detect(data)
            elif task_type == "inference.classify":
                return self._handle_classify(data)
            elif task_type == "inference.segment":
                return self._handle_segment(data)
            else:
                return False, None, f"Unsupported task type: {task_type}"
        except Exception as e:
            logger.error(f"Error handling task: {e}")
            return False, None, str(e)
    
    def _handle_detect(self, data: Dict[str, Any]) -> Tuple[bool, Optional[Dict[str, Any]], Optional[str]]:
        """
        Handle detect task.
        
        Args:
            data: Task data
        
        Returns:
            Tuple of (success, result, error)
        """
        try:
            # Get image data
            image_data = data.get("image")
            if not image_data:
                return False, None, "Image data not provided"
            
            # Convert base64 to image
            import base64
            image_bytes = base64.b64decode(image_data)
            nparr = np.frombuffer(image_bytes, np.uint8)
            image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            
            # Get model name
            model_name = data.get("model_name")
            if not model_name:
                return False, None, "Model name not provided"
            
            # Get confidence threshold
            confidence_threshold = data.get("confidence_threshold", 0.5)
            
            # Run inference
            detections = self.model_manager.detect(image, model_name, confidence_threshold)
            
            # Return result
            return True, {"detections": detections}, None
        except Exception as e:
            logger.error(f"Error handling detect task: {e}")
            return False, None, str(e)
    
    def _handle_classify(self, data: Dict[str, Any]) -> Tuple[bool, Optional[Dict[str, Any]], Optional[str]]:
        """
        Handle classify task.
        
        Args:
            data: Task data
        
        Returns:
            Tuple of (success, result, error)
        """
        try:
            # Get image data
            image_data = data.get("image")
            if not image_data:
                return False, None, "Image data not provided"
            
            # Convert base64 to image
            import base64
            image_bytes = base64.b64decode(image_data)
            nparr = np.frombuffer(image_bytes, np.uint8)
            image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            
            # Get model name
            model_name = data.get("model_name")
            if not model_name:
                return False, None, "Model name not provided"
            
            # Run inference
            classification = self.model_manager.classify(image, model_name)
            
            # Return result
            return True, {"classification": classification}, None
        except Exception as e:
            logger.error(f"Error handling classify task: {e}")
            return False, None, str(e)
    
    def _handle_segment(self, data: Dict[str, Any]) -> Tuple[bool, Optional[Dict[str, Any]], Optional[str]]:
        """
        Handle segment task.
        
        Args:
            data: Task data
        
        Returns:
            Tuple of (success, result, error)
        """
        try:
            # Get image data
            image_data = data.get("image")
            if not image_data:
                return False, None, "Image data not provided"
            
            # Convert base64 to image
            import base64
            image_bytes = base64.b64decode(image_data)
            nparr = np.frombuffer(image_bytes, np.uint8)
            image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            
            # Get model name
            model_name = data.get("model_name")
            if not model_name:
                return False, None, "Model name not provided"
            
            # Run inference
            segmentation = self.model_manager.segment(image, model_name)
            
            # Return result
            return True, {"segmentation": segmentation}, None
        except Exception as e:
            logger.error(f"Error handling segment task: {e}")
            return False, None, str(e)


class TaskQueue:
    """
    Task queue.
    
    Provides functionality for managing tasks.
    """
    
    def __init__(self):
        """Initialize task queue."""
        self.tasks: Dict[str, Task] = {}
        self.pending_tasks: List[str] = []
        self.lock = threading.Lock()
    
    def add_task(self, task: Task) -> bool:
        """
        Add task to queue.
        
        Args:
            task: Task to add
        
        Returns:
            True if task was added, False otherwise
        """
        with self.lock:
            # Check if task already exists
            if task.task_id in self.tasks:
                return False
            
            # Add task
            self.tasks[task.task_id] = task
            
            # Add to pending tasks
            self.pending_tasks.append(task.task_id)
            
            # Sort pending tasks by priority
            self.pending_tasks.sort(key=lambda task_id: self.tasks[task_id].priority.value, reverse=True)
            
            return True
    
    def get_task(self, task_id: str) -> Optional[Task]:
        """
        Get task by ID.
        
        Args:
            task_id: Task ID
        
        Returns:
            Task or None if not found
        """
        with self.lock:
            return self.tasks.get(task_id)
    
    def get_next_task(self) -> Optional[Task]:
        """
        Get next pending task.
        
        Returns:
            Next pending task or None if no pending tasks
        """
        with self.lock:
            if not self.pending_tasks:
                return None
            
            # Get next task ID
            task_id = self.pending_tasks[0]
            
            # Get task
            task = self.tasks.get(task_id)
            if not task:
                # Task not found, remove from pending tasks
                self.pending_tasks.pop(0)
                return self.get_next_task()
            
            # Check if task is still pending
            if task.status != TaskStatus.PENDING:
                # Task is not pending, remove from pending tasks
                self.pending_tasks.pop(0)
                return self.get_next_task()
            
            # Remove from pending tasks
            self.pending_tasks.pop(0)
            
            return task
    
    def update_task(self, task: Task) -> bool:
        """
        Update task.
        
        Args:
            task: Task to update
        
        Returns:
            True if task was updated, False otherwise
        """
        with self.lock:
            # Check if task exists
            if task.task_id not in self.tasks:
                return False
            
            # Update task
            self.tasks[task.task_id] = task
            
            # If task is pending, add to pending tasks
            if task.status == TaskStatus.PENDING and task.task_id not in self.pending_tasks:
                self.pending_tasks.append(task.task_id)
                
                # Sort pending tasks by priority
                self.pending_tasks.sort(key=lambda task_id: self.tasks[task_id].priority.value, reverse=True)
            
            return True
    
    def remove_task(self, task_id: str) -> bool:
        """
        Remove task.
        
        Args:
            task_id: Task ID
        
        Returns:
            True if task was removed, False otherwise
        """
        with self.lock:
            # Check if task exists
            if task_id not in self.tasks:
                return False
            
            # Remove task
            del self.tasks[task_id]
            
            # Remove from pending tasks
            if task_id in self.pending_tasks:
                self.pending_tasks.remove(task_id)
            
            return True
    
    def get_tasks_by_status(self, status: TaskStatus) -> List[Task]:
        """
        Get tasks by status.
        
        Args:
            status: Task status
        
        Returns:
            List of tasks with the specified status
        """
        with self.lock:
            return [task for task in self.tasks.values() if task.status == status]
    
    def get_tasks_by_node(self, node_id: str) -> List[Task]:
        """
        Get tasks assigned to node.
        
        Args:
            node_id: Node ID
        
        Returns:
            List of tasks assigned to the specified node
        """
        with self.lock:
            return [task for task in self.tasks.values() if task.assigned_to == node_id]
    
    def get_all_tasks(self) -> List[Task]:
        """
        Get all tasks.
        
        Returns:
            List of all tasks
        """
        with self.lock:
            return list(self.tasks.values())
    
    def clear(self) -> None:
        """Clear all tasks."""
        with self.lock:
            self.tasks.clear()
            self.pending_tasks.clear()


class NodeRegistry:
    """
    Node registry.
    
    Provides functionality for managing nodes.
    """
    
    def __init__(self):
        """Initialize node registry."""
        self.nodes: Dict[str, NodeInfo] = {}
        self.lock = threading.Lock()
    
    def register_node(self, node: NodeInfo) -> bool:
        """
        Register node.
        
        Args:
            node: Node to register
        
        Returns:
            True if node was registered, False otherwise
        """
        with self.lock:
            # Add node
            self.nodes[node.node_id] = node
            
            return True
    
    def unregister_node(self, node_id: str) -> bool:
        """
        Unregister node.
        
        Args:
            node_id: Node ID
        
        Returns:
            True if node was unregistered, False otherwise
        """
        with self.lock:
            # Check if node exists
            if node_id not in self.nodes:
                return False
            
            # Remove node
            del self.nodes[node_id]
            
            return True
    
    def get_node(self, node_id: str) -> Optional[NodeInfo]:
        """
        Get node by ID.
        
        Args:
            node_id: Node ID
        
        Returns:
            Node or None if not found
        """
        with self.lock:
            return self.nodes.get(node_id)
    
    def get_nodes_by_role(self, role: NodeRole) -> List[NodeInfo]:
        """
        Get nodes by role.
        
        Args:
            role: Node role
        
        Returns:
            List of nodes with the specified role
        """
        with self.lock:
            return [node for node in self.nodes.values() if node.node_role == role]
    
    def get_nodes_by_status(self, status: NodeStatus) -> List[NodeInfo]:
        """
        Get nodes by status.
        
        Args:
            status: Node status
        
        Returns:
            List of nodes with the specified status
        """
        with self.lock:
            return [node for node in self.nodes.values() if node.status == status]
    
    def get_all_nodes(self) -> List[NodeInfo]:
        """
        Get all nodes.
        
        Returns:
            List of all nodes
        """
        with self.lock:
            return list(self.nodes.values())
    
    def update_node(self, node: NodeInfo) -> bool:
        """
        Update node.
        
        Args:
            node: Node to update
        
        Returns:
            True if node was updated, False otherwise
        """
        with self.lock:
            # Check if node exists
            if node.node_id not in self.nodes:
                return False
            
            # Update node
            self.nodes[node.node_id] = node
            
            return True
    
    def clear(self) -> None:
        """Clear all nodes."""
        with self.lock:
            self.nodes.clear()


class MasterNode:
    """
    Master node.
    
    Provides functionality for managing worker nodes and distributing tasks.
    """
    
    def __init__(self, config: NodeConfig, model_manager=None):
        """
        Initialize master node.
        
        Args:
            config: Node configuration
            model_manager: Model manager
        """
        self.config = config
        self.model_manager = model_manager
        
        # Initialize node registry
        self.node_registry = NodeRegistry()
        
        # Initialize task queue
        self.task_queue = TaskQueue()
        
        # Initialize task handlers
        self.task_handlers: List[TaskHandler] = []
        self._register_default_task_handlers()
        
        # Initialize ZeroMQ context
        self.zmq_context = zmq.Context()
        
        # Initialize sockets
        self.router_socket = self.zmq_context.socket(zmq.ROUTER)
        self.router_socket.bind(f"tcp://*:{self.config.port}")
        
        # Initialize locks
        self.running_lock = threading.Lock()
        
        # Initialize flags
        self.running = False
        
        # Initialize threads
        self.heartbeat_thread = None
        self.task_distribution_thread = None
        self.task_timeout_thread = None
        self.message_handling_thread = None
        
        # Initialize start time
        self.start_time = datetime.datetime.now()
        
        # Initialize task counters
        self.completed_tasks = 0
        self.failed_tasks = 0
    
    def _register_default_task_handlers(self) -> None:
        """Register default task handlers."""
        # Register image processing task handler
        self.task_handlers.append(ImageProcessingTaskHandler())
        
        # Register inference task handler
        self.task_handlers.append(InferenceTaskHandler(self.model_manager))
    
    def register_task_handler(self, handler: TaskHandler) -> None:
        """
        Register task handler.
        
        Args:
            handler: Task handler to register
        """
        self.task_handlers.append(handler)
    
    def start(self) -> None:
        """Start master node."""
        with self.running_lock:
            if self.running:
                logger.warning("Master node is already running")
                return
            
            self.running = True
        
        # Start heartbeat thread
        self.heartbeat_thread = threading.Thread(target=self._heartbeat_loop, daemon=True)
        self.heartbeat_thread.start()
        
        # Start task distribution thread
        self.task_distribution_thread = threading.Thread(target=self._task_distribution_loop, daemon=True)
        self.task_distribution_thread.start()
        
        # Start task timeout thread
        self.task_timeout_thread = threading.Thread(target=self._task_timeout_loop, daemon=True)
        self.task_timeout_thread.start()
        
        # Start message handling thread
        self.message_handling_thread = threading.Thread(target=self._message_handling_loop, daemon=True)
        self.message_handling_thread.start()
        
        logger.info(f"Master node started: {self.config.node_id} ({self.config.host}:{self.config.port})")
    
    def stop(self) -> None:
        """Stop master node."""
        with self.running_lock:
            if not self.running:
                logger.warning("Master node is not running")
                return
            
            self.running = False
        
        # Wait for threads to stop
        if self.heartbeat_thread:
            self.heartbeat_thread.join(timeout=5.0)
        
        if self.task_distribution_thread:
            self.task_distribution_thread.join(timeout=5.0)
        
        if self.task_timeout_thread:
            self.task_timeout_thread.join(timeout=5.0)
        
        if self.message_handling_thread:
            self.message_handling_thread.join(timeout=5.0)
        
        # Close sockets
        self.router_socket.close()
        
        logger.info(f"Master node stopped: {self.config.node_id}")
    
    def _heartbeat_loop(self) -> None:
        """Heartbeat loop."""
        logger.info(f"Heartbeat thread started: {self.config.node_id}")
        
        while self.running:
            try:
                # Get all nodes
                nodes = self.node_registry.get_all_nodes()
                
                # Check each node
                for node in nodes:
                    # Calculate time since last heartbeat
                    time_since_heartbeat = datetime.datetime.now() - node.last_heartbeat
                    
                    # Check if node is offline
                    if time_since_heartbeat.total_seconds() > self.config.heartbeat_interval * 3:
                        # Node is offline
                        if node.status != NodeStatus.OFFLINE:
                            logger.warning(f"Node offline: {node.node_id} ({node.host}:{node.port})")
                            
                            # Update node status
                            node.status = NodeStatus.OFFLINE
                            self.node_registry.update_node(node)
                            
                            # Reassign tasks
                            self._reassign_node_tasks(node.node_id)
                
                # Sleep until next heartbeat
                time.sleep(self.config.heartbeat_interval)
            except Exception as e:
                logger.error(f"Error in heartbeat thread: {e}")
                time.sleep(1.0)
        
        logger.info(f"Heartbeat thread stopped: {self.config.node_id}")
    
    def _task_distribution_loop(self) -> None:
        """Task distribution loop."""
        logger.info(f"Task distribution thread started: {self.config.node_id}")
        
        while self.running:
            try:
                # Get next task
                task = self.task_queue.get_next_task()
                if not task:
                    # No pending tasks
                    time.sleep(0.1)
                    continue
                
                # Check if task can be handled locally
                if self.config.node_role == NodeRole.HYBRID:
                    # Check if any task handler can handle this task
                    for handler in self.task_handlers:
                        if handler.can_handle(task.task_type):
                            # Handle task locally
                            self._handle_task_locally(task)
                            break
                    else:
                        # No handler found, assign to worker
                        self._assign_task_to_worker(task)
                else:
                    # Assign task to worker
                    self._assign_task_to_worker(task)
            except Exception as e:
                logger.error(f"Error in task distribution thread: {e}")
                time.sleep(1.0)
        
        logger.info(f"Task distribution thread stopped: {self.config.node_id}")
    
    def _task_timeout_loop(self) -> None:
        """Task timeout loop."""
        logger.info(f"Task timeout thread started: {self.config.node_id}")
        
        while self.running:
            try:
                # Get assigned tasks
                assigned_tasks = self.task_queue.get_tasks_by_status(TaskStatus.ASSIGNED)
                
                # Check each task
                for task in assigned_tasks:
                    # Check if task has timed out
                    if task.assigned_at:
                        time_since_assigned = datetime.datetime.now() - task.assigned_at
                        
                        if time_since_assigned.total_seconds() > task.timeout_seconds:
                            # Task has timed out
                            logger.warning(f"Task timed out: {task.task_id} (assigned to {task.assigned_to})")
                            
                            # Update task status
                            task.status = TaskStatus.FAILED
                            task.error = "Task timed out"
                            task.completed_at = datetime.datetime.now()
                            self.task_queue.update_task(task)
                            
                            # Increment failed tasks counter
                            self.failed_tasks += 1
                
                # Get running tasks
                running_tasks = self.task_queue.get_tasks_by_status(TaskStatus.RUNNING)
                
                # Check each task
                for task in running_tasks:
                    # Check if task has timed out
                    if task.started_at:
                        time_since_started = datetime.datetime.now() - task.started_at
                        
                        if time_since_started.total_seconds() > task.timeout_seconds:
                            # Task has timed out
                            logger.warning(f"Task timed out: {task.task_id} (running on {task.assigned_to})")
                            
                            # Update task status
                            task.status = TaskStatus.FAILED
                            task.error = "Task timed out"
                            task.completed_at = datetime.datetime.now()
                            self.task_queue.update_task(task)
                            
                            # Increment failed tasks counter
                            self.failed_tasks += 1
                
                # Sleep until next check
                time.sleep(1.0)
            except Exception as e:
                logger.error(f"Error in task timeout thread: {e}")
                time.sleep(1.0)
        
        logger.info(f"Task timeout thread stopped: {self.config.node_id}")
    
    def _message_handling_loop(self) -> None:
        """Message handling loop."""
        logger.info(f"Message handling thread started: {self.config.node_id}")
        
        while self.running:
            try:
                # Receive message
                try:
                    identity, message = self.router_socket.recv_multipart(flags=zmq.NOBLOCK)
                except zmq.Again:
                    # No message available
                    time.sleep(0.01)
                    continue
                
                # Parse message
                try:
                    message_dict = json.loads(message.decode("utf-8"))
                except json.JSONDecodeError:
                    logger.warning(f"Invalid message format: {message}")
                    continue
                
                # Get message type
                message_type = message_dict.get("type")
                if not message_type:
                    logger.warning(f"Message type not provided: {message_dict}")
                    continue
                
                # Handle message
                if message_type == "register":
                    self._handle_register_message(identity, message_dict)
                elif message_type == "heartbeat":
                    self._handle_heartbeat_message(identity, message_dict)
                elif message_type == "task_update":
                    self._handle_task_update_message(identity, message_dict)
                elif message_type == "task_result":
                    self._handle_task_result_message(identity, message_dict)
                else:
                    logger.warning(f"Unknown message type: {message_type}")
            except Exception as e:
                logger.error(f"Error in message handling thread: {e}")
                time.sleep(1.0)
        
        logger.info(f"Message handling thread stopped: {self.config.node_id}")
    
    def _handle_register_message(self, identity: bytes, message: Dict[str, Any]) -> None:
        """
        Handle register message.
        
        Args:
            identity: Client identity
            message: Message
        """
        try:
            # Get node info
            node_info_dict = message.get("node_info")
            if not node_info_dict:
                logger.warning(f"Node info not provided: {message}")
                return
            
            # Create node info
            node_info = NodeInfo.from_dict(node_info_dict)
            
            # Update node status
            node_info.status = NodeStatus.ONLINE
            node_info.last_heartbeat = datetime.datetime.now()
            
            # Register node
            self.node_registry.register_node(node_info)
            
            logger.info(f"Node registered: {node_info.node_id} ({node_info.host}:{node_info.port})")
            
            # Send response
            response = {
                "type": "register_response",
                "success": True,
                "message": "Node registered successfully"
            }
            
            self.router_socket.send_multipart([identity, json.dumps(response).encode("utf-8")])
        except Exception as e:
            logger.error(f"Error handling register message: {e}")
            
            # Send error response
            response = {
                "type": "register_response",
                "success": False,
                "message": str(e)
            }
            
            self.router_socket.send_multipart([identity, json.dumps(response).encode("utf-8")])
    
    def _handle_heartbeat_message(self, identity: bytes, message: Dict[str, Any]) -> None:
        """
        Handle heartbeat message.
        
        Args:
            identity: Client identity
            message: Message
        """
        try:
            # Get node ID
            node_id = message.get("node_id")
            if not node_id:
                logger.warning(f"Node ID not provided: {message}")
                return
            
            # Get node info
            node_info = self.node_registry.get_node(node_id)
            if not node_info:
                logger.warning(f"Node not found: {node_id}")
                
                # Send response
                response = {
                    "type": "heartbeat_response",
                    "success": False,
                    "message": "Node not found"
                }
                
                self.router_socket.send_multipart([identity, json.dumps(response).encode("utf-8")])
                return
            
            # Update node info
            node_info_dict = message.get("node_info")
            if node_info_dict:
                # Update node info
                new_node_info = NodeInfo.from_dict(node_info_dict)
                
                # Keep node ID and role
                new_node_info.node_id = node_info.node_id
                new_node_info.node_role = node_info.node_role
                
                # Update status and last heartbeat
                new_node_info.status = NodeStatus.ONLINE
                new_node_info.last_heartbeat = datetime.datetime.now()
                
                # Update node
                self.node_registry.update_node(new_node_info)
            else:
                # Just update last heartbeat
                node_info.last_heartbeat = datetime.datetime.now()
                
                # Update status if offline
                if node_info.status == NodeStatus.OFFLINE:
                    node_info.status = NodeStatus.ONLINE
                
                # Update node
                self.node_registry.update_node(node_info)
            
            # Send response
            response = {
                "type": "heartbeat_response",
                "success": True,
                "message": "Heartbeat received"
            }
            
            self.router_socket.send_multipart([identity, json.dumps(response).encode("utf-8")])
        except Exception as e:
            logger.error(f"Error handling heartbeat message: {e}")
            
            # Send error response
            response = {
                "type": "heartbeat_response",
                "success": False,
                "message": str(e)
            }
            
            self.router_socket.send_multipart([identity, json.dumps(response).encode("utf-8")])
    
    def _handle_task_update_message(self, identity: bytes, message: Dict[str, Any]) -> None:
        """
        Handle task update message.
        
        Args:
            identity: Client identity
            message: Message
        """
        try:
            # Get task
            task_dict = message.get("task")
            if not task_dict:
                logger.warning(f"Task not provided: {message}")
                return
            
            # Create task
            task = Task.from_dict(task_dict)
            
            # Get existing task
            existing_task = self.task_queue.get_task(task.task_id)
            if not existing_task:
                logger.warning(f"Task not found: {task.task_id}")
                
                # Send response
                response = {
                    "type": "task_update_response",
                    "success": False,
                    "message": "Task not found"
                }
                
                self.router_socket.send_multipart([identity, json.dumps(response).encode("utf-8")])
                return
            
            # Update task
            self.task_queue.update_task(task)
            
            logger.info(f"Task updated: {task.task_id} (status: {task.status.name})")
            
            # Send response
            response = {
                "type": "task_update_response",
                "success": True,
                "message": "Task updated successfully"
            }
            
            self.router_socket.send_multipart([identity, json.dumps(response).encode("utf-8")])
        except Exception as e:
            logger.error(f"Error handling task update message: {e}")
            
            # Send error response
            response = {
                "type": "task_update_response",
                "success": False,
                "message": str(e)
            }
            
            self.router_socket.send_multipart([identity, json.dumps(response).encode("utf-8")])
    
    def _handle_task_result_message(self, identity: bytes, message: Dict[str, Any]) -> None:
        """
        Handle task result message.
        
        Args:
            identity: Client identity
            message: Message
        """
        try:
            # Get task ID
            task_id = message.get("task_id")
            if not task_id:
                logger.warning(f"Task ID not provided: {message}")
                return
            
            # Get task
            task = self.task_queue.get_task(task_id)
            if not task:
                logger.warning(f"Task not found: {task_id}")
                
                # Send response
                response = {
                    "type": "task_result_response",
                    "success": False,
                    "message": "Task not found"
                }
                
                self.router_socket.send_multipart([identity, json.dumps(response).encode("utf-8")])
                return
            
            # Get result
            result = message.get("result")
            
            # Get error
            error = message.get("error")
            
            # Update task
            task.result = result
            task.error = error
            task.completed_at = datetime.datetime.now()
            
            if error:
                task.status = TaskStatus.FAILED
                self.failed_tasks += 1
            else:
                task.status = TaskStatus.COMPLETED
                self.completed_tasks += 1
            
            self.task_queue.update_task(task)
            
            logger.info(f"Task completed: {task.task_id} (status: {task.status.name})")
            
            # Send response
            response = {
                "type": "task_result_response",
                "success": True,
                "message": "Task result received"
            }
            
            self.router_socket.send_multipart([identity, json.dumps(response).encode("utf-8")])
        except Exception as e:
            logger.error(f"Error handling task result message: {e}")
            
            # Send error response
            response = {
                "type": "task_result_response",
                "success": False,
                "message": str(e)
            }
            
            self.router_socket.send_multipart([identity, json.dumps(response).encode("utf-8")])
    
    def _assign_task_to_worker(self, task: Task) -> bool:
        """
        Assign task to worker.
        
        Args:
            task: Task to assign
        
        Returns:
            True if task was assigned, False otherwise
        """
        try:
            # Get online worker nodes
            worker_nodes = self.node_registry.get_nodes_by_role(NodeRole.WORKER)
            worker_nodes.extend(self.node_registry.get_nodes_by_role(NodeRole.HYBRID))
            
            # Filter online nodes
            online_nodes = [node for node in worker_nodes if node.status == NodeStatus.ONLINE]
            
            if not online_nodes:
                # No online worker nodes
                logger.warning(f"No online worker nodes available for task: {task.task_id}")
                
                # Put task back in queue
                task.status = TaskStatus.PENDING
                self.task_queue.update_task(task)
                
                return False
            
            # Sort nodes by load (active tasks)
            online_nodes.sort(key=lambda node: node.active_tasks)
            
            # Get least loaded node
            node = online_nodes[0]
            
            # Assign task to node
            task.status = TaskStatus.ASSIGNED
            task.assigned_to = node.node_id
            task.assigned_at = datetime.datetime.now()
            self.task_queue.update_task(task)
            
            # Update node active tasks
            node.active_tasks += 1
            self.node_registry.update_node(node)
            
            logger.info(f"Task assigned: {task.task_id} (assigned to {node.node_id})")
            
            # Send task to node
            self._send_task_to_node(node, task)
            
            return True
        except Exception as e:
            logger.error(f"Error assigning task to worker: {e}")
            
            # Put task back in queue
            task.status = TaskStatus.PENDING
            self.task_queue.update_task(task)
            
            return False
    
    def _send_task_to_node(self, node: NodeInfo, task: Task) -> bool:
        """
        Send task to node.
        
        Args:
            node: Node to send task to
            task: Task to send
        
        Returns:
            True if task was sent, False otherwise
        """
        try:
            # Create dealer socket
            dealer_socket = self.zmq_context.socket(zmq.DEALER)
            dealer_socket.connect(f"tcp://{node.host}:{node.port}")
            
            # Create message
            message = {
                "type": "task",
                "task": task.to_dict()
            }
            
            # Send message
            dealer_socket.send_json(message)
            
            # Close socket
            dealer_socket.close()
            
            return True
        except Exception as e:
            logger.error(f"Error sending task to node: {e}")
            return False
    
    def _handle_task_locally(self, task: Task) -> None:
        """
        Handle task locally.
        
        Args:
            task: Task to handle
        """
        # Update task status
        task.status = TaskStatus.RUNNING
        task.assigned_to = self.config.node_id
        task.assigned_at = datetime.datetime.now()
        task.started_at = datetime.datetime.now()
        self.task_queue.update_task(task)
        
        # Handle task in thread
        threading.Thread(target=self._handle_task_thread, args=(task,), daemon=True).start()
    
    def _handle_task_thread(self, task: Task) -> None:
        """
        Handle task in thread.
        
        Args:
            task: Task to handle
        """
        try:
            # Find handler for task
            for handler in self.task_handlers:
                if handler.can_handle(task.task_type):
                    # Handle task
                    success, result, error = handler.handle(task)
                    
                    # Update task
                    task.result = result
                    task.error = error
                    task.completed_at = datetime.datetime.now()
                    
                    if success:
                        task.status = TaskStatus.COMPLETED
                        self.completed_tasks += 1
                    else:
                        task.status = TaskStatus.FAILED
                        self.failed_tasks += 1
                    
                    self.task_queue.update_task(task)
                    
                    logger.info(f"Task handled locally: {task.task_id} (status: {task.status.name})")
                    
                    return
            
            # No handler found
            task.status = TaskStatus.FAILED
            task.error = f"No handler found for task type: {task.task_type}"
            task.completed_at = datetime.datetime.now()
            self.task_queue.update_task(task)
            
            self.failed_tasks += 1
            
            logger.warning(f"No handler found for task: {task.task_id} (type: {task.task_type})")
        except Exception as e:
            logger.error(f"Error handling task: {e}")
            
            # Update task
            task.status = TaskStatus.FAILED
            task.error = str(e)
            task.completed_at = datetime.datetime.now()
            self.task_queue.update_task(task)
            
            self.failed_tasks += 1
    
    def _reassign_node_tasks(self, node_id: str) -> None:
        """
        Reassign tasks from node.
        
        Args:
            node_id: Node ID
        """
        try:
            # Get tasks assigned to node
            tasks = self.task_queue.get_tasks_by_node(node_id)
            
            # Reassign each task
            for task in tasks:
                # Reset task
                task.status = TaskStatus.PENDING
                task.assigned_to = None
                task.assigned_at = None
                task.started_at = None
                self.task_queue.update_task(task)
                
                logger.info(f"Task reassigned: {task.task_id} (from {node_id})")
        except Exception as e:
            logger.error(f"Error reassigning node tasks: {e}")
    
    def add_task(self, task_type: str, data: Dict[str, Any], priority: TaskPriority = TaskPriority.NORMAL, timeout_seconds: int = 300) -> Optional[str]:
        """
        Add task.
        
        Args:
            task_type: Task type
            data: Task data
            priority: Task priority
            timeout_seconds: Task timeout in seconds
        
        Returns:
            Task ID or None if task could not be added
        """
        try:
            # Create task
            task_id = str(uuid.uuid4())
            task = Task(
                task_id=task_id,
                task_type=task_type,
                priority=priority,
                status=TaskStatus.PENDING,
                data=data,
                timeout_seconds=timeout_seconds
            )
            
            # Add task to queue
            if self.task_queue.add_task(task):
                return task_id
            
            return None
        except Exception as e:
            logger.error(f"Error adding task: {e}")
            return None
    
    def get_task(self, task_id: str) -> Optional[Task]:
        """
        Get task.
        
        Args:
            task_id: Task ID
        
        Returns:
            Task or None if not found
        """
        return self.task_queue.get_task(task_id)
    
    def cancel_task(self, task_id: str) -> bool:
        """
        Cancel task.
        
        Args:
            task_id: Task ID
        
        Returns:
            True if task was canceled, False otherwise
        """
        try:
            # Get task
            task = self.task_queue.get_task(task_id)
            if not task:
                return False
            
            # Check if task can be canceled
            if task.status in [TaskStatus.COMPLETED, TaskStatus.FAILED, TaskStatus.CANCELED]:
                return False
            
            # Cancel task
            task.status = TaskStatus.CANCELED
            task.completed_at = datetime.datetime.now()
            self.task_queue.update_task(task)
            
            logger.info(f"Task canceled: {task.task_id}")
            
            return True
        except Exception as e:
            logger.error(f"Error canceling task: {e}")
            return False
    
    def get_node_info(self) -> NodeInfo:
        """
        Get node info.
        
        Returns:
            Node info
        """
        try:
            # Get system info
            import psutil
            
            # Get CPU info
            cpu_count = psutil.cpu_count()
            cpu_percent = psutil.cpu_percent()
            
            # Get memory info
            memory = psutil.virtual_memory()
            
            # Get disk info
            disk = psutil.disk_usage("/")
            
            # Calculate uptime
            uptime = (datetime.datetime.now() - self.start_time).total_seconds()
            
            # Create node info
            return NodeInfo(
                node_id=self.config.node_id,
                node_name=self.config.node_name,
                node_role=self.config.node_role,
                host=self.config.host,
                port=self.config.port,
                status=NodeStatus.ONLINE,
                cpu_count=cpu_count,
                cpu_percent=cpu_percent,
                memory_total=memory.total,
                memory_available=memory.available,
                memory_percent=memory.percent,
                disk_total=disk.total,
                disk_available=disk.free,
                disk_percent=disk.percent,
                active_tasks=len(self.task_queue.get_tasks_by_status(TaskStatus.RUNNING)),
                completed_tasks=self.completed_tasks,
                failed_tasks=self.failed_tasks,
                uptime_seconds=int(uptime),
                last_heartbeat=datetime.datetime.now()
            )
        except Exception as e:
            logger.error(f"Error getting node info: {e}")
            
            # Return basic node info
            return NodeInfo(
                node_id=self.config.node_id,
                node_name=self.config.node_name,
                node_role=self.config.node_role,
                host=self.config.host,
                port=self.config.port,
                status=NodeStatus.ONLINE,
                cpu_count=0,
                cpu_percent=0.0,
                memory_total=0,
                memory_available=0,
                memory_percent=0.0,
                disk_total=0,
                disk_available=0,
                disk_percent=0.0,
                active_tasks=0,
                completed_tasks=0,
                failed_tasks=0,
                uptime_seconds=0,
                last_heartbeat=datetime.datetime.now()
            )
    
    def get_all_nodes(self) -> List[NodeInfo]:
        """
        Get all nodes.
        
        Returns:
            List of all nodes
        """
        return self.node_registry.get_all_nodes()
    
    def get_all_tasks(self) -> List[Task]:
        """
        Get all tasks.
        
        Returns:
            List of all tasks
        """
        return self.task_queue.get_all_tasks()
    
    def get_tasks_by_status(self, status: TaskStatus) -> List[Task]:
        """
        Get tasks by status.
        
        Args:
            status: Task status
        
        Returns:
            List of tasks with the specified status
        """
        return self.task_queue.get_tasks_by_status(status)


class WorkerNode:
    """
    Worker node.
    
    Provides functionality for executing tasks assigned by the master node.
    """
    
    def __init__(self, config: NodeConfig, master_host: str, master_port: int, model_manager=None):
        """
        Initialize worker node.
        
        Args:
            config: Node configuration
            master_host: Master node host
            master_port: Master node port
            model_manager: Model manager
        """
        self.config = config
        self.master_host = master_host
        self.master_port = master_port
        self.model_manager = model_manager
        
        # Initialize task handlers
        self.task_handlers: List[TaskHandler] = []
        self._register_default_task_handlers()
        
        # Initialize ZeroMQ context
        self.zmq_context = zmq.Context()
        
        # Initialize sockets
        self.router_socket = self.zmq_context.socket(zmq.ROUTER)
        self.router_socket.bind(f"tcp://*:{self.config.port}")
        
        self.dealer_socket = self.zmq_context.socket(zmq.DEALER)
        self.dealer_socket.connect(f"tcp://{self.master_host}:{self.master_port}")
        
        # Initialize locks
        self.running_lock = threading.Lock()
        self.tasks_lock = threading.Lock()
        
        # Initialize flags
        self.running = False
        self.registered = False
        
        # Initialize threads
        self.heartbeat_thread = None
        self.message_handling_thread = None
        
        # Initialize task pool
        self.task_pool = concurrent.futures.ThreadPoolExecutor(max_workers=self.config.max_workers)
        
        # Initialize tasks
        self.tasks: Dict[str, Task] = {}
        
        # Initialize start time
        self.start_time = datetime.datetime.now()
        
        # Initialize task counters
        self.completed_tasks = 0
        self.failed_tasks = 0
    
    def _register_default_task_handlers(self) -> None:
        """Register default task handlers."""
        # Register image processing task handler
        self.task_handlers.append(ImageProcessingTaskHandler())
        
        # Register inference task handler
        self.task_handlers.append(InferenceTaskHandler(self.model_manager))
    
    def register_task_handler(self, handler: TaskHandler) -> None:
        """
        Register task handler.
        
        Args:
            handler: Task handler to register
        """
        self.task_handlers.append(handler)
    
    def start(self) -> bool:
        """
        Start worker node.
        
        Returns:
            True if worker node was started, False otherwise
        """
        with self.running_lock:
            if self.running:
                logger.warning("Worker node is already running")
                return False
            
            self.running = True
        
        # Register with master
        if not self._register_with_master():
            logger.error("Failed to register with master")
            self.running = False
            return False
        
        # Start heartbeat thread
        self.heartbeat_thread = threading.Thread(target=self._heartbeat_loop, daemon=True)
        self.heartbeat_thread.start()
        
        # Start message handling thread
        self.message_handling_thread = threading.Thread(target=self._message_handling_loop, daemon=True)
        self.message_handling_thread.start()
        
        logger.info(f"Worker node started: {self.config.node_id} ({self.config.host}:{self.config.port})")
        
        return True
    
    def stop(self) -> None:
        """Stop worker node."""
        with self.running_lock:
            if not self.running:
                logger.warning("Worker node is not running")
                return
            
            self.running = False
        
        # Wait for threads to stop
        if self.heartbeat_thread:
            self.heartbeat_thread.join(timeout=5.0)
        
        if self.message_handling_thread:
            self.message_handling_thread.join(timeout=5.0)
        
        # Shutdown task pool
        self.task_pool.shutdown(wait=False)
        
        # Close sockets
        self.router_socket.close()
        self.dealer_socket.close()
        
        logger.info(f"Worker node stopped: {self.config.node_id}")
    
    def _register_with_master(self) -> bool:
        """
        Register with master.
        
        Returns:
            True if registration was successful, False otherwise
        """
        try:
            # Create node info
            node_info = self.get_node_info()
            
            # Create message
            message = {
                "type": "register",
                "node_info": node_info.to_dict()
            }
            
            # Send message
            self.dealer_socket.send_json(message)
            
            # Wait for response
            poller = zmq.Poller()
            poller.register(self.dealer_socket, zmq.POLLIN)
            
            if poller.poll(5000):
                # Receive response
                response = self.dealer_socket.recv_json()
                
                # Check if registration was successful
                if response.get("success"):
                    self.registered = True
                    logger.info(f"Registered with master: {self.master_host}:{self.master_port}")
                    return True
                else:
                    logger.error(f"Registration failed: {response.get('message')}")
                    return False
            else:
                logger.error("Registration timed out")
                return False
        except Exception as e:
            logger.error(f"Error registering with master: {e}")
            return False
    
    def _heartbeat_loop(self) -> None:
        """Heartbeat loop."""
        logger.info(f"Heartbeat thread started: {self.config.node_id}")
        
        while self.running:
            try:
                # Check if registered
                if not self.registered:
                    # Try to register
                    if not self._register_with_master():
                        # Registration failed, wait and try again
                        time.sleep(5.0)
                        continue
                
                # Create node info
                node_info = self.get_node_info()
                
                # Create message
                message = {
                    "type": "heartbeat",
                    "node_id": self.config.node_id,
                    "node_info": node_info.to_dict()
                }
                
                # Send message
                self.dealer_socket.send_json(message)
                
                # Wait for response
                poller = zmq.Poller()
                poller.register(self.dealer_socket, zmq.POLLIN)
                
                if poller.poll(5000):
                    # Receive response
                    response = self.dealer_socket.recv_json()
                    
                    # Check if heartbeat was successful
                    if not response.get("success"):
                        logger.warning(f"Heartbeat failed: {response.get('message')}")
                        self.registered = False
                else:
                    logger.warning("Heartbeat timed out")
                    self.registered = False
                
                # Sleep until next heartbeat
                time.sleep(self.config.heartbeat_interval)
            except Exception as e:
                logger.error(f"Error in heartbeat thread: {e}")
                self.registered = False
                time.sleep(1.0)
        
        logger.info(f"Heartbeat thread stopped: {self.config.node_id}")
    
    def _message_handling_loop(self) -> None:
        """Message handling loop."""
        logger.info(f"Message handling thread started: {self.config.node_id}")
        
        while self.running:
            try:
                # Receive message from router socket
                try:
                    identity, message = self.router_socket.recv_multipart(flags=zmq.NOBLOCK)
                except zmq.Again:
                    # No message available
                    time.sleep(0.01)
                    
                    # Check dealer socket
                    try:
                        message = self.dealer_socket.recv_json(flags=zmq.NOBLOCK)
                        
                        # Handle message from master
                        self._handle_master_message(message)
                    except zmq.Again:
                        # No message available
                        pass
                    
                    continue
                
                # Parse message
                try:
                    message_dict = json.loads(message.decode("utf-8"))
                except json.JSONDecodeError:
                    logger.warning(f"Invalid message format: {message}")
                    continue
                
                # Get message type
                message_type = message_dict.get("type")
                if not message_type:
                    logger.warning(f"Message type not provided: {message_dict}")
                    continue
                
                # Handle message
                if message_type == "task_status":
                    self._handle_task_status_message(identity, message_dict)
                else:
                    logger.warning(f"Unknown message type: {message_type}")
            except Exception as e:
                logger.error(f"Error in message handling thread: {e}")
                time.sleep(1.0)
        
        logger.info(f"Message handling thread stopped: {self.config.node_id}")
    
    def _handle_master_message(self, message: Dict[str, Any]) -> None:
        """
        Handle message from master.
        
        Args:
            message: Message
        """
        try:
            # Get message type
            message_type = message.get("type")
            if not message_type:
                logger.warning(f"Message type not provided: {message}")
                return
            
            # Handle message
            if message_type == "task":
                self._handle_task_message(message)
            else:
                logger.warning(f"Unknown message type: {message_type}")
        except Exception as e:
            logger.error(f"Error handling master message: {e}")
    
    def _handle_task_message(self, message: Dict[str, Any]) -> None:
        """
        Handle task message.
        
        Args:
            message: Message
        """
        try:
            # Get task
            task_dict = message.get("task")
            if not task_dict:
                logger.warning(f"Task not provided: {message}")
                return
            
            # Create task
            task = Task.from_dict(task_dict)
            
            # Check if task is already being processed
            with self.tasks_lock:
                if task.task_id in self.tasks:
                    logger.warning(f"Task already being processed: {task.task_id}")
                    return
                
                # Add task
                self.tasks[task.task_id] = task
            
            logger.info(f"Task received: {task.task_id} (type: {task.task_type})")
            
            # Update task status
            task.status = TaskStatus.RUNNING
            task.started_at = datetime.datetime.now()
            self._send_task_update(task)
            
            # Submit task to pool
            self.task_pool.submit(self._process_task, task)
        except Exception as e:
            logger.error(f"Error handling task message: {e}")
    
    def _handle_task_status_message(self, identity: bytes, message: Dict[str, Any]) -> None:
        """
        Handle task status message.
        
        Args:
            identity: Client identity
            message: Message
        """
        try:
            # Get task ID
            task_id = message.get("task_id")
            if not task_id:
                logger.warning(f"Task ID not provided: {message}")
                return
            
            # Get task
            with self.tasks_lock:
                task = self.tasks.get(task_id)
            
            if not task:
                logger.warning(f"Task not found: {task_id}")
                
                # Send response
                response = {
                    "type": "task_status_response",
                    "success": False,
                    "message": "Task not found"
                }
                
                self.router_socket.send_multipart([identity, json.dumps(response).encode("utf-8")])
                return
            
            # Send response
            response = {
                "type": "task_status_response",
                "success": True,
                "task": task.to_dict()
            }
            
            self.router_socket.send_multipart([identity, json.dumps(response).encode("utf-8")])
        except Exception as e:
            logger.error(f"Error handling task status message: {e}")
            
            # Send error response
            response = {
                "type": "task_status_response",
                "success": False,
                "message": str(e)
            }
            
            self.router_socket.send_multipart([identity, json.dumps(response).encode("utf-8")])
    
    def _process_task(self, task: Task) -> None:
        """
        Process task.
        
        Args:
            task: Task to process
        """
        try:
            # Find handler for task
            for handler in self.task_handlers:
                if handler.can_handle(task.task_type):
                    # Handle task
                    success, result, error = handler.handle(task)
                    
                    # Update task
                    task.result = result
                    task.error = error
                    task.completed_at = datetime.datetime.now()
                    
                    if success:
                        task.status = TaskStatus.COMPLETED
                        self.completed_tasks += 1
                    else:
                        task.status = TaskStatus.FAILED
                        self.failed_tasks += 1
                    
                    # Send task result
                    self._send_task_result(task)
                    
                    logger.info(f"Task processed: {task.task_id} (status: {task.status.name})")
                    
                    # Remove task
                    with self.tasks_lock:
                        self.tasks.pop(task.task_id, None)
                    
                    return
            
            # No handler found
            task.status = TaskStatus.FAILED
            task.error = f"No handler found for task type: {task.task_type}"
            task.completed_at = datetime.datetime.now()
            
            self.failed_tasks += 1
            
            # Send task result
            self._send_task_result(task)
            
            logger.warning(f"No handler found for task: {task.task_id} (type: {task.task_type})")
            
            # Remove task
            with self.tasks_lock:
                self.tasks.pop(task.task_id, None)
        except Exception as e:
            logger.error(f"Error processing task: {e}")
            
            # Update task
            task.status = TaskStatus.FAILED
            task.error = str(e)
            task.completed_at = datetime.datetime.now()
            
            self.failed_tasks += 1
            
            # Send task result
            self._send_task_result(task)
            
            # Remove task
            with self.tasks_lock:
                self.tasks.pop(task.task_id, None)
    
    def _send_task_update(self, task: Task) -> bool:
        """
        Send task update to master.
        
        Args:
            task: Task to update
        
        Returns:
            True if update was sent, False otherwise
        """
        try:
            # Create message
            message = {
                "type": "task_update",
                "task": task.to_dict()
            }
            
            # Send message
            self.dealer_socket.send_json(message)
            
            # Wait for response
            poller = zmq.Poller()
            poller.register(self.dealer_socket, zmq.POLLIN)
            
            if poller.poll(5000):
                # Receive response
                response = self.dealer_socket.recv_json()
                
                # Check if update was successful
                if response.get("success"):
                    return True
                else:
                    logger.warning(f"Task update failed: {response.get('message')}")
                    return False
            else:
                logger.warning("Task update timed out")
                return False
        except Exception as e:
            logger.error(f"Error sending task update: {e}")
            return False
    
    def _send_task_result(self, task: Task) -> bool:
        """
        Send task result to master.
        
        Args:
            task: Task with result
        
        Returns:
            True if result was sent, False otherwise
        """
        try:
            # Create message
            message = {
                "type": "task_result",
                "task_id": task.task_id,
                "result": task.result,
                "error": task.error
            }
            
            # Send message
            self.dealer_socket.send_json(message)
            
            # Wait for response
            poller = zmq.Poller()
            poller.register(self.dealer_socket, zmq.POLLIN)
            
            if poller.poll(5000):
                # Receive response
                response = self.dealer_socket.recv_json()
                
                # Check if result was successful
                if response.get("success"):
                    return True
                else:
                    logger.warning(f"Task result failed: {response.get('message')}")
                    return False
            else:
                logger.warning("Task result timed out")
                return False
        except Exception as e:
            logger.error(f"Error sending task result: {e}")
            return False
    
    def get_node_info(self) -> NodeInfo:
        """
        Get node info.
        
        Returns:
            Node info
        """
        try:
            # Get system info
            import psutil
            
            # Get CPU info
            cpu_count = psutil.cpu_count()
            cpu_percent = psutil.cpu_percent()
            
            # Get memory info
            memory = psutil.virtual_memory()
            
            # Get disk info
            disk = psutil.disk_usage("/")
            
            # Calculate uptime
            uptime = (datetime.datetime.now() - self.start_time).total_seconds()
            
            # Get active tasks
            with self.tasks_lock:
                active_tasks = len([task for task in self.tasks.values() if task.status == TaskStatus.RUNNING])
            
            # Create node info
            return NodeInfo(
                node_id=self.config.node_id,
                node_name=self.config.node_name,
                node_role=self.config.node_role,
                host=self.config.host,
                port=self.config.port,
                status=NodeStatus.ONLINE,
                cpu_count=cpu_count,
                cpu_percent=cpu_percent,
                memory_total=memory.total,
                memory_available=memory.available,
                memory_percent=memory.percent,
                disk_total=disk.total,
                disk_available=disk.free,
                disk_percent=disk.percent,
                active_tasks=active_tasks,
                completed_tasks=self.completed_tasks,
                failed_tasks=self.failed_tasks,
                uptime_seconds=int(uptime),
                last_heartbeat=datetime.datetime.now()
            )
        except Exception as e:
            logger.error(f"Error getting node info: {e}")
            
            # Return basic node info
            return NodeInfo(
                node_id=self.config.node_id,
                node_name=self.config.node_name,
                node_role=self.config.node_role,
                host=self.config.host,
                port=self.config.port,
                status=NodeStatus.ONLINE,
                cpu_count=0,
                cpu_percent=0.0,
                memory_total=0,
                memory_available=0,
                memory_percent=0.0,
                disk_total=0,
                disk_available=0,
                disk_percent=0.0,
                active_tasks=0,
                completed_tasks=0,
                failed_tasks=0,
                uptime_seconds=0,
                last_heartbeat=datetime.datetime.now()
            )
    
    def get_active_tasks(self) -> List[Task]:
        """
        Get active tasks.
        
        Returns:
            List of active tasks
        """
        with self.tasks_lock:
            return list(self.tasks.values())


class ScalabilityManager:
    """
    Scalability manager for OPSC Sandwich Quality Inspection System.
    
    Provides functionality for managing distributed processing across multiple nodes.
    """
    
    def __init__(self, config_file: str, model_manager=None):
        """
        Initialize scalability manager.
        
        Args:
            config_file: Configuration file path
            model_manager: Model manager
        """
        self.config_file = config_file
        self.model_manager = model_manager
        
        # Load configuration
        self.config = self._load_config()
        
        # Initialize node
        self.node = None
        
        # Initialize lock
        self.lock = threading.Lock()
    
    def _load_config(self) -> Dict[str, Any]:
        """
        Load configuration.
        
        Returns:
            Configuration
        """
        try:
            # Check if config file exists
            if not os.path.exists(self.config_file):
                # Create default config
                config = {
                    "node_id": str(uuid.uuid4()),
                    "node_name": socket.gethostname(),
                    "node_role": "WORKER",
                    "host": socket.gethostbyname(socket.gethostname()),
                    "port": 5555,
                    "master_host": "localhost",
                    "master_port": 5555,
                    "max_tasks": 10,
                    "max_workers": multiprocessing.cpu_count(),
                    "heartbeat_interval": 5,
                    "task_timeout": 300
                }
                
                # Save config
                with open(self.config_file, "w") as f:
                    json.dump(config, f, indent=2)
                
                return config
            
            # Load config
            with open(self.config_file, "r") as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"Error loading configuration: {e}")
            
            # Return default config
            return {
                "node_id": str(uuid.uuid4()),
                "node_name": socket.gethostname(),
                "node_role": "WORKER",
                "host": socket.gethostbyname(socket.gethostname()),
                "port": 5555,
                "master_host": "localhost",
                "master_port": 5555,
                "max_tasks": 10,
                "max_workers": multiprocessing.cpu_count(),
                "heartbeat_interval": 5,
                "task_timeout": 300
            }
    
    def _save_config(self) -> bool:
        """
        Save configuration.
        
        Returns:
            True if configuration was saved, False otherwise
        """
        try:
            # Save config
            with open(self.config_file, "w") as f:
                json.dump(self.config, f, indent=2)
            
            return True
        except Exception as e:
            logger.error(f"Error saving configuration: {e}")
            return False
    
    def start(self) -> bool:
        """
        Start scalability manager.
        
        Returns:
            True if scalability manager was started, False otherwise
        """
        with self.lock:
            if self.node:
                logger.warning("Scalability manager is already running")
                return False
            
            # Create node config
            node_config = NodeConfig(
                node_id=self.config.get("node_id", str(uuid.uuid4())),
                node_name=self.config.get("node_name", socket.gethostname()),
                node_role=NodeRole[self.config.get("node_role", "WORKER")],
                host=self.config.get("host", socket.gethostbyname(socket.gethostname())),
                port=self.config.get("port", 5555),
                max_tasks=self.config.get("max_tasks", 10),
                max_workers=self.config.get("max_workers", multiprocessing.cpu_count()),
                heartbeat_interval=self.config.get("heartbeat_interval", 5),
                task_timeout=self.config.get("task_timeout", 300)
            )
            
            # Create node
            if node_config.node_role == NodeRole.MASTER:
                # Create master node
                self.node = MasterNode(node_config, self.model_manager)
                self.node.start()
            else:
                # Create worker node
                master_host = self.config.get("master_host", "localhost")
                master_port = self.config.get("master_port", 5555)
                
                self.node = WorkerNode(node_config, master_host, master_port, self.model_manager)
                if not self.node.start():
                    self.node = None
                    return False
            
            return True
    
    def stop(self) -> None:
        """Stop scalability manager."""
        with self.lock:
            if not self.node:
                logger.warning("Scalability manager is not running")
                return
            
            # Stop node
            self.node.stop()
            self.node = None
    
    def is_running(self) -> bool:
        """
        Check if scalability manager is running.
        
        Returns:
            True if scalability manager is running, False otherwise
        """
        with self.lock:
            return self.node is not None
    
    def is_master(self) -> bool:
        """
        Check if node is master.
        
        Returns:
            True if node is master, False otherwise
        """
        with self.lock:
            if not self.node:
                return False
            
            return isinstance(self.node, MasterNode)
    
    def add_task(self, task_type: str, data: Dict[str, Any], priority: TaskPriority = TaskPriority.NORMAL, timeout_seconds: int = 300) -> Optional[str]:
        """
        Add task.
        
        Args:
            task_type: Task type
            data: Task data
            priority: Task priority
            timeout_seconds: Task timeout in seconds
        
        Returns:
            Task ID or None if task could not be added
        """
        with self.lock:
            if not self.node:
                logger.warning("Scalability manager is not running")
                return None
            
            if not isinstance(self.node, MasterNode):
                logger.warning("Only master node can add tasks")
                return None
            
            return self.node.add_task(task_type, data, priority, timeout_seconds)
    
    def get_task(self, task_id: str) -> Optional[Task]:
        """
        Get task.
        
        Args:
            task_id: Task ID
        
        Returns:
            Task or None if not found
        """
        with self.lock:
            if not self.node:
                logger.warning("Scalability manager is not running")
                return None
            
            if not isinstance(self.node, MasterNode):
                logger.warning("Only master node can get tasks")
                return None
            
            return self.node.get_task(task_id)
    
    def cancel_task(self, task_id: str) -> bool:
        """
        Cancel task.
        
        Args:
            task_id: Task ID
        
        Returns:
            True if task was canceled, False otherwise
        """
        with self.lock:
            if not self.node:
                logger.warning("Scalability manager is not running")
                return False
            
            if not isinstance(self.node, MasterNode):
                logger.warning("Only master node can cancel tasks")
                return False
            
            return self.node.cancel_task(task_id)
    
    def get_all_nodes(self) -> List[NodeInfo]:
        """
        Get all nodes.
        
        Returns:
            List of all nodes
        """
        with self.lock:
            if not self.node:
                logger.warning("Scalability manager is not running")
                return []
            
            if not isinstance(self.node, MasterNode):
                logger.warning("Only master node can get all nodes")
                return []
            
            return self.node.get_all_nodes()
    
    def get_all_tasks(self) -> List[Task]:
        """
        Get all tasks.
        
        Returns:
            List of all tasks
        """
        with self.lock:
            if not self.node:
                logger.warning("Scalability manager is not running")
                return []
            
            if not isinstance(self.node, MasterNode):
                logger.warning("Only master node can get all tasks")
                return []
            
            return self.node.get_all_tasks()
    
    def get_tasks_by_status(self, status: TaskStatus) -> List[Task]:
        """
        Get tasks by status.
        
        Args:
            status: Task status
        
        Returns:
            List of tasks with the specified status
        """
        with self.lock:
            if not self.node:
                logger.warning("Scalability manager is not running")
                return []
            
            if not isinstance(self.node, MasterNode):
                logger.warning("Only master node can get tasks by status")
                return []
            
            return self.node.get_tasks_by_status(status)
    
    def get_node_info(self) -> Optional[NodeInfo]:
        """
        Get node info.
        
        Returns:
            Node info or None if not running
        """
        with self.lock:
            if not self.node:
                logger.warning("Scalability manager is not running")
                return None
            
            if isinstance(self.node, MasterNode):
                return self.node.get_node_info()
            else:
                return self.node.get_node_info()
    
    def register_task_handler(self, handler: TaskHandler) -> None:
        """
        Register task handler.
        
        Args:
            handler: Task handler to register
        """
        with self.lock:
            if not self.node:
                logger.warning("Scalability manager is not running")
                return
            
            self.node.register_task_handler(handler)
    
    def set_role(self, role: NodeRole) -> bool:
        """
        Set node role.
        
        Args:
            role: Node role
        
        Returns:
            True if role was set, False otherwise
        """
        with self.lock:
            if self.node:
                logger.warning("Cannot change role while running")
                return False
            
            # Update config
            self.config["node_role"] = role.name
            
            # Save config
            return self._save_config()
    
    def set_master(self, host: str, port: int) -> bool:
        """
        Set master node.
        
        Args:
            host: Master host
            port: Master port
        
        Returns:
            True if master was set, False otherwise
        """
        with self.lock:
            if self.node:
                logger.warning("Cannot change master while running")
                return False
            
            # Update config
            self.config["master_host"] = host
            self.config["master_port"] = port
            
            # Save config
            return self._save_config()
    
    def set_host(self, host: str, port: int) -> bool:
        """
        Set host.
        
        Args:
            host: Host
            port: Port
        
        Returns:
            True if host was set, False otherwise
        """
        with self.lock:
            if self.node:
                logger.warning("Cannot change host while running")
                return False
            
            # Update config
            self.config["host"] = host
            self.config["port"] = port
            
            # Save config
            return self._save_config()


# Example usage
if __name__ == "__main__":
    # Setup logging
    logging.basicConfig(level=logging.INFO)
    
    # Create scalability manager
    manager = ScalabilityManager("scalability.json")
    
    # Set role to master
    manager.set_role(NodeRole.MASTER)
    
    # Start manager
    if manager.start():
        try:
            # Wait for Ctrl+C
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            pass
        finally:
            # Stop manager
            manager.stop()
