"""
Basler camera manager for OPSC Sandwich Quality Inspection System.
Provides high-level management of multiple Basler cameras.

Version: 1.0.0
Last Updated: 2025-04-20
"""

import os
import sys
import time
import threading
import queue
from typing import Dict, List, Optional, Tuple, Union, Any, Callable, Generator
import logging
import numpy as np
from dataclasses import dataclass, field
from enum import Enum
import json
import uuid
from pathlib import Path
import concurrent.futures

from ...utils.config import get_config
from ...utils.logging import setup_logging, log_exception
from .pylon_wrapper import (
    get_pylon_wrapper, CameraInfo, CameraImage, CameraState,
    CameraError, CameraConnectionError, CameraConfigurationError,
    CameraAcquisitionError, CameraNotFoundError
)

# Setup logging
logger = setup_logging(__name__)


@dataclass
class CameraConfig:
    """Camera configuration."""
    id: str
    model: str
    serial_number: Optional[str] = None
    ip_address: Optional[str] = None
    user_id: Optional[str] = None
    position: Optional[str] = None
    parameters: Dict[str, Any] = field(default_factory=dict)
    preprocessing: Dict[str, Any] = field(default_factory=dict)
    calibration: Dict[str, Any] = field(default_factory=dict)


@dataclass
class CameraStatus:
    """Camera status."""
    id: str
    state: CameraState
    connected: bool
    acquiring: bool
    frame_count: int = 0
    frame_rate: float = 0.0
    last_frame_time: Optional[float] = None
    error_message: Optional[str] = None
    parameters: Dict[str, Any] = field(default_factory=dict)


class BaslerCameraManager:
    """
    Manager for multiple Basler cameras.
    Provides high-level management of camera discovery, configuration, and image acquisition.
    """

    def __init__(self, config_file: Optional[str] = None):
        """
        Initialize the camera manager.
        
        Args:
            config_file: Path to camera configuration file. If None, uses the path from configuration.
        """
        # Get configuration file path
        if config_file is None:
            config_file = get_config("app.paths.config", "/home/ubuntu/opsc-vision-system/config") + "/cameras.yaml"
        
        self.config_file = config_file
        
        # Get Pylon wrapper
        self.pylon_wrapper = get_pylon_wrapper()
        
        # Initialize camera dictionaries
        self.camera_configs: Dict[str, CameraConfig] = {}
        self.camera_devices: Dict[str, Any] = {}
        self.camera_statuses: Dict[str, CameraStatus] = {}
        self.camera_threads: Dict[str, threading.Thread] = {}
        self.camera_locks: Dict[str, threading.RLock] = {}
        self.camera_image_queues: Dict[str, queue.Queue] = {}
        self.camera_callbacks: Dict[str, List[Callable[[CameraImage], None]]] = {}
        
        # Initialize frame rate calculation
        self.frame_rate_window = 30  # Number of frames to calculate frame rate
        self.frame_timestamps: Dict[str, List[float]] = {}
        
        # Initialize camera monitoring
        self.monitoring_thread = None
        self.monitoring_stop_event = threading.Event()
        
        # Load camera configurations
        self._load_camera_configs()
        
        # Initialize camera statuses
        self._initialize_camera_statuses()
        
        # Start camera monitoring
        self._start_monitoring()
    
    def __del__(self):
        """Clean up resources."""
        self.shutdown()
    
    def shutdown(self):
        """Shut down the camera manager and release all resources."""
        try:
            # Stop monitoring
            self._stop_monitoring()
            
            # Stop all cameras
            for camera_id in list(self.camera_devices.keys()):
                self.stop_camera(camera_id)
            
            # Close all cameras
            for camera_id in list(self.camera_devices.keys()):
                self.close_camera(camera_id)
            
            logger.info("Camera manager shut down")
        except Exception as e:
            logger.error(f"Error shutting down camera manager: {e}")
    
    def _load_camera_configs(self) -> None:
        """
        Load camera configurations from file.
        
        Raises:
            FileNotFoundError: If the configuration file is not found.
            ValueError: If the configuration file is invalid.
        """
        try:
            # Check if configuration file exists
            if not os.path.exists(self.config_file):
                logger.error(f"Camera configuration file not found: {self.config_file}")
                raise FileNotFoundError(f"Camera configuration file not found: {self.config_file}")
            
            # Load configuration
            from ...utils.config import load_config
            config = load_config(self.config_file)
            
            # Get cameras configuration
            cameras_config = config.get("cameras", [])
            
            if not cameras_config:
                logger.warning("No cameras configured")
                return
            
            # Process each camera configuration
            for camera_config in cameras_config:
                # Check required fields
                if "id" not in camera_config:
                    logger.error("Camera configuration missing 'id' field")
                    continue
                
                if "model" not in camera_config:
                    logger.error(f"Camera configuration for {camera_config['id']} missing 'model' field")
                    continue
                
                # Create camera configuration
                camera_id = camera_config["id"]
                
                # Create camera configuration object
                camera_config_obj = CameraConfig(
                    id=camera_id,
                    model=camera_config["model"],
                    serial_number=camera_config.get("serial_number"),
                    ip_address=camera_config.get("ip_address"),
                    user_id=camera_config.get("user_id"),
                    position=camera_config.get("position"),
                    parameters=camera_config.get("parameters", {}),
                    preprocessing=camera_config.get("preprocessing", {}),
                    calibration=camera_config.get("calibration", {})
                )
                
                # Add to dictionary
                self.camera_configs[camera_id] = camera_config_obj
                
                # Create camera lock
                self.camera_locks[camera_id] = threading.RLock()
                
                # Create camera image queue
                self.camera_image_queues[camera_id] = queue.Queue(maxsize=100)
                
                # Create camera callbacks list
                self.camera_callbacks[camera_id] = []
                
                # Create frame timestamps list
                self.frame_timestamps[camera_id] = []
            
            logger.info(f"Loaded {len(self.camera_configs)} camera configurations from {self.config_file}")
        except Exception as e:
            logger.error(f"Error loading camera configurations: {e}")
            raise
    
    def _initialize_camera_statuses(self) -> None:
        """Initialize camera statuses."""
        for camera_id, camera_config in self.camera_configs.items():
            # Create camera status
            camera_status = CameraStatus(
                id=camera_id,
                state=CameraState.DISCONNECTED,
                connected=False,
                acquiring=False
            )
            
            # Add to dictionary
            self.camera_statuses[camera_id] = camera_status
    
    def _start_monitoring(self) -> None:
        """Start camera monitoring thread."""
        # Check if monitoring is already running
        if self.monitoring_thread is not None and self.monitoring_thread.is_alive():
            logger.warning("Camera monitoring is already running")
            return
        
        # Reset stop event
        self.monitoring_stop_event.clear()
        
        # Create monitoring thread
        self.monitoring_thread = threading.Thread(target=self._monitoring_thread_func)
        self.monitoring_thread.daemon = True
        self.monitoring_thread.start()
        
        logger.info("Started camera monitoring")
    
    def _stop_monitoring(self) -> None:
        """Stop camera monitoring thread."""
        # Check if monitoring is running
        if self.monitoring_thread is None or not self.monitoring_thread.is_alive():
            logger.warning("Camera monitoring is not running")
            return
        
        # Set stop event
        self.monitoring_stop_event.set()
        
        # Wait for thread to finish
        self.monitoring_thread.join(timeout=5.0)
        
        # Reset thread
        self.monitoring_thread = None
        
        logger.info("Stopped camera monitoring")
    
    def _monitoring_thread_func(self) -> None:
        """Camera monitoring thread function."""
        try:
            # Monitoring interval
            interval = get_config("cameras.global.monitoring_interval", 1.0)
            
            # Monitoring loop
            while not self.monitoring_stop_event.is_set():
                try:
                    # Update camera statuses
                    self._update_camera_statuses()
                    
                    # Check for disconnected cameras
                    self._check_disconnected_cameras()
                    
                    # Wait for next iteration
                    self.monitoring_stop_event.wait(interval)
                except Exception as e:
                    logger.error(f"Error in camera monitoring: {e}")
                    
                    # Wait for next iteration
                    self.monitoring_stop_event.wait(interval)
        except Exception as e:
            logger.error(f"Error in camera monitoring thread: {e}")
    
    def _update_camera_statuses(self) -> None:
        """Update camera statuses."""
        for camera_id, camera_status in self.camera_statuses.items():
            try:
                # Get camera lock
                camera_lock = self.camera_locks.get(camera_id)
                
                if camera_lock is None:
                    continue
                
                # Acquire lock
                if not camera_lock.acquire(blocking=False):
                    continue
                
                try:
                    # Get camera device
                    camera_device = self.camera_devices.get(camera_id)
                    
                    if camera_device is None:
                        # Camera is not connected
                        camera_status.connected = False
                        camera_status.acquiring = False
                        camera_status.state = CameraState.DISCONNECTED
                        continue
                    
                    # Check if camera is connected
                    camera_status.connected = camera_device.IsOpen()
                    
                    # Check if camera is acquiring
                    camera_status.acquiring = camera_device.IsGrabbing()
                    
                    # Update state
                    if not camera_status.connected:
                        camera_status.state = CameraState.DISCONNECTED
                    elif camera_status.acquiring:
                        camera_status.state = CameraState.ACQUIRING
                    else:
                        camera_status.state = CameraState.CONNECTED
                    
                    # Update frame rate
                    self._update_frame_rate(camera_id)
                    
                    # Update parameters
                    if camera_status.connected:
                        try:
                            camera_status.parameters = self.pylon_wrapper.get_camera_parameters(camera_device)
                        except Exception as e:
                            logger.error(f"Error getting camera parameters for {camera_id}: {e}")
                finally:
                    # Release lock
                    camera_lock.release()
            except Exception as e:
                logger.error(f"Error updating camera status for {camera_id}: {e}")
    
    def _check_disconnected_cameras(self) -> None:
        """Check for disconnected cameras and try to reconnect."""
        # Get auto-reconnect setting
        auto_reconnect = get_config("cameras.global.auto_reconnect", True)
        
        if not auto_reconnect:
            return
        
        # Check each camera
        for camera_id, camera_status in self.camera_statuses.items():
            try:
                # Check if camera is disconnected
                if camera_status.state == CameraState.DISCONNECTED:
                    # Get camera lock
                    camera_lock = self.camera_locks.get(camera_id)
                    
                    if camera_lock is None:
                        continue
                    
                    # Acquire lock
                    if not camera_lock.acquire(blocking=False):
                        continue
                    
                    try:
                        # Try to reconnect
                        logger.info(f"Attempting to reconnect camera {camera_id}")
                        
                        # Get camera configuration
                        camera_config = self.camera_configs.get(camera_id)
                        
                        if camera_config is None:
                            logger.error(f"Camera configuration not found for {camera_id}")
                            continue
                        
                        # Connect to camera
                        try:
                            self.connect_camera(camera_id)
                            logger.info(f"Reconnected camera {camera_id}")
                        except Exception as e:
                            logger.error(f"Failed to reconnect camera {camera_id}: {e}")
                    finally:
                        # Release lock
                        camera_lock.release()
            except Exception as e:
                logger.error(f"Error checking disconnected camera {camera_id}: {e}")
    
    def _update_frame_rate(self, camera_id: str) -> None:
        """
        Update frame rate calculation for a camera.
        
        Args:
            camera_id: Camera ID.
        """
        try:
            # Get camera status
            camera_status = self.camera_statuses.get(camera_id)
            
            if camera_status is None:
                return
            
            # Get frame timestamps
            timestamps = self.frame_timestamps.get(camera_id, [])
            
            if not timestamps:
                camera_status.frame_rate = 0.0
                return
            
            # Calculate frame rate
            if len(timestamps) >= 2:
                # Calculate time difference between first and last timestamp
                time_diff = timestamps[-1] - timestamps[0]
                
                if time_diff > 0:
                    # Calculate frame rate
                    frame_rate = (len(timestamps) - 1) / time_diff
                    
                    # Update camera status
                    camera_status.frame_rate = frame_rate
            
            # Limit timestamps list to window size
            if len(timestamps) > self.frame_rate_window:
                self.frame_timestamps[camera_id] = timestamps[-self.frame_rate_window:]
        except Exception as e:
            logger.error(f"Error updating frame rate for {camera_id}: {e}")
    
    def discover_cameras(self) -> List[CameraInfo]:
        """
        Discover available cameras.
        
        Returns:
            List of camera information.
        """
        try:
            # Get available cameras
            cameras = self.pylon_wrapper.get_device_info_list()
            
            logger.info(f"Discovered {len(cameras)} cameras")
            
            return cameras
        except Exception as e:
            logger.error(f"Error discovering cameras: {e}")
            raise
    
    def connect_camera(self, camera_id: str) -> None:
        """
        Connect to a camera.
        
        Args:
            camera_id: Camera ID.
            
        Raises:
            ValueError: If the camera ID is not found in the configuration.
            CameraConnectionError: If the camera connection fails.
        """
        try:
            # Get camera configuration
            camera_config = self.camera_configs.get(camera_id)
            
            if camera_config is None:
                logger.error(f"Camera configuration not found for {camera_id}")
                raise ValueError(f"Camera configuration not found for {camera_id}")
            
            # Get camera lock
            camera_lock = self.camera_locks.get(camera_id)
            
            if camera_lock is None:
                logger.error(f"Camera lock not found for {camera_id}")
                raise ValueError(f"Camera lock not found for {camera_id}")
            
            # Acquire lock
            with camera_lock:
                # Check if camera is already connected
                if camera_id in self.camera_devices and self.camera_devices[camera_id].IsOpen():
                    logger.warning(f"Camera {camera_id} is already connected")
                    return
                
                # Create camera device
                camera_device = self.pylon_wrapper.create_device(
                    serial_number=camera_config.serial_number,
                    ip_address=camera_config.ip_address,
                    user_id=camera_config.user_id
                )
                
                # Open camera
                self.pylon_wrapper.open_camera(camera_device)
                
                # Configure camera
                self.pylon_wrapper.configure_camera(camera_device, camera_config.parameters)
                
                # Add to dictionary
                self.camera_devices[camera_id] = camera_device
                
                # Update camera status
                camera_status = self.camera_statuses.get(camera_id)
                
                if camera_status is not None:
                    camera_status.connected = True
                    camera_status.state = CameraState.CONNECTED
                    camera_status.error_message = None
                
                logger.info(f"Connected to camera {camera_id}")
        except Exception as e:
            logger.error(f"Error connecting to camera {camera_id}: {e}")
            
            # Update camera status
            camera_status = self.camera_statuses.get(camera_id)
            
            if camera_status is not None:
                camera_status.connected = False
                camera_status.state = CameraState.ERROR
                camera_status.error_message = str(e)
            
            raise CameraConnectionError(f"Error connecting to camera {camera_id}: {e}")
    
    def close_camera(self, camera_id: str) -> None:
        """
        Close a camera connection.
        
        Args:
            camera_id: Camera ID.
            
        Raises:
            ValueError: If the camera ID is not found in the configuration.
        """
        try:
            # Get camera lock
            camera_lock = self.camera_locks.get(camera_id)
            
            if camera_lock is None:
                logger.error(f"Camera lock not found for {camera_id}")
                raise ValueError(f"Camera lock not found for {camera_id}")
            
            # Acquire lock
            with camera_lock:
                # Check if camera is connected
                if camera_id not in self.camera_devices:
                    logger.warning(f"Camera {camera_id} is not connected")
                    return
                
                # Get camera device
                camera_device = self.camera_devices[camera_id]
                
                # Stop acquisition if running
                if camera_device.IsGrabbing():
                    self.stop_camera(camera_id)
                
                # Close camera
                self.pylon_wrapper.close_camera(camera_device)
                
                # Remove from dictionary
                del self.camera_devices[camera_id]
                
                # Update camera status
                camera_status = self.camera_statuses.get(camera_id)
                
                if camera_status is not None:
                    camera_status.connected = False
                    camera_status.acquiring = False
                    camera_status.state = CameraState.DISCONNECTED
                    camera_status.error_message = None
                
                logger.info(f"Closed camera {camera_id}")
        except Exception as e:
            logger.error(f"Error closing camera {camera_id}: {e}")
            
            # Update camera status
            camera_status = self.camera_statuses.get(camera_id)
            
            if camera_status is not None:
                camera_status.state = CameraState.ERROR
                camera_status.error_message = str(e)
    
    def configure_camera(self, camera_id: str, parameters: Dict[str, Any]) -> None:
        """
        Configure camera parameters.
        
        Args:
            camera_id: Camera ID.
            parameters: Camera parameters.
            
        Raises:
            ValueError: If the camera ID is not found in the configuration.
            CameraConfigurationError: If the camera configuration fails.
        """
        try:
            # Get camera lock
            camera_lock = self.camera_locks.get(camera_id)
            
            if camera_lock is None:
                logger.error(f"Camera lock not found for {camera_id}")
                raise ValueError(f"Camera lock not found for {camera_id}")
            
            # Acquire lock
            with camera_lock:
                # Check if camera is connected
                if camera_id not in self.camera_devices:
                    logger.error(f"Camera {camera_id} is not connected")
                    raise ValueError(f"Camera {camera_id} is not connected")
                
                # Get camera device
                camera_device = self.camera_devices[camera_id]
                
                # Configure camera
                self.pylon_wrapper.configure_camera(camera_device, parameters)
                
                # Update camera configuration
                camera_config = self.camera_configs.get(camera_id)
                
                if camera_config is not None:
                    # Update parameters
                    for key, value in parameters.items():
                        camera_config.parameters[key] = value
                
                logger.info(f"Configured camera {camera_id}")
        except Exception as e:
            logger.error(f"Error configuring camera {camera_id}: {e}")
            
            # Update camera status
            camera_status = self.camera_statuses.get(camera_id)
            
            if camera_status is not None:
                camera_status.state = CameraState.ERROR
                camera_status.error_message = str(e)
            
            raise CameraConfigurationError(f"Error configuring camera {camera_id}: {e}")
    
    def get_camera_parameters(self, camera_id: str) -> Dict[str, Any]:
        """
        Get current camera parameters.
        
        Args:
            camera_id: Camera ID.
            
        Returns:
            Dictionary of camera parameters.
            
        Raises:
            ValueError: If the camera ID is not found in the configuration.
            CameraError: If getting camera parameters fails.
        """
        try:
            # Get camera lock
            camera_lock = self.camera_locks.get(camera_id)
            
            if camera_lock is None:
                logger.error(f"Camera lock not found for {camera_id}")
                raise ValueError(f"Camera lock not found for {camera_id}")
            
            # Acquire lock
            with camera_lock:
                # Check if camera is connected
                if camera_id not in self.camera_devices:
                    logger.error(f"Camera {camera_id} is not connected")
                    raise ValueError(f"Camera {camera_id} is not connected")
                
                # Get camera device
                camera_device = self.camera_devices[camera_id]
                
                # Get camera parameters
                parameters = self.pylon_wrapper.get_camera_parameters(camera_device)
                
                return parameters
        except Exception as e:
            logger.error(f"Error getting camera parameters for {camera_id}: {e}")
            
            # Update camera status
            camera_status = self.camera_statuses.get(camera_id)
            
            if camera_status is not None:
                camera_status.state = CameraState.ERROR
                camera_status.error_message = str(e)
            
            raise CameraError(f"Error getting camera parameters for {camera_id}: {e}")
    
    def start_camera(self, camera_id: str) -> None:
        """
        Start image acquisition on a camera.
        
        Args:
            camera_id: Camera ID.
            
        Raises:
            ValueError: If the camera ID is not found in the configuration.
            CameraAcquisitionError: If starting image acquisition fails.
        """
        try:
            # Get camera lock
            camera_lock = self.camera_locks.get(camera_id)
            
            if camera_lock is None:
                logger.error(f"Camera lock not found for {camera_id}")
                raise ValueError(f"Camera lock not found for {camera_id}")
            
            # Acquire lock
            with camera_lock:
                # Check if camera is connected
                if camera_id not in self.camera_devices:
                    logger.error(f"Camera {camera_id} is not connected")
                    raise ValueError(f"Camera {camera_id} is not connected")
                
                # Get camera device
                camera_device = self.camera_devices[camera_id]
                
                # Check if camera is already acquiring
                if camera_device.IsGrabbing():
                    logger.warning(f"Camera {camera_id} is already acquiring")
                    return
                
                # Start grabbing
                self.pylon_wrapper.start_grabbing(camera_device)
                
                # Start image acquisition thread
                self._start_acquisition_thread(camera_id)
                
                # Update camera status
                camera_status = self.camera_statuses.get(camera_id)
                
                if camera_status is not None:
                    camera_status.acquiring = True
                    camera_status.state = CameraState.ACQUIRING
                    camera_status.error_message = None
                
                logger.info(f"Started image acquisition on camera {camera_id}")
        except Exception as e:
            logger.error(f"Error starting image acquisition on camera {camera_id}: {e}")
            
            # Update camera status
            camera_status = self.camera_statuses.get(camera_id)
            
            if camera_status is not None:
                camera_status.acquiring = False
                camera_status.state = CameraState.ERROR
                camera_status.error_message = str(e)
            
            raise CameraAcquisitionError(f"Error starting image acquisition on camera {camera_id}: {e}")
    
    def stop_camera(self, camera_id: str) -> None:
        """
        Stop image acquisition on a camera.
        
        Args:
            camera_id: Camera ID.
            
        Raises:
            ValueError: If the camera ID is not found in the configuration.
        """
        try:
            # Get camera lock
            camera_lock = self.camera_locks.get(camera_id)
            
            if camera_lock is None:
                logger.error(f"Camera lock not found for {camera_id}")
                raise ValueError(f"Camera lock not found for {camera_id}")
            
            # Acquire lock
            with camera_lock:
                # Check if camera is connected
                if camera_id not in self.camera_devices:
                    logger.warning(f"Camera {camera_id} is not connected")
                    return
                
                # Get camera device
                camera_device = self.camera_devices[camera_id]
                
                # Check if camera is acquiring
                if not camera_device.IsGrabbing():
                    logger.warning(f"Camera {camera_id} is not acquiring")
                    return
                
                # Stop grabbing
                self.pylon_wrapper.stop_grabbing(camera_device)
                
                # Stop image acquisition thread
                self._stop_acquisition_thread(camera_id)
                
                # Update camera status
                camera_status = self.camera_statuses.get(camera_id)
                
                if camera_status is not None:
                    camera_status.acquiring = False
                    camera_status.state = CameraState.CONNECTED
                    camera_status.error_message = None
                
                logger.info(f"Stopped image acquisition on camera {camera_id}")
        except Exception as e:
            logger.error(f"Error stopping image acquisition on camera {camera_id}: {e}")
            
            # Update camera status
            camera_status = self.camera_statuses.get(camera_id)
            
            if camera_status is not None:
                camera_status.state = CameraState.ERROR
                camera_status.error_message = str(e)
    
    def _start_acquisition_thread(self, camera_id: str) -> None:
        """
        Start image acquisition thread for a camera.
        
        Args:
            camera_id: Camera ID.
        """
        try:
            # Check if thread is already running
            if camera_id in self.camera_threads and self.camera_threads[camera_id].is_alive():
                logger.warning(f"Image acquisition thread for camera {camera_id} is already running")
                return
            
            # Get camera device
            camera_device = self.camera_devices.get(camera_id)
            
            if camera_device is None:
                logger.error(f"Camera device not found for {camera_id}")
                return
            
            # Create stop event
            stop_event = threading.Event()
            
            # Create acquisition thread
            def acquisition_thread():
                try:
                    # Get timeout
                    timeout = get_config("cameras.global.acquisition_timeout", 5000)
                    
                    # Acquisition loop
                    while not stop_event.is_set() and camera_device.IsGrabbing():
                        try:
                            # Grab image
                            grab_result = camera_device.RetrieveResult(timeout, pylon.TimeoutHandling_Return)
                            
                            # Check if grab was successful
                            if grab_result is not None and grab_result.GrabSucceeded():
                                try:
                                    # Get image data
                                    image = self.pylon_wrapper._convert_grab_result_to_image(grab_result, camera_device)
                                    
                                    # Update frame count
                                    camera_status = self.camera_statuses.get(camera_id)
                                    
                                    if camera_status is not None:
                                        camera_status.frame_count += 1
                                        camera_status.last_frame_time = time.time()
                                    
                                    # Add timestamp to frame timestamps
                                    self.frame_timestamps.setdefault(camera_id, []).append(time.time())
                                    
                                    # Add to queue
                                    image_queue = self.camera_image_queues.get(camera_id)
                                    
                                    if image_queue is not None:
                                        try:
                                            image_queue.put(image, block=False)
                                        except queue.Full:
                                            # Queue is full, discard oldest image
                                            try:
                                                image_queue.get(block=False)
                                                image_queue.put(image, block=False)
                                            except queue.Empty:
                                                # Queue was emptied by consumer thread
                                                image_queue.put(image, block=False)
                                    
                                    # Call callbacks
                                    callbacks = self.camera_callbacks.get(camera_id, [])
                                    
                                    for callback in callbacks:
                                        try:
                                            callback(image)
                                        except Exception as e:
                                            logger.error(f"Error in camera callback for {camera_id}: {e}")
                                except Exception as e:
                                    logger.error(f"Error processing image from camera {camera_id}: {e}")
                            
                            # Release grab result
                            if grab_result is not None:
                                grab_result.Release()
                        except Exception as e:
                            logger.error(f"Error in acquisition thread for camera {camera_id}: {e}")
                except Exception as e:
                    logger.error(f"Error in acquisition thread for camera {camera_id}: {e}")
                finally:
                    # Update camera status
                    camera_status = self.camera_statuses.get(camera_id)
                    
                    if camera_status is not None:
                        camera_status.acquiring = False
                        
                        if camera_status.state == CameraState.ACQUIRING:
                            camera_status.state = CameraState.CONNECTED
            
            # Create thread
            thread = threading.Thread(target=acquisition_thread)
            thread.daemon = True
            
            # Store stop event in thread object for later use
            thread.stop_event = stop_event
            
            # Start thread
            thread.start()
            
            # Store thread
            self.camera_threads[camera_id] = thread
            
            logger.info(f"Started image acquisition thread for camera {camera_id}")
        except Exception as e:
            logger.error(f"Error starting image acquisition thread for camera {camera_id}: {e}")
    
    def _stop_acquisition_thread(self, camera_id: str) -> None:
        """
        Stop image acquisition thread for a camera.
        
        Args:
            camera_id: Camera ID.
        """
        try:
            # Check if thread is running
            if camera_id not in self.camera_threads or not self.camera_threads[camera_id].is_alive():
                logger.warning(f"Image acquisition thread for camera {camera_id} is not running")
                return
            
            # Get thread
            thread = self.camera_threads[camera_id]
            
            # Set stop event
            thread.stop_event.set()
            
            # Wait for thread to finish
            thread.join(timeout=5.0)
            
            # Remove thread
            del self.camera_threads[camera_id]
            
            logger.info(f"Stopped image acquisition thread for camera {camera_id}")
        except Exception as e:
            logger.error(f"Error stopping image acquisition thread for camera {camera_id}: {e}")
    
    def get_image(self, camera_id: str, timeout: float = 1.0) -> Optional[CameraImage]:
        """
        Get the latest image from a camera.
        
        Args:
            camera_id: Camera ID.
            timeout: Timeout in seconds.
            
        Returns:
            Camera image, or None if no image is available.
            
        Raises:
            ValueError: If the camera ID is not found in the configuration.
        """
        try:
            # Get camera lock
            camera_lock = self.camera_locks.get(camera_id)
            
            if camera_lock is None:
                logger.error(f"Camera lock not found for {camera_id}")
                raise ValueError(f"Camera lock not found for {camera_id}")
            
            # Acquire lock
            with camera_lock:
                # Check if camera is connected
                if camera_id not in self.camera_devices:
                    logger.error(f"Camera {camera_id} is not connected")
                    raise ValueError(f"Camera {camera_id} is not connected")
                
                # Get camera device
                camera_device = self.camera_devices[camera_id]
                
                # Check if camera is acquiring
                if not camera_device.IsGrabbing():
                    logger.error(f"Camera {camera_id} is not acquiring")
                    raise ValueError(f"Camera {camera_id} is not acquiring")
                
                # Get image from queue
                image_queue = self.camera_image_queues.get(camera_id)
                
                if image_queue is None:
                    logger.error(f"Image queue not found for {camera_id}")
                    raise ValueError(f"Image queue not found for {camera_id}")
                
                try:
                    # Get image from queue
                    image = image_queue.get(block=True, timeout=timeout)
                    
                    # Mark task as done
                    image_queue.task_done()
                    
                    return image
                except queue.Empty:
                    # Queue is empty
                    return None
        except ValueError:
            raise
        except Exception as e:
            logger.error(f"Error getting image from camera {camera_id}: {e}")
            
            # Update camera status
            camera_status = self.camera_statuses.get(camera_id)
            
            if camera_status is not None:
                camera_status.state = CameraState.ERROR
                camera_status.error_message = str(e)
            
            return None
    
    def get_images(self, timeout: float = 1.0) -> Dict[str, CameraImage]:
        """
        Get the latest images from all cameras.
        
        Args:
            timeout: Timeout in seconds.
            
        Returns:
            Dictionary of camera images, keyed by camera ID.
        """
        try:
            # Get images from all cameras
            images = {}
            
            # Use thread pool for parallel image acquisition
            with concurrent.futures.ThreadPoolExecutor(max_workers=len(self.camera_configs)) as executor:
                # Submit tasks
                future_to_camera_id = {
                    executor.submit(self.get_image, camera_id, timeout): camera_id
                    for camera_id in self.camera_configs
                }
                
                # Get results
                for future in concurrent.futures.as_completed(future_to_camera_id):
                    camera_id = future_to_camera_id[future]
                    
                    try:
                        image = future.result()
                        
                        if image is not None:
                            images[camera_id] = image
                    except Exception as e:
                        logger.error(f"Error getting image from camera {camera_id}: {e}")
            
            return images
        except Exception as e:
            logger.error(f"Error getting images from cameras: {e}")
            return {}
    
    def register_callback(self, camera_id: str, callback: Callable[[CameraImage], None]) -> None:
        """
        Register a callback function for a camera.
        
        Args:
            camera_id: Camera ID.
            callback: Callback function to call for each image.
            
        Raises:
            ValueError: If the camera ID is not found in the configuration.
        """
        try:
            # Get camera lock
            camera_lock = self.camera_locks.get(camera_id)
            
            if camera_lock is None:
                logger.error(f"Camera lock not found for {camera_id}")
                raise ValueError(f"Camera lock not found for {camera_id}")
            
            # Acquire lock
            with camera_lock:
                # Get callbacks list
                callbacks = self.camera_callbacks.get(camera_id)
                
                if callbacks is None:
                    logger.error(f"Callbacks list not found for {camera_id}")
                    raise ValueError(f"Callbacks list not found for {camera_id}")
                
                # Add callback
                callbacks.append(callback)
                
                logger.info(f"Registered callback for camera {camera_id}")
        except Exception as e:
            logger.error(f"Error registering callback for camera {camera_id}: {e}")
            raise
    
    def unregister_callback(self, camera_id: str, callback: Callable[[CameraImage], None]) -> None:
        """
        Unregister a callback function for a camera.
        
        Args:
            camera_id: Camera ID.
            callback: Callback function to unregister.
            
        Raises:
            ValueError: If the camera ID is not found in the configuration.
        """
        try:
            # Get camera lock
            camera_lock = self.camera_locks.get(camera_id)
            
            if camera_lock is None:
                logger.error(f"Camera lock not found for {camera_id}")
                raise ValueError(f"Camera lock not found for {camera_id}")
            
            # Acquire lock
            with camera_lock:
                # Get callbacks list
                callbacks = self.camera_callbacks.get(camera_id)
                
                if callbacks is None:
                    logger.error(f"Callbacks list not found for {camera_id}")
                    raise ValueError(f"Callbacks list not found for {camera_id}")
                
                # Remove callback
                if callback in callbacks:
                    callbacks.remove(callback)
                    logger.info(f"Unregistered callback for camera {camera_id}")
                else:
                    logger.warning(f"Callback not found for camera {camera_id}")
        except Exception as e:
            logger.error(f"Error unregistering callback for camera {camera_id}: {e}")
            raise
    
    def save_image(self, image: CameraImage, file_path: str, format: str = "png") -> None:
        """
        Save an image to a file.
        
        Args:
            image: Camera image.
            file_path: Path to save the image to.
            format: Image format (png, jpg, tiff).
            
        Raises:
            IOError: If the image cannot be saved.
        """
        try:
            # Save image
            self.pylon_wrapper.save_image(image, file_path, format)
        except Exception as e:
            logger.error(f"Error saving image to {file_path}: {e}")
            raise IOError(f"Error saving image to {file_path}: {e}")
    
    def get_camera_status(self, camera_id: str) -> Optional[CameraStatus]:
        """
        Get the status of a camera.
        
        Args:
            camera_id: Camera ID.
            
        Returns:
            Camera status, or None if the camera ID is not found.
        """
        return self.camera_statuses.get(camera_id)
    
    def get_camera_statuses(self) -> Dict[str, CameraStatus]:
        """
        Get the status of all cameras.
        
        Returns:
            Dictionary of camera statuses, keyed by camera ID.
        """
        return self.camera_statuses.copy()
    
    def get_camera_config(self, camera_id: str) -> Optional[CameraConfig]:
        """
        Get the configuration of a camera.
        
        Args:
            camera_id: Camera ID.
            
        Returns:
            Camera configuration, or None if the camera ID is not found.
        """
        return self.camera_configs.get(camera_id)
    
    def get_camera_configs(self) -> Dict[str, CameraConfig]:
        """
        Get the configuration of all cameras.
        
        Returns:
            Dictionary of camera configurations, keyed by camera ID.
        """
        return self.camera_configs.copy()
    
    def execute_software_trigger(self, camera_id: str) -> None:
        """
        Execute a software trigger on a camera.
        
        Args:
            camera_id: Camera ID.
            
        Raises:
            ValueError: If the camera ID is not found in the configuration.
            CameraError: If the trigger execution fails.
        """
        try:
            # Get camera lock
            camera_lock = self.camera_locks.get(camera_id)
            
            if camera_lock is None:
                logger.error(f"Camera lock not found for {camera_id}")
                raise ValueError(f"Camera lock not found for {camera_id}")
            
            # Acquire lock
            with camera_lock:
                # Check if camera is connected
                if camera_id not in self.camera_devices:
                    logger.error(f"Camera {camera_id} is not connected")
                    raise ValueError(f"Camera {camera_id} is not connected")
                
                # Get camera device
                camera_device = self.camera_devices[camera_id]
                
                # Execute software trigger
                self.pylon_wrapper.execute_software_trigger(camera_device)
                
                logger.info(f"Executed software trigger on camera {camera_id}")
        except Exception as e:
            logger.error(f"Error executing software trigger on camera {camera_id}: {e}")
            
            # Update camera status
            camera_status = self.camera_statuses.get(camera_id)
            
            if camera_status is not None:
                camera_status.state = CameraState.ERROR
                camera_status.error_message = str(e)
            
            raise CameraError(f"Error executing software trigger on camera {camera_id}: {e}")


# Singleton instance
_camera_manager: Optional[BaslerCameraManager] = None


def get_camera_manager() -> BaslerCameraManager:
    """
    Get the singleton BaslerCameraManager instance.
    
    Returns:
        BaslerCameraManager instance.
    """
    global _camera_manager
    if _camera_manager is None:
        _camera_manager = BaslerCameraManager()
    return _camera_manager


if __name__ == "__main__":
    # Setup logging for standalone execution
    logging.basicConfig(level=logging.INFO)
    
    # Example usage
    camera_manager = get_camera_manager()
    
    try:
        # Discover cameras
        cameras = camera_manager.discover_cameras()
        logger.info(f"Found {len(cameras)} cameras")
        
        for i, camera in enumerate(cameras):
            logger.info(f"Camera {i+1}: {camera.serial_number} ({camera.model} by {camera.vendor})")
        
        # Get camera configurations
        camera_configs = camera_manager.get_camera_configs()
        logger.info(f"Loaded {len(camera_configs)} camera configurations")
        
        for camera_id, camera_config in camera_configs.items():
            logger.info(f"Camera {camera_id}: {camera_config.model}")
            
            # Connect to camera
            try:
                camera_manager.connect_camera(camera_id)
                
                # Start camera
                camera_manager.start_camera(camera_id)
                
                # Get image
                image = camera_manager.get_image(camera_id)
                
                if image:
                    logger.info(f"Got image from camera {camera_id}: {image.width}x{image.height} {image.pixel_format}")
                    
                    # Save image
                    camera_manager.save_image(image, f"test_image_{camera_id}.png")
                
                # Stop camera
                camera_manager.stop_camera(camera_id)
                
                # Close camera
                camera_manager.close_camera(camera_id)
            except Exception as e:
                logger.error(f"Error testing camera {camera_id}: {e}")
    except Exception as e:
        logger.error(f"Error in example: {e}")
    finally:
        # Shutdown camera manager
        camera_manager.shutdown()
