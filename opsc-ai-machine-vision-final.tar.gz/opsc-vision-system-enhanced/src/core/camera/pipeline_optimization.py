"""
Camera data pipeline optimization module for OPSC Sandwich Quality Inspection System.
Provides functionality for optimizing camera data acquisition, processing, and streaming.

Version: 1.0.0
Last Updated: 2025-04-21
"""

import os
import sys
import time
import json
import logging
import datetime
import uuid
import threading
import queue
import numpy as np
import cv2
from typing import Dict, List, Optional, Tuple, Union, Any, Callable
from dataclasses import dataclass, field
from pathlib import Path
from enum import Enum, auto
import multiprocessing as mp
from concurrent.futures import ThreadPoolExecutor

# Setup logging
logger = logging.getLogger(__name__)

class ProcessingStage(Enum):
    """Camera processing stage enum."""
    ACQUISITION = auto()
    PREPROCESSING = auto()
    TRANSFORMATION = auto()
    ENHANCEMENT = auto()
    COMPRESSION = auto()
    STREAMING = auto()


@dataclass
class PipelineConfig:
    """Pipeline configuration data class."""
    camera_id: str
    camera_name: str
    resolution: Tuple[int, int]
    fps: int
    format: str  # "RGB", "BGR", "GRAY"
    bit_depth: int  # 8, 10, 12, 16
    enable_preprocessing: bool = True
    enable_transformation: bool = True
    enable_enhancement: bool = True
    enable_compression: bool = False
    enable_streaming: bool = False
    buffer_size: int = 10
    processing_threads: int = 4
    preprocessing_params: Dict[str, Any] = field(default_factory=dict)
    transformation_params: Dict[str, Any] = field(default_factory=dict)
    enhancement_params: Dict[str, Any] = field(default_factory=dict)
    compression_params: Dict[str, Any] = field(default_factory=dict)
    streaming_params: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "camera_id": self.camera_id,
            "camera_name": self.camera_name,
            "resolution": self.resolution,
            "fps": self.fps,
            "format": self.format,
            "bit_depth": self.bit_depth,
            "enable_preprocessing": self.enable_preprocessing,
            "enable_transformation": self.enable_transformation,
            "enable_enhancement": self.enable_enhancement,
            "enable_compression": self.enable_compression,
            "enable_streaming": self.enable_streaming,
            "buffer_size": self.buffer_size,
            "processing_threads": self.processing_threads,
            "preprocessing_params": self.preprocessing_params,
            "transformation_params": self.transformation_params,
            "enhancement_params": self.enhancement_params,
            "compression_params": self.compression_params,
            "streaming_params": self.streaming_params
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'PipelineConfig':
        """Create from dictionary."""
        return cls(
            camera_id=data.get("camera_id"),
            camera_name=data.get("camera_name"),
            resolution=tuple(data.get("resolution")),
            fps=data.get("fps"),
            format=data.get("format"),
            bit_depth=data.get("bit_depth"),
            enable_preprocessing=data.get("enable_preprocessing", True),
            enable_transformation=data.get("enable_transformation", True),
            enable_enhancement=data.get("enable_enhancement", True),
            enable_compression=data.get("enable_compression", False),
            enable_streaming=data.get("enable_streaming", False),
            buffer_size=data.get("buffer_size", 10),
            processing_threads=data.get("processing_threads", 4),
            preprocessing_params=data.get("preprocessing_params", {}),
            transformation_params=data.get("transformation_params", {}),
            enhancement_params=data.get("enhancement_params", {}),
            compression_params=data.get("compression_params", {}),
            streaming_params=data.get("streaming_params", {})
        )


@dataclass
class FrameMetadata:
    """Frame metadata data class."""
    frame_id: str
    camera_id: str
    timestamp: float
    sequence_num: int
    resolution: Tuple[int, int]
    format: str
    bit_depth: int
    exposure_time: float
    gain: float
    processing_stages: List[ProcessingStage] = field(default_factory=list)
    processing_times: Dict[ProcessingStage, float] = field(default_factory=dict)
    custom_metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "frame_id": self.frame_id,
            "camera_id": self.camera_id,
            "timestamp": self.timestamp,
            "sequence_num": self.sequence_num,
            "resolution": self.resolution,
            "format": self.format,
            "bit_depth": self.bit_depth,
            "exposure_time": self.exposure_time,
            "gain": self.gain,
            "processing_stages": [stage.name for stage in self.processing_stages],
            "processing_times": {stage.name: time for stage, time in self.processing_times.items()},
            "custom_metadata": self.custom_metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'FrameMetadata':
        """Create from dictionary."""
        processing_stages = []
        for stage_name in data.get("processing_stages", []):
            try:
                processing_stages.append(ProcessingStage[stage_name])
            except KeyError:
                logger.warning(f"Invalid processing stage: {stage_name}")
        
        processing_times = {}
        for stage_name, time_value in data.get("processing_times", {}).items():
            try:
                processing_times[ProcessingStage[stage_name]] = time_value
            except KeyError:
                logger.warning(f"Invalid processing stage: {stage_name}")
        
        return cls(
            frame_id=data.get("frame_id"),
            camera_id=data.get("camera_id"),
            timestamp=data.get("timestamp"),
            sequence_num=data.get("sequence_num"),
            resolution=tuple(data.get("resolution")),
            format=data.get("format"),
            bit_depth=data.get("bit_depth"),
            exposure_time=data.get("exposure_time"),
            gain=data.get("gain"),
            processing_stages=processing_stages,
            processing_times=processing_times,
            custom_metadata=data.get("custom_metadata", {})
        )


class Frame:
    """
    Frame class for camera data pipeline.
    
    Represents a single frame with its data and metadata.
    """
    
    def __init__(self, data: np.ndarray, metadata: FrameMetadata):
        """
        Initialize frame.
        
        Args:
            data: Frame data as NumPy array
            metadata: Frame metadata
        """
        self.data = data
        self.metadata = metadata
    
    def copy(self) -> 'Frame':
        """
        Create a deep copy of the frame.
        
        Returns:
            Deep copy of the frame
        """
        return Frame(
            data=self.data.copy(),
            metadata=FrameMetadata(
                frame_id=self.metadata.frame_id,
                camera_id=self.metadata.camera_id,
                timestamp=self.metadata.timestamp,
                sequence_num=self.metadata.sequence_num,
                resolution=self.metadata.resolution,
                format=self.metadata.format,
                bit_depth=self.metadata.bit_depth,
                exposure_time=self.metadata.exposure_time,
                gain=self.metadata.gain,
                processing_stages=self.metadata.processing_stages.copy(),
                processing_times=self.metadata.processing_times.copy(),
                custom_metadata=self.metadata.custom_metadata.copy()
            )
        )
    
    def update_metadata(self, stage: ProcessingStage, processing_time: float):
        """
        Update metadata with processing stage and time.
        
        Args:
            stage: Processing stage
            processing_time: Processing time in milliseconds
        """
        self.metadata.processing_stages.append(stage)
        self.metadata.processing_times[stage] = processing_time


class FrameBuffer:
    """
    Frame buffer for camera data pipeline.
    
    Provides thread-safe buffer for frames with configurable size.
    """
    
    def __init__(self, buffer_size: int = 10):
        """
        Initialize frame buffer.
        
        Args:
            buffer_size: Maximum buffer size
        """
        self.buffer_size = buffer_size
        self.buffer = queue.Queue(maxsize=buffer_size)
        self.dropped_frames = 0
        self.total_frames = 0
        self.lock = threading.Lock()
    
    def put(self, frame: Frame, block: bool = True, timeout: Optional[float] = None) -> bool:
        """
        Put frame into buffer.
        
        Args:
            frame: Frame to put
            block: Whether to block if buffer is full
            timeout: Timeout in seconds
        
        Returns:
            True if frame was put, False if dropped
        """
        try:
            self.buffer.put(frame, block=block, timeout=timeout)
            with self.lock:
                self.total_frames += 1
            return True
        except queue.Full:
            with self.lock:
                self.dropped_frames += 1
                self.total_frames += 1
            logger.warning(f"Frame buffer full, dropped frame {frame.metadata.frame_id}")
            return False
    
    def get(self, block: bool = True, timeout: Optional[float] = None) -> Optional[Frame]:
        """
        Get frame from buffer.
        
        Args:
            block: Whether to block if buffer is empty
            timeout: Timeout in seconds
        
        Returns:
            Frame or None if buffer is empty
        """
        try:
            return self.buffer.get(block=block, timeout=timeout)
        except queue.Empty:
            return None
    
    def task_done(self):
        """Mark task as done."""
        self.buffer.task_done()
    
    def qsize(self) -> int:
        """
        Get current buffer size.
        
        Returns:
            Current buffer size
        """
        return self.buffer.qsize()
    
    def empty(self) -> bool:
        """
        Check if buffer is empty.
        
        Returns:
            True if buffer is empty, False otherwise
        """
        return self.buffer.empty()
    
    def full(self) -> bool:
        """
        Check if buffer is full.
        
        Returns:
            True if buffer is full, False otherwise
        """
        return self.buffer.full()
    
    def get_stats(self) -> Dict[str, int]:
        """
        Get buffer statistics.
        
        Returns:
            Dictionary with buffer statistics
        """
        with self.lock:
            return {
                "buffer_size": self.buffer_size,
                "current_size": self.qsize(),
                "dropped_frames": self.dropped_frames,
                "total_frames": self.total_frames
            }


class PipelineStage:
    """
    Pipeline stage for camera data pipeline.
    
    Base class for all pipeline stages.
    """
    
    def __init__(self, stage_type: ProcessingStage, name: str):
        """
        Initialize pipeline stage.
        
        Args:
            stage_type: Stage type
            name: Stage name
        """
        self.stage_type = stage_type
        self.name = name
        self.input_buffer = None
        self.output_buffer = None
        self.processing_thread = None
        self.processing_thread_running = False
        self.stats = {
            "processed_frames": 0,
            "processing_time_ms": 0.0,
            "avg_processing_time_ms": 0.0,
            "min_processing_time_ms": float('inf'),
            "max_processing_time_ms": 0.0
        }
        self.stats_lock = threading.Lock()
    
    def set_input_buffer(self, buffer: FrameBuffer):
        """
        Set input buffer.
        
        Args:
            buffer: Input buffer
        """
        self.input_buffer = buffer
    
    def set_output_buffer(self, buffer: FrameBuffer):
        """
        Set output buffer.
        
        Args:
            buffer: Output buffer
        """
        self.output_buffer = buffer
    
    def start(self):
        """Start processing thread."""
        if self.processing_thread is not None and self.processing_thread.is_alive():
            logger.warning(f"Processing thread for stage {self.name} is already running")
            return
        
        if self.input_buffer is None:
            raise ValueError(f"Input buffer for stage {self.name} is not set")
        
        if self.output_buffer is None:
            raise ValueError(f"Output buffer for stage {self.name} is not set")
        
        self.processing_thread_running = True
        self.processing_thread = threading.Thread(target=self._processing_loop, daemon=True)
        self.processing_thread.start()
        
        logger.info(f"Started processing thread for stage {self.name}")
    
    def stop(self):
        """Stop processing thread."""
        if self.processing_thread is None or not self.processing_thread.is_alive():
            logger.warning(f"Processing thread for stage {self.name} is not running")
            return
        
        self.processing_thread_running = False
        self.processing_thread.join(timeout=5.0)
        
        logger.info(f"Stopped processing thread for stage {self.name}")
    
    def _processing_loop(self):
        """Processing loop for thread."""
        logger.info(f"Processing thread for stage {self.name} started")
        
        while self.processing_thread_running:
            try:
                # Get frame from input buffer
                frame = self.input_buffer.get(block=True, timeout=1.0)
                if frame is None:
                    continue
                
                # Process frame
                try:
                    start_time = time.time()
                    processed_frame = self.process(frame)
                    end_time = time.time()
                    
                    # Calculate processing time
                    processing_time_ms = (end_time - start_time) * 1000
                    
                    # Update frame metadata
                    processed_frame.update_metadata(self.stage_type, processing_time_ms)
                    
                    # Update stats
                    with self.stats_lock:
                        self.stats["processed_frames"] += 1
                        self.stats["processing_time_ms"] += processing_time_ms
                        self.stats["avg_processing_time_ms"] = self.stats["processing_time_ms"] / self.stats["processed_frames"]
                        self.stats["min_processing_time_ms"] = min(self.stats["min_processing_time_ms"], processing_time_ms)
                        self.stats["max_processing_time_ms"] = max(self.stats["max_processing_time_ms"], processing_time_ms)
                    
                    # Put frame to output buffer
                    self.output_buffer.put(processed_frame, block=True)
                    
                    # Mark task as done
                    self.input_buffer.task_done()
                except Exception as e:
                    logger.error(f"Error processing frame in stage {self.name}: {e}")
                    
                    # Mark task as done
                    self.input_buffer.task_done()
            except queue.Empty:
                continue
            except Exception as e:
                logger.error(f"Error in processing thread for stage {self.name}: {e}")
        
        logger.info(f"Processing thread for stage {self.name} stopped")
    
    def process(self, frame: Frame) -> Frame:
        """
        Process frame.
        
        Args:
            frame: Input frame
        
        Returns:
            Processed frame
        """
        raise NotImplementedError("Subclasses must implement process method")
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Get stage statistics.
        
        Returns:
            Dictionary with stage statistics
        """
        with self.stats_lock:
            return {
                "stage_type": self.stage_type.name,
                "name": self.name,
                **self.stats
            }


class PreprocessingStage(PipelineStage):
    """
    Preprocessing stage for camera data pipeline.
    
    Performs preprocessing operations like debayering, noise reduction, and normalization.
    """
    
    def __init__(self, name: str, params: Dict[str, Any]):
        """
        Initialize preprocessing stage.
        
        Args:
            name: Stage name
            params: Preprocessing parameters
        """
        super().__init__(ProcessingStage.PREPROCESSING, name)
        self.params = params
        
        # Set default parameters if not provided
        self.params.setdefault("denoise_strength", 10)
        self.params.setdefault("normalize", True)
        self.params.setdefault("equalize_hist", False)
        self.params.setdefault("gamma_correction", 1.0)
    
    def process(self, frame: Frame) -> Frame:
        """
        Process frame.
        
        Args:
            frame: Input frame
        
        Returns:
            Processed frame
        """
        # Create a copy of the frame
        processed_frame = frame.copy()
        
        # Apply denoising if enabled
        denoise_strength = self.params.get("denoise_strength")
        if denoise_strength > 0:
            if processed_frame.data.ndim == 3:  # Color image
                processed_frame.data = cv2.fastNlMeansDenoisingColored(
                    processed_frame.data,
                    None,
                    denoise_strength,
                    denoise_strength,
                    7,
                    21
                )
            else:  # Grayscale image
                processed_frame.data = cv2.fastNlMeansDenoising(
                    processed_frame.data,
                    None,
                    denoise_strength,
                    7,
                    21
                )
        
        # Apply normalization if enabled
        if self.params.get("normalize"):
            if processed_frame.data.dtype != np.float32:
                processed_frame.data = processed_frame.data.astype(np.float32)
                processed_frame.data = processed_frame.data / 255.0
        
        # Apply histogram equalization if enabled
        if self.params.get("equalize_hist"):
            if processed_frame.data.ndim == 3:  # Color image
                # Convert to YUV
                yuv = cv2.cvtColor(processed_frame.data, cv2.COLOR_BGR2YUV)
                # Equalize Y channel
                yuv[:, :, 0] = cv2.equalizeHist(yuv[:, :, 0])
                # Convert back to BGR
                processed_frame.data = cv2.cvtColor(yuv, cv2.COLOR_YUV2BGR)
            else:  # Grayscale image
                processed_frame.data = cv2.equalizeHist(processed_frame.data)
        
        # Apply gamma correction if enabled
        gamma = self.params.get("gamma_correction")
        if gamma != 1.0:
            # Ensure data is in float32 format
            if processed_frame.data.dtype != np.float32:
                processed_frame.data = processed_frame.data.astype(np.float32)
                processed_frame.data = processed_frame.data / 255.0
            
            # Apply gamma correction
            processed_frame.data = np.power(processed_frame.data, gamma)
            
            # Convert back to original range if needed
            if frame.data.dtype != np.float32:
                processed_frame.data = (processed_frame.data * 255.0).astype(frame.data.dtype)
        
        return processed_frame


class TransformationStage(PipelineStage):
    """
    Transformation stage for camera data pipeline.
    
    Performs geometric transformations like rotation, scaling, and cropping.
    """
    
    def __init__(self, name: str, params: Dict[str, Any]):
        """
        Initialize transformation stage.
        
        Args:
            name: Stage name
            params: Transformation parameters
        """
        super().__init__(ProcessingStage.TRANSFORMATION, name)
        self.params = params
        
        # Set default parameters if not provided
        self.params.setdefault("rotation_angle", 0)
        self.params.setdefault("scale_factor", 1.0)
        self.params.setdefault("crop_rect", None)
        self.params.setdefault("flip_horizontal", False)
        self.params.setdefault("flip_vertical", False)
    
    def process(self, frame: Frame) -> Frame:
        """
        Process frame.
        
        Args:
            frame: Input frame
        
        Returns:
            Processed frame
        """
        # Create a copy of the frame
        processed_frame = frame.copy()
        
        # Apply rotation if enabled
        rotation_angle = self.params.get("rotation_angle")
        if rotation_angle != 0:
            height, width = processed_frame.data.shape[:2]
            center = (width // 2, height // 2)
            rotation_matrix = cv2.getRotationMatrix2D(center, rotation_angle, 1.0)
            processed_frame.data = cv2.warpAffine(processed_frame.data, rotation_matrix, (width, height))
        
        # Apply scaling if enabled
        scale_factor = self.params.get("scale_factor")
        if scale_factor != 1.0:
            processed_frame.data = cv2.resize(
                processed_frame.data,
                None,
                fx=scale_factor,
                fy=scale_factor,
                interpolation=cv2.INTER_AREA if scale_factor < 1.0 else cv2.INTER_LINEAR
            )
        
        # Apply cropping if enabled
        crop_rect = self.params.get("crop_rect")
        if crop_rect is not None:
            x, y, w, h = crop_rect
            processed_frame.data = processed_frame.data[y:y+h, x:x+w]
            
            # Update resolution in metadata
            processed_frame.metadata.resolution = (w, h)
        
        # Apply horizontal flip if enabled
        if self.params.get("flip_horizontal"):
            processed_frame.data = cv2.flip(processed_frame.data, 1)
        
        # Apply vertical flip if enabled
        if self.params.get("flip_vertical"):
            processed_frame.data = cv2.flip(processed_frame.data, 0)
        
        return processed_frame


class EnhancementStage(PipelineStage):
    """
    Enhancement stage for camera data pipeline.
    
    Performs image enhancement operations like contrast adjustment, sharpening, and color correction.
    """
    
    def __init__(self, name: str, params: Dict[str, Any]):
        """
        Initialize enhancement stage.
        
        Args:
            name: Stage name
            params: Enhancement parameters
        """
        super().__init__(ProcessingStage.ENHANCEMENT, name)
        self.params = params
        
        # Set default parameters if not provided
        self.params.setdefault("contrast_alpha", 1.0)
        self.params.setdefault("brightness_beta", 0)
        self.params.setdefault("sharpen_kernel_size", 0)
        self.params.setdefault("sharpen_strength", 1.0)
        self.params.setdefault("color_balance", [1.0, 1.0, 1.0])  # RGB multipliers
    
    def process(self, frame: Frame) -> Frame:
        """
        Process frame.
        
        Args:
            frame: Input frame
        
        Returns:
            Processed frame
        """
        # Create a copy of the frame
        processed_frame = frame.copy()
        
        # Apply contrast and brightness adjustment
        alpha = self.params.get("contrast_alpha")
        beta = self.params.get("brightness_beta")
        if alpha != 1.0 or beta != 0:
            processed_frame.data = cv2.convertScaleAbs(processed_frame.data, alpha=alpha, beta=beta)
        
        # Apply sharpening if enabled
        kernel_size = self.params.get("sharpen_kernel_size")
        strength = self.params.get("sharpen_strength")
        if kernel_size > 0 and strength > 0:
            # Create sharpening kernel
            kernel = np.zeros((kernel_size, kernel_size), np.float32)
            center = kernel_size // 2
            kernel[center, center] = 2.0
            kernel = kernel - np.ones((kernel_size, kernel_size), np.float32) / (kernel_size * kernel_size)
            kernel = kernel * strength
            
            # Apply kernel
            processed_frame.data = cv2.filter2D(processed_frame.data, -1, kernel)
        
        # Apply color balance if enabled
        color_balance = self.params.get("color_balance")
        if processed_frame.data.ndim == 3 and color_balance != [1.0, 1.0, 1.0]:
            # Split channels
            b, g, r = cv2.split(processed_frame.data)
            
            # Apply color balance
            r = cv2.convertScaleAbs(r, alpha=color_balance[0])
            g = cv2.convertScaleAbs(g, alpha=color_balance[1])
            b = cv2.convertScaleAbs(b, alpha=color_balance[2])
            
            # Merge channels
            processed_frame.data = cv2.merge([b, g, r])
        
        return processed_frame


class CompressionStage(PipelineStage):
    """
    Compression stage for camera data pipeline.
    
    Performs image compression for storage or streaming.
    """
    
    def __init__(self, name: str, params: Dict[str, Any]):
        """
        Initialize compression stage.
        
        Args:
            name: Stage name
            params: Compression parameters
        """
        super().__init__(ProcessingStage.COMPRESSION, name)
        self.params = params
        
        # Set default parameters if not provided
        self.params.setdefault("format", "JPEG")
        self.params.setdefault("quality", 90)
        self.params.setdefault("compression_level", 3)
    
    def process(self, frame: Frame) -> Frame:
        """
        Process frame.
        
        Args:
            frame: Input frame
        
        Returns:
            Processed frame
        """
        # Create a copy of the frame
        processed_frame = frame.copy()
        
        # Get compression parameters
        format_name = self.params.get("format")
        quality = self.params.get("quality")
        compression_level = self.params.get("compression_level")
        
        # Compress image based on format
        if format_name == "JPEG":
            # Encode image
            encode_params = [cv2.IMWRITE_JPEG_QUALITY, quality]
            _, compressed_data = cv2.imencode(".jpg", processed_frame.data, encode_params)
            
            # Add compressed data to metadata
            processed_frame.metadata.custom_metadata["compressed_data"] = compressed_data
            processed_frame.metadata.custom_metadata["compression_format"] = format_name
            processed_frame.metadata.custom_metadata["compression_quality"] = quality
            
            # Calculate compression ratio
            original_size = processed_frame.data.nbytes
            compressed_size = compressed_data.nbytes
            compression_ratio = original_size / compressed_size if compressed_size > 0 else 0
            processed_frame.metadata.custom_metadata["compression_ratio"] = compression_ratio
        elif format_name == "PNG":
            # Encode image
            encode_params = [cv2.IMWRITE_PNG_COMPRESSION, compression_level]
            _, compressed_data = cv2.imencode(".png", processed_frame.data, encode_params)
            
            # Add compressed data to metadata
            processed_frame.metadata.custom_metadata["compressed_data"] = compressed_data
            processed_frame.metadata.custom_metadata["compression_format"] = format_name
            processed_frame.metadata.custom_metadata["compression_level"] = compression_level
            
            # Calculate compression ratio
            original_size = processed_frame.data.nbytes
            compressed_size = compressed_data.nbytes
            compression_ratio = original_size / compressed_size if compressed_size > 0 else 0
            processed_frame.metadata.custom_metadata["compression_ratio"] = compression_ratio
        else:
            logger.warning(f"Unsupported compression format: {format_name}")
        
        return processed_frame


class StreamingStage(PipelineStage):
    """
    Streaming stage for camera data pipeline.
    
    Prepares frames for streaming to clients.
    """
    
    def __init__(self, name: str, params: Dict[str, Any]):
        """
        Initialize streaming stage.
        
        Args:
            name: Stage name
            params: Streaming parameters
        """
        super().__init__(ProcessingStage.STREAMING, name)
        self.params = params
        
        # Set default parameters if not provided
        self.params.setdefault("format", "MJPEG")
        self.params.setdefault("quality", 80)
        self.params.setdefault("max_fps", 30)
        self.params.setdefault("max_resolution", (1280, 720))
        
        # Initialize streaming buffer
        self.streaming_buffer = []
        self.streaming_buffer_lock = threading.Lock()
        self.last_frame_time = 0
    
    def process(self, frame: Frame) -> Frame:
        """
        Process frame.
        
        Args:
            frame: Input frame
        
        Returns:
            Processed frame
        """
        # Create a copy of the frame
        processed_frame = frame.copy()
        
        # Get streaming parameters
        format_name = self.params.get("format")
        quality = self.params.get("quality")
        max_fps = self.params.get("max_fps")
        max_resolution = self.params.get("max_resolution")
        
        # Check if we need to limit FPS
        current_time = time.time()
        if max_fps > 0:
            min_frame_interval = 1.0 / max_fps
            if current_time - self.last_frame_time < min_frame_interval:
                # Skip this frame to maintain FPS limit
                return processed_frame
        
        # Update last frame time
        self.last_frame_time = current_time
        
        # Resize frame if needed
        if max_resolution is not None:
            max_width, max_height = max_resolution
            height, width = processed_frame.data.shape[:2]
            
            if width > max_width or height > max_height:
                # Calculate new dimensions
                ratio = min(max_width / width, max_height / height)
                new_width = int(width * ratio)
                new_height = int(height * ratio)
                
                # Resize image
                processed_frame.data = cv2.resize(processed_frame.data, (new_width, new_height))
                
                # Update resolution in metadata
                processed_frame.metadata.resolution = (new_width, new_height)
        
        # Encode frame based on format
        if format_name == "MJPEG":
            # Encode image
            encode_params = [cv2.IMWRITE_JPEG_QUALITY, quality]
            _, encoded_data = cv2.imencode(".jpg", processed_frame.data, encode_params)
            
            # Add encoded data to metadata
            processed_frame.metadata.custom_metadata["encoded_data"] = encoded_data
            processed_frame.metadata.custom_metadata["streaming_format"] = format_name
            processed_frame.metadata.custom_metadata["streaming_quality"] = quality
        elif format_name == "H264":
            # H264 encoding would require additional libraries like gstreamer or ffmpeg
            # This is a placeholder for actual H264 encoding
            logger.warning("H264 encoding not implemented, using MJPEG instead")
            
            # Encode image as JPEG
            encode_params = [cv2.IMWRITE_JPEG_QUALITY, quality]
            _, encoded_data = cv2.imencode(".jpg", processed_frame.data, encode_params)
            
            # Add encoded data to metadata
            processed_frame.metadata.custom_metadata["encoded_data"] = encoded_data
            processed_frame.metadata.custom_metadata["streaming_format"] = "MJPEG"
            processed_frame.metadata.custom_metadata["streaming_quality"] = quality
        else:
            logger.warning(f"Unsupported streaming format: {format_name}")
        
        # Add frame to streaming buffer
        with self.streaming_buffer_lock:
            self.streaming_buffer.append(processed_frame)
            
            # Limit buffer size
            max_buffer_size = 10
            if len(self.streaming_buffer) > max_buffer_size:
                self.streaming_buffer = self.streaming_buffer[-max_buffer_size:]
        
        return processed_frame
    
    def get_latest_frame(self) -> Optional[Frame]:
        """
        Get latest frame from streaming buffer.
        
        Returns:
            Latest frame or None if buffer is empty
        """
        with self.streaming_buffer_lock:
            if not self.streaming_buffer:
                return None
            
            return self.streaming_buffer[-1]
    
    def get_streaming_buffer(self) -> List[Frame]:
        """
        Get copy of streaming buffer.
        
        Returns:
            Copy of streaming buffer
        """
        with self.streaming_buffer_lock:
            return self.streaming_buffer.copy()


class CameraDataPipeline:
    """
    Camera data pipeline for OPSC Sandwich Quality Inspection System.
    
    Provides functionality for optimizing camera data acquisition, processing, and streaming.
    """
    
    def __init__(self, config: PipelineConfig):
        """
        Initialize camera data pipeline.
        
        Args:
            config: Pipeline configuration
        """
        self.config = config
        
        # Create frame buffers
        self.acquisition_buffer = FrameBuffer(buffer_size=config.buffer_size)
        self.preprocessing_buffer = FrameBuffer(buffer_size=config.buffer_size)
        self.transformation_buffer = FrameBuffer(buffer_size=config.buffer_size)
        self.enhancement_buffer = FrameBuffer(buffer_size=config.buffer_size)
        self.compression_buffer = FrameBuffer(buffer_size=config.buffer_size)
        self.output_buffer = FrameBuffer(buffer_size=config.buffer_size)
        
        # Create pipeline stages
        self.preprocessing_stage = PreprocessingStage(
            name="preprocessing",
            params=config.preprocessing_params
        )
        self.transformation_stage = TransformationStage(
            name="transformation",
            params=config.transformation_params
        )
        self.enhancement_stage = EnhancementStage(
            name="enhancement",
            params=config.enhancement_params
        )
        self.compression_stage = CompressionStage(
            name="compression",
            params=config.compression_params
        )
        self.streaming_stage = StreamingStage(
            name="streaming",
            params=config.streaming_params
        )
        
        # Configure pipeline stages
        self.preprocessing_stage.set_input_buffer(self.acquisition_buffer)
        self.preprocessing_stage.set_output_buffer(self.preprocessing_buffer)
        
        self.transformation_stage.set_input_buffer(self.preprocessing_buffer)
        self.transformation_stage.set_output_buffer(self.transformation_buffer)
        
        self.enhancement_stage.set_input_buffer(self.transformation_buffer)
        self.enhancement_stage.set_output_buffer(self.enhancement_buffer)
        
        self.compression_stage.set_input_buffer(self.enhancement_buffer)
        self.compression_stage.set_output_buffer(self.compression_buffer)
        
        self.streaming_stage.set_input_buffer(self.compression_buffer)
        self.streaming_stage.set_output_buffer(self.output_buffer)
        
        # Initialize sequence number
        self.sequence_num = 0
        self.sequence_lock = threading.Lock()
        
        # Initialize thread pool
        self.thread_pool = ThreadPoolExecutor(max_workers=config.processing_threads)
        
        # Initialize pipeline status
        self.pipeline_running = False
    
    def start(self):
        """Start camera data pipeline."""
        if self.pipeline_running:
            logger.warning("Camera data pipeline is already running")
            return
        
        # Start pipeline stages
        if self.config.enable_preprocessing:
            self.preprocessing_stage.start()
        
        if self.config.enable_transformation:
            self.transformation_stage.start()
        
        if self.config.enable_enhancement:
            self.enhancement_stage.start()
        
        if self.config.enable_compression:
            self.compression_stage.start()
        
        if self.config.enable_streaming:
            self.streaming_stage.start()
        
        self.pipeline_running = True
        
        logger.info(f"Started camera data pipeline for camera {self.config.camera_id}")
    
    def stop(self):
        """Stop camera data pipeline."""
        if not self.pipeline_running:
            logger.warning("Camera data pipeline is not running")
            return
        
        # Stop pipeline stages
        if self.config.enable_preprocessing:
            self.preprocessing_stage.stop()
        
        if self.config.enable_transformation:
            self.transformation_stage.stop()
        
        if self.config.enable_enhancement:
            self.enhancement_stage.stop()
        
        if self.config.enable_compression:
            self.compression_stage.stop()
        
        if self.config.enable_streaming:
            self.streaming_stage.stop()
        
        self.pipeline_running = False
        
        logger.info(f"Stopped camera data pipeline for camera {self.config.camera_id}")
    
    def process_frame(self, frame_data: np.ndarray, exposure_time: float = 0.0, gain: float = 0.0) -> str:
        """
        Process frame through pipeline.
        
        Args:
            frame_data: Frame data as NumPy array
            exposure_time: Exposure time in milliseconds
            gain: Gain value
        
        Returns:
            Frame ID
        """
        # Generate frame ID
        frame_id = str(uuid.uuid4())
        
        # Get next sequence number
        with self.sequence_lock:
            sequence_num = self.sequence_num
            self.sequence_num += 1
        
        # Create frame metadata
        metadata = FrameMetadata(
            frame_id=frame_id,
            camera_id=self.config.camera_id,
            timestamp=time.time(),
            sequence_num=sequence_num,
            resolution=tuple(frame_data.shape[:2][::-1]),  # (width, height)
            format=self.config.format,
            bit_depth=self.config.bit_depth,
            exposure_time=exposure_time,
            gain=gain
        )
        
        # Create frame
        frame = Frame(data=frame_data, metadata=metadata)
        
        # Add frame to acquisition buffer
        if self.pipeline_running:
            # Add to pipeline
            self.acquisition_buffer.put(frame, block=False)
        else:
            # Process frame directly
            processed_frame = self._process_frame_direct(frame)
            
            # Add to output buffer
            self.output_buffer.put(processed_frame, block=False)
        
        return frame_id
    
    def _process_frame_direct(self, frame: Frame) -> Frame:
        """
        Process frame directly without pipeline.
        
        Args:
            frame: Input frame
        
        Returns:
            Processed frame
        """
        processed_frame = frame
        
        # Apply preprocessing if enabled
        if self.config.enable_preprocessing:
            processed_frame = self.preprocessing_stage.process(processed_frame)
        
        # Apply transformation if enabled
        if self.config.enable_transformation:
            processed_frame = self.transformation_stage.process(processed_frame)
        
        # Apply enhancement if enabled
        if self.config.enable_enhancement:
            processed_frame = self.enhancement_stage.process(processed_frame)
        
        # Apply compression if enabled
        if self.config.enable_compression:
            processed_frame = self.compression_stage.process(processed_frame)
        
        # Apply streaming if enabled
        if self.config.enable_streaming:
            processed_frame = self.streaming_stage.process(processed_frame)
        
        return processed_frame
    
    def process_frame_async(self, frame_data: np.ndarray, exposure_time: float = 0.0, gain: float = 0.0) -> str:
        """
        Process frame asynchronously.
        
        Args:
            frame_data: Frame data as NumPy array
            exposure_time: Exposure time in milliseconds
            gain: Gain value
        
        Returns:
            Frame ID
        """
        # Submit task to thread pool
        self.thread_pool.submit(self.process_frame, frame_data, exposure_time, gain)
        
        # Generate frame ID
        frame_id = str(uuid.uuid4())
        
        return frame_id
    
    def get_processed_frame(self, block: bool = True, timeout: Optional[float] = None) -> Optional[Frame]:
        """
        Get processed frame from output buffer.
        
        Args:
            block: Whether to block if buffer is empty
            timeout: Timeout in seconds
        
        Returns:
            Processed frame or None if buffer is empty
        """
        return self.output_buffer.get(block=block, timeout=timeout)
    
    def get_latest_streaming_frame(self) -> Optional[Frame]:
        """
        Get latest streaming frame.
        
        Returns:
            Latest streaming frame or None if not available
        """
        if not self.config.enable_streaming:
            return None
        
        return self.streaming_stage.get_latest_frame()
    
    def get_pipeline_stats(self) -> Dict[str, Any]:
        """
        Get pipeline statistics.
        
        Returns:
            Dictionary with pipeline statistics
        """
        stats = {
            "camera_id": self.config.camera_id,
            "camera_name": self.config.camera_name,
            "pipeline_running": self.pipeline_running,
            "buffers": {
                "acquisition": self.acquisition_buffer.get_stats(),
                "preprocessing": self.preprocessing_buffer.get_stats(),
                "transformation": self.transformation_buffer.get_stats(),
                "enhancement": self.enhancement_buffer.get_stats(),
                "compression": self.compression_buffer.get_stats(),
                "output": self.output_buffer.get_stats()
            },
            "stages": {}
        }
        
        # Add stage stats
        if self.config.enable_preprocessing:
            stats["stages"]["preprocessing"] = self.preprocessing_stage.get_stats()
        
        if self.config.enable_transformation:
            stats["stages"]["transformation"] = self.transformation_stage.get_stats()
        
        if self.config.enable_enhancement:
            stats["stages"]["enhancement"] = self.enhancement_stage.get_stats()
        
        if self.config.enable_compression:
            stats["stages"]["compression"] = self.compression_stage.get_stats()
        
        if self.config.enable_streaming:
            stats["stages"]["streaming"] = self.streaming_stage.get_stats()
        
        return stats


class MultiCameraPipeline:
    """
    Multi-camera pipeline for OPSC Sandwich Quality Inspection System.
    
    Manages multiple camera data pipelines.
    """
    
    def __init__(self):
        """Initialize multi-camera pipeline."""
        self.pipelines = {}
        self.pipeline_lock = threading.Lock()
    
    def add_pipeline(self, config: PipelineConfig) -> bool:
        """
        Add camera data pipeline.
        
        Args:
            config: Pipeline configuration
        
        Returns:
            True if pipeline was added, False otherwise
        """
        with self.pipeline_lock:
            if config.camera_id in self.pipelines:
                logger.warning(f"Pipeline for camera {config.camera_id} already exists")
                return False
            
            # Create pipeline
            pipeline = CameraDataPipeline(config)
            
            # Add to pipelines
            self.pipelines[config.camera_id] = pipeline
            
            logger.info(f"Added pipeline for camera {config.camera_id}")
            
            return True
    
    def remove_pipeline(self, camera_id: str) -> bool:
        """
        Remove camera data pipeline.
        
        Args:
            camera_id: Camera ID
        
        Returns:
            True if pipeline was removed, False otherwise
        """
        with self.pipeline_lock:
            if camera_id not in self.pipelines:
                logger.warning(f"Pipeline for camera {camera_id} does not exist")
                return False
            
            # Stop pipeline
            self.pipelines[camera_id].stop()
            
            # Remove from pipelines
            del self.pipelines[camera_id]
            
            logger.info(f"Removed pipeline for camera {camera_id}")
            
            return True
    
    def start_pipeline(self, camera_id: str) -> bool:
        """
        Start camera data pipeline.
        
        Args:
            camera_id: Camera ID
        
        Returns:
            True if pipeline was started, False otherwise
        """
        with self.pipeline_lock:
            if camera_id not in self.pipelines:
                logger.warning(f"Pipeline for camera {camera_id} does not exist")
                return False
            
            # Start pipeline
            self.pipelines[camera_id].start()
            
            return True
    
    def stop_pipeline(self, camera_id: str) -> bool:
        """
        Stop camera data pipeline.
        
        Args:
            camera_id: Camera ID
        
        Returns:
            True if pipeline was stopped, False otherwise
        """
        with self.pipeline_lock:
            if camera_id not in self.pipelines:
                logger.warning(f"Pipeline for camera {camera_id} does not exist")
                return False
            
            # Stop pipeline
            self.pipelines[camera_id].stop()
            
            return True
    
    def start_all_pipelines(self):
        """Start all camera data pipelines."""
        with self.pipeline_lock:
            for camera_id, pipeline in self.pipelines.items():
                pipeline.start()
                logger.info(f"Started pipeline for camera {camera_id}")
    
    def stop_all_pipelines(self):
        """Stop all camera data pipelines."""
        with self.pipeline_lock:
            for camera_id, pipeline in self.pipelines.items():
                pipeline.stop()
                logger.info(f"Stopped pipeline for camera {camera_id}")
    
    def process_frame(self, camera_id: str, frame_data: np.ndarray, exposure_time: float = 0.0, gain: float = 0.0) -> Optional[str]:
        """
        Process frame through pipeline.
        
        Args:
            camera_id: Camera ID
            frame_data: Frame data as NumPy array
            exposure_time: Exposure time in milliseconds
            gain: Gain value
        
        Returns:
            Frame ID or None if pipeline does not exist
        """
        with self.pipeline_lock:
            if camera_id not in self.pipelines:
                logger.warning(f"Pipeline for camera {camera_id} does not exist")
                return None
            
            # Process frame
            return self.pipelines[camera_id].process_frame(frame_data, exposure_time, gain)
    
    def process_frame_async(self, camera_id: str, frame_data: np.ndarray, exposure_time: float = 0.0, gain: float = 0.0) -> Optional[str]:
        """
        Process frame asynchronously.
        
        Args:
            camera_id: Camera ID
            frame_data: Frame data as NumPy array
            exposure_time: Exposure time in milliseconds
            gain: Gain value
        
        Returns:
            Frame ID or None if pipeline does not exist
        """
        with self.pipeline_lock:
            if camera_id not in self.pipelines:
                logger.warning(f"Pipeline for camera {camera_id} does not exist")
                return None
            
            # Process frame asynchronously
            return self.pipelines[camera_id].process_frame_async(frame_data, exposure_time, gain)
    
    def get_processed_frame(self, camera_id: str, block: bool = True, timeout: Optional[float] = None) -> Optional[Frame]:
        """
        Get processed frame from output buffer.
        
        Args:
            camera_id: Camera ID
            block: Whether to block if buffer is empty
            timeout: Timeout in seconds
        
        Returns:
            Processed frame or None if pipeline does not exist or buffer is empty
        """
        with self.pipeline_lock:
            if camera_id not in self.pipelines:
                logger.warning(f"Pipeline for camera {camera_id} does not exist")
                return None
            
            # Get processed frame
            return self.pipelines[camera_id].get_processed_frame(block, timeout)
    
    def get_latest_streaming_frame(self, camera_id: str) -> Optional[Frame]:
        """
        Get latest streaming frame.
        
        Args:
            camera_id: Camera ID
        
        Returns:
            Latest streaming frame or None if not available
        """
        with self.pipeline_lock:
            if camera_id not in self.pipelines:
                logger.warning(f"Pipeline for camera {camera_id} does not exist")
                return None
            
            # Get latest streaming frame
            return self.pipelines[camera_id].get_latest_streaming_frame()
    
    def get_pipeline_stats(self, camera_id: str) -> Optional[Dict[str, Any]]:
        """
        Get pipeline statistics.
        
        Args:
            camera_id: Camera ID
        
        Returns:
            Dictionary with pipeline statistics or None if pipeline does not exist
        """
        with self.pipeline_lock:
            if camera_id not in self.pipelines:
                logger.warning(f"Pipeline for camera {camera_id} does not exist")
                return None
            
            # Get pipeline stats
            return self.pipelines[camera_id].get_pipeline_stats()
    
    def get_all_pipeline_stats(self) -> Dict[str, Dict[str, Any]]:
        """
        Get statistics for all pipelines.
        
        Returns:
            Dictionary with pipeline statistics for all pipelines
        """
        stats = {}
        
        with self.pipeline_lock:
            for camera_id, pipeline in self.pipelines.items():
                stats[camera_id] = pipeline.get_pipeline_stats()
        
        return stats
    
    def get_pipeline_configs(self) -> Dict[str, PipelineConfig]:
        """
        Get configurations for all pipelines.
        
        Returns:
            Dictionary with pipeline configurations for all pipelines
        """
        configs = {}
        
        with self.pipeline_lock:
            for camera_id, pipeline in self.pipelines.items():
                configs[camera_id] = pipeline.config
        
        return configs


# Example usage
if __name__ == "__main__":
    # Setup logging
    logging.basicConfig(level=logging.INFO)
    
    # Create pipeline configuration
    config = PipelineConfig(
        camera_id="camera1",
        camera_name="Top Camera",
        resolution=(1920, 1080),
        fps=30,
        format="BGR",
        bit_depth=8,
        enable_preprocessing=True,
        enable_transformation=True,
        enable_enhancement=True,
        enable_compression=False,
        enable_streaming=True,
        buffer_size=10,
        processing_threads=4,
        preprocessing_params={
            "denoise_strength": 10,
            "normalize": True,
            "equalize_hist": False,
            "gamma_correction": 1.0
        },
        transformation_params={
            "rotation_angle": 0,
            "scale_factor": 1.0,
            "crop_rect": None,
            "flip_horizontal": False,
            "flip_vertical": False
        },
        enhancement_params={
            "contrast_alpha": 1.2,
            "brightness_beta": 10,
            "sharpen_kernel_size": 3,
            "sharpen_strength": 1.5,
            "color_balance": [1.0, 1.0, 1.0]
        },
        streaming_params={
            "format": "MJPEG",
            "quality": 80,
            "max_fps": 30,
            "max_resolution": (1280, 720)
        }
    )
    
    # Create multi-camera pipeline
    multi_pipeline = MultiCameraPipeline()
    
    # Add pipeline
    multi_pipeline.add_pipeline(config)
    
    # Start pipeline
    multi_pipeline.start_pipeline("camera1")
    
    # Process test frame
    test_frame = np.zeros((1080, 1920, 3), dtype=np.uint8)
    cv2.rectangle(test_frame, (100, 100), (500, 500), (0, 255, 0), 5)
    cv2.putText(test_frame, "Test Frame", (100, 600), cv2.FONT_HERSHEY_SIMPLEX, 2, (255, 0, 0), 5)
    
    frame_id = multi_pipeline.process_frame("camera1", test_frame)
    print(f"Processed frame: {frame_id}")
    
    # Wait for processing
    time.sleep(1)
    
    # Get processed frame
    processed_frame = multi_pipeline.get_processed_frame("camera1", block=False)
    if processed_frame:
        print(f"Got processed frame: {processed_frame.metadata.frame_id}")
        print(f"Processing stages: {[stage.name for stage in processed_frame.metadata.processing_stages]}")
        print(f"Processing times: {[(stage.name, time) for stage, time in processed_frame.metadata.processing_times.items()]}")
    
    # Get pipeline stats
    stats = multi_pipeline.get_pipeline_stats("camera1")
    print(f"Pipeline stats: {stats}")
    
    # Stop pipeline
    multi_pipeline.stop_pipeline("camera1")
    
    # Remove pipeline
    multi_pipeline.remove_pipeline("camera1")
