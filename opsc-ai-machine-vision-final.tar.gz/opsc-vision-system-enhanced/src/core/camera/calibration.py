"""
Camera calibration tools for OPSC Sandwich Quality Inspection System.
Provides functionality for camera calibration, intrinsic and extrinsic parameter estimation,
distortion correction, and camera alignment.

Version: 1.0.0
Last Updated: 2025-04-21
"""

import os
import sys
import time
import json
import logging
import datetime
import uuid
import sqlite3
import numpy as np
import cv2
import yaml
import threading
import queue
from typing import Dict, List, Optional, Tuple, Union, Any, BinaryIO
from dataclasses import dataclass, field
from pathlib import Path
import matplotlib.pyplot as plt

# Setup logging
logger = logging.getLogger(__name__)

@dataclass
class CalibrationConfig:
    """Calibration configuration data class."""
    camera_id: str
    chessboard_size: Tuple[int, int] = (9, 6)  # Number of inner corners (width, height)
    square_size: float = 25.0  # Size of chessboard square in mm
    frame_count: int = 20  # Number of frames to capture for calibration
    min_frames_required: int = 10  # Minimum number of good frames required
    max_frames_to_capture: int = 50  # Maximum number of frames to capture
    delay_between_captures: float = 1.0  # Delay between captures in seconds
    calibration_flags: int = cv2.CALIB_CB_ADAPTIVE_THRESH + cv2.CALIB_CB_NORMALIZE_IMAGE + cv2.CALIB_CB_FAST_CHECK
    fisheye: bool = False  # Whether to use fisheye calibration
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "camera_id": self.camera_id,
            "chessboard_size": self.chessboard_size,
            "square_size": self.square_size,
            "frame_count": self.frame_count,
            "min_frames_required": self.min_frames_required,
            "max_frames_to_capture": self.max_frames_to_capture,
            "delay_between_captures": self.delay_between_captures,
            "calibration_flags": self.calibration_flags,
            "fisheye": self.fisheye
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'CalibrationConfig':
        """Create from dictionary."""
        return cls(
            camera_id=data.get("camera_id"),
            chessboard_size=tuple(data.get("chessboard_size", (9, 6))),
            square_size=data.get("square_size", 25.0),
            frame_count=data.get("frame_count", 20),
            min_frames_required=data.get("min_frames_required", 10),
            max_frames_to_capture=data.get("max_frames_to_capture", 50),
            delay_between_captures=data.get("delay_between_captures", 1.0),
            calibration_flags=data.get("calibration_flags", 
                                      cv2.CALIB_CB_ADAPTIVE_THRESH + cv2.CALIB_CB_NORMALIZE_IMAGE + cv2.CALIB_CB_FAST_CHECK),
            fisheye=data.get("fisheye", False)
        )

@dataclass
class CalibrationResult:
    """Calibration result data class."""
    camera_id: str
    calibration_id: str
    timestamp: str
    image_size: Tuple[int, int]  # (width, height)
    camera_matrix: np.ndarray
    distortion_coefficients: np.ndarray
    rotation_vectors: Optional[List[np.ndarray]] = None
    translation_vectors: Optional[List[np.ndarray]] = None
    reprojection_error: float = 0.0
    fisheye: bool = False
    frame_count: int = 0
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "camera_id": self.camera_id,
            "calibration_id": self.calibration_id,
            "timestamp": self.timestamp,
            "image_size": self.image_size,
            "camera_matrix": self.camera_matrix.tolist() if self.camera_matrix is not None else None,
            "distortion_coefficients": self.distortion_coefficients.tolist() if self.distortion_coefficients is not None else None,
            "rotation_vectors": [rv.tolist() for rv in self.rotation_vectors] if self.rotation_vectors is not None else None,
            "translation_vectors": [tv.tolist() for tv in self.translation_vectors] if self.translation_vectors is not None else None,
            "reprojection_error": self.reprojection_error,
            "fisheye": self.fisheye,
            "frame_count": self.frame_count
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'CalibrationResult':
        """Create from dictionary."""
        camera_matrix = np.array(data.get("camera_matrix")) if data.get("camera_matrix") is not None else None
        distortion_coefficients = np.array(data.get("distortion_coefficients")) if data.get("distortion_coefficients") is not None else None
        rotation_vectors = [np.array(rv) for rv in data.get("rotation_vectors")] if data.get("rotation_vectors") is not None else None
        translation_vectors = [np.array(tv) for tv in data.get("translation_vectors")] if data.get("translation_vectors") is not None else None
        
        return cls(
            camera_id=data.get("camera_id"),
            calibration_id=data.get("calibration_id"),
            timestamp=data.get("timestamp"),
            image_size=tuple(data.get("image_size")),
            camera_matrix=camera_matrix,
            distortion_coefficients=distortion_coefficients,
            rotation_vectors=rotation_vectors,
            translation_vectors=translation_vectors,
            reprojection_error=data.get("reprojection_error", 0.0),
            fisheye=data.get("fisheye", False),
            frame_count=data.get("frame_count", 0)
        )

@dataclass
class AlignmentConfig:
    """Camera alignment configuration data class."""
    reference_camera_id: str
    target_camera_id: str
    chessboard_size: Tuple[int, int] = (9, 6)  # Number of inner corners (width, height)
    square_size: float = 25.0  # Size of chessboard square in mm
    frame_count: int = 10  # Number of frames to capture for alignment
    min_frames_required: int = 5  # Minimum number of good frames required
    max_frames_to_capture: int = 30  # Maximum number of frames to capture
    delay_between_captures: float = 1.0  # Delay between captures in seconds
    calibration_flags: int = cv2.CALIB_CB_ADAPTIVE_THRESH + cv2.CALIB_CB_NORMALIZE_IMAGE + cv2.CALIB_CB_FAST_CHECK
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "reference_camera_id": self.reference_camera_id,
            "target_camera_id": self.target_camera_id,
            "chessboard_size": self.chessboard_size,
            "square_size": self.square_size,
            "frame_count": self.frame_count,
            "min_frames_required": self.min_frames_required,
            "max_frames_to_capture": self.max_frames_to_capture,
            "delay_between_captures": self.delay_between_captures,
            "calibration_flags": self.calibration_flags
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'AlignmentConfig':
        """Create from dictionary."""
        return cls(
            reference_camera_id=data.get("reference_camera_id"),
            target_camera_id=data.get("target_camera_id"),
            chessboard_size=tuple(data.get("chessboard_size", (9, 6))),
            square_size=data.get("square_size", 25.0),
            frame_count=data.get("frame_count", 10),
            min_frames_required=data.get("min_frames_required", 5),
            max_frames_to_capture=data.get("max_frames_to_capture", 30),
            delay_between_captures=data.get("delay_between_captures", 1.0),
            calibration_flags=data.get("calibration_flags", 
                                      cv2.CALIB_CB_ADAPTIVE_THRESH + cv2.CALIB_CB_NORMALIZE_IMAGE + cv2.CALIB_CB_FAST_CHECK)
        )

@dataclass
class AlignmentResult:
    """Camera alignment result data class."""
    reference_camera_id: str
    target_camera_id: str
    alignment_id: str
    timestamp: str
    rotation_matrix: np.ndarray
    translation_vector: np.ndarray
    essential_matrix: Optional[np.ndarray] = None
    fundamental_matrix: Optional[np.ndarray] = None
    reprojection_error: float = 0.0
    frame_count: int = 0
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "reference_camera_id": self.reference_camera_id,
            "target_camera_id": self.target_camera_id,
            "alignment_id": self.alignment_id,
            "timestamp": self.timestamp,
            "rotation_matrix": self.rotation_matrix.tolist() if self.rotation_matrix is not None else None,
            "translation_vector": self.translation_vector.tolist() if self.translation_vector is not None else None,
            "essential_matrix": self.essential_matrix.tolist() if self.essential_matrix is not None else None,
            "fundamental_matrix": self.fundamental_matrix.tolist() if self.fundamental_matrix is not None else None,
            "reprojection_error": self.reprojection_error,
            "frame_count": self.frame_count
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'AlignmentResult':
        """Create from dictionary."""
        rotation_matrix = np.array(data.get("rotation_matrix")) if data.get("rotation_matrix") is not None else None
        translation_vector = np.array(data.get("translation_vector")) if data.get("translation_vector") is not None else None
        essential_matrix = np.array(data.get("essential_matrix")) if data.get("essential_matrix") is not None else None
        fundamental_matrix = np.array(data.get("fundamental_matrix")) if data.get("fundamental_matrix") is not None else None
        
        return cls(
            reference_camera_id=data.get("reference_camera_id"),
            target_camera_id=data.get("target_camera_id"),
            alignment_id=data.get("alignment_id"),
            timestamp=data.get("timestamp"),
            rotation_matrix=rotation_matrix,
            translation_vector=translation_vector,
            essential_matrix=essential_matrix,
            fundamental_matrix=fundamental_matrix,
            reprojection_error=data.get("reprojection_error", 0.0),
            frame_count=data.get("frame_count", 0)
        )

class CameraCalibrator:
    """
    Camera calibrator for OPSC Sandwich Quality Inspection System.
    
    Provides functionality for camera calibration, intrinsic and extrinsic parameter estimation,
    distortion correction, and camera alignment.
    """
    
    def __init__(self, db_path: str, output_dir: str):
        """
        Initialize camera calibrator.
        
        Args:
            db_path: Path to SQLite database file
            output_dir: Path to directory for calibration output
        """
        self.db_path = db_path
        self.output_dir = output_dir
        
        # Create output directory if it doesn't exist
        os.makedirs(self.output_dir, exist_ok=True)
        
        # Initialize calibration queue and worker thread
        self.calibration_queue = queue.Queue()
        self.calibration_thread = None
        self.calibration_thread_running = False
        
        # Initialize alignment queue and worker thread
        self.alignment_queue = queue.Queue()
        self.alignment_thread = None
        self.alignment_thread_running = False
    
    def start_calibration_worker(self):
        """Start background calibration worker thread."""
        if self.calibration_thread is not None and self.calibration_thread.is_alive():
            logger.warning("Calibration worker thread is already running")
            return
        
        self.calibration_thread_running = True
        self.calibration_thread = threading.Thread(target=self._calibration_worker, daemon=True)
        self.calibration_thread.start()
        
        logger.info("Started calibration worker thread")
    
    def stop_calibration_worker(self):
        """Stop background calibration worker thread."""
        if self.calibration_thread is None or not self.calibration_thread.is_alive():
            logger.warning("Calibration worker thread is not running")
            return
        
        self.calibration_thread_running = False
        self.calibration_thread.join(timeout=5.0)
        
        logger.info("Stopped calibration worker thread")
    
    def start_alignment_worker(self):
        """Start background alignment worker thread."""
        if self.alignment_thread is not None and self.alignment_thread.is_alive():
            logger.warning("Alignment worker thread is already running")
            return
        
        self.alignment_thread_running = True
        self.alignment_thread = threading.Thread(target=self._alignment_worker, daemon=True)
        self.alignment_thread.start()
        
        logger.info("Started alignment worker thread")
    
    def stop_alignment_worker(self):
        """Stop background alignment worker thread."""
        if self.alignment_thread is None or not self.alignment_thread.is_alive():
            logger.warning("Alignment worker thread is not running")
            return
        
        self.alignment_thread_running = False
        self.alignment_thread.join(timeout=5.0)
        
        logger.info("Stopped alignment worker thread")
    
    def _calibration_worker(self):
        """Background worker thread for processing calibration queue."""
        logger.info("Calibration worker thread started")
        
        while self.calibration_thread_running:
            try:
                # Get item from queue with timeout
                try:
                    item = self.calibration_queue.get(timeout=1.0)
                except queue.Empty:
                    continue
                
                # Process item
                try:
                    calibration_id = item.get("calibration_id")
                    config = item.get("config")
                    frames = item.get("frames")
                    
                    logger.info(f"Processing calibration: {calibration_id}")
                    
                    # Update calibration status to "processing"
                    self._update_calibration_status(calibration_id, "processing")
                    
                    # Perform calibration
                    try:
                        result = self._perform_calibration(calibration_id, config, frames)
                        
                        # Save calibration result
                        self._save_calibration_result(result)
                        
                        # Update calibration status to "completed"
                        self._update_calibration_status(calibration_id, "completed", result.reprojection_error)
                    except Exception as e:
                        logger.error(f"Error performing calibration {calibration_id}: {e}")
                        
                        # Update calibration status to "error"
                        self._update_calibration_status(calibration_id, "error", error_message=str(e))
                    
                    # Mark item as done
                    self.calibration_queue.task_done()
                except Exception as e:
                    logger.error(f"Error processing calibration item: {e}")
                    
                    # Mark item as done
                    self.calibration_queue.task_done()
            except Exception as e:
                logger.error(f"Error in calibration worker thread: {e}")
        
        logger.info("Calibration worker thread stopped")
    
    def _alignment_worker(self):
        """Background worker thread for processing alignment queue."""
        logger.info("Alignment worker thread started")
        
        while self.alignment_thread_running:
            try:
                # Get item from queue with timeout
                try:
                    item = self.alignment_queue.get(timeout=1.0)
                except queue.Empty:
                    continue
                
                # Process item
                try:
                    alignment_id = item.get("alignment_id")
                    config = item.get("config")
                    reference_frames = item.get("reference_frames")
                    target_frames = item.get("target_frames")
                    
                    logger.info(f"Processing alignment: {alignment_id}")
                    
                    # Update alignment status to "processing"
                    self._update_alignment_status(alignment_id, "processing")
                    
                    # Perform alignment
                    try:
                        result = self._perform_alignment(alignment_id, config, reference_frames, target_frames)
                        
                        # Save alignment result
                        self._save_alignment_result(result)
                        
                        # Update alignment status to "completed"
                        self._update_alignment_status(alignment_id, "completed", result.reprojection_error)
                    except Exception as e:
                        logger.error(f"Error performing alignment {alignment_id}: {e}")
                        
                        # Update alignment status to "error"
                        self._update_alignment_status(alignment_id, "error", error_message=str(e))
                    
                    # Mark item as done
                    self.alignment_queue.task_done()
                except Exception as e:
                    logger.error(f"Error processing alignment item: {e}")
                    
                    # Mark item as done
                    self.alignment_queue.task_done()
            except Exception as e:
                logger.error(f"Error in alignment worker thread: {e}")
        
        logger.info("Alignment worker thread stopped")
    
    def queue_calibration(self, config: CalibrationConfig, frames: List[np.ndarray]) -> str:
        """
        Queue a camera calibration.
        
        Args:
            config: Calibration configuration
            frames: List of frames for calibration
        
        Returns:
            Calibration ID
        """
        try:
            # Validate inputs
            if not frames:
                raise ValueError("No frames provided for calibration")
            
            if len(frames) < config.min_frames_required:
                raise ValueError(f"Insufficient frames for calibration: {len(frames)} < {config.min_frames_required}")
            
            # Generate calibration ID
            calibration_id = f"calib_{uuid.uuid4().hex[:8]}"
            
            # Get current timestamp
            now = datetime.datetime.now().isoformat()
            
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Insert calibration record
            cursor.execute(
                """
                INSERT INTO camera_calibrations (
                    calibration_id, camera_id, timestamp, status, config
                )
                VALUES (?, ?, ?, ?, ?)
                """,
                (
                    calibration_id,
                    config.camera_id,
                    now,
                    "queued",
                    json.dumps(config.to_dict())
                )
            )
            
            # Commit changes
            conn.commit()
            
            # Close connection
            conn.close()
            
            # Save frames
            frames_dir = os.path.join(self.output_dir, "frames", calibration_id)
            os.makedirs(frames_dir, exist_ok=True)
            
            for i, frame in enumerate(frames):
                frame_path = os.path.join(frames_dir, f"frame_{i:03d}.png")
                cv2.imwrite(frame_path, frame)
            
            # Add item to calibration queue
            self.calibration_queue.put({
                "calibration_id": calibration_id,
                "config": config,
                "frames": frames
            })
            
            logger.info(f"Queued calibration: {calibration_id}")
            
            return calibration_id
        except Exception as e:
            logger.error(f"Error queuing calibration: {e}")
            raise
    
    def queue_alignment(self, config: AlignmentConfig, reference_frames: List[np.ndarray], target_frames: List[np.ndarray]) -> str:
        """
        Queue a camera alignment.
        
        Args:
            config: Alignment configuration
            reference_frames: List of frames from reference camera
            target_frames: List of frames from target camera
        
        Returns:
            Alignment ID
        """
        try:
            # Validate inputs
            if not reference_frames or not target_frames:
                raise ValueError("No frames provided for alignment")
            
            if len(reference_frames) != len(target_frames):
                raise ValueError(f"Mismatched frame counts: {len(reference_frames)} != {len(target_frames)}")
            
            if len(reference_frames) < config.min_frames_required:
                raise ValueError(f"Insufficient frames for alignment: {len(reference_frames)} < {config.min_frames_required}")
            
            # Generate alignment ID
            alignment_id = f"align_{uuid.uuid4().hex[:8]}"
            
            # Get current timestamp
            now = datetime.datetime.now().isoformat()
            
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Insert alignment record
            cursor.execute(
                """
                INSERT INTO camera_alignments (
                    alignment_id, reference_camera_id, target_camera_id, timestamp, status, config
                )
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    alignment_id,
                    config.reference_camera_id,
                    config.target_camera_id,
                    now,
                    "queued",
                    json.dumps(config.to_dict())
                )
            )
            
            # Commit changes
            conn.commit()
            
            # Close connection
            conn.close()
            
            # Save frames
            frames_dir = os.path.join(self.output_dir, "frames", alignment_id)
            os.makedirs(frames_dir, exist_ok=True)
            
            for i, (ref_frame, tgt_frame) in enumerate(zip(reference_frames, target_frames)):
                ref_frame_path = os.path.join(frames_dir, f"ref_frame_{i:03d}.png")
                tgt_frame_path = os.path.join(frames_dir, f"tgt_frame_{i:03d}.png")
                cv2.imwrite(ref_frame_path, ref_frame)
                cv2.imwrite(tgt_frame_path, tgt_frame)
            
            # Add item to alignment queue
            self.alignment_queue.put({
                "alignment_id": alignment_id,
                "config": config,
                "reference_frames": reference_frames,
                "target_frames": target_frames
            })
            
            logger.info(f"Queued alignment: {alignment_id}")
            
            return alignment_id
        except Exception as e:
            logger.error(f"Error queuing alignment: {e}")
            raise
    
    def get_calibration_status(self, calibration_id: str) -> Dict[str, Any]:
        """
        Get calibration status.
        
        Args:
            calibration_id: Calibration ID
        
        Returns:
            Calibration status dictionary
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Get calibration status
            cursor.execute(
                """
                SELECT * FROM camera_calibrations WHERE calibration_id = ?
                """,
                (calibration_id,)
            )
            row = cursor.fetchone()
            
            # Close connection
            conn.close()
            
            if not row:
                return {"error": f"Calibration not found: {calibration_id}"}
            
            # Convert row to dictionary
            calibration = dict(row)
            
            # Parse config
            if calibration.get("config"):
                calibration["config"] = json.loads(calibration["config"])
            
            # Parse result
            if calibration.get("result"):
                calibration["result"] = json.loads(calibration["result"])
            
            return calibration
        except Exception as e:
            logger.error(f"Error getting calibration status: {e}")
            return {"error": str(e)}
    
    def get_alignment_status(self, alignment_id: str) -> Dict[str, Any]:
        """
        Get alignment status.
        
        Args:
            alignment_id: Alignment ID
        
        Returns:
            Alignment status dictionary
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Get alignment status
            cursor.execute(
                """
                SELECT * FROM camera_alignments WHERE alignment_id = ?
                """,
                (alignment_id,)
            )
            row = cursor.fetchone()
            
            # Close connection
            conn.close()
            
            if not row:
                return {"error": f"Alignment not found: {alignment_id}"}
            
            # Convert row to dictionary
            alignment = dict(row)
            
            # Parse config
            if alignment.get("config"):
                alignment["config"] = json.loads(alignment["config"])
            
            # Parse result
            if alignment.get("result"):
                alignment["result"] = json.loads(alignment["result"])
            
            return alignment
        except Exception as e:
            logger.error(f"Error getting alignment status: {e}")
            return {"error": str(e)}
    
    def list_calibrations(self, camera_id: Optional[str] = None, limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        """
        List calibrations.
        
        Args:
            camera_id: Filter by camera ID (optional)
            limit: Maximum number of calibrations to return
            offset: Offset for pagination
        
        Returns:
            List of calibration dictionaries
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Build query
            query = "SELECT * FROM camera_calibrations"
            params = []
            
            if camera_id:
                query += " WHERE camera_id = ?"
                params.append(camera_id)
            
            query += " ORDER BY timestamp DESC LIMIT ? OFFSET ?"
            params.extend([limit, offset])
            
            # Get calibrations
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            # Close connection
            conn.close()
            
            # Convert rows to dictionaries
            calibrations = []
            for row in rows:
                calibration = dict(row)
                
                # Parse config
                if calibration.get("config"):
                    calibration["config"] = json.loads(calibration["config"])
                
                # Parse result
                if calibration.get("result"):
                    calibration["result"] = json.loads(calibration["result"])
                
                calibrations.append(calibration)
            
            return calibrations
        except Exception as e:
            logger.error(f"Error listing calibrations: {e}")
            return []
    
    def list_alignments(self, reference_camera_id: Optional[str] = None, target_camera_id: Optional[str] = None, limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        """
        List alignments.
        
        Args:
            reference_camera_id: Filter by reference camera ID (optional)
            target_camera_id: Filter by target camera ID (optional)
            limit: Maximum number of alignments to return
            offset: Offset for pagination
        
        Returns:
            List of alignment dictionaries
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Build query
            query = "SELECT * FROM camera_alignments"
            params = []
            
            where_clauses = []
            if reference_camera_id:
                where_clauses.append("reference_camera_id = ?")
                params.append(reference_camera_id)
            
            if target_camera_id:
                where_clauses.append("target_camera_id = ?")
                params.append(target_camera_id)
            
            if where_clauses:
                query += " WHERE " + " AND ".join(where_clauses)
            
            query += " ORDER BY timestamp DESC LIMIT ? OFFSET ?"
            params.extend([limit, offset])
            
            # Get alignments
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            # Close connection
            conn.close()
            
            # Convert rows to dictionaries
            alignments = []
            for row in rows:
                alignment = dict(row)
                
                # Parse config
                if alignment.get("config"):
                    alignment["config"] = json.loads(alignment["config"])
                
                # Parse result
                if alignment.get("result"):
                    alignment["result"] = json.loads(alignment["result"])
                
                alignments.append(alignment)
            
            return alignments
        except Exception as e:
            logger.error(f"Error listing alignments: {e}")
            return []
    
    def get_latest_calibration(self, camera_id: str) -> Optional[Dict[str, Any]]:
        """
        Get latest successful calibration for a camera.
        
        Args:
            camera_id: Camera ID
        
        Returns:
            Calibration dictionary or None if not found
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Get latest calibration
            cursor.execute(
                """
                SELECT * FROM camera_calibrations
                WHERE camera_id = ? AND status = 'completed'
                ORDER BY timestamp DESC
                LIMIT 1
                """,
                (camera_id,)
            )
            row = cursor.fetchone()
            
            # Close connection
            conn.close()
            
            if not row:
                return None
            
            # Convert row to dictionary
            calibration = dict(row)
            
            # Parse config
            if calibration.get("config"):
                calibration["config"] = json.loads(calibration["config"])
            
            # Parse result
            if calibration.get("result"):
                calibration["result"] = json.loads(calibration["result"])
            
            return calibration
        except Exception as e:
            logger.error(f"Error getting latest calibration: {e}")
            return None
    
    def get_latest_alignment(self, reference_camera_id: str, target_camera_id: str) -> Optional[Dict[str, Any]]:
        """
        Get latest successful alignment between two cameras.
        
        Args:
            reference_camera_id: Reference camera ID
            target_camera_id: Target camera ID
        
        Returns:
            Alignment dictionary or None if not found
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Get latest alignment
            cursor.execute(
                """
                SELECT * FROM camera_alignments
                WHERE reference_camera_id = ? AND target_camera_id = ? AND status = 'completed'
                ORDER BY timestamp DESC
                LIMIT 1
                """,
                (reference_camera_id, target_camera_id)
            )
            row = cursor.fetchone()
            
            # Close connection
            conn.close()
            
            if not row:
                return None
            
            # Convert row to dictionary
            alignment = dict(row)
            
            # Parse config
            if alignment.get("config"):
                alignment["config"] = json.loads(alignment["config"])
            
            # Parse result
            if alignment.get("result"):
                alignment["result"] = json.loads(alignment["result"])
            
            return alignment
        except Exception as e:
            logger.error(f"Error getting latest alignment: {e}")
            return None
    
    def delete_calibration(self, calibration_id: str) -> bool:
        """
        Delete calibration.
        
        Args:
            calibration_id: Calibration ID
        
        Returns:
            True if successful, False otherwise
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Delete calibration record
            cursor.execute("DELETE FROM camera_calibrations WHERE calibration_id = ?", (calibration_id,))
            
            # Commit changes
            conn.commit()
            
            # Close connection
            conn.close()
            
            # Delete calibration frames
            frames_dir = os.path.join(self.output_dir, "frames", calibration_id)
            if os.path.exists(frames_dir):
                import shutil
                shutil.rmtree(frames_dir)
            
            logger.info(f"Deleted calibration: {calibration_id}")
            
            return True
        except Exception as e:
            logger.error(f"Error deleting calibration: {e}")
            return False
    
    def delete_alignment(self, alignment_id: str) -> bool:
        """
        Delete alignment.
        
        Args:
            alignment_id: Alignment ID
        
        Returns:
            True if successful, False otherwise
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Delete alignment record
            cursor.execute("DELETE FROM camera_alignments WHERE alignment_id = ?", (alignment_id,))
            
            # Commit changes
            conn.commit()
            
            # Close connection
            conn.close()
            
            # Delete alignment frames
            frames_dir = os.path.join(self.output_dir, "frames", alignment_id)
            if os.path.exists(frames_dir):
                import shutil
                shutil.rmtree(frames_dir)
            
            logger.info(f"Deleted alignment: {alignment_id}")
            
            return True
        except Exception as e:
            logger.error(f"Error deleting alignment: {e}")
            return False
    
    def _update_calibration_status(self, calibration_id: str, status: str, reprojection_error: Optional[float] = None, error_message: Optional[str] = None):
        """
        Update calibration status.
        
        Args:
            calibration_id: Calibration ID
            status: Calibration status (queued, processing, completed, error)
            reprojection_error: Reprojection error (if status is completed)
            error_message: Error message (if status is error)
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Update calibration status
            if status == "completed" and reprojection_error is not None:
                cursor.execute(
                    """
                    UPDATE camera_calibrations
                    SET status = ?, reprojection_error = ?
                    WHERE calibration_id = ?
                    """,
                    (status, reprojection_error, calibration_id)
                )
            elif status == "error" and error_message:
                cursor.execute(
                    """
                    UPDATE camera_calibrations
                    SET status = ?, error_message = ?
                    WHERE calibration_id = ?
                    """,
                    (status, error_message, calibration_id)
                )
            else:
                cursor.execute(
                    """
                    UPDATE camera_calibrations
                    SET status = ?
                    WHERE calibration_id = ?
                    """,
                    (status, calibration_id)
                )
            
            # Commit changes
            conn.commit()
            
            # Close connection
            conn.close()
        except Exception as e:
            logger.error(f"Error updating calibration status: {e}")
    
    def _update_alignment_status(self, alignment_id: str, status: str, reprojection_error: Optional[float] = None, error_message: Optional[str] = None):
        """
        Update alignment status.
        
        Args:
            alignment_id: Alignment ID
            status: Alignment status (queued, processing, completed, error)
            reprojection_error: Reprojection error (if status is completed)
            error_message: Error message (if status is error)
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Update alignment status
            if status == "completed" and reprojection_error is not None:
                cursor.execute(
                    """
                    UPDATE camera_alignments
                    SET status = ?, reprojection_error = ?
                    WHERE alignment_id = ?
                    """,
                    (status, reprojection_error, alignment_id)
                )
            elif status == "error" and error_message:
                cursor.execute(
                    """
                    UPDATE camera_alignments
                    SET status = ?, error_message = ?
                    WHERE alignment_id = ?
                    """,
                    (status, error_message, alignment_id)
                )
            else:
                cursor.execute(
                    """
                    UPDATE camera_alignments
                    SET status = ?
                    WHERE alignment_id = ?
                    """,
                    (status, alignment_id)
                )
            
            # Commit changes
            conn.commit()
            
            # Close connection
            conn.close()
        except Exception as e:
            logger.error(f"Error updating alignment status: {e}")
    
    def _perform_calibration(self, calibration_id: str, config: CalibrationConfig, frames: List[np.ndarray]) -> CalibrationResult:
        """
        Perform camera calibration.
        
        Args:
            calibration_id: Calibration ID
            config: Calibration configuration
            frames: List of frames for calibration
        
        Returns:
            Calibration result
        """
        try:
            # Prepare object points
            objp = np.zeros((config.chessboard_size[0] * config.chessboard_size[1], 3), np.float32)
            objp[:, :2] = np.mgrid[0:config.chessboard_size[0], 0:config.chessboard_size[1]].T.reshape(-1, 2) * config.square_size
            
            # Arrays to store object points and image points
            objpoints = []  # 3D points in real world space
            imgpoints = []  # 2D points in image plane
            
            # Process frames
            image_size = None
            for i, frame in enumerate(frames):
                # Convert to grayscale
                if len(frame.shape) == 3:
                    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                else:
                    gray = frame
                
                # Set image size
                if image_size is None:
                    image_size = (gray.shape[1], gray.shape[0])
                
                # Find chessboard corners
                ret, corners = cv2.findChessboardCorners(gray, config.chessboard_size, config.calibration_flags)
                
                # If found, add object points and image points
                if ret:
                    # Refine corner positions
                    criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 30, 0.001)
                    corners = cv2.cornerSubPix(gray, corners, (11, 11), (-1, -1), criteria)
                    
                    # Add points
                    objpoints.append(objp)
                    imgpoints.append(corners)
                    
                    # Draw and save corners
                    cv2.drawChessboardCorners(frame, config.chessboard_size, corners, ret)
                    corners_path = os.path.join(self.output_dir, "frames", calibration_id, f"corners_{i:03d}.png")
                    cv2.imwrite(corners_path, frame)
            
            # Check if we have enough points
            if len(objpoints) < config.min_frames_required:
                raise ValueError(f"Insufficient valid frames for calibration: {len(objpoints)} < {config.min_frames_required}")
            
            # Perform calibration
            if config.fisheye:
                # Fisheye calibration
                calibration_flags = cv2.fisheye.CALIB_RECOMPUTE_EXTRINSIC + cv2.fisheye.CALIB_CHECK_COND + cv2.fisheye.CALIB_FIX_SKEW
                
                # Initialize camera matrix and distortion coefficients
                K = np.zeros((3, 3))
                D = np.zeros((4, 1))
                
                # Prepare object points for fisheye calibration
                objpoints = [x.reshape(1, -1, 3) for x in objpoints]
                
                # Calibrate camera
                ret, K, D, rvecs, tvecs = cv2.fisheye.calibrate(
                    objpoints,
                    imgpoints,
                    image_size,
                    K,
                    D,
                    flags=calibration_flags
                )
                
                # Calculate reprojection error
                mean_error = 0
                for i in range(len(objpoints)):
                    imgpoints2, _ = cv2.fisheye.projectPoints(objpoints[i], rvecs[i], tvecs[i], K, D)
                    error = cv2.norm(imgpoints[i], imgpoints2, cv2.NORM_L2) / len(imgpoints2)
                    mean_error += error
                
                reprojection_error = mean_error / len(objpoints)
                
                # Create calibration result
                result = CalibrationResult(
                    camera_id=config.camera_id,
                    calibration_id=calibration_id,
                    timestamp=datetime.datetime.now().isoformat(),
                    image_size=image_size,
                    camera_matrix=K,
                    distortion_coefficients=D,
                    rotation_vectors=rvecs,
                    translation_vectors=tvecs,
                    reprojection_error=reprojection_error,
                    fisheye=True,
                    frame_count=len(objpoints)
                )
            else:
                # Standard calibration
                ret, mtx, dist, rvecs, tvecs = cv2.calibrateCamera(
                    objpoints,
                    imgpoints,
                    image_size,
                    None,
                    None
                )
                
                # Calculate reprojection error
                mean_error = 0
                for i in range(len(objpoints)):
                    imgpoints2, _ = cv2.projectPoints(objpoints[i], rvecs[i], tvecs[i], mtx, dist)
                    error = cv2.norm(imgpoints[i], imgpoints2, cv2.NORM_L2) / len(imgpoints2)
                    mean_error += error
                
                reprojection_error = mean_error / len(objpoints)
                
                # Create calibration result
                result = CalibrationResult(
                    camera_id=config.camera_id,
                    calibration_id=calibration_id,
                    timestamp=datetime.datetime.now().isoformat(),
                    image_size=image_size,
                    camera_matrix=mtx,
                    distortion_coefficients=dist,
                    rotation_vectors=rvecs,
                    translation_vectors=tvecs,
                    reprojection_error=reprojection_error,
                    fisheye=False,
                    frame_count=len(objpoints)
                )
            
            # Generate undistorted test images
            for i, frame in enumerate(frames[:5]):  # Only process first 5 frames
                if config.fisheye:
                    # Fisheye undistortion
                    map1, map2 = cv2.fisheye.initUndistortRectifyMap(
                        result.camera_matrix,
                        result.distortion_coefficients,
                        np.eye(3),
                        result.camera_matrix,
                        image_size,
                        cv2.CV_16SC2
                    )
                    undistorted = cv2.remap(frame, map1, map2, interpolation=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT)
                else:
                    # Standard undistortion
                    undistorted = cv2.undistort(frame, result.camera_matrix, result.distortion_coefficients)
                
                # Save undistorted image
                undistorted_path = os.path.join(self.output_dir, "frames", calibration_id, f"undistorted_{i:03d}.png")
                cv2.imwrite(undistorted_path, undistorted)
            
            # Generate visualization
            self._generate_calibration_visualization(calibration_id, result, frames[0] if frames else None)
            
            return result
        except Exception as e:
            logger.error(f"Error performing calibration: {e}")
            raise
    
    def _perform_alignment(self, alignment_id: str, config: AlignmentConfig, reference_frames: List[np.ndarray], target_frames: List[np.ndarray]) -> AlignmentResult:
        """
        Perform camera alignment.
        
        Args:
            alignment_id: Alignment ID
            config: Alignment configuration
            reference_frames: List of frames from reference camera
            target_frames: List of frames from target camera
        
        Returns:
            Alignment result
        """
        try:
            # Get latest calibrations
            reference_calibration = self.get_latest_calibration(config.reference_camera_id)
            target_calibration = self.get_latest_calibration(config.target_camera_id)
            
            if not reference_calibration or not target_calibration:
                raise ValueError("Calibration not found for one or both cameras")
            
            # Parse calibration results
            reference_result = CalibrationResult.from_dict(reference_calibration["result"])
            target_result = CalibrationResult.from_dict(target_calibration["result"])
            
            # Prepare object points
            objp = np.zeros((config.chessboard_size[0] * config.chessboard_size[1], 3), np.float32)
            objp[:, :2] = np.mgrid[0:config.chessboard_size[0], 0:config.chessboard_size[1]].T.reshape(-1, 2) * config.square_size
            
            # Arrays to store image points
            reference_points = []  # 2D points in reference image plane
            target_points = []  # 2D points in target image plane
            
            # Process frames
            for i, (ref_frame, tgt_frame) in enumerate(zip(reference_frames, target_frames)):
                # Convert to grayscale
                if len(ref_frame.shape) == 3:
                    ref_gray = cv2.cvtColor(ref_frame, cv2.COLOR_BGR2GRAY)
                else:
                    ref_gray = ref_frame
                
                if len(tgt_frame.shape) == 3:
                    tgt_gray = cv2.cvtColor(tgt_frame, cv2.COLOR_BGR2GRAY)
                else:
                    tgt_gray = tgt_frame
                
                # Find chessboard corners in reference frame
                ref_ret, ref_corners = cv2.findChessboardCorners(ref_gray, config.chessboard_size, config.calibration_flags)
                
                # Find chessboard corners in target frame
                tgt_ret, tgt_corners = cv2.findChessboardCorners(tgt_gray, config.chessboard_size, config.calibration_flags)
                
                # If found in both frames, add points
                if ref_ret and tgt_ret:
                    # Refine corner positions
                    criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 30, 0.001)
                    ref_corners = cv2.cornerSubPix(ref_gray, ref_corners, (11, 11), (-1, -1), criteria)
                    tgt_corners = cv2.cornerSubPix(tgt_gray, tgt_corners, (11, 11), (-1, -1), criteria)
                    
                    # Add points
                    reference_points.append(ref_corners)
                    target_points.append(tgt_corners)
                    
                    # Draw and save corners
                    cv2.drawChessboardCorners(ref_frame, config.chessboard_size, ref_corners, ref_ret)
                    cv2.drawChessboardCorners(tgt_frame, config.chessboard_size, tgt_corners, tgt_ret)
                    
                    ref_corners_path = os.path.join(self.output_dir, "frames", alignment_id, f"ref_corners_{i:03d}.png")
                    tgt_corners_path = os.path.join(self.output_dir, "frames", alignment_id, f"tgt_corners_{i:03d}.png")
                    
                    cv2.imwrite(ref_corners_path, ref_frame)
                    cv2.imwrite(tgt_corners_path, tgt_frame)
            
            # Check if we have enough points
            if len(reference_points) < config.min_frames_required:
                raise ValueError(f"Insufficient valid frame pairs for alignment: {len(reference_points)} < {config.min_frames_required}")
            
            # Compute essential matrix
            E, E_mask = cv2.findEssentialMat(
                reference_points[0],
                target_points[0],
                reference_result.camera_matrix,
                target_result.camera_matrix
            )
            
            # Compute fundamental matrix
            F, F_mask = cv2.findFundamentalMat(
                reference_points[0],
                target_points[0],
                cv2.FM_RANSAC
            )
            
            # Recover pose
            _, R, t, _ = cv2.recoverPose(E, reference_points[0], target_points[0], reference_result.camera_matrix, target_result.camera_matrix)
            
            # Calculate reprojection error
            mean_error = 0
            for ref_points, tgt_points in zip(reference_points, target_points):
                # Project reference points to target frame
                ref_points_3d = cv2.undistortPoints(ref_points, reference_result.camera_matrix, reference_result.distortion_coefficients)
                ref_points_3d = np.hstack((ref_points_3d.reshape(-1, 2), np.ones((ref_points_3d.shape[0], 1))))
                
                # Apply rotation and translation
                projected_points = np.dot(R, ref_points_3d.T) + t
                
                # Project to image plane
                projected_points = projected_points.T
                projected_points = projected_points[:, :2] / projected_points[:, 2:]
                
                # Apply target camera matrix
                projected_points = np.dot(projected_points, target_result.camera_matrix[:2, :2].T) + target_result.camera_matrix[:2, 2]
                
                # Calculate error
                error = np.mean(np.sqrt(np.sum((projected_points - tgt_points.reshape(-1, 2)) ** 2, axis=1)))
                mean_error += error
            
            reprojection_error = mean_error / len(reference_points)
            
            # Create alignment result
            result = AlignmentResult(
                reference_camera_id=config.reference_camera_id,
                target_camera_id=config.target_camera_id,
                alignment_id=alignment_id,
                timestamp=datetime.datetime.now().isoformat(),
                rotation_matrix=R,
                translation_vector=t,
                essential_matrix=E,
                fundamental_matrix=F,
                reprojection_error=reprojection_error,
                frame_count=len(reference_points)
            )
            
            # Generate visualization
            self._generate_alignment_visualization(alignment_id, result, reference_frames[0] if reference_frames else None, target_frames[0] if target_frames else None)
            
            return result
        except Exception as e:
            logger.error(f"Error performing alignment: {e}")
            raise
    
    def _save_calibration_result(self, result: CalibrationResult):
        """
        Save calibration result to database.
        
        Args:
            result: Calibration result
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Update calibration record
            cursor.execute(
                """
                UPDATE camera_calibrations
                SET result = ?
                WHERE calibration_id = ?
                """,
                (json.dumps(result.to_dict()), result.calibration_id)
            )
            
            # Commit changes
            conn.commit()
            
            # Close connection
            conn.close()
            
            # Save result to file
            result_path = os.path.join(self.output_dir, f"calibration_{result.calibration_id}.json")
            with open(result_path, "w") as f:
                json.dump(result.to_dict(), f, indent=2)
            
            logger.info(f"Saved calibration result: {result.calibration_id}")
        except Exception as e:
            logger.error(f"Error saving calibration result: {e}")
    
    def _save_alignment_result(self, result: AlignmentResult):
        """
        Save alignment result to database.
        
        Args:
            result: Alignment result
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Update alignment record
            cursor.execute(
                """
                UPDATE camera_alignments
                SET result = ?
                WHERE alignment_id = ?
                """,
                (json.dumps(result.to_dict()), result.alignment_id)
            )
            
            # Commit changes
            conn.commit()
            
            # Close connection
            conn.close()
            
            # Save result to file
            result_path = os.path.join(self.output_dir, f"alignment_{result.alignment_id}.json")
            with open(result_path, "w") as f:
                json.dump(result.to_dict(), f, indent=2)
            
            logger.info(f"Saved alignment result: {result.alignment_id}")
        except Exception as e:
            logger.error(f"Error saving alignment result: {e}")
    
    def _generate_calibration_visualization(self, calibration_id: str, result: CalibrationResult, sample_frame: Optional[np.ndarray] = None):
        """
        Generate visualization for calibration result.
        
        Args:
            calibration_id: Calibration ID
            result: Calibration result
            sample_frame: Sample frame for visualization
        """
        try:
            # Create figure
            fig = plt.figure(figsize=(12, 8))
            
            # Add title
            fig.suptitle(f"Camera Calibration: {result.camera_id}", fontsize=16)
            
            # Add camera matrix
            ax1 = fig.add_subplot(2, 2, 1)
            ax1.set_title("Camera Matrix")
            ax1.axis("off")
            
            # Format camera matrix
            mtx_text = "Camera Matrix:\n"
            for row in result.camera_matrix:
                mtx_text += f"{row[0]:.2f}  {row[1]:.2f}  {row[2]:.2f}\n"
            
            # Add distortion coefficients
            dist_text = "\nDistortion Coefficients:\n"
            for val in result.distortion_coefficients.flatten():
                dist_text += f"{val:.4f}  "
            
            # Add reprojection error
            error_text = f"\n\nReprojection Error: {result.reprojection_error:.4f}"
            
            # Add frame count
            frames_text = f"\nFrames Used: {result.frame_count}"
            
            # Add fisheye flag
            fisheye_text = f"\nFisheye: {'Yes' if result.fisheye else 'No'}"
            
            # Add text to plot
            ax1.text(0.1, 0.5, mtx_text + dist_text + error_text + frames_text + fisheye_text, fontsize=10, family="monospace")
            
            # Add sample frame if available
            if sample_frame is not None:
                # Original frame
                ax2 = fig.add_subplot(2, 2, 2)
                ax2.set_title("Original Frame")
                ax2.imshow(cv2.cvtColor(sample_frame, cv2.COLOR_BGR2RGB))
                ax2.axis("off")
                
                # Undistorted frame
                ax3 = fig.add_subplot(2, 2, 3)
                ax3.set_title("Undistorted Frame")
                
                if result.fisheye:
                    # Fisheye undistortion
                    map1, map2 = cv2.fisheye.initUndistortRectifyMap(
                        result.camera_matrix,
                        result.distortion_coefficients,
                        np.eye(3),
                        result.camera_matrix,
                        result.image_size,
                        cv2.CV_16SC2
                    )
                    undistorted = cv2.remap(sample_frame, map1, map2, interpolation=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT)
                else:
                    # Standard undistortion
                    undistorted = cv2.undistort(sample_frame, result.camera_matrix, result.distortion_coefficients)
                
                ax3.imshow(cv2.cvtColor(undistorted, cv2.COLOR_BGR2RGB))
                ax3.axis("off")
                
                # Distortion visualization
                ax4 = fig.add_subplot(2, 2, 4)
                ax4.set_title("Distortion Visualization")
                
                # Create grid
                h, w = sample_frame.shape[:2]
                grid_size = 20
                grid = np.zeros((h, w, 3), dtype=np.uint8)
                grid.fill(255)
                
                # Draw horizontal lines
                for y in range(0, h, grid_size):
                    cv2.line(grid, (0, y), (w, y), (0, 0, 0), 1)
                
                # Draw vertical lines
                for x in range(0, w, grid_size):
                    cv2.line(grid, (x, 0), (x, h), (0, 0, 0), 1)
                
                # Distort grid
                if result.fisheye:
                    # Fisheye distortion
                    map1, map2 = cv2.fisheye.initUndistortRectifyMap(
                        result.camera_matrix,
                        result.distortion_coefficients,
                        np.eye(3),
                        result.camera_matrix,
                        result.image_size,
                        cv2.CV_16SC2
                    )
                    distorted_grid = cv2.remap(grid, map1, map2, interpolation=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT)
                else:
                    # Standard distortion
                    distorted_grid = cv2.undistort(grid, result.camera_matrix, result.distortion_coefficients)
                
                ax4.imshow(cv2.cvtColor(distorted_grid, cv2.COLOR_BGR2RGB))
                ax4.axis("off")
            
            # Adjust layout
            plt.tight_layout(rect=[0, 0, 1, 0.95])
            
            # Save figure
            vis_path = os.path.join(self.output_dir, f"calibration_{calibration_id}_vis.png")
            plt.savefig(vis_path, dpi=150)
            plt.close(fig)
            
            logger.info(f"Generated calibration visualization: {vis_path}")
        except Exception as e:
            logger.error(f"Error generating calibration visualization: {e}")
    
    def _generate_alignment_visualization(self, alignment_id: str, result: AlignmentResult, reference_frame: Optional[np.ndarray] = None, target_frame: Optional[np.ndarray] = None):
        """
        Generate visualization for alignment result.
        
        Args:
            alignment_id: Alignment ID
            result: Alignment result
            reference_frame: Sample frame from reference camera
            target_frame: Sample frame from target camera
        """
        try:
            # Create figure
            fig = plt.figure(figsize=(12, 8))
            
            # Add title
            fig.suptitle(f"Camera Alignment: {result.reference_camera_id} → {result.target_camera_id}", fontsize=16)
            
            # Add rotation and translation
            ax1 = fig.add_subplot(2, 2, 1)
            ax1.set_title("Rotation and Translation")
            ax1.axis("off")
            
            # Format rotation matrix
            rot_text = "Rotation Matrix:\n"
            for row in result.rotation_matrix:
                rot_text += f"{row[0]:.4f}  {row[1]:.4f}  {row[2]:.4f}\n"
            
            # Format translation vector
            trans_text = "\nTranslation Vector:\n"
            for val in result.translation_vector.flatten():
                trans_text += f"{val:.4f}  "
            
            # Add reprojection error
            error_text = f"\n\nReprojection Error: {result.reprojection_error:.4f}"
            
            # Add frame count
            frames_text = f"\nFrames Used: {result.frame_count}"
            
            # Add text to plot
            ax1.text(0.1, 0.5, rot_text + trans_text + error_text + frames_text, fontsize=10, family="monospace")
            
            # Add sample frames if available
            if reference_frame is not None and target_frame is not None:
                # Reference frame
                ax2 = fig.add_subplot(2, 2, 2)
                ax2.set_title(f"Reference Camera: {result.reference_camera_id}")
                ax2.imshow(cv2.cvtColor(reference_frame, cv2.COLOR_BGR2RGB))
                ax2.axis("off")
                
                # Target frame
                ax3 = fig.add_subplot(2, 2, 3)
                ax3.set_title(f"Target Camera: {result.target_camera_id}")
                ax3.imshow(cv2.cvtColor(target_frame, cv2.COLOR_BGR2RGB))
                ax3.axis("off")
                
                # 3D visualization
                ax4 = fig.add_subplot(2, 2, 4, projection="3d")
                ax4.set_title("Camera Positions (3D)")
                
                # Plot reference camera
                ax4.scatter(0, 0, 0, c="r", marker="o", s=100, label="Reference Camera")
                
                # Plot camera axes
                ax4.quiver(0, 0, 0, 1, 0, 0, color="r", length=0.5, arrow_length_ratio=0.1)
                ax4.quiver(0, 0, 0, 0, 1, 0, color="g", length=0.5, arrow_length_ratio=0.1)
                ax4.quiver(0, 0, 0, 0, 0, 1, color="b", length=0.5, arrow_length_ratio=0.1)
                
                # Get target camera position
                R = result.rotation_matrix
                t = result.translation_vector.flatten()
                
                # Plot target camera
                ax4.scatter(t[0], t[1], t[2], c="b", marker="o", s=100, label="Target Camera")
                
                # Plot target camera axes
                ax4.quiver(t[0], t[1], t[2], R[0, 0], R[1, 0], R[2, 0], color="r", length=0.5, arrow_length_ratio=0.1)
                ax4.quiver(t[0], t[1], t[2], R[0, 1], R[1, 1], R[2, 1], color="g", length=0.5, arrow_length_ratio=0.1)
                ax4.quiver(t[0], t[1], t[2], R[0, 2], R[1, 2], R[2, 2], color="b", length=0.5, arrow_length_ratio=0.1)
                
                # Set equal aspect ratio
                ax4.set_box_aspect([1, 1, 1])
                
                # Add legend
                ax4.legend()
                
                # Set labels
                ax4.set_xlabel("X")
                ax4.set_ylabel("Y")
                ax4.set_zlabel("Z")
            
            # Adjust layout
            plt.tight_layout(rect=[0, 0, 1, 0.95])
            
            # Save figure
            vis_path = os.path.join(self.output_dir, f"alignment_{alignment_id}_vis.png")
            plt.savefig(vis_path, dpi=150)
            plt.close(fig)
            
            logger.info(f"Generated alignment visualization: {vis_path}")
        except Exception as e:
            logger.error(f"Error generating alignment visualization: {e}")


class CameraCalibrationTool:
    """
    Camera calibration tool for OPSC Sandwich Quality Inspection System.
    
    Provides a high-level interface for camera calibration and alignment.
    """
    
    def __init__(self, camera_manager, calibrator: CameraCalibrator):
        """
        Initialize camera calibration tool.
        
        Args:
            camera_manager: Camera manager instance
            calibrator: Camera calibrator instance
        """
        self.camera_manager = camera_manager
        self.calibrator = calibrator
        
        # Start calibration and alignment workers
        self.calibrator.start_calibration_worker()
        self.calibrator.start_alignment_worker()
    
    def calibrate_camera(self, camera_id: str, config: Optional[CalibrationConfig] = None) -> str:
        """
        Calibrate a camera.
        
        Args:
            camera_id: Camera ID
            config: Calibration configuration (optional)
        
        Returns:
            Calibration ID
        """
        try:
            # Get camera
            camera = self.camera_manager.get_camera(camera_id)
            if not camera:
                raise ValueError(f"Camera not found: {camera_id}")
            
            # Create default configuration if not provided
            if config is None:
                config = CalibrationConfig(camera_id=camera_id)
            
            # Capture frames
            frames = []
            frame_count = 0
            max_frames = config.max_frames_to_capture
            
            logger.info(f"Capturing frames for calibration of camera {camera_id}...")
            
            while frame_count < max_frames:
                # Capture frame
                frame = camera.capture_frame()
                if frame is None:
                    logger.warning(f"Failed to capture frame from camera {camera_id}")
                    continue
                
                # Convert to grayscale for chessboard detection
                if len(frame.shape) == 3:
                    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                else:
                    gray = frame
                
                # Find chessboard corners
                ret, corners = cv2.findChessboardCorners(gray, config.chessboard_size, config.calibration_flags)
                
                # If found, add frame
                if ret:
                    frames.append(frame.copy())
                    frame_count += 1
                    logger.info(f"Captured frame {frame_count}/{config.frame_count} with chessboard")
                    
                    # Check if we have enough frames
                    if frame_count >= config.frame_count:
                        break
                
                # Wait between captures
                time.sleep(config.delay_between_captures)
            
            # Check if we have enough frames
            if len(frames) < config.min_frames_required:
                raise ValueError(f"Insufficient frames for calibration: {len(frames)} < {config.min_frames_required}")
            
            # Queue calibration
            calibration_id = self.calibrator.queue_calibration(config, frames)
            
            logger.info(f"Queued calibration {calibration_id} for camera {camera_id}")
            
            return calibration_id
        except Exception as e:
            logger.error(f"Error calibrating camera: {e}")
            raise
    
    def align_cameras(self, reference_camera_id: str, target_camera_id: str, config: Optional[AlignmentConfig] = None) -> str:
        """
        Align two cameras.
        
        Args:
            reference_camera_id: Reference camera ID
            target_camera_id: Target camera ID
            config: Alignment configuration (optional)
        
        Returns:
            Alignment ID
        """
        try:
            # Get cameras
            reference_camera = self.camera_manager.get_camera(reference_camera_id)
            target_camera = self.camera_manager.get_camera(target_camera_id)
            
            if not reference_camera:
                raise ValueError(f"Reference camera not found: {reference_camera_id}")
            
            if not target_camera:
                raise ValueError(f"Target camera not found: {target_camera_id}")
            
            # Create default configuration if not provided
            if config is None:
                config = AlignmentConfig(
                    reference_camera_id=reference_camera_id,
                    target_camera_id=target_camera_id
                )
            
            # Capture frames
            reference_frames = []
            target_frames = []
            frame_count = 0
            max_frames = config.max_frames_to_capture
            
            logger.info(f"Capturing frames for alignment of cameras {reference_camera_id} and {target_camera_id}...")
            
            while frame_count < max_frames:
                # Capture frames
                reference_frame = reference_camera.capture_frame()
                target_frame = target_camera.capture_frame()
                
                if reference_frame is None or target_frame is None:
                    logger.warning("Failed to capture frames from one or both cameras")
                    continue
                
                # Convert to grayscale for chessboard detection
                if len(reference_frame.shape) == 3:
                    reference_gray = cv2.cvtColor(reference_frame, cv2.COLOR_BGR2GRAY)
                else:
                    reference_gray = reference_frame
                
                if len(target_frame.shape) == 3:
                    target_gray = cv2.cvtColor(target_frame, cv2.COLOR_BGR2GRAY)
                else:
                    target_gray = target_frame
                
                # Find chessboard corners in reference frame
                reference_ret, _ = cv2.findChessboardCorners(reference_gray, config.chessboard_size, config.calibration_flags)
                
                # Find chessboard corners in target frame
                target_ret, _ = cv2.findChessboardCorners(target_gray, config.chessboard_size, config.calibration_flags)
                
                # If found in both frames, add frames
                if reference_ret and target_ret:
                    reference_frames.append(reference_frame.copy())
                    target_frames.append(target_frame.copy())
                    frame_count += 1
                    logger.info(f"Captured frame pair {frame_count}/{config.frame_count} with chessboard")
                    
                    # Check if we have enough frames
                    if frame_count >= config.frame_count:
                        break
                
                # Wait between captures
                time.sleep(config.delay_between_captures)
            
            # Check if we have enough frames
            if len(reference_frames) < config.min_frames_required:
                raise ValueError(f"Insufficient frame pairs for alignment: {len(reference_frames)} < {config.min_frames_required}")
            
            # Queue alignment
            alignment_id = self.calibrator.queue_alignment(config, reference_frames, target_frames)
            
            logger.info(f"Queued alignment {alignment_id} for cameras {reference_camera_id} and {target_camera_id}")
            
            return alignment_id
        except Exception as e:
            logger.error(f"Error aligning cameras: {e}")
            raise
    
    def get_calibration_status(self, calibration_id: str) -> Dict[str, Any]:
        """
        Get calibration status.
        
        Args:
            calibration_id: Calibration ID
        
        Returns:
            Calibration status dictionary
        """
        return self.calibrator.get_calibration_status(calibration_id)
    
    def get_alignment_status(self, alignment_id: str) -> Dict[str, Any]:
        """
        Get alignment status.
        
        Args:
            alignment_id: Alignment ID
        
        Returns:
            Alignment status dictionary
        """
        return self.calibrator.get_alignment_status(alignment_id)
    
    def list_calibrations(self, camera_id: Optional[str] = None, limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        """
        List calibrations.
        
        Args:
            camera_id: Filter by camera ID (optional)
            limit: Maximum number of calibrations to return
            offset: Offset for pagination
        
        Returns:
            List of calibration dictionaries
        """
        return self.calibrator.list_calibrations(camera_id, limit, offset)
    
    def list_alignments(self, reference_camera_id: Optional[str] = None, target_camera_id: Optional[str] = None, limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        """
        List alignments.
        
        Args:
            reference_camera_id: Filter by reference camera ID (optional)
            target_camera_id: Filter by target camera ID (optional)
            limit: Maximum number of alignments to return
            offset: Offset for pagination
        
        Returns:
            List of alignment dictionaries
        """
        return self.calibrator.list_alignments(reference_camera_id, target_camera_id, limit, offset)
    
    def get_latest_calibration(self, camera_id: str) -> Optional[Dict[str, Any]]:
        """
        Get latest successful calibration for a camera.
        
        Args:
            camera_id: Camera ID
        
        Returns:
            Calibration dictionary or None if not found
        """
        return self.calibrator.get_latest_calibration(camera_id)
    
    def get_latest_alignment(self, reference_camera_id: str, target_camera_id: str) -> Optional[Dict[str, Any]]:
        """
        Get latest successful alignment between two cameras.
        
        Args:
            reference_camera_id: Reference camera ID
            target_camera_id: Target camera ID
        
        Returns:
            Alignment dictionary or None if not found
        """
        return self.calibrator.get_latest_alignment(reference_camera_id, target_camera_id)
    
    def delete_calibration(self, calibration_id: str) -> bool:
        """
        Delete calibration.
        
        Args:
            calibration_id: Calibration ID
        
        Returns:
            True if successful, False otherwise
        """
        return self.calibrator.delete_calibration(calibration_id)
    
    def delete_alignment(self, alignment_id: str) -> bool:
        """
        Delete alignment.
        
        Args:
            alignment_id: Alignment ID
        
        Returns:
            True if successful, False otherwise
        """
        return self.calibrator.delete_alignment(alignment_id)
    
    def undistort_image(self, image: np.ndarray, camera_id: str) -> Optional[np.ndarray]:
        """
        Undistort an image using camera calibration.
        
        Args:
            image: Input image
            camera_id: Camera ID
        
        Returns:
            Undistorted image or None if calibration not found
        """
        try:
            # Get latest calibration
            calibration = self.get_latest_calibration(camera_id)
            if not calibration:
                logger.warning(f"No calibration found for camera {camera_id}")
                return None
            
            # Parse calibration result
            result = CalibrationResult.from_dict(calibration["result"])
            
            # Check image size
            if image.shape[1] != result.image_size[0] or image.shape[0] != result.image_size[1]:
                logger.warning(f"Image size mismatch: {image.shape[1]}x{image.shape[0]} != {result.image_size[0]}x{result.image_size[1]}")
                
                # Resize image to match calibration
                image = cv2.resize(image, result.image_size)
            
            # Undistort image
            if result.fisheye:
                # Fisheye undistortion
                map1, map2 = cv2.fisheye.initUndistortRectifyMap(
                    result.camera_matrix,
                    result.distortion_coefficients,
                    np.eye(3),
                    result.camera_matrix,
                    result.image_size,
                    cv2.CV_16SC2
                )
                undistorted = cv2.remap(image, map1, map2, interpolation=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT)
            else:
                # Standard undistortion
                undistorted = cv2.undistort(image, result.camera_matrix, result.distortion_coefficients)
            
            return undistorted
        except Exception as e:
            logger.error(f"Error undistorting image: {e}")
            return None
    
    def rectify_stereo_images(self, left_image: np.ndarray, right_image: np.ndarray, left_camera_id: str, right_camera_id: str) -> Optional[Tuple[np.ndarray, np.ndarray]]:
        """
        Rectify stereo images using camera calibration and alignment.
        
        Args:
            left_image: Left camera image
            right_image: Right camera image
            left_camera_id: Left camera ID
            right_camera_id: Right camera ID
        
        Returns:
            Tuple of rectified left and right images or None if calibration or alignment not found
        """
        try:
            # Get latest calibrations
            left_calibration = self.get_latest_calibration(left_camera_id)
            right_calibration = self.get_latest_calibration(right_camera_id)
            
            if not left_calibration or not right_calibration:
                logger.warning(f"Calibration not found for one or both cameras")
                return None
            
            # Get latest alignment
            alignment = self.get_latest_alignment(left_camera_id, right_camera_id)
            if not alignment:
                # Try reverse alignment
                alignment = self.get_latest_alignment(right_camera_id, left_camera_id)
                if not alignment:
                    logger.warning(f"No alignment found between cameras {left_camera_id} and {right_camera_id}")
                    return None
                
                # Invert alignment
                result = AlignmentResult.from_dict(alignment["result"])
                R = result.rotation_matrix.T
                t = -np.dot(R, result.translation_vector)
            else:
                # Use alignment as is
                result = AlignmentResult.from_dict(alignment["result"])
                R = result.rotation_matrix
                t = result.translation_vector
            
            # Parse calibration results
            left_result = CalibrationResult.from_dict(left_calibration["result"])
            right_result = CalibrationResult.from_dict(right_calibration["result"])
            
            # Check image sizes
            if left_image.shape[1] != left_result.image_size[0] or left_image.shape[0] != left_result.image_size[1]:
                logger.warning(f"Left image size mismatch: {left_image.shape[1]}x{left_image.shape[0]} != {left_result.image_size[0]}x{left_result.image_size[1]}")
                
                # Resize image to match calibration
                left_image = cv2.resize(left_image, left_result.image_size)
            
            if right_image.shape[1] != right_result.image_size[0] or right_image.shape[0] != right_result.image_size[1]:
                logger.warning(f"Right image size mismatch: {right_image.shape[1]}x{right_image.shape[0]} != {right_result.image_size[0]}x{right_result.image_size[1]}")
                
                # Resize image to match calibration
                right_image = cv2.resize(right_image, right_result.image_size)
            
            # Compute rectification transforms
            R1, R2, P1, P2, Q, _, _ = cv2.stereoRectify(
                left_result.camera_matrix,
                left_result.distortion_coefficients,
                right_result.camera_matrix,
                right_result.distortion_coefficients,
                left_result.image_size,
                R,
                t
            )
            
            # Compute undistortion and rectification maps
            map1x, map1y = cv2.initUndistortRectifyMap(
                left_result.camera_matrix,
                left_result.distortion_coefficients,
                R1,
                P1,
                left_result.image_size,
                cv2.CV_32FC1
            )
            
            map2x, map2y = cv2.initUndistortRectifyMap(
                right_result.camera_matrix,
                right_result.distortion_coefficients,
                R2,
                P2,
                right_result.image_size,
                cv2.CV_32FC1
            )
            
            # Rectify images
            left_rectified = cv2.remap(left_image, map1x, map1y, cv2.INTER_LINEAR)
            right_rectified = cv2.remap(right_image, map2x, map2y, cv2.INTER_LINEAR)
            
            return left_rectified, right_rectified
        except Exception as e:
            logger.error(f"Error rectifying stereo images: {e}")
            return None
    
    def compute_disparity_map(self, left_image: np.ndarray, right_image: np.ndarray, left_camera_id: str, right_camera_id: str) -> Optional[np.ndarray]:
        """
        Compute disparity map from stereo images.
        
        Args:
            left_image: Left camera image
            right_image: Right camera image
            left_camera_id: Left camera ID
            right_camera_id: Right camera ID
        
        Returns:
            Disparity map or None if rectification failed
        """
        try:
            # Rectify images
            rectified = self.rectify_stereo_images(left_image, right_image, left_camera_id, right_camera_id)
            if not rectified:
                return None
            
            left_rectified, right_rectified = rectified
            
            # Convert to grayscale
            if len(left_rectified.shape) == 3:
                left_gray = cv2.cvtColor(left_rectified, cv2.COLOR_BGR2GRAY)
            else:
                left_gray = left_rectified
            
            if len(right_rectified.shape) == 3:
                right_gray = cv2.cvtColor(right_rectified, cv2.COLOR_BGR2GRAY)
            else:
                right_gray = right_rectified
            
            # Compute disparity map
            stereo = cv2.StereoSGBM_create(
                minDisparity=0,
                numDisparities=128,
                blockSize=5,
                P1=8 * 3 * 5**2,
                P2=32 * 3 * 5**2,
                disp12MaxDiff=1,
                uniquenessRatio=15,
                speckleWindowSize=100,
                speckleRange=32
            )
            
            disparity = stereo.compute(left_gray, right_gray)
            
            # Normalize disparity map
            disparity = cv2.normalize(disparity, None, alpha=0, beta=255, norm_type=cv2.NORM_MINMAX, dtype=cv2.CV_8U)
            
            return disparity
        except Exception as e:
            logger.error(f"Error computing disparity map: {e}")
            return None
    
    def compute_depth_map(self, left_image: np.ndarray, right_image: np.ndarray, left_camera_id: str, right_camera_id: str) -> Optional[np.ndarray]:
        """
        Compute depth map from stereo images.
        
        Args:
            left_image: Left camera image
            right_image: Right camera image
            left_camera_id: Left camera ID
            right_camera_id: Right camera ID
        
        Returns:
            Depth map or None if rectification failed
        """
        try:
            # Get latest calibrations
            left_calibration = self.get_latest_calibration(left_camera_id)
            right_calibration = self.get_latest_calibration(right_camera_id)
            
            if not left_calibration or not right_calibration:
                logger.warning(f"Calibration not found for one or both cameras")
                return None
            
            # Get latest alignment
            alignment = self.get_latest_alignment(left_camera_id, right_camera_id)
            if not alignment:
                # Try reverse alignment
                alignment = self.get_latest_alignment(right_camera_id, left_camera_id)
                if not alignment:
                    logger.warning(f"No alignment found between cameras {left_camera_id} and {right_camera_id}")
                    return None
                
                # Invert alignment
                result = AlignmentResult.from_dict(alignment["result"])
                R = result.rotation_matrix.T
                t = -np.dot(R, result.translation_vector)
            else:
                # Use alignment as is
                result = AlignmentResult.from_dict(alignment["result"])
                R = result.rotation_matrix
                t = result.translation_vector
            
            # Parse calibration results
            left_result = CalibrationResult.from_dict(left_calibration["result"])
            right_result = CalibrationResult.from_dict(right_calibration["result"])
            
            # Rectify images
            rectified = self.rectify_stereo_images(left_image, right_image, left_camera_id, right_camera_id)
            if not rectified:
                return None
            
            left_rectified, right_rectified = rectified
            
            # Convert to grayscale
            if len(left_rectified.shape) == 3:
                left_gray = cv2.cvtColor(left_rectified, cv2.COLOR_BGR2GRAY)
            else:
                left_gray = left_rectified
            
            if len(right_rectified.shape) == 3:
                right_gray = cv2.cvtColor(right_rectified, cv2.COLOR_BGR2GRAY)
            else:
                right_gray = right_rectified
            
            # Compute disparity map
            stereo = cv2.StereoSGBM_create(
                minDisparity=0,
                numDisparities=128,
                blockSize=5,
                P1=8 * 3 * 5**2,
                P2=32 * 3 * 5**2,
                disp12MaxDiff=1,
                uniquenessRatio=15,
                speckleWindowSize=100,
                speckleRange=32
            )
            
            disparity = stereo.compute(left_gray, right_gray).astype(np.float32) / 16.0
            
            # Compute rectification transforms
            R1, R2, P1, P2, Q, _, _ = cv2.stereoRectify(
                left_result.camera_matrix,
                left_result.distortion_coefficients,
                right_result.camera_matrix,
                right_result.distortion_coefficients,
                left_result.image_size,
                R,
                t
            )
            
            # Compute depth map
            points = cv2.reprojectImageTo3D(disparity, Q)
            depth = points[:, :, 2]
            
            # Filter invalid values
            mask = disparity > disparity.min()
            depth = depth * mask
            
            # Normalize depth map
            depth = cv2.normalize(depth, None, alpha=0, beta=255, norm_type=cv2.NORM_MINMAX, dtype=cv2.CV_8U)
            
            return depth
        except Exception as e:
            logger.error(f"Error computing depth map: {e}")
            return None


# Example usage
if __name__ == "__main__":
    # Setup logging
    logging.basicConfig(level=logging.INFO)
    
    # Create camera calibrator
    calibrator = CameraCalibrator(
        db_path="data/database/sandwich_inspection.db",
        output_dir="data/calibration"
    )
    
    # Start calibration and alignment workers
    calibrator.start_calibration_worker()
    calibrator.start_alignment_worker()
    
    # Create calibration configuration
    config = CalibrationConfig(
        camera_id="camera1",
        chessboard_size=(9, 6),
        square_size=25.0,
        frame_count=20
    )
    
    # Queue calibration (example with dummy frames)
    dummy_frames = [np.zeros((480, 640, 3), dtype=np.uint8) for _ in range(20)]
    calibration_id = calibrator.queue_calibration(config, dummy_frames)
    print(f"Queued calibration: {calibration_id}")
    
    # Wait for calibration to complete
    time.sleep(5)
    
    # Get calibration status
    status = calibrator.get_calibration_status(calibration_id)
    print(f"Calibration status: {status}")
    
    # Stop calibration and alignment workers
    calibrator.stop_calibration_worker()
    calibrator.stop_alignment_worker()
