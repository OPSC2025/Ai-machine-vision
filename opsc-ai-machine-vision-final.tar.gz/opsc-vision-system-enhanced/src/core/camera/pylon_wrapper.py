"""
Pylon SDK wrapper for OPSC Sandwich Quality Inspection System.
Provides a Python interface to the Basler Pylon SDK for camera control.

Version: 1.0.0
Last Updated: 2025-04-20
"""

import os
import sys
import time
import threading
import queue
from typing import Dict, List, Optional, Tuple, Union, Any, Callable, Generator
import logging
import numpy as np
from dataclasses import dataclass
from enum import Enum
import ctypes
from pathlib import Path

try:
    import pypylon
    from pypylon import pylon
    from pypylon import genicam
except ImportError:
    raise ImportError(
        "Failed to import pypylon. Please ensure Pylon SDK 7.4.0 is installed "
        "and pypylon is properly configured. See installation instructions in "
        "the documentation."
    )

from ...utils.config import get_config
from ...utils.logging import setup_logging, log_exception

# Setup logging
logger = setup_logging(__name__)


class CameraError(Exception):
    """Base exception for camera-related errors."""
    pass


class CameraConnectionError(CameraError):
    """Exception raised when a camera connection fails."""
    pass


class CameraConfigurationError(CameraError):
    """Exception raised when camera configuration fails."""
    pass


class CameraAcquisitionError(CameraError):
    """Exception raised when image acquisition fails."""
    pass


class CameraNotFoundError(CameraError):
    """Exception raised when a camera is not found."""
    pass


class CameraState(Enum):
    """Camera state enumeration."""
    DISCONNECTED = 0
    CONNECTED = 1
    CONFIGURED = 2
    ACQUIRING = 3
    ERROR = 4


@dataclass
class CameraInfo:
    """Camera information."""
    serial_number: str
    model: str
    vendor: str
    user_id: Optional[str] = None
    ip_address: Optional[str] = None
    mac_address: Optional[str] = None
    firmware_version: Optional[str] = None
    device_version: Optional[str] = None
    friendly_name: Optional[str] = None


@dataclass
class CameraImage:
    """Camera image with metadata."""
    image: np.ndarray
    timestamp: float
    frame_id: int
    camera_id: str
    width: int
    height: int
    pixel_format: str
    exposure_time: float
    gain: float
    metadata: Dict[str, Any] = None


class PylonWrapper:
    """
    Wrapper for the Basler Pylon SDK.
    Provides a simplified interface for camera discovery, configuration, and image acquisition.
    """

    def __init__(self):
        """Initialize the Pylon wrapper."""
        # Check Pylon SDK version
        self._check_pylon_version()
        
        # Initialize Pylon runtime
        pylon.PylonInitialize()
        
        # Register cleanup on exit
        import atexit
        atexit.register(self._cleanup)
    
    def _check_pylon_version(self) -> None:
        """
        Check if the installed Pylon SDK version is compatible.
        
        Raises:
            CameraError: If the Pylon SDK version is incompatible.
        """
        required_version = get_config("cameras.global.sdk_version", "7.4.0")
        
        try:
            version = pypylon.version.version
            logger.info(f"Pylon SDK version: {version}")
            
            # Parse version strings
            required_parts = [int(x) for x in required_version.split('.')]
            actual_parts = [int(x) for x in version.split('.')]
            
            # Compare major and minor versions
            if actual_parts[0] < required_parts[0] or (
                actual_parts[0] == required_parts[0] and actual_parts[1] < required_parts[1]
            ):
                logger.error(f"Incompatible Pylon SDK version: {version}, required: {required_version}")
                raise CameraError(f"Incompatible Pylon SDK version: {version}, required: {required_version}")
        except Exception as e:
            if not isinstance(e, CameraError):
                logger.error(f"Failed to check Pylon SDK version: {e}")
                raise CameraError(f"Failed to check Pylon SDK version: {e}")
            raise
    
    def _cleanup(self) -> None:
        """Clean up Pylon resources."""
        try:
            pylon.PylonTerminate()
            logger.info("Pylon resources released")
        except Exception as e:
            logger.error(f"Error cleaning up Pylon resources: {e}")
    
    def get_device_info_list(self) -> List[CameraInfo]:
        """
        Get information about all available cameras.
        
        Returns:
            List of camera information.
        """
        try:
            # Create device info list
            device_info_list = []
            
            # Get all devices
            tl_factory = pylon.TlFactory.GetInstance()
            devices = tl_factory.EnumerateDevices()
            
            if len(devices) == 0:
                logger.warning("No cameras found")
                return []
            
            # Get information for each device
            for device_info in devices:
                try:
                    # Extract basic information
                    serial_number = device_info.GetSerialNumber()
                    model = device_info.GetModelName()
                    vendor = device_info.GetVendorName()
                    
                    # Extract additional information if available
                    user_id = None
                    ip_address = None
                    mac_address = None
                    firmware_version = None
                    device_version = None
                    friendly_name = None
                    
                    try:
                        user_id = device_info.GetUserDefinedName()
                    except (AttributeError, genicam.GenericException):
                        pass
                    
                    try:
                        ip_address = device_info.GetIpAddress()
                    except (AttributeError, genicam.GenericException):
                        pass
                    
                    try:
                        mac_address = device_info.GetMacAddress()
                    except (AttributeError, genicam.GenericException):
                        pass
                    
                    try:
                        firmware_version = device_info.GetDeviceVersion()
                    except (AttributeError, genicam.GenericException):
                        pass
                    
                    try:
                        device_version = device_info.GetDeviceVersion()
                    except (AttributeError, genicam.GenericException):
                        pass
                    
                    try:
                        friendly_name = device_info.GetFriendlyName()
                    except (AttributeError, genicam.GenericException):
                        pass
                    
                    # Create camera info
                    camera_info = CameraInfo(
                        serial_number=serial_number,
                        model=model,
                        vendor=vendor,
                        user_id=user_id,
                        ip_address=ip_address,
                        mac_address=mac_address,
                        firmware_version=firmware_version,
                        device_version=device_version,
                        friendly_name=friendly_name
                    )
                    
                    device_info_list.append(camera_info)
                except Exception as e:
                    logger.error(f"Error getting information for camera: {e}")
            
            return device_info_list
        except Exception as e:
            logger.error(f"Error enumerating camera devices: {e}")
            raise CameraError(f"Error enumerating camera devices: {e}")
    
    def create_device(
        self,
        serial_number: Optional[str] = None,
        ip_address: Optional[str] = None,
        user_id: Optional[str] = None
    ) -> pylon.InstantCamera:
        """
        Create a camera device instance.
        
        Args:
            serial_number: Serial number of the camera to connect to.
            ip_address: IP address of the camera to connect to.
            user_id: User-defined name of the camera to connect to.
            
        Returns:
            Camera device instance.
            
        Raises:
            CameraNotFoundError: If the camera is not found.
            CameraConnectionError: If the camera connection fails.
        """
        try:
            # Get all devices
            tl_factory = pylon.TlFactory.GetInstance()
            devices = tl_factory.EnumerateDevices()
            
            if len(devices) == 0:
                logger.error("No cameras found")
                raise CameraNotFoundError("No cameras found")
            
            # Find the requested device
            device_info = None
            
            if serial_number is not None:
                for info in devices:
                    if info.GetSerialNumber() == serial_number:
                        device_info = info
                        break
                
                if device_info is None:
                    logger.error(f"Camera with serial number {serial_number} not found")
                    raise CameraNotFoundError(f"Camera with serial number {serial_number} not found")
            
            elif ip_address is not None:
                for info in devices:
                    try:
                        if info.GetIpAddress() == ip_address:
                            device_info = info
                            break
                    except (AttributeError, genicam.GenericException):
                        pass
                
                if device_info is None:
                    logger.error(f"Camera with IP address {ip_address} not found")
                    raise CameraNotFoundError(f"Camera with IP address {ip_address} not found")
            
            elif user_id is not None:
                for info in devices:
                    try:
                        if info.GetUserDefinedName() == user_id:
                            device_info = info
                            break
                    except (AttributeError, genicam.GenericException):
                        pass
                
                if device_info is None:
                    logger.error(f"Camera with user ID {user_id} not found")
                    raise CameraNotFoundError(f"Camera with user ID {user_id} not found")
            
            else:
                # Use the first device if no specific device is requested
                device_info = devices[0]
                logger.info(f"Using first available camera: {device_info.GetSerialNumber()}")
            
            # Create camera instance
            camera = pylon.InstantCamera(tl_factory.CreateDevice(device_info))
            
            return camera
        except CameraNotFoundError:
            raise
        except Exception as e:
            logger.error(f"Error creating camera device: {e}")
            raise CameraConnectionError(f"Error creating camera device: {e}")
    
    def open_camera(self, camera: pylon.InstantCamera) -> None:
        """
        Open a camera connection.
        
        Args:
            camera: Camera device instance.
            
        Raises:
            CameraConnectionError: If the camera connection fails.
        """
        try:
            # Open camera
            camera.Open()
            
            # Log camera information
            serial_number = camera.GetDeviceInfo().GetSerialNumber()
            model = camera.GetDeviceInfo().GetModelName()
            vendor = camera.GetDeviceInfo().GetVendorName()
            
            logger.info(f"Connected to camera: {serial_number} ({model} by {vendor})")
        except Exception as e:
            logger.error(f"Error opening camera: {e}")
            raise CameraConnectionError(f"Error opening camera: {e}")
    
    def close_camera(self, camera: pylon.InstantCamera) -> None:
        """
        Close a camera connection.
        
        Args:
            camera: Camera device instance.
        """
        try:
            # Stop acquisition if running
            if camera.IsGrabbing():
                camera.StopGrabbing()
            
            # Close camera
            camera.Close()
            
            logger.info(f"Closed camera: {camera.GetDeviceInfo().GetSerialNumber()}")
        except Exception as e:
            logger.error(f"Error closing camera: {e}")
    
    def configure_camera(
        self,
        camera: pylon.InstantCamera,
        config: Dict[str, Any]
    ) -> None:
        """
        Configure camera parameters.
        
        Args:
            camera: Camera device instance.
            config: Camera configuration parameters.
            
        Raises:
            CameraConfigurationError: If the camera configuration fails.
        """
        try:
            # Ensure camera is open
            if not camera.IsOpen():
                self.open_camera(camera)
            
            # Get node map
            nodemap = camera.GetNodeMap()
            
            # Configure parameters
            for key, value in config.items():
                try:
                    # Handle special cases
                    if key == "PixelFormat":
                        # Convert string format to enum value
                        pixel_format_node = genicam.CEnumerationPtr(nodemap.GetNode("PixelFormat"))
                        pixel_format_value = pixel_format_node.GetEntryByName(value)
                        if pixel_format_value is not None:
                            pixel_format_node.SetIntValue(pixel_format_value.GetValue())
                        else:
                            logger.warning(f"Invalid pixel format: {value}")
                    
                    elif key == "TriggerMode":
                        # Convert string mode to enum value
                        trigger_mode_node = genicam.CEnumerationPtr(nodemap.GetNode("TriggerMode"))
                        trigger_mode_value = trigger_mode_node.GetEntryByName(value)
                        if trigger_mode_value is not None:
                            trigger_mode_node.SetIntValue(trigger_mode_value.GetValue())
                        else:
                            logger.warning(f"Invalid trigger mode: {value}")
                    
                    elif key == "TriggerSource":
                        # Configure trigger source if trigger mode is enabled
                        trigger_mode_node = genicam.CEnumerationPtr(nodemap.GetNode("TriggerMode"))
                        trigger_mode_value = trigger_mode_node.GetEntryByName("On")
                        if trigger_mode_value is not None and trigger_mode_node.GetIntValue() == trigger_mode_value.GetValue():
                            trigger_source_node = genicam.CEnumerationPtr(nodemap.GetNode("TriggerSource"))
                            trigger_source_value = trigger_source_node.GetEntryByName(value)
                            if trigger_source_value is not None:
                                trigger_source_node.SetIntValue(trigger_source_value.GetValue())
                            else:
                                logger.warning(f"Invalid trigger source: {value}")
                    
                    elif key == "ExposureAuto":
                        # Configure exposure auto mode
                        exposure_auto_node = genicam.CEnumerationPtr(nodemap.GetNode("ExposureAuto"))
                        exposure_auto_value = exposure_auto_node.GetEntryByName(value)
                        if exposure_auto_value is not None:
                            exposure_auto_node.SetIntValue(exposure_auto_value.GetValue())
                        else:
                            logger.warning(f"Invalid exposure auto mode: {value}")
                    
                    elif key == "GainAuto":
                        # Configure gain auto mode
                        gain_auto_node = genicam.CEnumerationPtr(nodemap.GetNode("GainAuto"))
                        gain_auto_value = gain_auto_node.GetEntryByName(value)
                        if gain_auto_value is not None:
                            gain_auto_node.SetIntValue(gain_auto_value.GetValue())
                        else:
                            logger.warning(f"Invalid gain auto mode: {value}")
                    
                    elif key == "BalanceWhiteAuto":
                        # Configure white balance auto mode
                        balance_white_auto_node = genicam.CEnumerationPtr(nodemap.GetNode("BalanceWhiteAuto"))
                        balance_white_auto_value = balance_white_auto_node.GetEntryByName(value)
                        if balance_white_auto_value is not None:
                            balance_white_auto_node.SetIntValue(balance_white_auto_value.GetValue())
                        else:
                            logger.warning(f"Invalid white balance auto mode: {value}")
                    
                    elif key == "ExposureTime":
                        # Set exposure time in microseconds
                        exposure_time_node = genicam.CFloatPtr(nodemap.GetNode("ExposureTime"))
                        exposure_time_node.SetValue(float(value))
                    
                    elif key == "Gain":
                        # Set gain in dB
                        gain_node = genicam.CFloatPtr(nodemap.GetNode("Gain"))
                        gain_node.SetValue(float(value))
                    
                    elif key == "AcquisitionFrameRate":
                        # Enable frame rate control
                        acquisition_frame_rate_enable_node = genicam.CBooleanPtr(nodemap.GetNode("AcquisitionFrameRateEnable"))
                        acquisition_frame_rate_enable_node.SetValue(True)
                        
                        # Set frame rate
                        acquisition_frame_rate_node = genicam.CFloatPtr(nodemap.GetNode("AcquisitionFrameRate"))
                        acquisition_frame_rate_node.SetValue(float(value))
                    
                    elif key == "Width":
                        # Set width
                        width_node = genicam.CIntegerPtr(nodemap.GetNode("Width"))
                        width_node.SetValue(int(value))
                    
                    elif key == "Height":
                        # Set height
                        height_node = genicam.CIntegerPtr(nodemap.GetNode("Height"))
                        height_node.SetValue(int(value))
                    
                    elif key == "OffsetX":
                        # Set X offset
                        offset_x_node = genicam.CIntegerPtr(nodemap.GetNode("OffsetX"))
                        offset_x_node.SetValue(int(value))
                    
                    elif key == "OffsetY":
                        # Set Y offset
                        offset_y_node = genicam.CIntegerPtr(nodemap.GetNode("OffsetY"))
                        offset_y_node.SetValue(int(value))
                    
                    elif key == "ReverseX":
                        # Set X reverse
                        reverse_x_node = genicam.CBooleanPtr(nodemap.GetNode("ReverseX"))
                        reverse_x_node.SetValue(bool(value))
                    
                    elif key == "ReverseY":
                        # Set Y reverse
                        reverse_y_node = genicam.CBooleanPtr(nodemap.GetNode("ReverseY"))
                        reverse_y_node.SetValue(bool(value))
                    
                    else:
                        # Try to set the parameter directly
                        node = nodemap.GetNode(key)
                        if node is not None and genicam.IsWritable(node):
                            if isinstance(value, bool):
                                boolean_node = genicam.CBooleanPtr(node)
                                boolean_node.SetValue(value)
                            elif isinstance(value, int):
                                integer_node = genicam.CIntegerPtr(node)
                                integer_node.SetValue(value)
                            elif isinstance(value, float):
                                float_node = genicam.CFloatPtr(node)
                                float_node.SetValue(value)
                            elif isinstance(value, str):
                                # Try as enum first
                                try:
                                    enum_node = genicam.CEnumerationPtr(node)
                                    enum_value = enum_node.GetEntryByName(value)
                                    if enum_value is not None:
                                        enum_node.SetIntValue(enum_value.GetValue())
                                except (TypeError, genicam.GenericException):
                                    # Try as string
                                    string_node = genicam.CStringPtr(node)
                                    string_node.SetValue(value)
                            else:
                                logger.warning(f"Unsupported value type for parameter {key}: {type(value)}")
                        else:
                            logger.warning(f"Parameter not found or not writable: {key}")
                except Exception as e:
                    logger.error(f"Error setting parameter {key} to {value}: {e}")
            
            logger.info(f"Configured camera: {camera.GetDeviceInfo().GetSerialNumber()}")
        except Exception as e:
            logger.error(f"Error configuring camera: {e}")
            raise CameraConfigurationError(f"Error configuring camera: {e}")
    
    def get_camera_parameters(self, camera: pylon.InstantCamera) -> Dict[str, Any]:
        """
        Get current camera parameters.
        
        Args:
            camera: Camera device instance.
            
        Returns:
            Dictionary of camera parameters.
        """
        try:
            # Ensure camera is open
            if not camera.IsOpen():
                self.open_camera(camera)
            
            # Get node map
            nodemap = camera.GetNodeMap()
            
            # Get common parameters
            parameters = {}
            
            # Get pixel format
            try:
                pixel_format_node = genicam.CEnumerationPtr(nodemap.GetNode("PixelFormat"))
                pixel_format_entry = pixel_format_node.GetCurrentEntry()
                parameters["PixelFormat"] = pixel_format_entry.GetSymbolic()
            except (AttributeError, genicam.GenericException) as e:
                logger.warning(f"Error getting pixel format: {e}")
            
            # Get trigger mode
            try:
                trigger_mode_node = genicam.CEnumerationPtr(nodemap.GetNode("TriggerMode"))
                trigger_mode_entry = trigger_mode_node.GetCurrentEntry()
                parameters["TriggerMode"] = trigger_mode_entry.GetSymbolic()
            except (AttributeError, genicam.GenericException) as e:
                logger.warning(f"Error getting trigger mode: {e}")
            
            # Get trigger source if trigger mode is enabled
            try:
                trigger_mode_node = genicam.CEnumerationPtr(nodemap.GetNode("TriggerMode"))
                trigger_mode_entry = trigger_mode_node.GetCurrentEntry()
                if trigger_mode_entry.GetSymbolic() == "On":
                    trigger_source_node = genicam.CEnumerationPtr(nodemap.GetNode("TriggerSource"))
                    trigger_source_entry = trigger_source_node.GetCurrentEntry()
                    parameters["TriggerSource"] = trigger_source_entry.GetSymbolic()
            except (AttributeError, genicam.GenericException) as e:
                logger.warning(f"Error getting trigger source: {e}")
            
            # Get exposure auto mode
            try:
                exposure_auto_node = genicam.CEnumerationPtr(nodemap.GetNode("ExposureAuto"))
                exposure_auto_entry = exposure_auto_node.GetCurrentEntry()
                parameters["ExposureAuto"] = exposure_auto_entry.GetSymbolic()
            except (AttributeError, genicam.GenericException) as e:
                logger.warning(f"Error getting exposure auto mode: {e}")
            
            # Get gain auto mode
            try:
                gain_auto_node = genicam.CEnumerationPtr(nodemap.GetNode("GainAuto"))
                gain_auto_entry = gain_auto_node.GetCurrentEntry()
                parameters["GainAuto"] = gain_auto_entry.GetSymbolic()
            except (AttributeError, genicam.GenericException) as e:
                logger.warning(f"Error getting gain auto mode: {e}")
            
            # Get white balance auto mode
            try:
                balance_white_auto_node = genicam.CEnumerationPtr(nodemap.GetNode("BalanceWhiteAuto"))
                balance_white_auto_entry = balance_white_auto_node.GetCurrentEntry()
                parameters["BalanceWhiteAuto"] = balance_white_auto_entry.GetSymbolic()
            except (AttributeError, genicam.GenericException) as e:
                logger.warning(f"Error getting white balance auto mode: {e}")
            
            # Get exposure time
            try:
                exposure_time_node = genicam.CFloatPtr(nodemap.GetNode("ExposureTime"))
                parameters["ExposureTime"] = exposure_time_node.GetValue()
            except (AttributeError, genicam.GenericException) as e:
                logger.warning(f"Error getting exposure time: {e}")
            
            # Get gain
            try:
                gain_node = genicam.CFloatPtr(nodemap.GetNode("Gain"))
                parameters["Gain"] = gain_node.GetValue()
            except (AttributeError, genicam.GenericException) as e:
                logger.warning(f"Error getting gain: {e}")
            
            # Get frame rate
            try:
                acquisition_frame_rate_node = genicam.CFloatPtr(nodemap.GetNode("AcquisitionFrameRate"))
                parameters["AcquisitionFrameRate"] = acquisition_frame_rate_node.GetValue()
            except (AttributeError, genicam.GenericException) as e:
                logger.warning(f"Error getting acquisition frame rate: {e}")
            
            # Get width
            try:
                width_node = genicam.CIntegerPtr(nodemap.GetNode("Width"))
                parameters["Width"] = width_node.GetValue()
            except (AttributeError, genicam.GenericException) as e:
                logger.warning(f"Error getting width: {e}")
            
            # Get height
            try:
                height_node = genicam.CIntegerPtr(nodemap.GetNode("Height"))
                parameters["Height"] = height_node.GetValue()
            except (AttributeError, genicam.GenericException) as e:
                logger.warning(f"Error getting height: {e}")
            
            # Get X offset
            try:
                offset_x_node = genicam.CIntegerPtr(nodemap.GetNode("OffsetX"))
                parameters["OffsetX"] = offset_x_node.GetValue()
            except (AttributeError, genicam.GenericException) as e:
                logger.warning(f"Error getting X offset: {e}")
            
            # Get Y offset
            try:
                offset_y_node = genicam.CIntegerPtr(nodemap.GetNode("OffsetY"))
                parameters["OffsetY"] = offset_y_node.GetValue()
            except (AttributeError, genicam.GenericException) as e:
                logger.warning(f"Error getting Y offset: {e}")
            
            # Get X reverse
            try:
                reverse_x_node = genicam.CBooleanPtr(nodemap.GetNode("ReverseX"))
                parameters["ReverseX"] = reverse_x_node.GetValue()
            except (AttributeError, genicam.GenericException) as e:
                logger.warning(f"Error getting X reverse: {e}")
            
            # Get Y reverse
            try:
                reverse_y_node = genicam.CBooleanPtr(nodemap.GetNode("ReverseY"))
                parameters["ReverseY"] = reverse_y_node.GetValue()
            except (AttributeError, genicam.GenericException) as e:
                logger.warning(f"Error getting Y reverse: {e}")
            
            return parameters
        except Exception as e:
            logger.error(f"Error getting camera parameters: {e}")
            raise CameraError(f"Error getting camera parameters: {e}")
    
    def start_grabbing(
        self,
        camera: pylon.InstantCamera,
        strategy: pylon.GrabStrategy = pylon.GrabStrategy_LatestImageOnly,
        max_buffer: int = 10
    ) -> None:
        """
        Start image acquisition.
        
        Args:
            camera: Camera device instance.
            strategy: Grab strategy.
            max_buffer: Maximum number of buffers.
            
        Raises:
            CameraAcquisitionError: If image acquisition fails to start.
        """
        try:
            # Ensure camera is open
            if not camera.IsOpen():
                self.open_camera(camera)
            
            # Start grabbing
            camera.StartGrabbing(strategy, pylon.GrabLoop_ProvidedByUser)
            
            logger.info(f"Started image acquisition on camera: {camera.GetDeviceInfo().GetSerialNumber()}")
        except Exception as e:
            logger.error(f"Error starting image acquisition: {e}")
            raise CameraAcquisitionError(f"Error starting image acquisition: {e}")
    
    def stop_grabbing(self, camera: pylon.InstantCamera) -> None:
        """
        Stop image acquisition.
        
        Args:
            camera: Camera device instance.
        """
        try:
            # Stop grabbing if running
            if camera.IsGrabbing():
                camera.StopGrabbing()
                
                logger.info(f"Stopped image acquisition on camera: {camera.GetDeviceInfo().GetSerialNumber()}")
        except Exception as e:
            logger.error(f"Error stopping image acquisition: {e}")
    
    def grab_image(
        self,
        camera: pylon.InstantCamera,
        timeout: int = 5000
    ) -> Optional[CameraImage]:
        """
        Grab a single image from the camera.
        
        Args:
            camera: Camera device instance.
            timeout: Timeout in milliseconds.
            
        Returns:
            Camera image with metadata, or None if no image was grabbed.
            
        Raises:
            CameraAcquisitionError: If image acquisition fails.
        """
        try:
            # Ensure camera is grabbing
            if not camera.IsGrabbing():
                self.start_grabbing(camera)
            
            # Grab image
            grab_result = camera.RetrieveResult(timeout, pylon.TimeoutHandling_ThrowException)
            
            # Check if grab was successful
            if grab_result.GrabSucceeded():
                # Get image data
                image = self._convert_grab_result_to_image(grab_result, camera)
                
                # Release grab result
                grab_result.Release()
                
                return image
            else:
                # Log error
                logger.error(f"Error grabbing image: {grab_result.GetErrorDescription()}")
                
                # Release grab result
                grab_result.Release()
                
                return None
        except genicam.GenericException as e:
            logger.error(f"Error grabbing image: {e}")
            raise CameraAcquisitionError(f"Error grabbing image: {e}")
    
    def grab_images(
        self,
        camera: pylon.InstantCamera,
        count: int,
        timeout: int = 5000
    ) -> List[CameraImage]:
        """
        Grab multiple images from the camera.
        
        Args:
            camera: Camera device instance.
            count: Number of images to grab.
            timeout: Timeout in milliseconds per image.
            
        Returns:
            List of camera images with metadata.
            
        Raises:
            CameraAcquisitionError: If image acquisition fails.
        """
        try:
            # Ensure camera is grabbing
            if not camera.IsGrabbing():
                self.start_grabbing(camera)
            
            # Grab images
            images = []
            
            for i in range(count):
                # Grab image
                grab_result = camera.RetrieveResult(timeout, pylon.TimeoutHandling_ThrowException)
                
                # Check if grab was successful
                if grab_result.GrabSucceeded():
                    # Get image data
                    image = self._convert_grab_result_to_image(grab_result, camera)
                    
                    # Add to list
                    images.append(image)
                else:
                    # Log error
                    logger.error(f"Error grabbing image {i+1}/{count}: {grab_result.GetErrorDescription()}")
                
                # Release grab result
                grab_result.Release()
            
            return images
        except genicam.GenericException as e:
            logger.error(f"Error grabbing images: {e}")
            raise CameraAcquisitionError(f"Error grabbing images: {e}")
    
    def grab_images_async(
        self,
        camera: pylon.InstantCamera,
        callback: Callable[[CameraImage], None],
        timeout: int = 5000,
        max_queue_size: int = 10
    ) -> threading.Thread:
        """
        Grab images asynchronously from the camera.
        
        Args:
            camera: Camera device instance.
            callback: Callback function to call for each image.
            timeout: Timeout in milliseconds per image.
            max_queue_size: Maximum size of the image queue.
            
        Returns:
            Thread object for the grabbing thread.
            
        Raises:
            CameraAcquisitionError: If image acquisition fails to start.
        """
        try:
            # Ensure camera is grabbing
            if not camera.IsGrabbing():
                self.start_grabbing(camera)
            
            # Create image queue
            image_queue = queue.Queue(maxsize=max_queue_size)
            
            # Create stop event
            stop_event = threading.Event()
            
            # Create grabbing thread
            def grabbing_thread():
                try:
                    while not stop_event.is_set() and camera.IsGrabbing():
                        try:
                            # Grab image
                            grab_result = camera.RetrieveResult(timeout, pylon.TimeoutHandling_Return)
                            
                            # Check if grab was successful
                            if grab_result is not None and grab_result.GrabSucceeded():
                                # Get image data
                                image = self._convert_grab_result_to_image(grab_result, camera)
                                
                                # Add to queue
                                try:
                                    image_queue.put(image, block=False)
                                except queue.Full:
                                    # Queue is full, discard oldest image
                                    try:
                                        image_queue.get(block=False)
                                        image_queue.put(image, block=False)
                                    except queue.Empty:
                                        # Queue was emptied by consumer thread
                                        image_queue.put(image, block=False)
                            
                            # Release grab result
                            if grab_result is not None:
                                grab_result.Release()
                        except Exception as e:
                            logger.error(f"Error in grabbing thread: {e}")
                except Exception as e:
                    logger.error(f"Error in grabbing thread: {e}")
                finally:
                    # Stop grabbing
                    try:
                        if camera.IsGrabbing():
                            camera.StopGrabbing()
                    except Exception as e:
                        logger.error(f"Error stopping grabbing: {e}")
            
            # Create consumer thread
            def consumer_thread():
                try:
                    while not stop_event.is_set() or not image_queue.empty():
                        try:
                            # Get image from queue
                            image = image_queue.get(block=True, timeout=0.1)
                            
                            # Call callback
                            callback(image)
                            
                            # Mark task as done
                            image_queue.task_done()
                        except queue.Empty:
                            # Queue is empty, continue waiting
                            pass
                except Exception as e:
                    logger.error(f"Error in consumer thread: {e}")
            
            # Start threads
            grabbing_thread_obj = threading.Thread(target=grabbing_thread)
            grabbing_thread_obj.daemon = True
            grabbing_thread_obj.start()
            
            consumer_thread_obj = threading.Thread(target=consumer_thread)
            consumer_thread_obj.daemon = True
            consumer_thread_obj.start()
            
            # Store stop event in thread object for later use
            grabbing_thread_obj.stop_event = stop_event
            
            return grabbing_thread_obj
        except Exception as e:
            logger.error(f"Error starting asynchronous image acquisition: {e}")
            raise CameraAcquisitionError(f"Error starting asynchronous image acquisition: {e}")
    
    def stop_grabbing_async(self, thread: threading.Thread) -> None:
        """
        Stop asynchronous image acquisition.
        
        Args:
            thread: Thread object returned by grab_images_async.
        """
        try:
            # Set stop event
            thread.stop_event.set()
            
            # Wait for thread to finish
            thread.join(timeout=5.0)
            
            logger.info("Stopped asynchronous image acquisition")
        except Exception as e:
            logger.error(f"Error stopping asynchronous image acquisition: {e}")
    
    def execute_software_trigger(self, camera: pylon.InstantCamera) -> None:
        """
        Execute a software trigger.
        
        Args:
            camera: Camera device instance.
            
        Raises:
            CameraError: If the trigger execution fails.
        """
        try:
            # Ensure camera is open
            if not camera.IsOpen():
                self.open_camera(camera)
            
            # Get node map
            nodemap = camera.GetNodeMap()
            
            # Check if trigger mode is enabled
            trigger_mode_node = genicam.CEnumerationPtr(nodemap.GetNode("TriggerMode"))
            trigger_mode_entry = trigger_mode_node.GetCurrentEntry()
            
            if trigger_mode_entry.GetSymbolic() != "On":
                logger.warning("Trigger mode is not enabled")
                return
            
            # Check if trigger source is set to software
            trigger_source_node = genicam.CEnumerationPtr(nodemap.GetNode("TriggerSource"))
            trigger_source_entry = trigger_source_node.GetCurrentEntry()
            
            if trigger_source_entry.GetSymbolic() != "Software":
                logger.warning(f"Trigger source is not set to Software: {trigger_source_entry.GetSymbolic()}")
                return
            
            # Execute software trigger
            trigger_software_node = genicam.CCommandPtr(nodemap.GetNode("TriggerSoftware"))
            trigger_software_node.Execute()
            
            logger.debug("Executed software trigger")
        except Exception as e:
            logger.error(f"Error executing software trigger: {e}")
            raise CameraError(f"Error executing software trigger: {e}")
    
    def save_image(self, image: CameraImage, file_path: str, format: str = "png") -> None:
        """
        Save an image to a file.
        
        Args:
            image: Camera image.
            file_path: Path to save the image to.
            format: Image format (png, jpg, tiff).
            
        Raises:
            IOError: If the image cannot be saved.
        """
        try:
            # Import OpenCV
            import cv2
            
            # Convert image to BGR for OpenCV
            if len(image.image.shape) == 3 and image.image.shape[2] == 3:
                # RGB to BGR
                bgr_image = cv2.cvtColor(image.image, cv2.COLOR_RGB2BGR)
            else:
                # Grayscale or other format
                bgr_image = image.image
            
            # Save image
            cv2.imwrite(file_path, bgr_image)
            
            logger.info(f"Saved image to {file_path}")
        except Exception as e:
            logger.error(f"Error saving image to {file_path}: {e}")
            raise IOError(f"Error saving image to {file_path}: {e}")
    
    def _convert_grab_result_to_image(
        self,
        grab_result: pylon.GrabResult,
        camera: pylon.InstantCamera
    ) -> CameraImage:
        """
        Convert a grab result to a camera image.
        
        Args:
            grab_result: Grab result from the camera.
            camera: Camera device instance.
            
        Returns:
            Camera image with metadata.
        """
        # Get image data
        pixel_type = grab_result.GetPixelType()
        width = grab_result.GetWidth()
        height = grab_result.GetHeight()
        
        # Get image format
        if pixel_type == pylon.PixelType_Mono8:
            # Mono8 format
            image_data = grab_result.GetArray()
            image_array = np.array(image_data, dtype=np.uint8).reshape(height, width)
            pixel_format = "Mono8"
        elif pixel_type == pylon.PixelType_RGB8packed:
            # RGB8 format
            image_data = grab_result.GetArray()
            image_array = np.array(image_data, dtype=np.uint8).reshape(height, width, 3)
            pixel_format = "RGB8"
        elif pixel_type == pylon.PixelType_BGR8packed:
            # BGR8 format
            image_data = grab_result.GetArray()
            image_array = np.array(image_data, dtype=np.uint8).reshape(height, width, 3)
            # Convert BGR to RGB
            image_array = image_array[:, :, ::-1]
            pixel_format = "RGB8"
        else:
            # Unsupported format, convert to mono8
            converter = pylon.ImageFormatConverter()
            converter.OutputPixelFormat = pylon.PixelType_Mono8
            converted_grab_result = converter.Convert(grab_result)
            image_data = converted_grab_result.GetArray()
            image_array = np.array(image_data, dtype=np.uint8).reshape(height, width)
            pixel_format = "Mono8"
        
        # Get metadata
        timestamp = grab_result.GetTimeStamp() / 1e9  # Convert to seconds
        frame_id = grab_result.GetID()
        camera_id = camera.GetDeviceInfo().GetSerialNumber()
        
        # Get camera parameters
        nodemap = camera.GetNodeMap()
        
        # Get exposure time
        exposure_time = None
        try:
            exposure_time_node = genicam.CFloatPtr(nodemap.GetNode("ExposureTime"))
            exposure_time = exposure_time_node.GetValue()
        except (AttributeError, genicam.GenericException):
            pass
        
        # Get gain
        gain = None
        try:
            gain_node = genicam.CFloatPtr(nodemap.GetNode("Gain"))
            gain = gain_node.GetValue()
        except (AttributeError, genicam.GenericException):
            pass
        
        # Create camera image
        camera_image = CameraImage(
            image=image_array,
            timestamp=timestamp,
            frame_id=frame_id,
            camera_id=camera_id,
            width=width,
            height=height,
            pixel_format=pixel_format,
            exposure_time=exposure_time,
            gain=gain
        )
        
        return camera_image


# Singleton instance
_pylon_wrapper: Optional[PylonWrapper] = None


def get_pylon_wrapper() -> PylonWrapper:
    """
    Get the singleton PylonWrapper instance.
    
    Returns:
        PylonWrapper instance.
    """
    global _pylon_wrapper
    if _pylon_wrapper is None:
        _pylon_wrapper = PylonWrapper()
    return _pylon_wrapper


if __name__ == "__main__":
    # Setup logging for standalone execution
    logging.basicConfig(level=logging.INFO)
    
    # Example usage
    pylon_wrapper = get_pylon_wrapper()
    
    # Get available cameras
    devices = pylon_wrapper.get_device_info_list()
    logger.info(f"Found {len(devices)} cameras")
    
    for i, device in enumerate(devices):
        logger.info(f"Camera {i+1}: {device.serial_number} ({device.model} by {device.vendor})")
    
    # Connect to first camera
    if devices:
        try:
            # Create camera instance
            camera = pylon_wrapper.create_device(serial_number=devices[0].serial_number)
            
            # Open camera
            pylon_wrapper.open_camera(camera)
            
            # Configure camera
            config = {
                "PixelFormat": "RGB8",
                "ExposureTime": 10000,
                "Gain": 0.0,
                "AcquisitionFrameRate": 20.0
            }
            pylon_wrapper.configure_camera(camera, config)
            
            # Get camera parameters
            parameters = pylon_wrapper.get_camera_parameters(camera)
            logger.info(f"Camera parameters: {parameters}")
            
            # Grab an image
            image = pylon_wrapper.grab_image(camera)
            
            if image:
                logger.info(f"Grabbed image: {image.width}x{image.height} {image.pixel_format}")
                
                # Save image
                pylon_wrapper.save_image(image, "test_image.png")
            
            # Close camera
            pylon_wrapper.close_camera(camera)
        except Exception as e:
            logger.error(f"Error in example: {e}")
    else:
        logger.warning("No cameras found")
