"""
Hardware monitoring module for the OPSC Sandwich Quality Inspection System.

This module provides utilities for monitoring Jetson Xavier NX hardware status,
including CPU usage, GPU usage, memory usage, temperature, and power consumption.

Version: 1.0.0
Last Updated: 2025-04-21
"""

import os
import sys
import time
import logging
import threading
import subprocess
import json
from typing import Dict, List, Optional, Tuple, Union, Any
import numpy as np
from pathlib import Path

# Setup logging
logger = logging.getLogger(__name__)

class JetsonMonitor:
    """
    Monitor for Jetson Xavier NX hardware.
    
    This class provides methods for monitoring hardware status of the Jetson Xavier NX,
    including CPU usage, GPU usage, memory usage, temperature, and power consumption.
    """
    
    def __init__(
        self,
        update_interval: float = 5.0,
        temperature_threshold: float = 85.0,  # Celsius
        gpu_usage_threshold: float = 0.9,     # 90%
        memory_threshold: float = 0.9,        # 90%
        power_threshold: float = 15.0,        # Watts
        log_to_file: bool = True,
        log_dir: str = "data/logs",
        alert_callback: Optional[callable] = None
    ):
        """
        Initialize the Jetson monitor.
        
        Args:
            update_interval: Update interval in seconds
            temperature_threshold: Temperature threshold in Celsius
            gpu_usage_threshold: GPU usage threshold (0.0-1.0)
            memory_threshold: Memory usage threshold (0.0-1.0)
            power_threshold: Power consumption threshold in Watts
            log_to_file: Whether to log hardware status to file
            log_dir: Directory for log files
            alert_callback: Callback function for alerts
        """
        self.update_interval = update_interval
        self.temperature_threshold = temperature_threshold
        self.gpu_usage_threshold = gpu_usage_threshold
        self.memory_threshold = memory_threshold
        self.power_threshold = power_threshold
        self.log_to_file = log_to_file
        self.log_dir = log_dir
        self.alert_callback = alert_callback
        
        # Create log directory if it doesn't exist and logging is enabled
        if self.log_to_file:
            os.makedirs(self.log_dir, exist_ok=True)
        
        # Initialize monitoring thread
        self.monitoring_thread = None
        self.stop_event = threading.Event()
        
        # Initialize hardware status
        self.hardware_status = {
            "timestamp": 0.0,
            "cpu_usage": 0.0,
            "gpu_usage": 0.0,
            "memory_usage": 0.0,
            "temperature": 0.0,
            "power_usage": 0.0,
            "cpu_clock": 0.0,
            "gpu_clock": 0.0
        }
        
        # Initialize status lock
        self.status_lock = threading.Lock()
    
    def start_monitoring(self):
        """Start hardware monitoring."""
        if self.monitoring_thread is not None and self.monitoring_thread.is_alive():
            logger.warning("Monitoring thread is already running")
            return
        
        # Reset stop event
        self.stop_event.clear()
        
        # Create and start monitoring thread
        self.monitoring_thread = threading.Thread(target=self._monitoring_worker, daemon=True)
        self.monitoring_thread.start()
        
        logger.info("Started hardware monitoring")
    
    def stop_monitoring(self):
        """Stop hardware monitoring."""
        if self.monitoring_thread is None or not self.monitoring_thread.is_alive():
            logger.warning("Monitoring thread is not running")
            return
        
        # Set stop event
        self.stop_event.set()
        
        # Wait for thread to stop
        self.monitoring_thread.join(timeout=2.0)
        
        logger.info("Stopped hardware monitoring")
    
    def get_hardware_status(self) -> Dict[str, Any]:
        """
        Get current hardware status.
        
        Returns:
            Hardware status as dictionary
        """
        with self.status_lock:
            return self.hardware_status.copy()
    
    def _monitoring_worker(self):
        """Hardware monitoring worker thread."""
        while not self.stop_event.is_set():
            try:
                # Update hardware status
                self._update_hardware_status()
                
                # Check thresholds and trigger alerts if necessary
                self._check_thresholds()
                
                # Log hardware status if enabled
                if self.log_to_file:
                    self._log_hardware_status()
                
                # Wait for next update
                self.stop_event.wait(self.update_interval)
            except Exception as e:
                logger.error(f"Error in monitoring worker: {e}")
                # Wait a shorter time before retrying
                self.stop_event.wait(1.0)
    
    def _update_hardware_status(self):
        """Update hardware status."""
        try:
            # Get current timestamp
            timestamp = time.time()
            
            # Get CPU usage
            cpu_usage = self._get_cpu_usage()
            
            # Get GPU usage
            gpu_usage = self._get_gpu_usage()
            
            # Get memory usage
            memory_usage = self._get_memory_usage()
            
            # Get temperature
            temperature = self._get_temperature()
            
            # Get power usage
            power_usage = self._get_power_usage()
            
            # Get CPU clock
            cpu_clock = self._get_cpu_clock()
            
            # Get GPU clock
            gpu_clock = self._get_gpu_clock()
            
            # Update hardware status
            with self.status_lock:
                self.hardware_status = {
                    "timestamp": timestamp,
                    "cpu_usage": cpu_usage,
                    "gpu_usage": gpu_usage,
                    "memory_usage": memory_usage,
                    "temperature": temperature,
                    "power_usage": power_usage,
                    "cpu_clock": cpu_clock,
                    "gpu_clock": gpu_clock
                }
            
            logger.debug(f"Updated hardware status: {self.hardware_status}")
        except Exception as e:
            logger.error(f"Error updating hardware status: {e}")
    
    def _check_thresholds(self):
        """Check hardware thresholds and trigger alerts if necessary."""
        try:
            # Get current hardware status
            status = self.get_hardware_status()
            
            # Check temperature threshold
            if status["temperature"] > self.temperature_threshold:
                self._trigger_alert(
                    "temperature",
                    f"Temperature threshold exceeded: {status['temperature']:.1f}°C > {self.temperature_threshold:.1f}°C"
                )
            
            # Check GPU usage threshold
            if status["gpu_usage"] > self.gpu_usage_threshold:
                self._trigger_alert(
                    "gpu_usage",
                    f"GPU usage threshold exceeded: {status['gpu_usage'] * 100:.1f}% > {self.gpu_usage_threshold * 100:.1f}%"
                )
            
            # Check memory usage threshold
            if status["memory_usage"] > self.memory_threshold:
                self._trigger_alert(
                    "memory_usage",
                    f"Memory usage threshold exceeded: {status['memory_usage'] * 100:.1f}% > {self.memory_threshold * 100:.1f}%"
                )
            
            # Check power usage threshold
            if status["power_usage"] > self.power_threshold:
                self._trigger_alert(
                    "power_usage",
                    f"Power usage threshold exceeded: {status['power_usage']:.1f}W > {self.power_threshold:.1f}W"
                )
        except Exception as e:
            logger.error(f"Error checking thresholds: {e}")
    
    def _trigger_alert(self, alert_type: str, message: str):
        """
        Trigger hardware alert.
        
        Args:
            alert_type: Type of alert
            message: Alert message
        """
        try:
            # Log alert
            logger.warning(f"Hardware alert: {message}")
            
            # Call alert callback if provided
            if self.alert_callback is not None:
                self.alert_callback(alert_type, message)
        except Exception as e:
            logger.error(f"Error triggering alert: {e}")
    
    def _log_hardware_status(self):
        """Log hardware status to file."""
        try:
            # Get current hardware status
            status = self.get_hardware_status()
            
            # Get current date for log file name
            date_str = time.strftime("%Y%m%d", time.localtime(status["timestamp"]))
            log_file = os.path.join(self.log_dir, f"hardware_{date_str}.log")
            
            # Format log entry
            log_entry = json.dumps(status)
            
            # Append to log file
            with open(log_file, "a") as f:
                f.write(log_entry + "\n")
        except Exception as e:
            logger.error(f"Error logging hardware status: {e}")
    
    def _get_cpu_usage(self) -> float:
        """
        Get CPU usage.
        
        Returns:
            CPU usage as fraction (0.0-1.0)
        """
        try:
            # Run top command to get CPU usage
            cmd = "top -bn1 | grep 'Cpu(s)' | awk '{print $2 + $4}'"
            output = subprocess.check_output(cmd, shell=True).decode("utf-8").strip()
            
            # Parse output
            cpu_usage = float(output) / 100.0
            
            return cpu_usage
        except Exception as e:
            logger.error(f"Error getting CPU usage: {e}")
            return 0.0
    
    def _get_gpu_usage(self) -> float:
        """
        Get GPU usage.
        
        Returns:
            GPU usage as fraction (0.0-1.0)
        """
        try:
            # Check if tegrastats is available
            if not self._is_jetson():
                return 0.0
            
            # Run tegrastats command to get GPU usage
            cmd = "tegrastats --interval 1000 --count 1 | grep -o 'GR3D_FREQ.*' | awk '{print $2}'"
            output = subprocess.check_output(cmd, shell=True).decode("utf-8").strip()
            
            # Parse output (format: XX%)
            gpu_usage = float(output.replace("%", "")) / 100.0
            
            return gpu_usage
        except Exception as e:
            logger.error(f"Error getting GPU usage: {e}")
            return 0.0
    
    def _get_memory_usage(self) -> float:
        """
        Get memory usage.
        
        Returns:
            Memory usage as fraction (0.0-1.0)
        """
        try:
            # Run free command to get memory usage
            cmd = "free | grep Mem | awk '{print $3/$2}'"
            output = subprocess.check_output(cmd, shell=True).decode("utf-8").strip()
            
            # Parse output
            memory_usage = float(output)
            
            return memory_usage
        except Exception as e:
            logger.error(f"Error getting memory usage: {e}")
            return 0.0
    
    def _get_temperature(self) -> float:
        """
        Get CPU temperature.
        
        Returns:
            Temperature in Celsius
        """
        try:
            # Check if thermal zone is available
            if not os.path.exists("/sys/devices/virtual/thermal/thermal_zone0/temp"):
                return 0.0
            
            # Read temperature from thermal zone
            with open("/sys/devices/virtual/thermal/thermal_zone0/temp", "r") as f:
                temp = float(f.read().strip()) / 1000.0
            
            return temp
        except Exception as e:
            logger.error(f"Error getting temperature: {e}")
            return 0.0
    
    def _get_power_usage(self) -> float:
        """
        Get power usage.
        
        Returns:
            Power usage in Watts
        """
        try:
            # Check if tegrastats is available
            if not self._is_jetson():
                return 0.0
            
            # Run tegrastats command to get power usage
            cmd = "tegrastats --interval 1000 --count 1 | grep -o 'VDD_IN.*' | awk '{print $2}'"
            output = subprocess.check_output(cmd, shell=True).decode("utf-8").strip()
            
            # Parse output (format: XXXXmW)
            power_usage = float(output.replace("mW", "")) / 1000.0
            
            return power_usage
        except Exception as e:
            logger.error(f"Error getting power usage: {e}")
            return 0.0
    
    def _get_cpu_clock(self) -> float:
        """
        Get CPU clock frequency.
        
        Returns:
            CPU clock frequency in MHz
        """
        try:
            # Check if cpufreq is available
            if not os.path.exists("/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq"):
                return 0.0
            
            # Read CPU frequency from cpufreq
            with open("/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq", "r") as f:
                freq = float(f.read().strip()) / 1000.0
            
            return freq
        except Exception as e:
            logger.error(f"Error getting CPU clock: {e}")
            return 0.0
    
    def _get_gpu_clock(self) -> float:
        """
        Get GPU clock frequency.
        
        Returns:
            GPU clock frequency in MHz
        """
        try:
            # Check if tegrastats is available
            if not self._is_jetson():
                return 0.0
            
            # Run tegrastats command to get GPU clock
            cmd = "tegrastats --interval 1000 --count 1 | grep -o 'GR3D_FREQ.*' | awk '{print $1}'"
            output = subprocess.check_output(cmd, shell=True).decode("utf-8").strip()
            
            # Parse output (format: XXXMHz)
            gpu_clock = float(output.replace("MHz", ""))
            
            return gpu_clock
        except Exception as e:
            logger.error(f"Error getting GPU clock: {e}")
            return 0.0
    
    def _is_jetson(self) -> bool:
        """
        Check if running on Jetson device.
        
        Returns:
            True if running on Jetson device, False otherwise
        """
        return os.path.exists("/etc/nv_tegra_release")


class HardwareVerification:
    """
    Hardware verification for the OPSC Sandwich Quality Inspection System.
    
    This class provides methods for verifying hardware components,
    including Jetson Xavier NX, cameras, and host PC.
    """
    
    def __init__(self, config_path: Optional[str] = None):
        """
        Initialize the hardware verification.
        
        Args:
            config_path: Path to hardware configuration file
        """
        self.config_path = config_path
        self.config = self._load_config()
        
        # Initialize Jetson monitor
        self.jetson_monitor = None
        
        # Initialize verification results
        self.verification_results = {}
    
    def _load_config(self) -> Dict[str, Any]:
        """
        Load hardware configuration from file.
        
        Returns:
            Configuration dictionary
        """
        config = {
            "jetson": {
                "ip": "192.168.1.101",
                "ssh_port": 22,
                "username": "nvidia",
                "min_cuda_version": "11.4",
                "min_cudnn_version": "8.2",
                "min_tensorrt_version": "8.4"
            },
            "cameras": {
                "num_cameras": 4,
                "subnet": "192.168.1.0/24",
                "min_firmware_version": "2.5.0"
            },
            "host": {
                "min_cuda_version": "11.7",
                "min_cudnn_version": "8.5",
                "min_tensorrt_version": "8.5",
                "min_gpu_memory": 8  # GB
            }
        }
        
        # If config path is provided, load from file
        if self.config_path and os.path.exists(self.config_path):
            try:
                with open(self.config_path, "r") as f:
                    file_config = json.load(f)
                
                # Update config with file values
                for key, value in file_config.items():
                    if key in config:
                        config[key].update(value)
            except Exception as e:
                logger.error(f"Error loading config from {self.config_path}: {e}")
        
        return config
    
    def verify_all(self) -> Dict[str, Any]:
        """
        Verify all hardware components.
        
        Returns:
            Verification results as dictionary
        """
        # Verify Jetson
        jetson_result = self.verify_jetson()
        
        # Verify cameras
        cameras_result = self.verify_cameras()
        
        # Verify host PC
        host_result = self.verify_host()
        
        # Combine results
        self.verification_results = {
            "timestamp": time.time(),
            "jetson": jetson_result,
            "cameras": cameras_result,
            "host": host_result,
            "overall_status": all([
                jetson_result.get("status", False),
                cameras_result.get("status", False),
                host_result.get("status", False)
            ])
        }
        
        return self.verification_results
    
    def verify_jetson(self) -> Dict[str, Any]:
        """
        Verify Jetson Xavier NX.
        
        Returns:
            Verification results as dictionary
        """
        try:
            logger.info("Verifying Jetson Xavier NX")
            
            # Check if running on Jetson
            is_jetson = self._is_jetson()
            
            if is_jetson:
                # Running on Jetson, perform local verification
                result = self._verify_jetson_local()
            else:
                # Not running on Jetson, perform remote verification
                result = self._verify_jetson_remote()
            
            logger.info(f"Jetson verification result: {result}")
            
            return result
        except Exception as e:
            logger.error(f"Error verifying Jetson: {e}")
            return {
                "status": False,
                "error": str(e)
            }
    
    def _verify_jetson_local(self) -> Dict[str, Any]:
        """
        Verify Jetson Xavier NX locally.
        
        Returns:
            Verification results as dictionary
        """
        try:
            # Check CUDA version
            cuda_version = self._get_cuda_version()
            cuda_ok = self._compare_versions(cuda_version, self.config["jetson"]["min_cuda_version"])
            
            # Check cuDNN version
            cudnn_version = self._get_cudnn_version()
            cudnn_ok = self._compare_versions(cudnn_version, self.config["jetson"]["min_cudnn_version"])
            
            # Check TensorRT version
            tensorrt_version = self._get_tensorrt_version()
            tensorrt_ok = self._compare_versions(tensorrt_version, self.config["jetson"]["min_tensorrt_version"])
            
            # Check GPU
            gpu_info = self._get_gpu_info()
            
            # Start Jetson monitor if not already running
            if self.jetson_monitor is None:
                self.jetson_monitor = JetsonMonitor()
                self.jetson_monitor.start_monitoring()
            
            # Get hardware status
            hardware_status = self.jetson_monitor.get_hardware_status()
            
            # Determine overall status
            status = cuda_ok and cudnn_ok and tensorrt_ok
            
            return {
                "status": status,
                "is_local": True,
                "cuda_version": cuda_version,
                "cuda_ok": cuda_ok,
                "cudnn_version": cudnn_version,
                "cudnn_ok": cudnn_ok,
                "tensorrt_version": tensorrt_version,
                "tensorrt_ok": tensorrt_ok,
                "gpu_info": gpu_info,
                "hardware_status": hardware_status
            }
        except Exception as e:
            logger.error(f"Error verifying Jetson locally: {e}")
            return {
                "status": False,
                "is_local": True,
                "error": str(e)
            }
    
    def _verify_jetson_remote(self) -> Dict[str, Any]:
        """
        Verify Jetson Xavier NX remotely.
        
        Returns:
            Verification results as dictionary
        """
        try:
            # Check if Jetson is reachable
            jetson_ip = self.config["jetson"]["ip"]
            reachable = self._ping_host(jetson_ip)
            
            if not reachable:
                return {
                    "status": False,
                    "is_local": False,
                    "error": f"Jetson at {jetson_ip} is not reachable"
                }
            
            # TODO: Implement SSH-based verification
            # This would require SSH credentials and would execute commands remotely
            
            return {
                "status": True,
                "is_local": False,
                "reachable": True,
                "ip": jetson_ip,
                "note": "Remote verification is limited to reachability check"
            }
        except Exception as e:
            logger.error(f"Error verifying Jetson remotely: {e}")
            return {
                "status": False,
                "is_local": False,
                "error": str(e)
            }
    
    def verify_cameras(self) -> Dict[str, Any]:
        """
        Verify Basler cameras.
        
        Returns:
            Verification results as dictionary
        """
        try:
            logger.info("Verifying Basler cameras")
            
            # Check if pypylon is available
            try:
                import pypylon.pylon as py
                pypylon_available = True
            except ImportError:
                pypylon_available = False
                logger.warning("pypylon is not available, camera verification will be limited")
            
            if pypylon_available:
                # Get available cameras
                available_cameras = py.TlFactory.GetInstance().EnumerateDevices()
                num_available = len(available_cameras)
                
                # Check if enough cameras are available
                num_required = self.config["cameras"]["num_cameras"]
                cameras_ok = num_available >= num_required
                
                # Get camera details
                camera_details = []
                for i, device_info in enumerate(available_cameras):
                    try:
                        # Create camera object
                        camera = py.InstantCamera(py.TlFactory.GetInstance().CreateDevice(device_info))
                        
                        # Open camera
                        camera.Open()
                        
                        # Get camera info
                        model = camera.GetDeviceInfo().GetModelName()
                        serial = camera.GetDeviceInfo().GetSerialNumber()
                        ip = camera.GetDeviceInfo().GetIpAddress()
                        firmware = camera.DeviceFirmwareVersion.GetValue()
                        
                        # Check firmware version
                        firmware_ok = self._compare_versions(
                            firmware,
                            self.config["cameras"]["min_firmware_version"]
                        )
                        
                        # Add to details
                        camera_details.append({
                            "index": i,
                            "model": model,
                            "serial": serial,
                            "ip": ip,
                            "firmware": firmware,
                            "firmware_ok": firmware_ok
                        })
                        
                        # Close camera
                        camera.Close()
                    except Exception as e:
                        logger.error(f"Error getting camera details for camera {i}: {e}")
                        camera_details.append({
                            "index": i,
                            "error": str(e)
                        })
                
                return {
                    "status": cameras_ok,
                    "num_available": num_available,
                    "num_required": num_required,
                    "camera_details": camera_details
                }
            else:
                # Fallback to network scan
                return self._verify_cameras_network()
        except Exception as e:
            logger.error(f"Error verifying cameras: {e}")
            return {
                "status": False,
                "error": str(e)
            }
    
    def _verify_cameras_network(self) -> Dict[str, Any]:
        """
        Verify cameras by network scan.
        
        Returns:
            Verification results as dictionary
        """
        try:
            # Parse subnet
            subnet = self.config["cameras"]["subnet"]
            
            # Scan network for cameras
            # This is a simplified version that just checks if the expected IPs are reachable
            camera_ips = [f"192.168.1.{201 + i}" for i in range(self.config["cameras"]["num_cameras"])]
            
            # Check if cameras are reachable
            camera_details = []
            num_reachable = 0
            
            for i, ip in enumerate(camera_ips):
                reachable = self._ping_host(ip)
                if reachable:
                    num_reachable += 1
                
                camera_details.append({
                    "index": i,
                    "ip": ip,
                    "reachable": reachable
                })
            
            # Check if enough cameras are reachable
            num_required = self.config["cameras"]["num_cameras"]
            cameras_ok = num_reachable >= num_required
            
            return {
                "status": cameras_ok,
                "num_reachable": num_reachable,
                "num_required": num_required,
                "camera_details": camera_details,
                "note": "Camera verification is limited to network reachability check"
            }
        except Exception as e:
            logger.error(f"Error verifying cameras by network scan: {e}")
            return {
                "status": False,
                "error": str(e)
            }
    
    def verify_host(self) -> Dict[str, Any]:
        """
        Verify host PC.
        
        Returns:
            Verification results as dictionary
        """
        try:
            logger.info("Verifying host PC")
            
            # Check CUDA version
            cuda_version = self._get_cuda_version()
            cuda_ok = self._compare_versions(cuda_version, self.config["host"]["min_cuda_version"])
            
            # Check cuDNN version
            cudnn_version = self._get_cudnn_version()
            cudnn_ok = self._compare_versions(cudnn_version, self.config["host"]["min_cudnn_version"])
            
            # Check TensorRT version
            tensorrt_version = self._get_tensorrt_version()
            tensorrt_ok = self._compare_versions(tensorrt_version, self.config["host"]["min_tensorrt_version"])
            
            # Check GPU
            gpu_info = self._get_gpu_info()
            
            # Check GPU memory
            gpu_memory = self._get_gpu_memory()
            gpu_memory_ok = gpu_memory >= self.config["host"]["min_gpu_memory"]
            
            # Determine overall status
            status = cuda_ok and cudnn_ok and tensorrt_ok and gpu_memory_ok
            
            return {
                "status": status,
                "cuda_version": cuda_version,
                "cuda_ok": cuda_ok,
                "cudnn_version": cudnn_version,
                "cudnn_ok": cudnn_ok,
                "tensorrt_version": tensorrt_version,
                "tensorrt_ok": tensorrt_ok,
                "gpu_info": gpu_info,
                "gpu_memory": gpu_memory,
                "gpu_memory_ok": gpu_memory_ok
            }
        except Exception as e:
            logger.error(f"Error verifying host PC: {e}")
            return {
                "status": False,
                "error": str(e)
            }
    
    def _get_cuda_version(self) -> str:
        """
        Get CUDA version.
        
        Returns:
            CUDA version as string
        """
        try:
            # Run nvcc command to get CUDA version
            cmd = "nvcc --version | grep 'release' | awk '{print $6}' | cut -c2-"
            output = subprocess.check_output(cmd, shell=True).decode("utf-8").strip()
            
            return output
        except Exception as e:
            logger.error(f"Error getting CUDA version: {e}")
            return "0.0"
    
    def _get_cudnn_version(self) -> str:
        """
        Get cuDNN version.
        
        Returns:
            cuDNN version as string
        """
        try:
            # Check if cuDNN is available
            cudnn_path = "/usr/include/cudnn.h"
            if not os.path.exists(cudnn_path):
                cudnn_path = "/usr/include/cudnn_version.h"
                if not os.path.exists(cudnn_path):
                    return "0.0"
            
            # Run grep command to get cuDNN version
            cmd = f"grep -o 'CUDNN_MAJOR.*' {cudnn_path} | head -1 | awk '{{print $3}}'"
            major = subprocess.check_output(cmd, shell=True).decode("utf-8").strip()
            
            cmd = f"grep -o 'CUDNN_MINOR.*' {cudnn_path} | head -1 | awk '{{print $3}}'"
            minor = subprocess.check_output(cmd, shell=True).decode("utf-8").strip()
            
            cmd = f"grep -o 'CUDNN_PATCHLEVEL.*' {cudnn_path} | head -1 | awk '{{print $3}}'"
            patch = subprocess.check_output(cmd, shell=True).decode("utf-8").strip()
            
            return f"{major}.{minor}.{patch}"
        except Exception as e:
            logger.error(f"Error getting cuDNN version: {e}")
            return "0.0"
    
    def _get_tensorrt_version(self) -> str:
        """
        Get TensorRT version.
        
        Returns:
            TensorRT version as string
        """
        try:
            # Try to import tensorrt
            try:
                import tensorrt as trt
                return trt.__version__
            except ImportError:
                pass
            
            # Fallback to checking TensorRT header
            tensorrt_path = "/usr/include/NvInferVersion.h"
            if not os.path.exists(tensorrt_path):
                return "0.0"
            
            # Run grep command to get TensorRT version
            cmd = f"grep -o 'NV_TENSORRT_MAJOR.*' {tensorrt_path} | head -1 | awk '{{print $3}}'"
            major = subprocess.check_output(cmd, shell=True).decode("utf-8").strip()
            
            cmd = f"grep -o 'NV_TENSORRT_MINOR.*' {tensorrt_path} | head -1 | awk '{{print $3}}'"
            minor = subprocess.check_output(cmd, shell=True).decode("utf-8").strip()
            
            cmd = f"grep -o 'NV_TENSORRT_PATCH.*' {tensorrt_path} | head -1 | awk '{{print $3}}'"
            patch = subprocess.check_output(cmd, shell=True).decode("utf-8").strip()
            
            return f"{major}.{minor}.{patch}"
        except Exception as e:
            logger.error(f"Error getting TensorRT version: {e}")
            return "0.0"
    
    def _get_gpu_info(self) -> Dict[str, Any]:
        """
        Get GPU information.
        
        Returns:
            GPU information as dictionary
        """
        try:
            # Run nvidia-smi command to get GPU info
            cmd = "nvidia-smi --query-gpu=name,driver_version,memory.total,memory.free,memory.used --format=csv,noheader,nounits"
            output = subprocess.check_output(cmd, shell=True).decode("utf-8").strip()
            
            # Parse output
            parts = output.split(", ")
            if len(parts) >= 5:
                return {
                    "name": parts[0],
                    "driver_version": parts[1],
                    "memory_total": float(parts[2]),
                    "memory_free": float(parts[3]),
                    "memory_used": float(parts[4])
                }
            else:
                return {}
        except Exception as e:
            logger.error(f"Error getting GPU info: {e}")
            return {}
    
    def _get_gpu_memory(self) -> float:
        """
        Get GPU memory in GB.
        
        Returns:
            GPU memory in GB
        """
        try:
            # Get GPU info
            gpu_info = self._get_gpu_info()
            
            # Get memory total in GB
            memory_total = gpu_info.get("memory_total", 0) / 1024.0
            
            return memory_total
        except Exception as e:
            logger.error(f"Error getting GPU memory: {e}")
            return 0.0
    
    def _ping_host(self, host: str) -> bool:
        """
        Check if host is reachable.
        
        Args:
            host: Hostname or IP address
        
        Returns:
            True if host is reachable, False otherwise
        """
        try:
            # Run ping command
            cmd = f"ping -c 1 -W 1 {host}"
            subprocess.check_output(cmd, shell=True)
            
            return True
        except subprocess.CalledProcessError:
            return False
        except Exception as e:
            logger.error(f"Error pinging host {host}: {e}")
            return False
    
    def _is_jetson(self) -> bool:
        """
        Check if running on Jetson device.
        
        Returns:
            True if running on Jetson device, False otherwise
        """
        return os.path.exists("/etc/nv_tegra_release")
    
    def _compare_versions(self, version1: str, version2: str) -> bool:
        """
        Compare two version strings.
        
        Args:
            version1: First version string
            version2: Second version string
        
        Returns:
            True if version1 >= version2, False otherwise
        """
        try:
            # Split versions into parts
            parts1 = [int(part) for part in version1.split(".")]
            parts2 = [int(part) for part in version2.split(".")]
            
            # Pad with zeros if necessary
            while len(parts1) < len(parts2):
                parts1.append(0)
            while len(parts2) < len(parts1):
                parts2.append(0)
            
            # Compare parts
            for i in range(len(parts1)):
                if parts1[i] > parts2[i]:
                    return True
                elif parts1[i] < parts2[i]:
                    return False
            
            # All parts are equal
            return True
        except Exception as e:
            logger.error(f"Error comparing versions {version1} and {version2}: {e}")
            return False


# Example usage
if __name__ == "__main__":
    # Setup logging
    logging.basicConfig(level=logging.INFO)
    
    # Create hardware verification
    verification = HardwareVerification()
    
    # Verify all hardware
    results = verification.verify_all()
    
    # Print results
    print(json.dumps(results, indent=2))
