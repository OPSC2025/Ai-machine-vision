"""
Performance optimization module for OPSC Sandwich Quality Inspection System.

This module provides tools and utilities for optimizing the performance of the
sandwich inspection system, focusing on throughput, latency, and resource utilization.

Version: 1.0.0
Last Updated: 2025-04-20
"""

import os
import sys
import time
import json
import logging
import threading
import queue
import numpy as np
import cv2
import psutil
import GPUtil
from typing import Dict, List, Optional, Tuple, Union, Any
from dataclasses import dataclass
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor

# Import project modules
sys.path.append('/home/ubuntu/opsc-vision-system')
from src.utils.config import get_config, ConfigManager
from src.utils.logging import setup_logging

# Setup logging
logger = setup_logging(__name__)


@dataclass
class PerformanceMetrics:
    """Container for performance metrics."""
    
    # Timing metrics (milliseconds)
    camera_acquisition_time: float = 0.0
    preprocessing_time: float = 0.0
    inference_time: float = 0.0
    database_time: float = 0.0
    total_processing_time: float = 0.0
    
    # Throughput metrics
    frames_per_second: float = 0.0
    sandwiches_per_minute: float = 0.0
    
    # Resource utilization
    cpu_usage: float = 0.0
    memory_usage: float = 0.0
    gpu_usage: float = 0.0
    gpu_memory_usage: float = 0.0
    
    # Quality metrics
    detection_confidence: float = 0.0
    
    def to_dict(self) -> Dict[str, float]:
        """Convert metrics to dictionary."""
        return {
            "camera_acquisition_time": self.camera_acquisition_time,
            "preprocessing_time": self.preprocessing_time,
            "inference_time": self.inference_time,
            "database_time": self.database_time,
            "total_processing_time": self.total_processing_time,
            "frames_per_second": self.frames_per_second,
            "sandwiches_per_minute": self.sandwiches_per_minute,
            "cpu_usage": self.cpu_usage,
            "memory_usage": self.memory_usage,
            "gpu_usage": self.gpu_usage,
            "gpu_memory_usage": self.gpu_memory_usage,
            "detection_confidence": self.detection_confidence
        }


class PerformanceMonitor:
    """
    Monitor and track performance metrics for the sandwich inspection system.
    
    This class provides tools for measuring, recording, and analyzing performance
    metrics across all components of the system.
    """
    
    def __init__(self, config_path: str = None):
        """
        Initialize the performance monitor.
        
        Args:
            config_path: Path to configuration file (optional)
        """
        self.config = get_config("performance") if config_path is None else ConfigManager(config_path).get_config()
        self.metrics_history: List[PerformanceMetrics] = []
        self.current_metrics = PerformanceMetrics()
        self.start_time = time.time()
        self.frame_count = 0
        self.lock = threading.Lock()
        
        # Performance thresholds
        self.max_processing_time = self.config.get("max_processing_time", 100)  # ms
        self.min_fps = self.config.get("min_fps", 20)
        self.min_sandwiches_per_minute = self.config.get("min_sandwiches_per_minute", 250)
        
        # Initialize monitoring thread
        self.monitoring_active = False
        self.monitoring_thread = None
    
    def start_monitoring(self, interval: float = 1.0):
        """
        Start continuous monitoring of system performance.
        
        Args:
            interval: Monitoring interval in seconds
        """
        if self.monitoring_active:
            logger.warning("Performance monitoring already active")
            return
        
        self.monitoring_active = True
        self.monitoring_thread = threading.Thread(
            target=self._monitoring_loop,
            args=(interval,),
            daemon=True
        )
        self.monitoring_thread.start()
        logger.info(f"Performance monitoring started with interval {interval}s")
    
    def stop_monitoring(self):
        """Stop continuous monitoring."""
        if not self.monitoring_active:
            logger.warning("Performance monitoring not active")
            return
        
        self.monitoring_active = False
        if self.monitoring_thread:
            self.monitoring_thread.join(timeout=5.0)
        logger.info("Performance monitoring stopped")
    
    def _monitoring_loop(self, interval: float):
        """
        Continuous monitoring loop.
        
        Args:
            interval: Monitoring interval in seconds
        """
        while self.monitoring_active:
            try:
                self.update_system_metrics()
                self.log_current_metrics()
                
                # Check for performance issues
                self._check_performance_thresholds()
                
                time.sleep(interval)
            except Exception as e:
                logger.error(f"Error in performance monitoring loop: {e}")
    
    def _check_performance_thresholds(self):
        """Check if performance metrics are within acceptable thresholds."""
        metrics = self.current_metrics
        
        # Check processing time
        if metrics.total_processing_time > self.max_processing_time:
            logger.warning(
                f"Processing time ({metrics.total_processing_time:.2f} ms) exceeds threshold "
                f"({self.max_processing_time} ms)"
            )
        
        # Check FPS
        if metrics.frames_per_second < self.min_fps:
            logger.warning(
                f"Frame rate ({metrics.frames_per_second:.2f} FPS) below threshold "
                f"({self.min_fps} FPS)"
            )
        
        # Check throughput
        if metrics.sandwiches_per_minute < self.min_sandwiches_per_minute:
            logger.warning(
                f"Throughput ({metrics.sandwiches_per_minute:.2f} sandwiches/min) below threshold "
                f"({self.min_sandwiches_per_minute} sandwiches/min)"
            )
        
        # Check resource utilization
        if metrics.cpu_usage > 90:
            logger.warning(f"High CPU usage: {metrics.cpu_usage:.2f}%")
        
        if metrics.memory_usage > 90:
            logger.warning(f"High memory usage: {metrics.memory_usage:.2f}%")
        
        if metrics.gpu_usage > 90:
            logger.warning(f"High GPU usage: {metrics.gpu_usage:.2f}%")
        
        if metrics.gpu_memory_usage > 90:
            logger.warning(f"High GPU memory usage: {metrics.gpu_memory_usage:.2f}%")
    
    def start_timer(self) -> float:
        """
        Start a timer for performance measurement.
        
        Returns:
            Current time in seconds
        """
        return time.time()
    
    def stop_timer(self, start_time: float) -> float:
        """
        Stop a timer and return elapsed time in milliseconds.
        
        Args:
            start_time: Start time from start_timer()
            
        Returns:
            Elapsed time in milliseconds
        """
        return (time.time() - start_time) * 1000.0
    
    def record_camera_time(self, elapsed_ms: float):
        """
        Record camera acquisition time.
        
        Args:
            elapsed_ms: Elapsed time in milliseconds
        """
        with self.lock:
            self.current_metrics.camera_acquisition_time = elapsed_ms
    
    def record_preprocessing_time(self, elapsed_ms: float):
        """
        Record preprocessing time.
        
        Args:
            elapsed_ms: Elapsed time in milliseconds
        """
        with self.lock:
            self.current_metrics.preprocessing_time = elapsed_ms
    
    def record_inference_time(self, elapsed_ms: float):
        """
        Record inference time.
        
        Args:
            elapsed_ms: Elapsed time in milliseconds
        """
        with self.lock:
            self.current_metrics.inference_time = elapsed_ms
    
    def record_database_time(self, elapsed_ms: float):
        """
        Record database operation time.
        
        Args:
            elapsed_ms: Elapsed time in milliseconds
        """
        with self.lock:
            self.current_metrics.database_time = elapsed_ms
    
    def record_frame_processed(self):
        """Record a processed frame for FPS calculation."""
        with self.lock:
            self.frame_count += 1
            elapsed = time.time() - self.start_time
            
            # Update FPS every second
            if elapsed >= 1.0:
                self.current_metrics.frames_per_second = self.frame_count / elapsed
                self.current_metrics.sandwiches_per_minute = self.current_metrics.frames_per_second * 60 / 4  # 4 cameras per sandwich
                
                # Reset counters
                self.start_time = time.time()
                self.frame_count = 0
    
    def record_total_processing_time(self, elapsed_ms: float):
        """
        Record total processing time for a frame.
        
        Args:
            elapsed_ms: Elapsed time in milliseconds
        """
        with self.lock:
            self.current_metrics.total_processing_time = elapsed_ms
    
    def record_detection_confidence(self, confidence: float):
        """
        Record detection confidence.
        
        Args:
            confidence: Detection confidence (0.0-1.0)
        """
        with self.lock:
            self.current_metrics.detection_confidence = confidence
    
    def update_system_metrics(self):
        """Update system resource utilization metrics."""
        with self.lock:
            # CPU usage
            self.current_metrics.cpu_usage = psutil.cpu_percent()
            
            # Memory usage
            memory = psutil.virtual_memory()
            self.current_metrics.memory_usage = memory.percent
            
            # GPU usage (if available)
            try:
                gpus = GPUtil.getGPUs()
                if gpus:
                    gpu = gpus[0]  # Use first GPU
                    self.current_metrics.gpu_usage = gpu.load * 100
                    self.current_metrics.gpu_memory_usage = gpu.memoryUtil * 100
            except Exception as e:
                logger.debug(f"Could not get GPU metrics: {e}")
    
    def save_current_metrics(self):
        """Save current metrics to history."""
        with self.lock:
            self.metrics_history.append(self.current_metrics)
            
            # Limit history size
            max_history = self.config.get("max_history_size", 1000)
            if len(self.metrics_history) > max_history:
                self.metrics_history = self.metrics_history[-max_history:]
    
    def get_current_metrics(self) -> PerformanceMetrics:
        """
        Get current performance metrics.
        
        Returns:
            Current performance metrics
        """
        with self.lock:
            return self.current_metrics
    
    def get_metrics_history(self) -> List[PerformanceMetrics]:
        """
        Get performance metrics history.
        
        Returns:
            List of performance metrics
        """
        with self.lock:
            return self.metrics_history.copy()
    
    def log_current_metrics(self):
        """Log current performance metrics."""
        metrics = self.get_current_metrics()
        logger.info(
            f"Performance: {metrics.total_processing_time:.2f}ms total "
            f"({metrics.camera_acquisition_time:.2f}ms camera, "
            f"{metrics.preprocessing_time:.2f}ms preproc, "
            f"{metrics.inference_time:.2f}ms inference, "
            f"{metrics.database_time:.2f}ms db) | "
            f"FPS: {metrics.frames_per_second:.2f} | "
            f"Throughput: {metrics.sandwiches_per_minute:.2f} sandwiches/min | "
            f"CPU: {metrics.cpu_usage:.1f}% | "
            f"Mem: {metrics.memory_usage:.1f}% | "
            f"GPU: {metrics.gpu_usage:.1f}% | "
            f"GPU Mem: {metrics.gpu_memory_usage:.1f}%"
        )
    
    def generate_performance_report(self) -> Dict[str, Any]:
        """
        Generate a comprehensive performance report.
        
        Returns:
            Dictionary with performance statistics
        """
        with self.lock:
            if not self.metrics_history:
                return {"error": "No performance data available"}
            
            # Calculate statistics
            camera_times = [m.camera_acquisition_time for m in self.metrics_history]
            preprocessing_times = [m.preprocessing_time for m in self.metrics_history]
            inference_times = [m.inference_time for m in self.metrics_history]
            database_times = [m.database_time for m in self.metrics_history]
            total_times = [m.total_processing_time for m in self.metrics_history]
            fps_values = [m.frames_per_second for m in self.metrics_history if m.frames_per_second > 0]
            throughput_values = [m.sandwiches_per_minute for m in self.metrics_history if m.sandwiches_per_minute > 0]
            
            # Calculate statistics for each metric
            def calculate_stats(values):
                if not values:
                    return {"min": 0, "max": 0, "avg": 0, "median": 0}
                
                return {
                    "min": min(values),
                    "max": max(values),
                    "avg": sum(values) / len(values),
                    "median": sorted(values)[len(values) // 2]
                }
            
            report = {
                "timestamp": time.time(),
                "sample_count": len(self.metrics_history),
                "timing": {
                    "camera": calculate_stats(camera_times),
                    "preprocessing": calculate_stats(preprocessing_times),
                    "inference": calculate_stats(inference_times),
                    "database": calculate_stats(database_times),
                    "total": calculate_stats(total_times)
                },
                "throughput": {
                    "fps": calculate_stats(fps_values),
                    "sandwiches_per_minute": calculate_stats(throughput_values)
                },
                "resource_utilization": {
                    "cpu": calculate_stats([m.cpu_usage for m in self.metrics_history]),
                    "memory": calculate_stats([m.memory_usage for m in self.metrics_history]),
                    "gpu": calculate_stats([m.gpu_usage for m in self.metrics_history if m.gpu_usage > 0]),
                    "gpu_memory": calculate_stats([m.gpu_memory_usage for m in self.metrics_history if m.gpu_memory_usage > 0])
                },
                "thresholds": {
                    "max_processing_time": self.max_processing_time,
                    "min_fps": self.min_fps,
                    "min_sandwiches_per_minute": self.min_sandwiches_per_minute
                },
                "status": self._get_performance_status(total_times, fps_values, throughput_values)
            }
            
            return report
    
    def _get_performance_status(self, total_times, fps_values, throughput_values):
        """
        Determine overall performance status.
        
        Args:
            total_times: List of total processing times
            fps_values: List of FPS values
            throughput_values: List of throughput values
            
        Returns:
            Performance status dictionary
        """
        status = {
            "overall": "good",
            "issues": []
        }
        
        # Check processing time
        if total_times and max(total_times) > self.max_processing_time:
            status["overall"] = "warning"
            status["issues"].append(
                f"Processing time exceeds threshold: {max(total_times):.2f}ms > {self.max_processing_time}ms"
            )
        
        # Check FPS
        if fps_values and min(fps_values) < self.min_fps:
            status["overall"] = "warning"
            status["issues"].append(
                f"Frame rate below threshold: {min(fps_values):.2f} FPS < {self.min_fps} FPS"
            )
        
        # Check throughput
        if throughput_values and min(throughput_values) < self.min_sandwiches_per_minute:
            status["overall"] = "critical"
            status["issues"].append(
                f"Throughput below threshold: {min(throughput_values):.2f} sandwiches/min < "
                f"{self.min_sandwiches_per_minute} sandwiches/min"
            )
        
        return status


class PerformanceOptimizer:
    """
    Optimize system performance based on monitoring data.
    
    This class provides tools for automatically adjusting system parameters
    to optimize performance based on monitoring data.
    """
    
    def __init__(self, config_path: str = None):
        """
        Initialize the performance optimizer.
        
        Args:
            config_path: Path to configuration file (optional)
        """
        self.config = get_config("performance") if config_path is None else ConfigManager(config_path).get_config()
        self.monitor = PerformanceMonitor(config_path)
        self.lock = threading.Lock()
        
        # Optimization parameters
        self.batch_size = self.config.get("initial_batch_size", 1)
        self.max_batch_size = self.config.get("max_batch_size", 8)
        self.resolution_scale = self.config.get("initial_resolution_scale", 1.0)
        self.min_resolution_scale = self.config.get("min_resolution_scale", 0.5)
        self.thread_count = self.config.get("initial_thread_count", 4)
        self.max_thread_count = self.config.get("max_thread_count", 16)
        
        # Optimization state
        self.optimization_active = False
        self.optimization_thread = None
        
        # Thread pool for parallel processing
        self.thread_pool = ThreadPoolExecutor(max_workers=self.thread_count)
        
        logger.info(
            f"Performance optimizer initialized with batch_size={self.batch_size}, "
            f"resolution_scale={self.resolution_scale}, thread_count={self.thread_count}"
        )
    
    def start_optimization(self, interval: float = 10.0):
        """
        Start continuous performance optimization.
        
        Args:
            interval: Optimization interval in seconds
        """
        if self.optimization_active:
            logger.warning("Performance optimization already active")
            return
        
        # Start performance monitoring
        self.monitor.start_monitoring()
        
        # Start optimization thread
        self.optimization_active = True
        self.optimization_thread = threading.Thread(
            target=self._optimization_loop,
            args=(interval,),
            daemon=True
        )
        self.optimization_thread.start()
        logger.info(f"Performance optimization started with interval {interval}s")
    
    def stop_optimization(self):
        """Stop continuous optimization."""
        if not self.optimization_active:
            logger.warning("Performance optimization not active")
            return
        
        self.optimization_active = False
        if self.optimization_thread:
            self.optimization_thread.join(timeout=5.0)
        
        # Stop performance monitoring
        self.monitor.stop_monitoring()
        
        logger.info("Performance optimization stopped")
    
    def _optimization_loop(self, interval: float):
        """
        Continuous optimization loop.
        
        Args:
            interval: Optimization interval in seconds
        """
        while self.optimization_active:
            try:
                # Get current performance metrics
                metrics = self.monitor.get_current_metrics()
                
                # Check if optimization is needed
                if self._should_optimize(metrics):
                    self._optimize_parameters(metrics)
                
                time.sleep(interval)
            except Exception as e:
                logger.error(f"Error in performance optimization loop: {e}")
    
    def _should_optimize(self, metrics: PerformanceMetrics) -> bool:
        """
        Determine if optimization is needed based on current metrics.
        
        Args:
            metrics: Current performance metrics
            
        Returns:
            True if optimization is needed, False otherwise
        """
        # Check if we have enough data
        if metrics.frames_per_second == 0:
            return False
        
        # Check if we're meeting performance targets
        if (metrics.total_processing_time > self.monitor.max_processing_time or
                metrics.frames_per_second < self.monitor.min_fps or
                metrics.sandwiches_per_minute < self.monitor.min_sandwiches_per_minute):
            return True
        
        # Check if we have room for improvement
        if (metrics.total_processing_time < self.monitor.max_processing_time * 0.7 and
                self.batch_size < self.max_batch_size):
            return True
        
        return False
    
    def _optimize_parameters(self, metrics: PerformanceMetrics):
        """
        Optimize system parameters based on current metrics.
        
        Args:
            metrics: Current performance metrics
        """
        with self.lock:
            logger.info("Optimizing performance parameters...")
            
            # Identify bottleneck
            bottleneck = self._identify_bottleneck(metrics)
            logger.info(f"Identified bottleneck: {bottleneck}")
            
            # Optimize based on bottleneck
            if bottleneck == "camera":
                # Camera is the bottleneck, not much we can do
                logger.info("Camera is the bottleneck, consider hardware upgrades")
            
            elif bottleneck == "preprocessing":
                # Preprocessing is the bottleneck, adjust resolution or threading
                if metrics.cpu_usage < 80 and self.thread_count < self.max_thread_count:
                    # Increase thread count
                    self.thread_count = min(self.thread_count + 2, self.max_thread_count)
                    self.thread_pool.shutdown(wait=True)
                    self.thread_pool = ThreadPoolExecutor(max_workers=self.thread_count)
                    logger.info(f"Increased thread count to {self.thread_count}")
                elif self.resolution_scale > self.min_resolution_scale:
                    # Reduce resolution
                    self.resolution_scale = max(self.resolution_scale * 0.9, self.min_resolution_scale)
                    logger.info(f"Reduced resolution scale to {self.resolution_scale}")
            
            elif bottleneck == "inference":
                # Inference is the bottleneck, adjust batch size or resolution
                if self.batch_size < self.max_batch_size:
                    # Increase batch size
                    self.batch_size = min(self.batch_size + 1, self.max_batch_size)
                    logger.info(f"Increased batch size to {self.batch_size}")
                elif self.resolution_scale > self.min_resolution_scale:
                    # Reduce resolution
                    self.resolution_scale = max(self.resolution_scale * 0.9, self.min_resolution_scale)
                    logger.info(f"Reduced resolution scale to {self.resolution_scale}")
            
            elif bottleneck == "database":
                # Database is the bottleneck, optimize queries or add indexing
                logger.info("Database is the bottleneck, consider query optimization or indexing")
            
            # Log updated parameters
            logger.info(
                f"Updated parameters: batch_size={self.batch_size}, "
                f"resolution_scale={self.resolution_scale}, thread_count={self.thread_count}"
            )
    
    def _identify_bottleneck(self, metrics: PerformanceMetrics) -> str:
        """
        Identify the performance bottleneck based on metrics.
        
        Args:
            metrics: Current performance metrics
            
        Returns:
            Bottleneck component name: "camera", "preprocessing", "inference", or "database"
        """
        times = {
            "camera": metrics.camera_acquisition_time,
            "preprocessing": metrics.preprocessing_time,
            "inference": metrics.inference_time,
            "database": metrics.database_time
        }
        
        # Find the component with the highest processing time
        bottleneck = max(times.items(), key=lambda x: x[1])
        return bottleneck[0]
    
    def get_batch_size(self) -> int:
        """
        Get current optimal batch size.
        
        Returns:
            Current batch size
        """
        with self.lock:
            return self.batch_size
    
    def get_resolution_scale(self) -> float:
        """
        Get current optimal resolution scale.
        
        Returns:
            Current resolution scale (0.5-1.0)
        """
        with self.lock:
            return self.resolution_scale
    
    def get_thread_count(self) -> int:
        """
        Get current optimal thread count.
        
        Returns:
            Current thread count
        """
        with self.lock:
            return self.thread_count
    
    def get_optimization_status(self) -> Dict[str, Any]:
        """
        Get current optimization status.
        
        Returns:
            Dictionary with optimization status
        """
        with self.lock:
            return {
                "active": self.optimization_active,
                "parameters": {
                    "batch_size": self.batch_size,
                    "resolution_scale": self.resolution_scale,
                    "thread_count": self.thread_count
                },
                "limits": {
                    "max_batch_size": self.max_batch_size,
                    "min_resolution_scale": self.min_resolution_scale,
                    "max_thread_count": self.max_thread_count
                }
            }
    
    def process_batch(self, items, process_func):
        """
        Process a batch of items in parallel.
        
        Args:
            items: List of items to process
            process_func: Function to process each item
            
        Returns:
            List of processed results
        """
        with self.lock:
            # Split into batches
            batch_size = self.batch_size
            batches = [items[i:i + batch_size] for i in range(0, len(items), batch_size)]
            
            results = []
            for batch in batches:
                # Process batch in parallel
                batch_results = list(self.thread_pool.map(process_func, batch))
                results.extend(batch_results)
            
            return results


class ImageOptimizer:
    """
    Optimize image processing for performance.
    
    This class provides tools for optimizing image processing operations
    for maximum performance while maintaining quality.
    """
    
    def __init__(self, config_path: str = None):
        """
        Initialize the image optimizer.
        
        Args:
            config_path: Path to configuration file (optional)
        """
        self.config = get_config("performance") if config_path is None else ConfigManager(config_path).get_config()
        self.optimizer = PerformanceOptimizer(config_path)
    
    def resize_for_inference(self, image: np.ndarray) -> np.ndarray:
        """
        Resize image for optimal inference performance.
        
        Args:
            image: Input image
            
        Returns:
            Resized image
        """
        scale = self.optimizer.get_resolution_scale()
        if scale >= 0.99:
            return image
        
        h, w = image.shape[:2]
        new_h, new_w = int(h * scale), int(w * scale)
        
        return cv2.resize(image, (new_w, new_h), interpolation=cv2.INTER_AREA)
    
    def optimize_image_batch(self, images: List[np.ndarray]) -> List[np.ndarray]:
        """
        Optimize a batch of images for inference.
        
        Args:
            images: List of input images
            
        Returns:
            List of optimized images
        """
        return self.optimizer.process_batch(images, self.resize_for_inference)
    
    def optimize_preprocessing_pipeline(self, pipeline_steps: List[callable]) -> callable:
        """
        Optimize a preprocessing pipeline for performance.
        
        Args:
            pipeline_steps: List of preprocessing functions
            
        Returns:
            Optimized pipeline function
        """
        def optimized_pipeline(image):
            # Apply resolution scaling first
            scaled_image = self.resize_for_inference(image)
            
            # Apply remaining pipeline steps
            result = scaled_image
            for step in pipeline_steps:
                result = step(result)
            
            return result
        
        return optimized_pipeline
    
    def get_optimal_jpeg_quality(self) -> int:
        """
        Get optimal JPEG quality setting based on current performance.
        
        Returns:
            JPEG quality (0-100)
        """
        # Base quality on resolution scale
        scale = self.optimizer.get_resolution_scale()
        
        # Higher scale (less downsampling) = higher quality
        # Lower scale (more downsampling) = lower quality
        quality = int(70 + 30 * scale)
        
        return quality
    
    def compress_for_storage(self, image: np.ndarray) -> bytes:
        """
        Compress image for efficient storage.
        
        Args:
            image: Input image
            
        Returns:
            Compressed image bytes
        """
        quality = self.get_optimal_jpeg_quality()
        encode_param = [int(cv2.IMWRITE_JPEG_QUALITY), quality]
        
        _, buffer = cv2.imencode('.jpg', image, encode_param)
        return buffer.tobytes()
    
    def compress_for_network(self, image: np.ndarray) -> bytes:
        """
        Compress image for efficient network transfer.
        
        Args:
            image: Input image
            
        Returns:
            Compressed image bytes
        """
        # Use lower quality for network transfer
        quality = max(50, self.get_optimal_jpeg_quality() - 20)
        encode_param = [int(cv2.IMWRITE_JPEG_QUALITY), quality]
        
        _, buffer = cv2.imencode('.jpg', image, encode_param)
        return buffer.tobytes()


class DatabaseOptimizer:
    """
    Optimize database operations for performance.
    
    This class provides tools for optimizing database operations
    for maximum performance.
    """
    
    def __init__(self, config_path: str = None):
        """
        Initialize the database optimizer.
        
        Args:
            config_path: Path to configuration file (optional)
        """
        self.config = get_config("performance") if config_path is None else ConfigManager(config_path).get_config()
        self.optimizer = PerformanceOptimizer(config_path)
        
        # Database optimization parameters
        self.batch_insert_size = self.config.get("batch_insert_size", 100)
        self.max_connections = self.config.get("max_connections", 10)
        self.query_timeout = self.config.get("query_timeout", 5.0)  # seconds
    
    def optimize_query(self, query: str) -> str:
        """
        Optimize an SQL query for performance.
        
        Args:
            query: SQL query string
            
        Returns:
            Optimized query string
        """
        # Simple query optimization rules
        optimized = query
        
        # Add LIMIT to SELECT queries without one
        if query.strip().upper().startswith("SELECT") and "LIMIT" not in query.upper():
            optimized += " LIMIT 1000"  # Default limit
        
        # Use indexed columns in WHERE clauses
        # This is a simplified example - real optimization would be more complex
        indexed_columns = ["id", "timestamp", "inspection_id", "production_run_id", "defect_type"]
        for col in indexed_columns:
            if f"WHERE {col}" in optimized:
                # Already using indexed column
                return optimized
        
        return optimized
    
    def get_connection_pool_size(self) -> int:
        """
        Get optimal database connection pool size.
        
        Returns:
            Connection pool size
        """
        # Base on thread count
        thread_count = self.optimizer.get_thread_count()
        
        # Use at least 2 connections, at most max_connections
        return max(2, min(thread_count // 2, self.max_connections))
    
    def get_batch_insert_size(self) -> int:
        """
        Get optimal batch insert size.
        
        Returns:
            Batch insert size
        """
        return self.batch_insert_size
    
    def get_query_timeout(self) -> float:
        """
        Get optimal query timeout.
        
        Returns:
            Query timeout in seconds
        """
        return self.query_timeout
    
    def optimize_table(self, table_name: str) -> List[str]:
        """
        Generate SQL statements to optimize a database table.
        
        Args:
            table_name: Name of table to optimize
            
        Returns:
            List of SQL statements for optimization
        """
        statements = []
        
        # Add indexes for common query patterns
        if table_name == "inspections":
            statements.extend([
                f"CREATE INDEX IF NOT EXISTS idx_{table_name}_timestamp ON {table_name}(timestamp)",
                f"CREATE INDEX IF NOT EXISTS idx_{table_name}_result ON {table_name}(result)",
                f"CREATE INDEX IF NOT EXISTS idx_{table_name}_production_run_id ON {table_name}(production_run_id)"
            ])
        elif table_name == "defects":
            statements.extend([
                f"CREATE INDEX IF NOT EXISTS idx_{table_name}_inspection_id ON {table_name}(inspection_id)",
                f"CREATE INDEX IF NOT EXISTS idx_{table_name}_defect_type ON {table_name}(defect_type)",
                f"CREATE INDEX IF NOT EXISTS idx_{table_name}_confidence ON {table_name}(confidence)"
            ])
        elif table_name == "production_runs":
            statements.extend([
                f"CREATE INDEX IF NOT EXISTS idx_{table_name}_lot_number ON {table_name}(lot_number)",
                f"CREATE INDEX IF NOT EXISTS idx_{table_name}_start_time ON {table_name}(start_time)",
                f"CREATE INDEX IF NOT EXISTS idx_{table_name}_end_time ON {table_name}(end_time)"
            ])
        
        # Add VACUUM statement to optimize storage
        statements.append(f"VACUUM {table_name}")
        
        # Add ANALYZE statement to update statistics
        statements.append(f"ANALYZE {table_name}")
        
        return statements


class NetworkOptimizer:
    """
    Optimize network operations for performance.
    
    This class provides tools for optimizing network operations
    for maximum performance.
    """
    
    def __init__(self, config_path: str = None):
        """
        Initialize the network optimizer.
        
        Args:
            config_path: Path to configuration file (optional)
        """
        self.config = get_config("performance") if config_path is None else ConfigManager(config_path).get_config()
        self.optimizer = PerformanceOptimizer(config_path)
        self.image_optimizer = ImageOptimizer(config_path)
        
        # Network optimization parameters
        self.max_concurrent_connections = self.config.get("max_concurrent_connections", 10)
        self.connection_timeout = self.config.get("connection_timeout", 5.0)  # seconds
        self.keepalive_interval = self.config.get("keepalive_interval", 30.0)  # seconds
    
    def get_max_concurrent_connections(self) -> int:
        """
        Get optimal maximum concurrent connections.
        
        Returns:
            Maximum concurrent connections
        """
        # Base on thread count
        thread_count = self.optimizer.get_thread_count()
        
        # Use at least 2 connections, at most max_concurrent_connections
        return max(2, min(thread_count, self.max_concurrent_connections))
    
    def get_connection_timeout(self) -> float:
        """
        Get optimal connection timeout.
        
        Returns:
            Connection timeout in seconds
        """
        return self.connection_timeout
    
    def get_keepalive_interval(self) -> float:
        """
        Get optimal keepalive interval.
        
        Returns:
            Keepalive interval in seconds
        """
        return self.keepalive_interval
    
    def optimize_image_for_transfer(self, image: np.ndarray) -> bytes:
        """
        Optimize an image for network transfer.
        
        Args:
            image: Input image
            
        Returns:
            Optimized image bytes
        """
        return self.image_optimizer.compress_for_network(image)
    
    def optimize_batch_transfer(self, images: List[np.ndarray]) -> List[bytes]:
        """
        Optimize a batch of images for network transfer.
        
        Args:
            images: List of input images
            
        Returns:
            List of optimized image bytes
        """
        return self.optimizer.process_batch(images, self.optimize_image_for_transfer)
    
    def estimate_bandwidth_requirement(self, fps: float, image_size: int) -> float:
        """
        Estimate bandwidth requirement for streaming.
        
        Args:
            fps: Frames per second
            image_size: Average compressed image size in bytes
            
        Returns:
            Bandwidth requirement in Mbps
        """
        bytes_per_second = fps * image_size
        mbps = bytes_per_second * 8 / 1024 / 1024
        
        return mbps
    
    def optimize_grpc_settings(self) -> Dict[str, Any]:
        """
        Get optimal gRPC settings for Jetson communication.
        
        Returns:
            Dictionary with gRPC settings
        """
        thread_count = self.optimizer.get_thread_count()
        
        return {
            "max_message_length": 100 * 1024 * 1024,  # 100 MB
            "max_concurrent_streams": thread_count * 2,
            "initial_window_size": 10 * 1024 * 1024,  # 10 MB
            "initial_connection_window_size": 20 * 1024 * 1024,  # 20 MB
            "keepalive_time_ms": int(self.keepalive_interval * 1000),
            "keepalive_timeout_ms": 20000,  # 20 seconds
            "keepalive_permit_without_calls": True,
            "http2_max_pings_without_data": 5,
            "http2_min_sent_ping_interval_without_data_ms": 300000  # 5 minutes
        }


# Singleton instances
_performance_monitor = None
_performance_optimizer = None
_image_optimizer = None
_database_optimizer = None
_network_optimizer = None


def get_performance_monitor(config_path: str = None) -> PerformanceMonitor:
    """
    Get singleton instance of PerformanceMonitor.
    
    Args:
        config_path: Path to configuration file (optional)
        
    Returns:
        PerformanceMonitor instance
    """
    global _performance_monitor
    if _performance_monitor is None:
        _performance_monitor = PerformanceMonitor(config_path)
    return _performance_monitor


def get_performance_optimizer(config_path: str = None) -> PerformanceOptimizer:
    """
    Get singleton instance of PerformanceOptimizer.
    
    Args:
        config_path: Path to configuration file (optional)
        
    Returns:
        PerformanceOptimizer instance
    """
    global _performance_optimizer
    if _performance_optimizer is None:
        _performance_optimizer = PerformanceOptimizer(config_path)
    return _performance_optimizer


def get_image_optimizer(config_path: str = None) -> ImageOptimizer:
    """
    Get singleton instance of ImageOptimizer.
    
    Args:
        config_path: Path to configuration file (optional)
        
    Returns:
        ImageOptimizer instance
    """
    global _image_optimizer
    if _image_optimizer is None:
        _image_optimizer = ImageOptimizer(config_path)
    return _image_optimizer


def get_database_optimizer(config_path: str = None) -> DatabaseOptimizer:
    """
    Get singleton instance of DatabaseOptimizer.
    
    Args:
        config_path: Path to configuration file (optional)
        
    Returns:
        DatabaseOptimizer instance
    """
    global _database_optimizer
    if _database_optimizer is None:
        _database_optimizer = DatabaseOptimizer(config_path)
    return _database_optimizer


def get_network_optimizer(config_path: str = None) -> NetworkOptimizer:
    """
    Get singleton instance of NetworkOptimizer.
    
    Args:
        config_path: Path to configuration file (optional)
        
    Returns:
        NetworkOptimizer instance
    """
    global _network_optimizer
    if _network_optimizer is None:
        _network_optimizer = NetworkOptimizer(config_path)
    return _network_optimizer
