"""
System monitoring module for OPSC Sandwich Quality Inspection System.
Provides monitoring and alerting for system components.

Version: 1.0.0
Last Updated: 2025-04-20
"""

import os
import sys
import time
import json
import logging
import threading
import queue
import socket
import platform
import subprocess
import psutil
import datetime
from typing import Dict, List, Optional, Tuple, Union, Any, Callable, Iterator
import numpy as np
from dataclasses import dataclass, field
from enum import Enum
import uuid
from pathlib import Path
import concurrent.futures
import asyncio
import re
import traceback
import signal
import warnings
import tempfile
import shutil
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication

# Import GPU monitoring libraries
try:
    import GPUtil
    GPU_UTIL_AVAILABLE = True
except ImportError:
    GPU_UTIL_AVAILABLE = False
    # Install GPUtil if not available
    try:
        import subprocess
        subprocess.check_call([sys.executable, "-m", "pip", "install", "gputil==1.4.0"])
        import GPUtil
        GPU_UTIL_AVAILABLE = True
    except:
        pass

# Import NVIDIA monitoring libraries
try:
    import pynvml
    NVML_AVAILABLE = True
except ImportError:
    NVML_AVAILABLE = False
    # Install pynvml if not available
    try:
        import subprocess
        subprocess.check_call([sys.executable, "-m", "pip", "install", "pynvml==11.5.0"])
        import pynvml
        NVML_AVAILABLE = True
    except:
        pass

# Import Prometheus client
try:
    from prometheus_client import start_http_server, Gauge, Counter, Summary, Histogram, Info
    PROMETHEUS_AVAILABLE = True
except ImportError:
    PROMETHEUS_AVAILABLE = False
    # Install prometheus_client if not available
    try:
        import subprocess
        subprocess.check_call([sys.executable, "-m", "pip", "install", "prometheus_client==0.17.1"])
        from prometheus_client import start_http_server, Gauge, Counter, Summary, Histogram, Info
        PROMETHEUS_AVAILABLE = True
    except:
        pass

from ...utils.config import get_config
from ...utils.logging import setup_logging, log_exception
from ...core.data.database import get_database_manager, EventType
from ...core.camera.basler_manager import get_camera_manager
from ...core.inference.model_manager import get_model_manager
from ...core.inference.jetson_client import get_jetson_client

# Setup logging
logger = setup_logging(__name__)


class MonitoringError(Exception):
    """Base exception for monitoring errors."""
    pass


class AlertingError(Exception):
    """Base exception for alerting errors."""
    pass


class ResourceType(Enum):
    """Types of resources to monitor."""
    CPU = "cpu"
    MEMORY = "memory"
    DISK = "disk"
    GPU = "gpu"
    NETWORK = "network"
    CAMERA = "camera"
    JETSON = "jetson"
    DATABASE = "database"
    APPLICATION = "application"


class AlertLevel(Enum):
    """Alert levels."""
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


class AlertChannel(Enum):
    """Alert channels."""
    EMAIL = "email"
    SMS = "sms"
    DASHBOARD = "dashboard"
    DATABASE = "database"
    WEBHOOK = "webhook"


@dataclass
class ResourceMetric:
    """Resource metric data."""
    name: str
    value: float
    unit: str
    timestamp: float = field(default_factory=time.time)
    resource_type: ResourceType = ResourceType.APPLICATION
    labels: Dict[str, str] = field(default_factory=dict)


@dataclass
class Alert:
    """Alert data."""
    level: AlertLevel
    resource_type: ResourceType
    message: str
    details: Dict[str, Any]
    timestamp: float = field(default_factory=time.time)
    alert_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    resolved: bool = False
    resolved_timestamp: Optional[float] = None
    resolution_message: Optional[str] = None


class SystemMonitor:
    """
    System monitoring class for OPSC Sandwich Quality Inspection System.
    Monitors system resources, components, and performance.
    """
    
    def __init__(self):
        """Initialize system monitor."""
        # Load configuration
        self.config = get_config("monitoring", {})
        
        # Set monitoring parameters
        self.enabled = self.config.get("enabled", True)
        self.interval = self.config.get("interval", 10)  # seconds
        self.history_size = self.config.get("history_size", 1000)
        self.prometheus_enabled = self.config.get("prometheus", {}).get("enabled", False)
        self.prometheus_port = self.config.get("prometheus", {}).get("port", 9090)
        
        # Set alerting parameters
        self.alerting_enabled = self.config.get("alerting", {}).get("enabled", True)
        self.alert_channels = self.config.get("alerting", {}).get("channels", ["dashboard", "database"])
        self.email_config = self.config.get("alerting", {}).get("email", {})
        self.sms_config = self.config.get("alerting", {}).get("sms", {})
        self.webhook_config = self.config.get("alerting", {}).get("webhook", {})
        
        # Set thresholds
        self.thresholds = self.config.get("thresholds", {})
        
        # Initialize metrics storage
        self.metrics: Dict[str, List[ResourceMetric]] = {}
        self.alerts: List[Alert] = []
        
        # Initialize locks
        self.metrics_lock = threading.Lock()
        self.alerts_lock = threading.Lock()
        
        # Initialize monitoring thread
        self.monitoring_thread = None
        self.stop_event = threading.Event()
        
        # Initialize Prometheus metrics if enabled
        self.prometheus_metrics = {}
        if self.prometheus_enabled and PROMETHEUS_AVAILABLE:
            self._init_prometheus_metrics()
        
        # Initialize components
        self.db_manager = None
        self.camera_manager = None
        self.model_manager = None
        self.jetson_client = None
        
        # Initialize NVML if available
        if NVML_AVAILABLE:
            try:
                pynvml.nvmlInit()
                self.nvml_initialized = True
            except:
                self.nvml_initialized = False
        else:
            self.nvml_initialized = False
        
        logger.info("Initialized system monitor")
    
    def _init_prometheus_metrics(self):
        """Initialize Prometheus metrics."""
        # System metrics
        self.prometheus_metrics["cpu_usage"] = Gauge("opsc_cpu_usage_percent", "CPU usage in percent")
        self.prometheus_metrics["memory_usage"] = Gauge("opsc_memory_usage_percent", "Memory usage in percent")
        self.prometheus_metrics["disk_usage"] = Gauge("opsc_disk_usage_percent", "Disk usage in percent", ["mount"])
        
        # GPU metrics
        if GPU_UTIL_AVAILABLE or NVML_AVAILABLE:
            self.prometheus_metrics["gpu_usage"] = Gauge("opsc_gpu_usage_percent", "GPU usage in percent", ["gpu"])
            self.prometheus_metrics["gpu_memory_usage"] = Gauge("opsc_gpu_memory_usage_percent", "GPU memory usage in percent", ["gpu"])
            self.prometheus_metrics["gpu_temperature"] = Gauge("opsc_gpu_temperature_celsius", "GPU temperature in Celsius", ["gpu"])
        
        # Network metrics
        self.prometheus_metrics["network_bytes_sent"] = Counter("opsc_network_bytes_sent_total", "Network bytes sent", ["interface"])
        self.prometheus_metrics["network_bytes_recv"] = Counter("opsc_network_bytes_recv_total", "Network bytes received", ["interface"])
        
        # Camera metrics
        self.prometheus_metrics["camera_status"] = Gauge("opsc_camera_status", "Camera status (1=connected, 0=disconnected)", ["camera"])
        self.prometheus_metrics["camera_fps"] = Gauge("opsc_camera_fps", "Camera frames per second", ["camera"])
        self.prometheus_metrics["camera_temperature"] = Gauge("opsc_camera_temperature_celsius", "Camera temperature in Celsius", ["camera"])
        
        # Jetson metrics
        self.prometheus_metrics["jetson_status"] = Gauge("opsc_jetson_status", "Jetson status (1=connected, 0=disconnected)")
        self.prometheus_metrics["jetson_cpu_usage"] = Gauge("opsc_jetson_cpu_usage_percent", "Jetson CPU usage in percent")
        self.prometheus_metrics["jetson_memory_usage"] = Gauge("opsc_jetson_memory_usage_percent", "Jetson memory usage in percent")
        self.prometheus_metrics["jetson_gpu_usage"] = Gauge("opsc_jetson_gpu_usage_percent", "Jetson GPU usage in percent")
        self.prometheus_metrics["jetson_temperature"] = Gauge("opsc_jetson_temperature_celsius", "Jetson temperature in Celsius")
        
        # Database metrics
        self.prometheus_metrics["database_size"] = Gauge("opsc_database_size_bytes", "Database size in bytes")
        self.prometheus_metrics["image_storage_size"] = Gauge("opsc_image_storage_size_bytes", "Image storage size in bytes")
        
        # Application metrics
        self.prometheus_metrics["inspection_count"] = Counter("opsc_inspection_count_total", "Total number of inspections")
        self.prometheus_metrics["defect_count"] = Counter("opsc_defect_count_total", "Total number of defects", ["defect_type"])
        self.prometheus_metrics["processing_time"] = Histogram("opsc_processing_time_seconds", "Processing time in seconds")
        
        # Alert metrics
        self.prometheus_metrics["alert_count"] = Counter("opsc_alert_count_total", "Total number of alerts", ["level", "resource_type"])
        
        # System info
        self.prometheus_metrics["system_info"] = Info("opsc_system_info", "System information")
        self.prometheus_metrics["system_info"].info({
            "version": "1.0.0",
            "platform": platform.platform(),
            "python_version": platform.python_version(),
            "hostname": socket.gethostname()
        })
        
        # Start Prometheus HTTP server
        start_http_server(self.prometheus_port)
        logger.info(f"Started Prometheus HTTP server on port {self.prometheus_port}")
    
    def start(self):
        """Start monitoring."""
        if not self.enabled:
            logger.info("Monitoring is disabled")
            return
        
        if self.monitoring_thread and self.monitoring_thread.is_alive():
            logger.warning("Monitoring thread is already running")
            return
        
        # Initialize components
        self.db_manager = get_database_manager()
        self.camera_manager = get_camera_manager()
        self.model_manager = get_model_manager()
        self.jetson_client = get_jetson_client()
        
        # Reset stop event
        self.stop_event.clear()
        
        # Start monitoring thread
        self.monitoring_thread = threading.Thread(target=self._monitoring_loop, daemon=True)
        self.monitoring_thread.start()
        
        logger.info("Started system monitoring")
    
    def stop(self):
        """Stop monitoring."""
        if not self.monitoring_thread or not self.monitoring_thread.is_alive():
            logger.warning("Monitoring thread is not running")
            return
        
        # Set stop event
        self.stop_event.set()
        
        # Wait for thread to stop
        self.monitoring_thread.join(timeout=5)
        
        if self.monitoring_thread.is_alive():
            logger.warning("Monitoring thread did not stop gracefully")
        else:
            logger.info("Stopped system monitoring")
        
        # Shutdown NVML if initialized
        if self.nvml_initialized:
            try:
                pynvml.nvmlShutdown()
            except:
                pass
    
    def _monitoring_loop(self):
        """Main monitoring loop."""
        last_run_time = 0
        
        while not self.stop_event.is_set():
            try:
                # Calculate sleep time to maintain consistent interval
                current_time = time.time()
                sleep_time = max(0, self.interval - (current_time - last_run_time))
                
                if sleep_time > 0:
                    # Sleep with check for stop event
                    if self.stop_event.wait(sleep_time):
                        break
                
                # Record start time
                last_run_time = time.time()
                
                # Collect metrics
                self._collect_system_metrics()
                self._collect_gpu_metrics()
                self._collect_network_metrics()
                self._collect_camera_metrics()
                self._collect_jetson_metrics()
                self._collect_database_metrics()
                self._collect_application_metrics()
                
                # Check thresholds and generate alerts
                self._check_thresholds()
                
                # Update Prometheus metrics if enabled
                if self.prometheus_enabled and PROMETHEUS_AVAILABLE:
                    self._update_prometheus_metrics()
                
            except Exception as e:
                logger.error(f"Error in monitoring loop: {e}")
                log_exception(e)
    
    def _collect_system_metrics(self):
        """Collect system metrics (CPU, memory, disk)."""
        try:
            # Collect CPU metrics
            cpu_percent = psutil.cpu_percent(interval=1)
            self.add_metric(ResourceMetric(
                name="cpu_usage",
                value=cpu_percent,
                unit="percent",
                resource_type=ResourceType.CPU
            ))
            
            # Collect per-core CPU metrics
            cpu_percent_per_core = psutil.cpu_percent(interval=0, percpu=True)
            for i, percent in enumerate(cpu_percent_per_core):
                self.add_metric(ResourceMetric(
                    name=f"cpu_core_{i}_usage",
                    value=percent,
                    unit="percent",
                    resource_type=ResourceType.CPU,
                    labels={"core": str(i)}
                ))
            
            # Collect memory metrics
            memory = psutil.virtual_memory()
            self.add_metric(ResourceMetric(
                name="memory_usage",
                value=memory.percent,
                unit="percent",
                resource_type=ResourceType.MEMORY
            ))
            self.add_metric(ResourceMetric(
                name="memory_available",
                value=memory.available,
                unit="bytes",
                resource_type=ResourceType.MEMORY
            ))
            self.add_metric(ResourceMetric(
                name="memory_used",
                value=memory.used,
                unit="bytes",
                resource_type=ResourceType.MEMORY
            ))
            
            # Collect disk metrics
            for partition in psutil.disk_partitions():
                if partition.mountpoint:
                    try:
                        usage = psutil.disk_usage(partition.mountpoint)
                        self.add_metric(ResourceMetric(
                            name=f"disk_usage_{partition.mountpoint.replace('/', '_')}",
                            value=usage.percent,
                            unit="percent",
                            resource_type=ResourceType.DISK,
                            labels={"mountpoint": partition.mountpoint}
                        ))
                        self.add_metric(ResourceMetric(
                            name=f"disk_free_{partition.mountpoint.replace('/', '_')}",
                            value=usage.free,
                            unit="bytes",
                            resource_type=ResourceType.DISK,
                            labels={"mountpoint": partition.mountpoint}
                        ))
                    except PermissionError:
                        # Skip partitions that can't be accessed
                        pass
            
            # Collect load average
            load1, load5, load15 = psutil.getloadavg()
            self.add_metric(ResourceMetric(
                name="load_average_1min",
                value=load1,
                unit="load",
                resource_type=ResourceType.CPU
            ))
            self.add_metric(ResourceMetric(
                name="load_average_5min",
                value=load5,
                unit="load",
                resource_type=ResourceType.CPU
            ))
            self.add_metric(ResourceMetric(
                name="load_average_15min",
                value=load15,
                unit="load",
                resource_type=ResourceType.CPU
            ))
            
        except Exception as e:
            logger.error(f"Error collecting system metrics: {e}")
            log_exception(e)
    
    def _collect_gpu_metrics(self):
        """Collect GPU metrics."""
        try:
            # Try using NVML first (more detailed)
            if self.nvml_initialized:
                try:
                    device_count = pynvml.nvmlDeviceGetCount()
                    
                    for i in range(device_count):
                        handle = pynvml.nvmlDeviceGetHandleByIndex(i)
                        
                        # Get device name
                        name = pynvml.nvmlDeviceGetName(handle).decode('utf-8')
                        
                        # Get utilization
                        utilization = pynvml.nvmlDeviceGetUtilizationRates(handle)
                        self.add_metric(ResourceMetric(
                            name=f"gpu_{i}_usage",
                            value=utilization.gpu,
                            unit="percent",
                            resource_type=ResourceType.GPU,
                            labels={"gpu": str(i), "name": name}
                        ))
                        self.add_metric(ResourceMetric(
                            name=f"gpu_{i}_memory_usage",
                            value=utilization.memory,
                            unit="percent",
                            resource_type=ResourceType.GPU,
                            labels={"gpu": str(i), "name": name}
                        ))
                        
                        # Get memory info
                        memory = pynvml.nvmlDeviceGetMemoryInfo(handle)
                        self.add_metric(ResourceMetric(
                            name=f"gpu_{i}_memory_used",
                            value=memory.used,
                            unit="bytes",
                            resource_type=ResourceType.GPU,
                            labels={"gpu": str(i), "name": name}
                        ))
                        self.add_metric(ResourceMetric(
                            name=f"gpu_{i}_memory_total",
                            value=memory.total,
                            unit="bytes",
                            resource_type=ResourceType.GPU,
                            labels={"gpu": str(i), "name": name}
                        ))
                        
                        # Get temperature
                        temperature = pynvml.nvmlDeviceGetTemperature(handle, pynvml.NVML_TEMPERATURE_GPU)
                        self.add_metric(ResourceMetric(
                            name=f"gpu_{i}_temperature",
                            value=temperature,
                            unit="celsius",
                            resource_type=ResourceType.GPU,
                            labels={"gpu": str(i), "name": name}
                        ))
                        
                        # Get power usage
                        try:
                            power_usage = pynvml.nvmlDeviceGetPowerUsage(handle) / 1000.0  # Convert from mW to W
                            self.add_metric(ResourceMetric(
                                name=f"gpu_{i}_power_usage",
                                value=power_usage,
                                unit="watts",
                                resource_type=ResourceType.GPU,
                                labels={"gpu": str(i), "name": name}
                            ))
                        except:
                            # Power usage may not be available on all GPUs
                            pass
                        
                        # Get fan speed
                        try:
                            fan_speed = pynvml.nvmlDeviceGetFanSpeed(handle)
                            self.add_metric(ResourceMetric(
                                name=f"gpu_{i}_fan_speed",
                                value=fan_speed,
                                unit="percent",
                                resource_type=ResourceType.GPU,
                                labels={"gpu": str(i), "name": name}
                            ))
                        except:
                            # Fan speed may not be available on all GPUs
                            pass
                    
                    return  # If NVML worked, don't try GPUtil
                except Exception as e:
                    logger.warning(f"Error collecting GPU metrics with NVML: {e}")
            
            # Fall back to GPUtil
            if GPU_UTIL_AVAILABLE:
                try:
                    gpus = GPUtil.getGPUs()
                    
                    for i, gpu in enumerate(gpus):
                        self.add_metric(ResourceMetric(
                            name=f"gpu_{i}_usage",
                            value=gpu.load * 100,  # Convert to percentage
                            unit="percent",
                            resource_type=ResourceType.GPU,
                            labels={"gpu": str(i), "name": gpu.name}
                        ))
                        self.add_metric(ResourceMetric(
                            name=f"gpu_{i}_memory_usage",
                            value=gpu.memoryUtil * 100,  # Convert to percentage
                            unit="percent",
                            resource_type=ResourceType.GPU,
                            labels={"gpu": str(i), "name": gpu.name}
                        ))
                        self.add_metric(ResourceMetric(
                            name=f"gpu_{i}_temperature",
                            value=gpu.temperature,
                            unit="celsius",
                            resource_type=ResourceType.GPU,
                            labels={"gpu": str(i), "name": gpu.name}
                        ))
                except Exception as e:
                    logger.warning(f"Error collecting GPU metrics with GPUtil: {e}")
        
        except Exception as e:
            logger.error(f"Error collecting GPU metrics: {e}")
            log_exception(e)
    
    def _collect_network_metrics(self):
        """Collect network metrics."""
        try:
            # Get network counters
            net_io = psutil.net_io_counters(pernic=True)
            
            for interface, counters in net_io.items():
                # Skip loopback interface
                if interface == "lo":
                    continue
                
                self.add_metric(ResourceMetric(
                    name=f"network_{interface}_bytes_sent",
                    value=counters.bytes_sent,
                    unit="bytes",
                    resource_type=ResourceType.NETWORK,
                    labels={"interface": interface}
                ))
                self.add_metric(ResourceMetric(
                    name=f"network_{interface}_bytes_recv",
                    value=counters.bytes_recv,
                    unit="bytes",
                    resource_type=ResourceType.NETWORK,
                    labels={"interface": interface}
                ))
                self.add_metric(ResourceMetric(
                    name=f"network_{interface}_packets_sent",
                    value=counters.packets_sent,
                    unit="packets",
                    resource_type=ResourceType.NETWORK,
                    labels={"interface": interface}
                ))
                self.add_metric(ResourceMetric(
                    name=f"network_{interface}_packets_recv",
                    value=counters.packets_recv,
                    unit="packets",
                    resource_type=ResourceType.NETWORK,
                    labels={"interface": interface}
                ))
                self.add_metric(ResourceMetric(
                    name=f"network_{interface}_errin",
                    value=counters.errin,
                    unit="errors",
                    resource_type=ResourceType.NETWORK,
                    labels={"interface": interface}
                ))
                self.add_metric(ResourceMetric(
                    name=f"network_{interface}_errout",
                    value=counters.errout,
                    unit="errors",
                    resource_type=ResourceType.NETWORK,
                    labels={"interface": interface}
                ))
                self.add_metric(ResourceMetric(
                    name=f"network_{interface}_dropin",
                    value=counters.dropin,
                    unit="packets",
                    resource_type=ResourceType.NETWORK,
                    labels={"interface": interface}
                ))
                self.add_metric(ResourceMetric(
                    name=f"network_{interface}_dropout",
                    value=counters.dropout,
                    unit="packets",
                    resource_type=ResourceType.NETWORK,
                    labels={"interface": interface}
                ))
            
            # Calculate network throughput (bytes/s)
            # This requires comparing with previous values
            for interface in net_io.keys():
                if interface == "lo":
                    continue
                
                # Get previous metrics
                prev_sent_metric = self.get_latest_metric(f"network_{interface}_bytes_sent")
                prev_recv_metric = self.get_latest_metric(f"network_{interface}_bytes_recv")
                
                if prev_sent_metric and prev_recv_metric:
                    # Calculate time difference
                    time_diff = time.time() - prev_sent_metric.timestamp
                    
                    if time_diff > 0:
                        # Calculate throughput
                        sent_throughput = (counters.bytes_sent - prev_sent_metric.value) / time_diff
                        recv_throughput = (counters.bytes_recv - prev_recv_metric.value) / time_diff
                        
                        self.add_metric(ResourceMetric(
                            name=f"network_{interface}_sent_throughput",
                            value=sent_throughput,
                            unit="bytes/s",
                            resource_type=ResourceType.NETWORK,
                            labels={"interface": interface}
                        ))
                        self.add_metric(ResourceMetric(
                            name=f"network_{interface}_recv_throughput",
                            value=recv_throughput,
                            unit="bytes/s",
                            resource_type=ResourceType.NETWORK,
                            labels={"interface": interface}
                        ))
        
        except Exception as e:
            logger.error(f"Error collecting network metrics: {e}")
            log_exception(e)
    
    def _collect_camera_metrics(self):
        """Collect camera metrics."""
        try:
            if not self.camera_manager:
                return
            
            # Get camera list
            cameras = self.camera_manager.list_cameras()
            
            for camera in cameras:
                camera_id = camera["id"]
                
                # Get camera status
                status_value = 1 if camera["status"] == "connected" else 0
                self.add_metric(ResourceMetric(
                    name=f"camera_{camera_id}_status",
                    value=status_value,
                    unit="status",
                    resource_type=ResourceType.CAMERA,
                    labels={"camera": camera_id}
                ))
                
                # Get camera FPS
                if "fps" in camera:
                    self.add_metric(ResourceMetric(
                        name=f"camera_{camera_id}_fps",
                        value=camera["fps"],
                        unit="fps",
                        resource_type=ResourceType.CAMERA,
                        labels={"camera": camera_id}
                    ))
                
                # Get camera temperature if available
                if "temperature" in camera:
                    self.add_metric(ResourceMetric(
                        name=f"camera_{camera_id}_temperature",
                        value=camera["temperature"],
                        unit="celsius",
                        resource_type=ResourceType.CAMERA,
                        labels={"camera": camera_id}
                    ))
                
                # Get camera packet errors if available
                if "packet_errors" in camera:
                    self.add_metric(ResourceMetric(
                        name=f"camera_{camera_id}_packet_errors",
                        value=camera["packet_errors"],
                        unit="errors",
                        resource_type=ResourceType.CAMERA,
                        labels={"camera": camera_id}
                    ))
                
                # Get camera bandwidth usage if available
                if "bandwidth_usage" in camera:
                    self.add_metric(ResourceMetric(
                        name=f"camera_{camera_id}_bandwidth_usage",
                        value=camera["bandwidth_usage"],
                        unit="bytes/s",
                        resource_type=ResourceType.CAMERA,
                        labels={"camera": camera_id}
                    ))
        
        except Exception as e:
            logger.error(f"Error collecting camera metrics: {e}")
            log_exception(e)
    
    def _collect_jetson_metrics(self):
        """Collect Jetson metrics."""
        try:
            if not self.jetson_client:
                return
            
            # Get Jetson status
            status = self.jetson_client.get_status()
            
            # Convert status to numeric value
            status_value = 1 if status == "connected" else 0
            
            self.add_metric(ResourceMetric(
                name="jetson_status",
                value=status_value,
                unit="status",
                resource_type=ResourceType.JETSON
            ))
            
            # If connected, get detailed metrics
            if status == "connected":
                # Get Jetson metrics
                metrics = self.jetson_client.get_metrics()
                
                if metrics:
                    # CPU usage
                    if "cpu_usage" in metrics:
                        self.add_metric(ResourceMetric(
                            name="jetson_cpu_usage",
                            value=metrics["cpu_usage"],
                            unit="percent",
                            resource_type=ResourceType.JETSON
                        ))
                    
                    # Memory usage
                    if "memory_usage" in metrics:
                        self.add_metric(ResourceMetric(
                            name="jetson_memory_usage",
                            value=metrics["memory_usage"],
                            unit="percent",
                            resource_type=ResourceType.JETSON
                        ))
                    
                    # GPU usage
                    if "gpu_usage" in metrics:
                        self.add_metric(ResourceMetric(
                            name="jetson_gpu_usage",
                            value=metrics["gpu_usage"],
                            unit="percent",
                            resource_type=ResourceType.JETSON
                        ))
                    
                    # Temperature
                    if "temperature" in metrics:
                        self.add_metric(ResourceMetric(
                            name="jetson_temperature",
                            value=metrics["temperature"],
                            unit="celsius",
                            resource_type=ResourceType.JETSON
                        ))
                    
                    # Power usage
                    if "power_usage" in metrics:
                        self.add_metric(ResourceMetric(
                            name="jetson_power_usage",
                            value=metrics["power_usage"],
                            unit="watts",
                            resource_type=ResourceType.JETSON
                        ))
                    
                    # Inference performance
                    if "inference_time" in metrics:
                        self.add_metric(ResourceMetric(
                            name="jetson_inference_time",
                            value=metrics["inference_time"],
                            unit="ms",
                            resource_type=ResourceType.JETSON
                        ))
                    
                    # DLA usage
                    if "dla_usage" in metrics:
                        self.add_metric(ResourceMetric(
                            name="jetson_dla_usage",
                            value=metrics["dla_usage"],
                            unit="percent",
                            resource_type=ResourceType.JETSON
                        ))
        
        except Exception as e:
            logger.error(f"Error collecting Jetson metrics: {e}")
            log_exception(e)
    
    def _collect_database_metrics(self):
        """Collect database metrics."""
        try:
            if not self.db_manager:
                return
            
            # Get database size
            db_size = self.db_manager.get_database_size()
            self.add_metric(ResourceMetric(
                name="database_size",
                value=db_size,
                unit="bytes",
                resource_type=ResourceType.DATABASE
            ))
            
            # Get image storage size
            img_size = self.db_manager.get_image_storage_size()
            self.add_metric(ResourceMetric(
                name="image_storage_size",
                value=img_size,
                unit="bytes",
                resource_type=ResourceType.DATABASE
            ))
            
            # Calculate database growth rate
            prev_db_size_metric = self.get_latest_metric("database_size")
            prev_img_size_metric = self.get_latest_metric("image_storage_size")
            
            if prev_db_size_metric and prev_img_size_metric:
                # Calculate time difference
                time_diff = time.time() - prev_db_size_metric.timestamp
                
                if time_diff > 0:
                    # Calculate growth rate
                    db_growth_rate = (db_size - prev_db_size_metric.value) / time_diff
                    img_growth_rate = (img_size - prev_img_size_metric.value) / time_diff
                    
                    self.add_metric(ResourceMetric(
                        name="database_growth_rate",
                        value=db_growth_rate,
                        unit="bytes/s",
                        resource_type=ResourceType.DATABASE
                    ))
                    self.add_metric(ResourceMetric(
                        name="image_storage_growth_rate",
                        value=img_growth_rate,
                        unit="bytes/s",
                        resource_type=ResourceType.DATABASE
                    ))
        
        except Exception as e:
            logger.error(f"Error collecting database metrics: {e}")
            log_exception(e)
    
    def _collect_application_metrics(self):
        """Collect application metrics."""
        try:
            if not self.db_manager:
                return
            
            # Get current timestamp for time-based queries
            now = datetime.datetime.now()
            
            # Get 24 hours ago
            day_ago = now - datetime.timedelta(days=1)
            
            # Get inspection count for last 24 hours
            inspections = self.db_manager.list_inspections(
                start_time=day_ago,
                end_time=now
            )
            
            self.add_metric(ResourceMetric(
                name="inspection_count_24h",
                value=len(inspections),
                unit="count",
                resource_type=ResourceType.APPLICATION
            ))
            
            # Get defect counts for last 24 hours
            defect_counts = self.db_manager.get_defect_counts(
                start_time=day_ago,
                end_time=now,
                group_by="defect_type"
            )
            
            for defect_type, count in defect_counts.items():
                self.add_metric(ResourceMetric(
                    name=f"defect_count_24h_{defect_type}",
                    value=count,
                    unit="count",
                    resource_type=ResourceType.APPLICATION,
                    labels={"defect_type": defect_type}
                ))
            
            # Calculate defect rate
            if inspections:
                defect_rate = sum(defect_counts.values()) / len(inspections) * 100
                self.add_metric(ResourceMetric(
                    name="defect_rate_24h",
                    value=defect_rate,
                    unit="percent",
                    resource_type=ResourceType.APPLICATION
                ))
            
            # Get average processing time
            processing_times = [insp["processing_time"] for insp in inspections if insp["processing_time"] is not None]
            if processing_times:
                avg_processing_time = sum(processing_times) / len(processing_times)
                self.add_metric(ResourceMetric(
                    name="average_processing_time_24h",
                    value=avg_processing_time,
                    unit="ms",
                    resource_type=ResourceType.APPLICATION
                ))
        
        except Exception as e:
            logger.error(f"Error collecting application metrics: {e}")
            log_exception(e)
    
    def _check_thresholds(self):
        """Check thresholds and generate alerts."""
        try:
            # CPU usage threshold
            cpu_threshold = self.thresholds.get("cpu_usage", 90)
            cpu_metric = self.get_latest_metric("cpu_usage")
            if cpu_metric and cpu_metric.value > cpu_threshold:
                self._create_alert(
                    level=AlertLevel.WARNING,
                    resource_type=ResourceType.CPU,
                    message=f"CPU usage above threshold: {cpu_metric.value:.1f}% (threshold: {cpu_threshold}%)",
                    details={
                        "metric": "cpu_usage",
                        "value": cpu_metric.value,
                        "threshold": cpu_threshold,
                        "unit": "percent"
                    }
                )
            
            # Memory usage threshold
            memory_threshold = self.thresholds.get("memory_usage", 90)
            memory_metric = self.get_latest_metric("memory_usage")
            if memory_metric and memory_metric.value > memory_threshold:
                self._create_alert(
                    level=AlertLevel.WARNING,
                    resource_type=ResourceType.MEMORY,
                    message=f"Memory usage above threshold: {memory_metric.value:.1f}% (threshold: {memory_threshold}%)",
                    details={
                        "metric": "memory_usage",
                        "value": memory_metric.value,
                        "threshold": memory_threshold,
                        "unit": "percent"
                    }
                )
            
            # Disk usage thresholds
            disk_threshold = self.thresholds.get("disk_usage", 90)
            for metric in self.get_metrics_by_type(ResourceType.DISK):
                if metric.name.startswith("disk_usage_") and metric.value > disk_threshold:
                    mountpoint = metric.labels.get("mountpoint", "unknown")
                    self._create_alert(
                        level=AlertLevel.WARNING,
                        resource_type=ResourceType.DISK,
                        message=f"Disk usage above threshold for {mountpoint}: {metric.value:.1f}% (threshold: {disk_threshold}%)",
                        details={
                            "metric": metric.name,
                            "value": metric.value,
                            "threshold": disk_threshold,
                            "unit": "percent",
                            "mountpoint": mountpoint
                        }
                    )
            
            # GPU temperature threshold
            gpu_temp_threshold = self.thresholds.get("gpu_temperature", 85)
            for metric in self.get_metrics_by_type(ResourceType.GPU):
                if metric.name.endswith("_temperature") and metric.value > gpu_temp_threshold:
                    gpu_id = metric.labels.get("gpu", "unknown")
                    gpu_name = metric.labels.get("name", "unknown")
                    self._create_alert(
                        level=AlertLevel.WARNING,
                        resource_type=ResourceType.GPU,
                        message=f"GPU temperature above threshold for GPU {gpu_id} ({gpu_name}): {metric.value:.1f}°C (threshold: {gpu_temp_threshold}°C)",
                        details={
                            "metric": metric.name,
                            "value": metric.value,
                            "threshold": gpu_temp_threshold,
                            "unit": "celsius",
                            "gpu_id": gpu_id,
                            "gpu_name": gpu_name
                        }
                    )
            
            # GPU usage threshold
            gpu_usage_threshold = self.thresholds.get("gpu_usage", 95)
            for metric in self.get_metrics_by_type(ResourceType.GPU):
                if metric.name.endswith("_usage") and metric.value > gpu_usage_threshold:
                    gpu_id = metric.labels.get("gpu", "unknown")
                    gpu_name = metric.labels.get("name", "unknown")
                    self._create_alert(
                        level=AlertLevel.WARNING,
                        resource_type=ResourceType.GPU,
                        message=f"GPU usage above threshold for GPU {gpu_id} ({gpu_name}): {metric.value:.1f}% (threshold: {gpu_usage_threshold}%)",
                        details={
                            "metric": metric.name,
                            "value": metric.value,
                            "threshold": gpu_usage_threshold,
                            "unit": "percent",
                            "gpu_id": gpu_id,
                            "gpu_name": gpu_name
                        }
                    )
            
            # Camera status check
            for metric in self.get_metrics_by_type(ResourceType.CAMERA):
                if metric.name.endswith("_status") and metric.value == 0:
                    camera_id = metric.labels.get("camera", "unknown")
                    self._create_alert(
                        level=AlertLevel.ERROR,
                        resource_type=ResourceType.CAMERA,
                        message=f"Camera {camera_id} is disconnected",
                        details={
                            "metric": metric.name,
                            "value": metric.value,
                            "camera_id": camera_id
                        }
                    )
            
            # Jetson status check
            jetson_status_metric = self.get_latest_metric("jetson_status")
            if jetson_status_metric and jetson_status_metric.value == 0:
                self._create_alert(
                    level=AlertLevel.ERROR,
                    resource_type=ResourceType.JETSON,
                    message="Jetson device is disconnected",
                    details={
                        "metric": "jetson_status",
                        "value": jetson_status_metric.value
                    }
                )
            
            # Jetson temperature threshold
            jetson_temp_threshold = self.thresholds.get("jetson_temperature", 85)
            jetson_temp_metric = self.get_latest_metric("jetson_temperature")
            if jetson_temp_metric and jetson_temp_metric.value > jetson_temp_threshold:
                self._create_alert(
                    level=AlertLevel.WARNING,
                    resource_type=ResourceType.JETSON,
                    message=f"Jetson temperature above threshold: {jetson_temp_metric.value:.1f}°C (threshold: {jetson_temp_threshold}°C)",
                    details={
                        "metric": "jetson_temperature",
                        "value": jetson_temp_metric.value,
                        "threshold": jetson_temp_threshold,
                        "unit": "celsius"
                    }
                )
            
            # Database size threshold
            db_size_threshold = self.thresholds.get("database_size", 1024 * 1024 * 1024)  # 1 GB default
            db_size_metric = self.get_latest_metric("database_size")
            if db_size_metric and db_size_metric.value > db_size_threshold:
                self._create_alert(
                    level=AlertLevel.WARNING,
                    resource_type=ResourceType.DATABASE,
                    message=f"Database size above threshold: {db_size_metric.value / (1024 * 1024):.1f} MB (threshold: {db_size_threshold / (1024 * 1024):.1f} MB)",
                    details={
                        "metric": "database_size",
                        "value": db_size_metric.value,
                        "threshold": db_size_threshold,
                        "unit": "bytes"
                    }
                )
            
            # Image storage size threshold
            img_size_threshold = self.thresholds.get("image_storage_size", 10 * 1024 * 1024 * 1024)  # 10 GB default
            img_size_metric = self.get_latest_metric("image_storage_size")
            if img_size_metric and img_size_metric.value > img_size_threshold:
                self._create_alert(
                    level=AlertLevel.WARNING,
                    resource_type=ResourceType.DATABASE,
                    message=f"Image storage size above threshold: {img_size_metric.value / (1024 * 1024 * 1024):.1f} GB (threshold: {img_size_threshold / (1024 * 1024 * 1024):.1f} GB)",
                    details={
                        "metric": "image_storage_size",
                        "value": img_size_metric.value,
                        "threshold": img_size_threshold,
                        "unit": "bytes"
                    }
                )
            
            # Defect rate threshold
            defect_rate_threshold = self.thresholds.get("defect_rate", 10)  # 10% default
            defect_rate_metric = self.get_latest_metric("defect_rate_24h")
            if defect_rate_metric and defect_rate_metric.value > defect_rate_threshold:
                self._create_alert(
                    level=AlertLevel.WARNING,
                    resource_type=ResourceType.APPLICATION,
                    message=f"Defect rate above threshold: {defect_rate_metric.value:.1f}% (threshold: {defect_rate_threshold}%)",
                    details={
                        "metric": "defect_rate_24h",
                        "value": defect_rate_metric.value,
                        "threshold": defect_rate_threshold,
                        "unit": "percent"
                    }
                )
            
            # Processing time threshold
            processing_time_threshold = self.thresholds.get("processing_time", 100)  # 100 ms default
            processing_time_metric = self.get_latest_metric("average_processing_time_24h")
            if processing_time_metric and processing_time_metric.value > processing_time_threshold:
                self._create_alert(
                    level=AlertLevel.WARNING,
                    resource_type=ResourceType.APPLICATION,
                    message=f"Average processing time above threshold: {processing_time_metric.value:.1f} ms (threshold: {processing_time_threshold} ms)",
                    details={
                        "metric": "average_processing_time_24h",
                        "value": processing_time_metric.value,
                        "threshold": processing_time_threshold,
                        "unit": "ms"
                    }
                )
        
        except Exception as e:
            logger.error(f"Error checking thresholds: {e}")
            log_exception(e)
    
    def _update_prometheus_metrics(self):
        """Update Prometheus metrics."""
        try:
            if not PROMETHEUS_AVAILABLE:
                return
            
            # System metrics
            cpu_metric = self.get_latest_metric("cpu_usage")
            if cpu_metric:
                self.prometheus_metrics["cpu_usage"].set(cpu_metric.value)
            
            memory_metric = self.get_latest_metric("memory_usage")
            if memory_metric:
                self.prometheus_metrics["memory_usage"].set(memory_metric.value)
            
            # Disk metrics
            for metric in self.get_metrics_by_type(ResourceType.DISK):
                if metric.name.startswith("disk_usage_"):
                    mountpoint = metric.labels.get("mountpoint", "unknown")
                    self.prometheus_metrics["disk_usage"].labels(mountpoint).set(metric.value)
            
            # GPU metrics
            if "gpu_usage" in self.prometheus_metrics:
                for metric in self.get_metrics_by_type(ResourceType.GPU):
                    if metric.name.endswith("_usage"):
                        gpu_id = metric.labels.get("gpu", "unknown")
                        self.prometheus_metrics["gpu_usage"].labels(gpu_id).set(metric.value)
                    elif metric.name.endswith("_memory_usage"):
                        gpu_id = metric.labels.get("gpu", "unknown")
                        self.prometheus_metrics["gpu_memory_usage"].labels(gpu_id).set(metric.value)
                    elif metric.name.endswith("_temperature"):
                        gpu_id = metric.labels.get("gpu", "unknown")
                        self.prometheus_metrics["gpu_temperature"].labels(gpu_id).set(metric.value)
            
            # Network metrics
            for metric in self.get_metrics_by_type(ResourceType.NETWORK):
                if metric.name.endswith("_bytes_sent"):
                    interface = metric.labels.get("interface", "unknown")
                    self.prometheus_metrics["network_bytes_sent"].labels(interface).inc(
                        metric.value - self.get_previous_metric(metric.name, 0).value
                    )
                elif metric.name.endswith("_bytes_recv"):
                    interface = metric.labels.get("interface", "unknown")
                    self.prometheus_metrics["network_bytes_recv"].labels(interface).inc(
                        metric.value - self.get_previous_metric(metric.name, 0).value
                    )
            
            # Camera metrics
            for metric in self.get_metrics_by_type(ResourceType.CAMERA):
                if metric.name.endswith("_status"):
                    camera_id = metric.labels.get("camera", "unknown")
                    self.prometheus_metrics["camera_status"].labels(camera_id).set(metric.value)
                elif metric.name.endswith("_fps"):
                    camera_id = metric.labels.get("camera", "unknown")
                    self.prometheus_metrics["camera_fps"].labels(camera_id).set(metric.value)
                elif metric.name.endswith("_temperature"):
                    camera_id = metric.labels.get("camera", "unknown")
                    self.prometheus_metrics["camera_temperature"].labels(camera_id).set(metric.value)
            
            # Jetson metrics
            jetson_status_metric = self.get_latest_metric("jetson_status")
            if jetson_status_metric:
                self.prometheus_metrics["jetson_status"].set(jetson_status_metric.value)
            
            jetson_cpu_metric = self.get_latest_metric("jetson_cpu_usage")
            if jetson_cpu_metric:
                self.prometheus_metrics["jetson_cpu_usage"].set(jetson_cpu_metric.value)
            
            jetson_memory_metric = self.get_latest_metric("jetson_memory_usage")
            if jetson_memory_metric:
                self.prometheus_metrics["jetson_memory_usage"].set(jetson_memory_metric.value)
            
            jetson_gpu_metric = self.get_latest_metric("jetson_gpu_usage")
            if jetson_gpu_metric:
                self.prometheus_metrics["jetson_gpu_usage"].set(jetson_gpu_metric.value)
            
            jetson_temp_metric = self.get_latest_metric("jetson_temperature")
            if jetson_temp_metric:
                self.prometheus_metrics["jetson_temperature"].set(jetson_temp_metric.value)
            
            # Database metrics
            db_size_metric = self.get_latest_metric("database_size")
            if db_size_metric:
                self.prometheus_metrics["database_size"].set(db_size_metric.value)
            
            img_size_metric = self.get_latest_metric("image_storage_size")
            if img_size_metric:
                self.prometheus_metrics["image_storage_size"].set(img_size_metric.value)
            
            # Application metrics
            inspection_count_metric = self.get_latest_metric("inspection_count_24h")
            if inspection_count_metric:
                # Update counter with difference from previous value
                prev_value = self.get_previous_metric("inspection_count_24h", 0).value
                self.prometheus_metrics["inspection_count"].inc(inspection_count_metric.value - prev_value)
            
            # Defect counts by type
            for metric in self.get_metrics_by_resource_type(ResourceType.APPLICATION):
                if metric.name.startswith("defect_count_24h_"):
                    defect_type = metric.name.replace("defect_count_24h_", "")
                    prev_value = self.get_previous_metric(metric.name, 0).value
                    self.prometheus_metrics["defect_count"].labels(defect_type).inc(metric.value - prev_value)
            
            # Processing time
            processing_time_metric = self.get_latest_metric("average_processing_time_24h")
            if processing_time_metric:
                self.prometheus_metrics["processing_time"].observe(processing_time_metric.value / 1000)  # Convert ms to seconds
        
        except Exception as e:
            logger.error(f"Error updating Prometheus metrics: {e}")
            log_exception(e)
    
    def add_metric(self, metric: ResourceMetric) -> None:
        """
        Add a metric to the metrics storage.
        
        Args:
            metric: Metric to add.
        """
        with self.metrics_lock:
            if metric.name not in self.metrics:
                self.metrics[metric.name] = []
            
            # Add metric to list
            self.metrics[metric.name].append(metric)
            
            # Trim list if it exceeds history size
            if len(self.metrics[metric.name]) > self.history_size:
                self.metrics[metric.name] = self.metrics[metric.name][-self.history_size:]
    
    def get_latest_metric(self, name: str) -> Optional[ResourceMetric]:
        """
        Get the latest metric with the given name.
        
        Args:
            name: Metric name.
            
        Returns:
            Latest metric or None if not found.
        """
        with self.metrics_lock:
            if name in self.metrics and self.metrics[name]:
                return self.metrics[name][-1]
            return None
    
    def get_previous_metric(self, name: str, index: int = 1) -> Optional[ResourceMetric]:
        """
        Get a previous metric with the given name.
        
        Args:
            name: Metric name.
            index: Index from the end (1 = second last, 2 = third last, etc.).
            
        Returns:
            Previous metric or None if not found.
        """
        with self.metrics_lock:
            if name in self.metrics and len(self.metrics[name]) > index:
                return self.metrics[name][-(index + 1)]
            
            # Return a dummy metric with value 0 if not found
            return ResourceMetric(name=name, value=0, unit="unknown")
    
    def get_metrics_by_type(self, resource_type: ResourceType) -> List[ResourceMetric]:
        """
        Get all latest metrics of a specific resource type.
        
        Args:
            resource_type: Resource type.
            
        Returns:
            List of metrics.
        """
        result = []
        
        with self.metrics_lock:
            for name, metrics in self.metrics.items():
                if metrics and metrics[-1].resource_type == resource_type:
                    result.append(metrics[-1])
        
        return result
    
    def get_metrics_by_resource_type(self, resource_type: ResourceType) -> List[ResourceMetric]:
        """
        Get all latest metrics of a specific resource type.
        
        Args:
            resource_type: Resource type.
            
        Returns:
            List of metrics.
        """
        return self.get_metrics_by_type(resource_type)
    
    def get_metric_history(self, name: str, limit: Optional[int] = None) -> List[ResourceMetric]:
        """
        Get the history of a metric.
        
        Args:
            name: Metric name.
            limit: Maximum number of metrics to return.
            
        Returns:
            List of metrics.
        """
        with self.metrics_lock:
            if name in self.metrics:
                if limit:
                    return self.metrics[name][-limit:]
                return self.metrics[name].copy()
            return []
    
    def _create_alert(self, level: AlertLevel, resource_type: ResourceType, message: str, details: Dict[str, Any]) -> Alert:
        """
        Create a new alert.
        
        Args:
            level: Alert level.
            resource_type: Resource type.
            message: Alert message.
            details: Alert details.
            
        Returns:
            Created alert.
        """
        # Create alert
        alert = Alert(
            level=level,
            resource_type=resource_type,
            message=message,
            details=details
        )
        
        # Check if similar alert already exists and is not resolved
        with self.alerts_lock:
            for existing_alert in self.alerts:
                if (
                    existing_alert.level == level and
                    existing_alert.resource_type == resource_type and
                    existing_alert.message == message and
                    not existing_alert.resolved
                ):
                    # Similar alert already exists
                    return existing_alert
            
            # Add alert to list
            self.alerts.append(alert)
        
        # Send alert
        if self.alerting_enabled:
            self._send_alert(alert)
        
        # Log alert
        log_level = logging.INFO
        if level == AlertLevel.WARNING:
            log_level = logging.WARNING
        elif level == AlertLevel.ERROR:
            log_level = logging.ERROR
        elif level == AlertLevel.CRITICAL:
            log_level = logging.CRITICAL
        
        logger.log(log_level, f"Alert: {message}")
        
        # Add to database if enabled
        if "database" in self.alert_channels and self.db_manager:
            try:
                # Convert alert level to event type
                event_type = EventType.INFO
                if level == AlertLevel.WARNING:
                    event_type = EventType.WARNING
                elif level == AlertLevel.ERROR:
                    event_type = EventType.ERROR
                elif level == AlertLevel.CRITICAL:
                    event_type = EventType.CRITICAL
                
                # Add to database
                self.db_manager.add_system_event(
                    event_type=event_type,
                    component=f"monitoring_{resource_type.value}",
                    message=message,
                    details=details
                )
            except Exception as e:
                logger.error(f"Error adding alert to database: {e}")
        
        # Update Prometheus metrics if enabled
        if self.prometheus_enabled and PROMETHEUS_AVAILABLE:
            try:
                self.prometheus_metrics["alert_count"].labels(level.value, resource_type.value).inc()
            except Exception as e:
                logger.error(f"Error updating Prometheus alert metrics: {e}")
        
        return alert
    
    def _send_alert(self, alert: Alert) -> None:
        """
        Send alert through configured channels.
        
        Args:
            alert: Alert to send.
        """
        # Send email alert
        if "email" in self.alert_channels and self.email_config.get("enabled", False):
            self._send_email_alert(alert)
        
        # Send SMS alert
        if "sms" in self.alert_channels and self.sms_config.get("enabled", False):
            self._send_sms_alert(alert)
        
        # Send webhook alert
        if "webhook" in self.alert_channels and self.webhook_config.get("enabled", False):
            self._send_webhook_alert(alert)
    
    def _send_email_alert(self, alert: Alert) -> None:
        """
        Send alert via email.
        
        Args:
            alert: Alert to send.
        """
        try:
            # Get email configuration
            smtp_server = self.email_config.get("smtp_server")
            smtp_port = self.email_config.get("smtp_port", 587)
            smtp_username = self.email_config.get("username")
            smtp_password = self.email_config.get("password")
            sender = self.email_config.get("sender")
            recipients = self.email_config.get("recipients", [])
            
            if not smtp_server or not sender or not recipients:
                logger.warning("Email configuration incomplete, skipping email alert")
                return
            
            # Create message
            msg = MIMEMultipart()
            msg["From"] = sender
            msg["To"] = ", ".join(recipients)
            msg["Subject"] = f"OPSC Vision System Alert: {alert.level.value.upper()} - {alert.resource_type.value}"
            
            # Create message body
            body = f"""
            <html>
            <body>
                <h2>OPSC Vision System Alert</h2>
                <p><strong>Level:</strong> {alert.level.value.upper()}</p>
                <p><strong>Resource:</strong> {alert.resource_type.value}</p>
                <p><strong>Message:</strong> {alert.message}</p>
                <p><strong>Time:</strong> {datetime.datetime.fromtimestamp(alert.timestamp).strftime('%Y-%m-%d %H:%M:%S')}</p>
                <h3>Details:</h3>
                <table border="1">
                    <tr><th>Key</th><th>Value</th></tr>
            """
            
            for key, value in alert.details.items():
                body += f"<tr><td>{key}</td><td>{value}</td></tr>"
            
            body += """
                </table>
            </body>
            </html>
            """
            
            # Attach body
            msg.attach(MIMEText(body, "html"))
            
            # Send email
            with smtplib.SMTP(smtp_server, smtp_port) as server:
                server.starttls()
                if smtp_username and smtp_password:
                    server.login(smtp_username, smtp_password)
                server.send_message(msg)
            
            logger.info(f"Sent email alert: {alert.message}")
        
        except Exception as e:
            logger.error(f"Error sending email alert: {e}")
            log_exception(e)
    
    def _send_sms_alert(self, alert: Alert) -> None:
        """
        Send alert via SMS.
        
        Args:
            alert: Alert to send.
        """
        # SMS implementation would go here
        # This is a placeholder for future implementation
        pass
    
    def _send_webhook_alert(self, alert: Alert) -> None:
        """
        Send alert via webhook.
        
        Args:
            alert: Alert to send.
        """
        try:
            # Get webhook configuration
            webhook_url = self.webhook_config.get("url")
            
            if not webhook_url:
                logger.warning("Webhook URL not configured, skipping webhook alert")
                return
            
            # Create payload
            payload = {
                "level": alert.level.value,
                "resource_type": alert.resource_type.value,
                "message": alert.message,
                "timestamp": alert.timestamp,
                "details": alert.details
            }
            
            # Send webhook
            import requests
            response = requests.post(
                webhook_url,
                json=payload,
                headers={"Content-Type": "application/json"}
            )
            
            if response.status_code >= 400:
                logger.warning(f"Webhook returned error status: {response.status_code}")
            else:
                logger.info(f"Sent webhook alert: {alert.message}")
        
        except Exception as e:
            logger.error(f"Error sending webhook alert: {e}")
            log_exception(e)
    
    def resolve_alert(self, alert_id: str, resolution_message: Optional[str] = None) -> bool:
        """
        Resolve an alert.
        
        Args:
            alert_id: Alert ID.
            resolution_message: Resolution message.
            
        Returns:
            True if alert was resolved, False otherwise.
        """
        with self.alerts_lock:
            for alert in self.alerts:
                if alert.alert_id == alert_id and not alert.resolved:
                    alert.resolved = True
                    alert.resolved_timestamp = time.time()
                    alert.resolution_message = resolution_message
                    
                    logger.info(f"Resolved alert: {alert.message}")
                    
                    return True
            
            return False
    
    def get_active_alerts(self, level: Optional[AlertLevel] = None, resource_type: Optional[ResourceType] = None) -> List[Alert]:
        """
        Get active (unresolved) alerts.
        
        Args:
            level: Filter by alert level.
            resource_type: Filter by resource type.
            
        Returns:
            List of active alerts.
        """
        with self.alerts_lock:
            alerts = [alert for alert in self.alerts if not alert.resolved]
            
            if level:
                alerts = [alert for alert in alerts if alert.level == level]
            
            if resource_type:
                alerts = [alert for alert in alerts if alert.resource_type == resource_type]
            
            return alerts.copy()
    
    def get_all_alerts(self, limit: Optional[int] = None) -> List[Alert]:
        """
        Get all alerts.
        
        Args:
            limit: Maximum number of alerts to return.
            
        Returns:
            List of alerts.
        """
        with self.alerts_lock:
            if limit:
                return self.alerts[-limit:].copy()
            return self.alerts.copy()
    
    def get_system_status(self) -> Dict[str, Any]:
        """
        Get system status.
        
        Returns:
            System status.
        """
        status = {
            "timestamp": time.time(),
            "cpu": {},
            "memory": {},
            "disk": {},
            "gpu": {},
            "network": {},
            "camera": {},
            "jetson": {},
            "database": {},
            "application": {},
            "alerts": {
                "active": len(self.get_active_alerts()),
                "by_level": {
                    "info": len(self.get_active_alerts(level=AlertLevel.INFO)),
                    "warning": len(self.get_active_alerts(level=AlertLevel.WARNING)),
                    "error": len(self.get_active_alerts(level=AlertLevel.ERROR)),
                    "critical": len(self.get_active_alerts(level=AlertLevel.CRITICAL))
                }
            }
        }
        
        # CPU metrics
        cpu_metric = self.get_latest_metric("cpu_usage")
        if cpu_metric:
            status["cpu"]["usage"] = cpu_metric.value
        
        load1_metric = self.get_latest_metric("load_average_1min")
        if load1_metric:
            status["cpu"]["load_1min"] = load1_metric.value
        
        # Memory metrics
        memory_metric = self.get_latest_metric("memory_usage")
        if memory_metric:
            status["memory"]["usage"] = memory_metric.value
        
        memory_available_metric = self.get_latest_metric("memory_available")
        if memory_available_metric:
            status["memory"]["available"] = memory_available_metric.value
        
        # Disk metrics
        status["disk"]["partitions"] = {}
        for metric in self.get_metrics_by_type(ResourceType.DISK):
            if metric.name.startswith("disk_usage_"):
                mountpoint = metric.labels.get("mountpoint", "unknown")
                partition_key = mountpoint.replace("/", "_")
                if partition_key not in status["disk"]["partitions"]:
                    status["disk"]["partitions"][partition_key] = {}
                status["disk"]["partitions"][partition_key]["usage"] = metric.value
            elif metric.name.startswith("disk_free_"):
                mountpoint = metric.labels.get("mountpoint", "unknown")
                partition_key = mountpoint.replace("/", "_")
                if partition_key not in status["disk"]["partitions"]:
                    status["disk"]["partitions"][partition_key] = {}
                status["disk"]["partitions"][partition_key]["free"] = metric.value
        
        # GPU metrics
        status["gpu"]["devices"] = {}
        for metric in self.get_metrics_by_type(ResourceType.GPU):
            if "_usage" in metric.name:
                gpu_id = metric.labels.get("gpu", "unknown")
                if gpu_id not in status["gpu"]["devices"]:
                    status["gpu"]["devices"][gpu_id] = {
                        "name": metric.labels.get("name", "unknown")
                    }
                status["gpu"]["devices"][gpu_id]["usage"] = metric.value
            elif "_memory_usage" in metric.name:
                gpu_id = metric.labels.get("gpu", "unknown")
                if gpu_id not in status["gpu"]["devices"]:
                    status["gpu"]["devices"][gpu_id] = {
                        "name": metric.labels.get("name", "unknown")
                    }
                status["gpu"]["devices"][gpu_id]["memory_usage"] = metric.value
            elif "_temperature" in metric.name:
                gpu_id = metric.labels.get("gpu", "unknown")
                if gpu_id not in status["gpu"]["devices"]:
                    status["gpu"]["devices"][gpu_id] = {
                        "name": metric.labels.get("name", "unknown")
                    }
                status["gpu"]["devices"][gpu_id]["temperature"] = metric.value
        
        # Network metrics
        status["network"]["interfaces"] = {}
        for metric in self.get_metrics_by_type(ResourceType.NETWORK):
            if "_bytes_sent" in metric.name:
                interface = metric.labels.get("interface", "unknown")
                if interface not in status["network"]["interfaces"]:
                    status["network"]["interfaces"][interface] = {}
                status["network"]["interfaces"][interface]["bytes_sent"] = metric.value
            elif "_bytes_recv" in metric.name:
                interface = metric.labels.get("interface", "unknown")
                if interface not in status["network"]["interfaces"]:
                    status["network"]["interfaces"][interface] = {}
                status["network"]["interfaces"][interface]["bytes_recv"] = metric.value
            elif "_sent_throughput" in metric.name:
                interface = metric.labels.get("interface", "unknown")
                if interface not in status["network"]["interfaces"]:
                    status["network"]["interfaces"][interface] = {}
                status["network"]["interfaces"][interface]["sent_throughput"] = metric.value
            elif "_recv_throughput" in metric.name:
                interface = metric.labels.get("interface", "unknown")
                if interface not in status["network"]["interfaces"]:
                    status["network"]["interfaces"][interface] = {}
                status["network"]["interfaces"][interface]["recv_throughput"] = metric.value
        
        # Camera metrics
        status["camera"]["devices"] = {}
        for metric in self.get_metrics_by_type(ResourceType.CAMERA):
            if "_status" in metric.name:
                camera_id = metric.labels.get("camera", "unknown")
                if camera_id not in status["camera"]["devices"]:
                    status["camera"]["devices"][camera_id] = {}
                status["camera"]["devices"][camera_id]["status"] = "connected" if metric.value == 1 else "disconnected"
            elif "_fps" in metric.name:
                camera_id = metric.labels.get("camera", "unknown")
                if camera_id not in status["camera"]["devices"]:
                    status["camera"]["devices"][camera_id] = {}
                status["camera"]["devices"][camera_id]["fps"] = metric.value
            elif "_temperature" in metric.name:
                camera_id = metric.labels.get("camera", "unknown")
                if camera_id not in status["camera"]["devices"]:
                    status["camera"]["devices"][camera_id] = {}
                status["camera"]["devices"][camera_id]["temperature"] = metric.value
        
        # Jetson metrics
        jetson_status_metric = self.get_latest_metric("jetson_status")
        if jetson_status_metric:
            status["jetson"]["status"] = "connected" if jetson_status_metric.value == 1 else "disconnected"
        
        jetson_cpu_metric = self.get_latest_metric("jetson_cpu_usage")
        if jetson_cpu_metric:
            status["jetson"]["cpu_usage"] = jetson_cpu_metric.value
        
        jetson_memory_metric = self.get_latest_metric("jetson_memory_usage")
        if jetson_memory_metric:
            status["jetson"]["memory_usage"] = jetson_memory_metric.value
        
        jetson_gpu_metric = self.get_latest_metric("jetson_gpu_usage")
        if jetson_gpu_metric:
            status["jetson"]["gpu_usage"] = jetson_gpu_metric.value
        
        jetson_temp_metric = self.get_latest_metric("jetson_temperature")
        if jetson_temp_metric:
            status["jetson"]["temperature"] = jetson_temp_metric.value
        
        # Database metrics
        db_size_metric = self.get_latest_metric("database_size")
        if db_size_metric:
            status["database"]["size"] = db_size_metric.value
        
        img_size_metric = self.get_latest_metric("image_storage_size")
        if img_size_metric:
            status["database"]["image_storage_size"] = img_size_metric.value
        
        # Application metrics
        inspection_count_metric = self.get_latest_metric("inspection_count_24h")
        if inspection_count_metric:
            status["application"]["inspection_count_24h"] = inspection_count_metric.value
        
        defect_rate_metric = self.get_latest_metric("defect_rate_24h")
        if defect_rate_metric:
            status["application"]["defect_rate_24h"] = defect_rate_metric.value
        
        processing_time_metric = self.get_latest_metric("average_processing_time_24h")
        if processing_time_metric:
            status["application"]["average_processing_time_24h"] = processing_time_metric.value
        
        return status
    
    def get_metrics_for_dashboard(self) -> Dict[str, Any]:
        """
        Get metrics formatted for dashboard display.
        
        Returns:
            Metrics for dashboard.
        """
        # Get system status
        status = self.get_system_status()
        
        # Add metric history for charts
        metrics = {
            "status": status,
            "history": {
                "cpu_usage": self._format_metric_history("cpu_usage", 60),
                "memory_usage": self._format_metric_history("memory_usage", 60),
                "gpu_usage": {},
                "network_throughput": {},
                "defect_rate": self._format_metric_history("defect_rate_24h", 30)
            }
        }
        
        # Add GPU history
        for gpu_id in status["gpu"]["devices"]:
            metrics["history"]["gpu_usage"][gpu_id] = self._format_metric_history(f"gpu_{gpu_id}_usage", 60)
        
        # Add network history
        for interface in status["network"]["interfaces"]:
            metrics["history"]["network_throughput"][interface] = {
                "sent": self._format_metric_history(f"network_{interface}_sent_throughput", 60),
                "recv": self._format_metric_history(f"network_{interface}_recv_throughput", 60)
            }
        
        return metrics
    
    def _format_metric_history(self, name: str, limit: int) -> List[Dict[str, Any]]:
        """
        Format metric history for charts.
        
        Args:
            name: Metric name.
            limit: Maximum number of points.
            
        Returns:
            Formatted metric history.
        """
        history = self.get_metric_history(name, limit)
        
        return [
            {
                "timestamp": metric.timestamp,
                "value": metric.value,
                "unit": metric.unit
            }
            for metric in history
        ]


# Singleton instance
_system_monitor: Optional[SystemMonitor] = None


def get_system_monitor() -> SystemMonitor:
    """
    Get the singleton SystemMonitor instance.
    
    Returns:
        SystemMonitor instance.
    """
    global _system_monitor
    if _system_monitor is None:
        _system_monitor = SystemMonitor()
    return _system_monitor


if __name__ == "__main__":
    # Setup logging for standalone execution
    logging.basicConfig(level=logging.INFO)
    
    # Create and start monitor
    monitor = get_system_monitor()
    monitor.start()
    
    try:
        # Run for a while
        time.sleep(60)
    except KeyboardInterrupt:
        pass
    finally:
        # Stop monitor
        monitor.stop()
        
        # Print status
        import json
        print(json.dumps(monitor.get_system_status(), indent=2))
