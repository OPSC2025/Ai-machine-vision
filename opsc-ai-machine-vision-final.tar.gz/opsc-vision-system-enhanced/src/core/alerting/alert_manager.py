"""
Alerting system for OPSC Sandwich Quality Inspection System.
Provides functionality for generating alerts based on system events, defect detection, and performance metrics.

Version: 1.0.0
Last Updated: 2025-04-21
"""

import os
import sys
import time
import json
import logging
import datetime
import uuid
import sqlite3
import threading
import queue
import smtplib
import requests
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.image import MIMEImage
from email.mime.application import MIMEApplication
from typing import Dict, List, Optional, Tuple, Union, Any, Callable
from dataclasses import dataclass, field
import jinja2
import yaml
import socket
import cv2
import numpy as np
from pathlib import Path

# Setup logging
logger = logging.getLogger(__name__)

@dataclass
class AlertConfig:
    """Alert configuration data class."""
    alert_type: str
    name: str
    description: Optional[str] = None
    enabled: bool = True
    severity: str = "info"  # info, warning, error, critical
    parameters: Dict[str, Any] = field(default_factory=dict)
    notification_channels: List[str] = field(default_factory=list)
    throttle_period: int = 0  # Minimum seconds between alerts of same type
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "alert_type": self.alert_type,
            "name": self.name,
            "description": self.description,
            "enabled": self.enabled,
            "severity": self.severity,
            "parameters": self.parameters,
            "notification_channels": self.notification_channels,
            "throttle_period": self.throttle_period
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'AlertConfig':
        """Create from dictionary."""
        return cls(
            alert_type=data.get("alert_type"),
            name=data.get("name"),
            description=data.get("description"),
            enabled=data.get("enabled", True),
            severity=data.get("severity", "info"),
            parameters=data.get("parameters", {}),
            notification_channels=data.get("notification_channels", []),
            throttle_period=data.get("throttle_period", 0)
        )

@dataclass
class NotificationChannelConfig:
    """Notification channel configuration data class."""
    channel_type: str
    name: str
    description: Optional[str] = None
    enabled: bool = True
    parameters: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "channel_type": self.channel_type,
            "name": self.name,
            "description": self.description,
            "enabled": self.enabled,
            "parameters": self.parameters
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'NotificationChannelConfig':
        """Create from dictionary."""
        return cls(
            channel_type=data.get("channel_type"),
            name=data.get("name"),
            description=data.get("description"),
            enabled=data.get("enabled", True),
            parameters=data.get("parameters", {})
        )

class AlertManager:
    """
    Alert manager for OPSC Sandwich Quality Inspection System.
    
    Provides functionality for generating alerts based on system events, defect detection, and performance metrics.
    """
    
    def __init__(self, db_path: str, config_path: str, templates_dir: str, output_dir: str):
        """
        Initialize alert manager.
        
        Args:
            db_path: Path to SQLite database file
            config_path: Path to alert configuration file
            templates_dir: Path to directory containing alert templates
            output_dir: Path to directory for alert output
        """
        self.db_path = db_path
        self.config_path = config_path
        self.templates_dir = templates_dir
        self.output_dir = output_dir
        
        # Create directories if they don't exist
        os.makedirs(self.templates_dir, exist_ok=True)
        os.makedirs(self.output_dir, exist_ok=True)
        
        # Initialize Jinja2 environment
        self.jinja_env = jinja2.Environment(
            loader=jinja2.FileSystemLoader(self.templates_dir),
            autoescape=jinja2.select_autoescape(['html', 'xml']),
            trim_blocks=True,
            lstrip_blocks=True
        )
        
        # Initialize alert queue and worker thread
        self.alert_queue = queue.Queue()
        self.alert_thread = None
        self.alert_thread_running = False
        
        # Initialize alert configs
        self.alert_configs = {}
        self.notification_channels = {}
        
        # Initialize alert throttling
        self.last_alert_times = {}
        
        # Initialize default templates
        self._init_default_templates()
        
        # Load configuration
        self._load_configuration()
    
    def _init_default_templates(self):
        """Initialize default alert templates."""
        try:
            # Define default templates
            default_templates = {
                "email_alert.html": self._get_email_alert_template(),
                "slack_alert.json": self._get_slack_alert_template(),
                "teams_alert.json": self._get_teams_alert_template(),
                "sms_alert.txt": self._get_sms_alert_template(),
                "webhook_alert.json": self._get_webhook_alert_template()
            }
            
            # Create default templates if they don't exist
            for filename, content in default_templates.items():
                filepath = os.path.join(self.templates_dir, filename)
                if not os.path.exists(filepath):
                    with open(filepath, "w") as f:
                        f.write(content)
                    logger.info(f"Created default template: {filepath}")
        except Exception as e:
            logger.error(f"Error initializing default templates: {e}")
    
    def _load_configuration(self):
        """Load alert configuration from file."""
        try:
            # Check if configuration file exists
            if not os.path.exists(self.config_path):
                # Create default configuration
                self._create_default_configuration()
            
            # Load configuration
            with open(self.config_path, "r") as f:
                config = yaml.safe_load(f)
            
            # Load alert configs
            self.alert_configs = {}
            for alert_config in config.get("alerts", []):
                alert = AlertConfig.from_dict(alert_config)
                self.alert_configs[alert.alert_type] = alert
            
            # Load notification channels
            self.notification_channels = {}
            for channel_config in config.get("notification_channels", []):
                channel = NotificationChannelConfig.from_dict(channel_config)
                self.notification_channels[channel.name] = channel
            
            logger.info(f"Loaded {len(self.alert_configs)} alert configs and {len(self.notification_channels)} notification channels")
        except Exception as e:
            logger.error(f"Error loading configuration: {e}")
            
            # Create default configuration
            self._create_default_configuration()
    
    def _create_default_configuration(self):
        """Create default alert configuration."""
        try:
            # Create default alert configs
            default_alerts = [
                AlertConfig(
                    alert_type="defect_detected",
                    name="Defect Detected",
                    description="Alert when a defect is detected",
                    enabled=True,
                    severity="warning",
                    parameters={
                        "min_confidence": 0.7,
                        "include_image": True,
                        "defect_types": []  # Empty list means all defect types
                    },
                    notification_channels=["email", "slack"],
                    throttle_period=60  # 1 minute
                ),
                AlertConfig(
                    alert_type="high_rejection_rate",
                    name="High Rejection Rate",
                    description="Alert when rejection rate exceeds threshold",
                    enabled=True,
                    severity="warning",
                    parameters={
                        "threshold": 0.1,  # 10%
                        "window_size": 100  # Last 100 inspections
                    },
                    notification_channels=["email", "slack", "sms"],
                    throttle_period=300  # 5 minutes
                ),
                AlertConfig(
                    alert_type="system_error",
                    name="System Error",
                    description="Alert when system error occurs",
                    enabled=True,
                    severity="error",
                    parameters={},
                    notification_channels=["email", "slack", "sms"],
                    throttle_period=60  # 1 minute
                ),
                AlertConfig(
                    alert_type="camera_offline",
                    name="Camera Offline",
                    description="Alert when camera goes offline",
                    enabled=True,
                    severity="error",
                    parameters={},
                    notification_channels=["email", "slack"],
                    throttle_period=300  # 5 minutes
                ),
                AlertConfig(
                    alert_type="jetson_offline",
                    name="Jetson Offline",
                    description="Alert when Jetson device goes offline",
                    enabled=True,
                    severity="error",
                    parameters={},
                    notification_channels=["email", "slack", "sms"],
                    throttle_period=300  # 5 minutes
                ),
                AlertConfig(
                    alert_type="low_disk_space",
                    name="Low Disk Space",
                    description="Alert when disk space is low",
                    enabled=True,
                    severity="warning",
                    parameters={
                        "threshold": 0.1  # 10% free space
                    },
                    notification_channels=["email", "slack"],
                    throttle_period=3600  # 1 hour
                ),
                AlertConfig(
                    alert_type="high_cpu_usage",
                    name="High CPU Usage",
                    description="Alert when CPU usage is high",
                    enabled=True,
                    severity="warning",
                    parameters={
                        "threshold": 0.9,  # 90% usage
                        "duration": 300  # 5 minutes
                    },
                    notification_channels=["email", "slack"],
                    throttle_period=3600  # 1 hour
                ),
                AlertConfig(
                    alert_type="high_memory_usage",
                    name="High Memory Usage",
                    description="Alert when memory usage is high",
                    enabled=True,
                    severity="warning",
                    parameters={
                        "threshold": 0.9,  # 90% usage
                        "duration": 300  # 5 minutes
                    },
                    notification_channels=["email", "slack"],
                    throttle_period=3600  # 1 hour
                ),
                AlertConfig(
                    alert_type="production_run_started",
                    name="Production Run Started",
                    description="Alert when production run starts",
                    enabled=True,
                    severity="info",
                    parameters={},
                    notification_channels=["email", "slack"],
                    throttle_period=0  # No throttling
                ),
                AlertConfig(
                    alert_type="production_run_completed",
                    name="Production Run Completed",
                    description="Alert when production run completes",
                    enabled=True,
                    severity="info",
                    parameters={
                        "include_summary": True
                    },
                    notification_channels=["email", "slack"],
                    throttle_period=0  # No throttling
                )
            ]
            
            # Create default notification channels
            default_channels = [
                NotificationChannelConfig(
                    channel_type="email",
                    name="email",
                    description="Email notification channel",
                    enabled=True,
                    parameters={
                        "smtp_server": "smtp.gmail.com",
                        "smtp_port": 587,
                        "smtp_username": "your-email@gmail.com",
                        "smtp_password": "your-app-password",
                        "from_email": "your-email@gmail.com",
                        "to_emails": ["recipient1@example.com", "recipient2@example.com"],
                        "use_tls": True
                    }
                ),
                NotificationChannelConfig(
                    channel_type="slack",
                    name="slack",
                    description="Slack notification channel",
                    enabled=True,
                    parameters={
                        "webhook_url": "https://hooks.slack.com/services/your/webhook/url",
                        "channel": "#alerts",
                        "username": "OPSC Alert Bot",
                        "icon_emoji": ":sandwich:"
                    }
                ),
                NotificationChannelConfig(
                    channel_type="teams",
                    name="teams",
                    description="Microsoft Teams notification channel",
                    enabled=False,
                    parameters={
                        "webhook_url": "https://outlook.office.com/webhook/your/webhook/url"
                    }
                ),
                NotificationChannelConfig(
                    channel_type="sms",
                    name="sms",
                    description="SMS notification channel",
                    enabled=False,
                    parameters={
                        "provider": "twilio",
                        "account_sid": "your-account-sid",
                        "auth_token": "your-auth-token",
                        "from_number": "+1234567890",
                        "to_numbers": ["+1234567890", "+0987654321"]
                    }
                ),
                NotificationChannelConfig(
                    channel_type="webhook",
                    name="webhook",
                    description="Generic webhook notification channel",
                    enabled=False,
                    parameters={
                        "url": "https://example.com/webhook",
                        "method": "POST",
                        "headers": {
                            "Content-Type": "application/json",
                            "Authorization": "Bearer your-token"
                        }
                    }
                )
            ]
            
            # Create configuration
            config = {
                "alerts": [alert.to_dict() for alert in default_alerts],
                "notification_channels": [channel.to_dict() for channel in default_channels]
            }
            
            # Save configuration
            with open(self.config_path, "w") as f:
                yaml.dump(config, f, default_flow_style=False)
            
            # Load configuration
            self.alert_configs = {alert.alert_type: alert for alert in default_alerts}
            self.notification_channels = {channel.name: channel for channel in default_channels}
            
            logger.info(f"Created default configuration with {len(default_alerts)} alert configs and {len(default_channels)} notification channels")
        except Exception as e:
            logger.error(f"Error creating default configuration: {e}")
    
    def start_alert_worker(self):
        """Start background alert worker thread."""
        if self.alert_thread is not None and self.alert_thread.is_alive():
            logger.warning("Alert worker thread is already running")
            return
        
        self.alert_thread_running = True
        self.alert_thread = threading.Thread(target=self._alert_worker, daemon=True)
        self.alert_thread.start()
        
        logger.info("Started alert worker thread")
    
    def stop_alert_worker(self):
        """Stop background alert worker thread."""
        if self.alert_thread is None or not self.alert_thread.is_alive():
            logger.warning("Alert worker thread is not running")
            return
        
        self.alert_thread_running = False
        self.alert_thread.join(timeout=5.0)
        
        logger.info("Stopped alert worker thread")
    
    def _alert_worker(self):
        """Background worker thread for processing alert queue."""
        logger.info("Alert worker thread started")
        
        while self.alert_thread_running:
            try:
                # Get item from queue with timeout
                try:
                    item = self.alert_queue.get(timeout=1.0)
                except queue.Empty:
                    continue
                
                # Process item
                try:
                    alert_id = item.get("alert_id")
                    alert_type = item.get("alert_type")
                    alert_data = item.get("alert_data", {})
                    
                    logger.info(f"Processing alert: {alert_id} ({alert_type})")
                    
                    # Get alert config
                    alert_config = self.alert_configs.get(alert_type)
                    if not alert_config:
                        logger.warning(f"Alert config not found for type: {alert_type}")
                        self.alert_queue.task_done()
                        continue
                    
                    # Check if alert is enabled
                    if not alert_config.enabled:
                        logger.info(f"Alert type is disabled: {alert_type}")
                        self.alert_queue.task_done()
                        continue
                    
                    # Check throttling
                    throttle_key = f"{alert_type}:{alert_data.get('source_id', '')}"
                    if alert_config.throttle_period > 0:
                        now = time.time()
                        last_time = self.last_alert_times.get(throttle_key, 0)
                        if now - last_time < alert_config.throttle_period:
                            logger.info(f"Alert throttled: {alert_type}")
                            self.alert_queue.task_done()
                            continue
                    
                    # Update last alert time
                    self.last_alert_times[throttle_key] = time.time()
                    
                    # Update alert status to "processing"
                    self._update_alert_status(alert_id, "processing")
                    
                    # Send notifications
                    notification_results = []
                    for channel_name in alert_config.notification_channels:
                        channel_config = self.notification_channels.get(channel_name)
                        if not channel_config:
                            logger.warning(f"Notification channel not found: {channel_name}")
                            continue
                        
                        if not channel_config.enabled:
                            logger.info(f"Notification channel is disabled: {channel_name}")
                            continue
                        
                        try:
                            result = self._send_notification(channel_config, alert_config, alert_data)
                            notification_results.append({
                                "channel": channel_name,
                                "success": result.get("success", False),
                                "message": result.get("message", "")
                            })
                        except Exception as e:
                            logger.error(f"Error sending notification to channel {channel_name}: {e}")
                            notification_results.append({
                                "channel": channel_name,
                                "success": False,
                                "message": str(e)
                            })
                    
                    # Update alert status to "completed"
                    self._update_alert_status(alert_id, "completed", notification_results=notification_results)
                    
                    # Mark item as done
                    self.alert_queue.task_done()
                except Exception as e:
                    logger.error(f"Error processing alert item: {e}")
                    
                    # Mark item as done
                    self.alert_queue.task_done()
            except Exception as e:
                logger.error(f"Error in alert worker thread: {e}")
        
        logger.info("Alert worker thread stopped")
    
    def trigger_alert(self, alert_type: str, alert_data: Dict[str, Any] = None) -> Optional[str]:
        """
        Trigger an alert.
        
        Args:
            alert_type: Alert type
            alert_data: Alert data (optional)
        
        Returns:
            Alert ID if successful, None otherwise
        """
        try:
            # Check if alert type exists
            if alert_type not in self.alert_configs:
                logger.warning(f"Alert type not found: {alert_type}")
                return None
            
            # Get alert config
            alert_config = self.alert_configs[alert_type]
            
            # Check if alert is enabled
            if not alert_config.enabled:
                logger.info(f"Alert type is disabled: {alert_type}")
                return None
            
            # Initialize alert data
            if alert_data is None:
                alert_data = {}
            
            # Generate alert ID
            alert_id = f"alert_{uuid.uuid4().hex[:8]}"
            
            # Get current timestamp
            now = datetime.datetime.now().isoformat()
            
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Insert alert record
            cursor.execute(
                """
                INSERT INTO alerts (
                    alert_id, alert_type, severity, source_id, source_type,
                    message, details, created_at, status
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    alert_id,
                    alert_type,
                    alert_config.severity,
                    alert_data.get("source_id", ""),
                    alert_data.get("source_type", ""),
                    alert_data.get("message", alert_config.name),
                    json.dumps(alert_data),
                    now,
                    "queued"
                )
            )
            
            # Commit changes
            conn.commit()
            
            # Close connection
            conn.close()
            
            # Add item to alert queue
            self.alert_queue.put({
                "alert_id": alert_id,
                "alert_type": alert_type,
                "alert_data": alert_data
            })
            
            logger.info(f"Triggered alert: {alert_id} ({alert_type})")
            
            return alert_id
        except Exception as e:
            logger.error(f"Error triggering alert: {e}")
            return None
    
    def get_alert_status(self, alert_id: str) -> Dict[str, Any]:
        """
        Get alert status.
        
        Args:
            alert_id: Alert ID
        
        Returns:
            Alert status dictionary
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Get alert status
            cursor.execute(
                """
                SELECT * FROM alerts WHERE alert_id = ?
                """,
                (alert_id,)
            )
            row = cursor.fetchone()
            
            # Close connection
            conn.close()
            
            if not row:
                return {"error": f"Alert not found: {alert_id}"}
            
            # Convert row to dictionary
            alert = dict(row)
            
            # Parse details
            if alert.get("details"):
                alert["details"] = json.loads(alert["details"])
            
            # Parse notification results
            if alert.get("notification_results"):
                alert["notification_results"] = json.loads(alert["notification_results"])
            
            return alert
        except Exception as e:
            logger.error(f"Error getting alert status: {e}")
            return {"error": str(e)}
    
    def list_alerts(self, limit: int = 100, offset: int = 0, alert_type: Optional[str] = None, severity: Optional[str] = None, status: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        List alerts.
        
        Args:
            limit: Maximum number of alerts to return
            offset: Offset for pagination
            alert_type: Filter by alert type (optional)
            severity: Filter by severity (optional)
            status: Filter by status (optional)
        
        Returns:
            List of alert dictionaries
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Build query
            query = "SELECT * FROM alerts"
            params = []
            
            where_clauses = []
            if alert_type:
                where_clauses.append("alert_type = ?")
                params.append(alert_type)
            
            if severity:
                where_clauses.append("severity = ?")
                params.append(severity)
            
            if status:
                where_clauses.append("status = ?")
                params.append(status)
            
            if where_clauses:
                query += " WHERE " + " AND ".join(where_clauses)
            
            query += " ORDER BY created_at DESC LIMIT ? OFFSET ?"
            params.extend([limit, offset])
            
            # Get alerts
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            # Close connection
            conn.close()
            
            # Convert rows to dictionaries
            alerts = []
            for row in rows:
                alert = dict(row)
                
                # Parse details
                if alert.get("details"):
                    alert["details"] = json.loads(alert["details"])
                
                # Parse notification results
                if alert.get("notification_results"):
                    alert["notification_results"] = json.loads(alert["notification_results"])
                
                alerts.append(alert)
            
            return alerts
        except Exception as e:
            logger.error(f"Error listing alerts: {e}")
            return []
    
    def delete_alert(self, alert_id: str) -> bool:
        """
        Delete alert.
        
        Args:
            alert_id: Alert ID
        
        Returns:
            True if successful, False otherwise
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Delete alert record
            cursor.execute("DELETE FROM alerts WHERE alert_id = ?", (alert_id,))
            
            # Commit changes
            conn.commit()
            
            # Close connection
            conn.close()
            
            logger.info(f"Deleted alert: {alert_id}")
            
            return True
        except Exception as e:
            logger.error(f"Error deleting alert: {e}")
            return False
    
    def _update_alert_status(self, alert_id: str, status: str, notification_results: Optional[List[Dict[str, Any]]] = None):
        """
        Update alert status.
        
        Args:
            alert_id: Alert ID
            status: Alert status (queued, processing, completed, error)
            notification_results: Notification results (if status is completed)
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Update alert status
            if status == "completed" and notification_results:
                cursor.execute(
                    """
                    UPDATE alerts
                    SET status = ?, notification_results = ?
                    WHERE alert_id = ?
                    """,
                    (status, json.dumps(notification_results), alert_id)
                )
            else:
                cursor.execute(
                    """
                    UPDATE alerts
                    SET status = ?
                    WHERE alert_id = ?
                    """,
                    (status, alert_id)
                )
            
            # Commit changes
            conn.commit()
            
            # Close connection
            conn.close()
        except Exception as e:
            logger.error(f"Error updating alert status: {e}")
    
    def _send_notification(self, channel_config: NotificationChannelConfig, alert_config: AlertConfig, alert_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Send notification.
        
        Args:
            channel_config: Notification channel configuration
            alert_config: Alert configuration
            alert_data: Alert data
        
        Returns:
            Result dictionary with success flag and message
        """
        try:
            # Get channel type
            channel_type = channel_config.channel_type
            
            # Send notification based on channel type
            if channel_type == "email":
                return self._send_email_notification(channel_config, alert_config, alert_data)
            elif channel_type == "slack":
                return self._send_slack_notification(channel_config, alert_config, alert_data)
            elif channel_type == "teams":
                return self._send_teams_notification(channel_config, alert_config, alert_data)
            elif channel_type == "sms":
                return self._send_sms_notification(channel_config, alert_config, alert_data)
            elif channel_type == "webhook":
                return self._send_webhook_notification(channel_config, alert_config, alert_data)
            else:
                return {"success": False, "message": f"Unsupported channel type: {channel_type}"}
        except Exception as e:
            logger.error(f"Error sending notification: {e}")
            return {"success": False, "message": str(e)}
    
    def _send_email_notification(self, channel_config: NotificationChannelConfig, alert_config: AlertConfig, alert_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Send email notification.
        
        Args:
            channel_config: Notification channel configuration
            alert_config: Alert configuration
            alert_data: Alert data
        
        Returns:
            Result dictionary with success flag and message
        """
        try:
            # Get channel parameters
            params = channel_config.parameters
            smtp_server = params.get("smtp_server")
            smtp_port = params.get("smtp_port")
            smtp_username = params.get("smtp_username")
            smtp_password = params.get("smtp_password")
            from_email = params.get("from_email")
            to_emails = params.get("to_emails", [])
            use_tls = params.get("use_tls", True)
            
            if not smtp_server or not smtp_port or not from_email or not to_emails:
                return {"success": False, "message": "Missing required email parameters"}
            
            # Prepare email subject
            subject = f"[{alert_config.severity.upper()}] {alert_config.name}"
            
            # Prepare email content
            template = self.jinja_env.get_template("email_alert.html")
            html_content = template.render(
                alert_type=alert_config.alert_type,
                alert_name=alert_config.name,
                alert_description=alert_config.description,
                alert_severity=alert_config.severity,
                alert_data=alert_data,
                timestamp=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                hostname=socket.gethostname()
            )
            
            # Create message
            msg = MIMEMultipart()
            msg["From"] = from_email
            msg["To"] = ", ".join(to_emails)
            msg["Subject"] = subject
            
            # Attach HTML content
            msg.attach(MIMEText(html_content, "html"))
            
            # Attach image if available
            if alert_data.get("image_path") and os.path.exists(alert_data["image_path"]):
                with open(alert_data["image_path"], "rb") as f:
                    img = MIMEImage(f.read())
                    img.add_header("Content-Disposition", "attachment", filename=os.path.basename(alert_data["image_path"]))
                    msg.attach(img)
            
            # Connect to SMTP server
            server = smtplib.SMTP(smtp_server, smtp_port)
            if use_tls:
                server.starttls()
            
            # Login if credentials provided
            if smtp_username and smtp_password:
                server.login(smtp_username, smtp_password)
            
            # Send email
            server.send_message(msg)
            
            # Disconnect
            server.quit()
            
            return {"success": True, "message": f"Email sent to {len(to_emails)} recipients"}
        except Exception as e:
            logger.error(f"Error sending email notification: {e}")
            return {"success": False, "message": str(e)}
    
    def _send_slack_notification(self, channel_config: NotificationChannelConfig, alert_config: AlertConfig, alert_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Send Slack notification.
        
        Args:
            channel_config: Notification channel configuration
            alert_config: Alert configuration
            alert_data: Alert data
        
        Returns:
            Result dictionary with success flag and message
        """
        try:
            # Get channel parameters
            params = channel_config.parameters
            webhook_url = params.get("webhook_url")
            channel = params.get("channel")
            username = params.get("username", "OPSC Alert Bot")
            icon_emoji = params.get("icon_emoji", ":sandwich:")
            
            if not webhook_url:
                return {"success": False, "message": "Missing required Slack webhook URL"}
            
            # Prepare message
            template = self.jinja_env.get_template("slack_alert.json")
            payload_str = template.render(
                alert_type=alert_config.alert_type,
                alert_name=alert_config.name,
                alert_description=alert_config.description,
                alert_severity=alert_config.severity,
                alert_data=alert_data,
                timestamp=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                hostname=socket.gethostname(),
                channel=channel,
                username=username,
                icon_emoji=icon_emoji
            )
            
            # Parse JSON payload
            payload = json.loads(payload_str)
            
            # Send message
            response = requests.post(webhook_url, json=payload)
            response.raise_for_status()
            
            return {"success": True, "message": f"Slack notification sent, status code: {response.status_code}"}
        except Exception as e:
            logger.error(f"Error sending Slack notification: {e}")
            return {"success": False, "message": str(e)}
    
    def _send_teams_notification(self, channel_config: NotificationChannelConfig, alert_config: AlertConfig, alert_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Send Microsoft Teams notification.
        
        Args:
            channel_config: Notification channel configuration
            alert_config: Alert configuration
            alert_data: Alert data
        
        Returns:
            Result dictionary with success flag and message
        """
        try:
            # Get channel parameters
            params = channel_config.parameters
            webhook_url = params.get("webhook_url")
            
            if not webhook_url:
                return {"success": False, "message": "Missing required Teams webhook URL"}
            
            # Prepare message
            template = self.jinja_env.get_template("teams_alert.json")
            payload_str = template.render(
                alert_type=alert_config.alert_type,
                alert_name=alert_config.name,
                alert_description=alert_config.description,
                alert_severity=alert_config.severity,
                alert_data=alert_data,
                timestamp=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                hostname=socket.gethostname()
            )
            
            # Parse JSON payload
            payload = json.loads(payload_str)
            
            # Send message
            response = requests.post(webhook_url, json=payload)
            response.raise_for_status()
            
            return {"success": True, "message": f"Teams notification sent, status code: {response.status_code}"}
        except Exception as e:
            logger.error(f"Error sending Teams notification: {e}")
            return {"success": False, "message": str(e)}
    
    def _send_sms_notification(self, channel_config: NotificationChannelConfig, alert_config: AlertConfig, alert_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Send SMS notification.
        
        Args:
            channel_config: Notification channel configuration
            alert_config: Alert configuration
            alert_data: Alert data
        
        Returns:
            Result dictionary with success flag and message
        """
        try:
            # Get channel parameters
            params = channel_config.parameters
            provider = params.get("provider", "twilio")
            
            if provider == "twilio":
                # Get Twilio parameters
                account_sid = params.get("account_sid")
                auth_token = params.get("auth_token")
                from_number = params.get("from_number")
                to_numbers = params.get("to_numbers", [])
                
                if not account_sid or not auth_token or not from_number or not to_numbers:
                    return {"success": False, "message": "Missing required Twilio parameters"}
                
                # Prepare message
                template = self.jinja_env.get_template("sms_alert.txt")
                message = template.render(
                    alert_type=alert_config.alert_type,
                    alert_name=alert_config.name,
                    alert_severity=alert_config.severity,
                    alert_data=alert_data,
                    timestamp=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    hostname=socket.gethostname()
                )
                
                # Import Twilio client
                try:
                    from twilio.rest import Client
                except ImportError:
                    return {"success": False, "message": "Twilio client not installed"}
                
                # Create Twilio client
                client = Client(account_sid, auth_token)
                
                # Send messages
                sent_count = 0
                for to_number in to_numbers:
                    try:
                        client.messages.create(
                            body=message,
                            from_=from_number,
                            to=to_number
                        )
                        sent_count += 1
                    except Exception as e:
                        logger.error(f"Error sending SMS to {to_number}: {e}")
                
                return {"success": True, "message": f"SMS sent to {sent_count} recipients"}
            else:
                return {"success": False, "message": f"Unsupported SMS provider: {provider}"}
        except Exception as e:
            logger.error(f"Error sending SMS notification: {e}")
            return {"success": False, "message": str(e)}
    
    def _send_webhook_notification(self, channel_config: NotificationChannelConfig, alert_config: AlertConfig, alert_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Send webhook notification.
        
        Args:
            channel_config: Notification channel configuration
            alert_config: Alert configuration
            alert_data: Alert data
        
        Returns:
            Result dictionary with success flag and message
        """
        try:
            # Get channel parameters
            params = channel_config.parameters
            url = params.get("url")
            method = params.get("method", "POST")
            headers = params.get("headers", {})
            
            if not url:
                return {"success": False, "message": "Missing required webhook URL"}
            
            # Prepare payload
            template = self.jinja_env.get_template("webhook_alert.json")
            payload_str = template.render(
                alert_type=alert_config.alert_type,
                alert_name=alert_config.name,
                alert_description=alert_config.description,
                alert_severity=alert_config.severity,
                alert_data=alert_data,
                timestamp=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                hostname=socket.gethostname()
            )
            
            # Parse JSON payload
            payload = json.loads(payload_str)
            
            # Send request
            response = requests.request(method, url, json=payload, headers=headers)
            response.raise_for_status()
            
            return {"success": True, "message": f"Webhook notification sent, status code: {response.status_code}"}
        except Exception as e:
            logger.error(f"Error sending webhook notification: {e}")
            return {"success": False, "message": str(e)}
    
    def _get_email_alert_template(self) -> str:
        """Get default email alert template."""
        return """<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ alert_name }}</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }
        .alert-header {
            padding: 10px 15px;
            border-radius: 5px 5px 0 0;
            color: white;
            font-weight: bold;
        }
        .alert-info .alert-header {
            background-color: #3498db;
        }
        .alert-warning .alert-header {
            background-color: #f39c12;
        }
        .alert-error .alert-header {
            background-color: #e74c3c;
        }
        .alert-critical .alert-header {
            background-color: #c0392b;
        }
        .alert-body {
            padding: 15px;
            border: 1px solid #ddd;
            border-top: none;
            border-radius: 0 0 5px 5px;
        }
        .alert-footer {
            margin-top: 20px;
            padding-top: 10px;
            border-top: 1px solid #ddd;
            font-size: 0.9em;
            color: #777;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 15px 0;
        }
        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <div class="alert-{{ alert_severity }}">
        <div class="alert-header">
            {{ alert_name }}
        </div>
        <div class="alert-body">
            <p><strong>Description:</strong> {{ alert_description }}</p>
            <p><strong>Severity:</strong> {{ alert_severity }}</p>
            <p><strong>Time:</strong> {{ timestamp }}</p>
            <p><strong>Host:</strong> {{ hostname }}</p>
            
            {% if alert_data.message %}
            <p><strong>Message:</strong> {{ alert_data.message }}</p>
            {% endif %}
            
            {% if alert_data.source_id %}
            <p><strong>Source ID:</strong> {{ alert_data.source_id }}</p>
            {% endif %}
            
            {% if alert_data.source_type %}
            <p><strong>Source Type:</strong> {{ alert_data.source_type }}</p>
            {% endif %}
            
            {% if alert_data.details %}
            <h3>Details</h3>
            <table>
                <thead>
                    <tr>
                        <th>Property</th>
                        <th>Value</th>
                    </tr>
                </thead>
                <tbody>
                    {% for key, value in alert_data.details.items() %}
                    <tr>
                        <td>{{ key }}</td>
                        <td>{{ value }}</td>
                    </tr>
                    {% endfor %}
                </tbody>
            </table>
            {% endif %}
            
            {% if alert_type == "defect_detected" and alert_data.defect_type %}
            <h3>Defect Information</h3>
            <table>
                <tbody>
                    <tr>
                        <td>Defect Type</td>
                        <td>{{ alert_data.defect_type }}</td>
                    </tr>
                    {% if alert_data.defect_name %}
                    <tr>
                        <td>Defect Name</td>
                        <td>{{ alert_data.defect_name }}</td>
                    </tr>
                    {% endif %}
                    {% if alert_data.confidence %}
                    <tr>
                        <td>Confidence</td>
                        <td>{{ "%.2f"|format(alert_data.confidence * 100) }}%</td>
                    </tr>
                    {% endif %}
                    {% if alert_data.camera_id %}
                    <tr>
                        <td>Camera</td>
                        <td>{{ alert_data.camera_id }}</td>
                    </tr>
                    {% endif %}
                    {% if alert_data.timestamp %}
                    <tr>
                        <td>Detection Time</td>
                        <td>{{ alert_data.timestamp }}</td>
                    </tr>
                    {% endif %}
                </tbody>
            </table>
            {% endif %}
            
            {% if alert_type == "high_rejection_rate" %}
            <h3>Rejection Rate Information</h3>
            <table>
                <tbody>
                    <tr>
                        <td>Current Rate</td>
                        <td>{{ "%.2f"|format(alert_data.current_rate * 100) }}%</td>
                    </tr>
                    <tr>
                        <td>Threshold</td>
                        <td>{{ "%.2f"|format(alert_data.threshold * 100) }}%</td>
                    </tr>
                    <tr>
                        <td>Window Size</td>
                        <td>{{ alert_data.window_size }}</td>
                    </tr>
                    {% if alert_data.run_id %}
                    <tr>
                        <td>Production Run</td>
                        <td>{{ alert_data.run_id }}</td>
                    </tr>
                    {% endif %}
                </tbody>
            </table>
            {% endif %}
            
            {% if alert_type == "production_run_completed" and alert_data.summary %}
            <h3>Production Run Summary</h3>
            <table>
                <tbody>
                    <tr>
                        <td>Run ID</td>
                        <td>{{ alert_data.run_id }}</td>
                    </tr>
                    <tr>
                        <td>Product Type</td>
                        <td>{{ alert_data.product_type }}</td>
                    </tr>
                    <tr>
                        <td>Batch Number</td>
                        <td>{{ alert_data.batch_number }}</td>
                    </tr>
                    <tr>
                        <td>Start Time</td>
                        <td>{{ alert_data.start_time }}</td>
                    </tr>
                    <tr>
                        <td>End Time</td>
                        <td>{{ alert_data.end_time }}</td>
                    </tr>
                    <tr>
                        <td>Duration</td>
                        <td>{{ alert_data.duration }}</td>
                    </tr>
                    <tr>
                        <td>Total Inspected</td>
                        <td>{{ alert_data.summary.total_inspected }}</td>
                    </tr>
                    <tr>
                        <td>Total Rejected</td>
                        <td>{{ alert_data.summary.total_rejected }}</td>
                    </tr>
                    <tr>
                        <td>Rejection Rate</td>
                        <td>{{ "%.2f"|format(alert_data.summary.rejection_rate * 100) }}%</td>
                    </tr>
                </tbody>
            </table>
            {% endif %}
        </div>
    </div>
    <div class="alert-footer">
        <p>This is an automated alert from the OPSC Sandwich Quality Inspection System.</p>
    </div>
</body>
</html>"""
    
    def _get_slack_alert_template(self) -> str:
        """Get default Slack alert template."""
        return """{
    "channel": "{{ channel }}",
    "username": "{{ username }}",
    "icon_emoji": "{{ icon_emoji }}",
    "attachments": [
        {
            "color": "{% if alert_severity == 'info' %}#3498db{% elif alert_severity == 'warning' %}#f39c12{% elif alert_severity == 'error' %}#e74c3c{% elif alert_severity == 'critical' %}#c0392b{% endif %}",
            "title": "{{ alert_name }}",
            "text": "{{ alert_description }}",
            "fields": [
                {
                    "title": "Severity",
                    "value": "{{ alert_severity|upper }}",
                    "short": true
                },
                {
                    "title": "Time",
                    "value": "{{ timestamp }}",
                    "short": true
                },
                {
                    "title": "Host",
                    "value": "{{ hostname }}",
                    "short": true
                },
                {
                    "title": "Alert Type",
                    "value": "{{ alert_type }}",
                    "short": true
                }{% if alert_data.message %},
                {
                    "title": "Message",
                    "value": "{{ alert_data.message }}",
                    "short": false
                }{% endif %}{% if alert_data.source_id %},
                {
                    "title": "Source ID",
                    "value": "{{ alert_data.source_id }}",
                    "short": true
                }{% endif %}{% if alert_data.source_type %},
                {
                    "title": "Source Type",
                    "value": "{{ alert_data.source_type }}",
                    "short": true
                }{% endif %}{% if alert_type == "defect_detected" and alert_data.defect_type %},
                {
                    "title": "Defect Type",
                    "value": "{{ alert_data.defect_type }}",
                    "short": true
                }{% endif %}{% if alert_type == "defect_detected" and alert_data.confidence %},
                {
                    "title": "Confidence",
                    "value": "{{ "%.2f"|format(alert_data.confidence * 100) }}%",
                    "short": true
                }{% endif %}{% if alert_type == "high_rejection_rate" %},
                {
                    "title": "Current Rate",
                    "value": "{{ "%.2f"|format(alert_data.current_rate * 100) }}%",
                    "short": true
                },
                {
                    "title": "Threshold",
                    "value": "{{ "%.2f"|format(alert_data.threshold * 100) }}%",
                    "short": true
                }{% endif %}{% if alert_type == "production_run_completed" and alert_data.summary %},
                {
                    "title": "Run Summary",
                    "value": "Run ID: {{ alert_data.run_id }}\\nProduct: {{ alert_data.product_type }}\\nBatch: {{ alert_data.batch_number }}\\nInspected: {{ alert_data.summary.total_inspected }}\\nRejected: {{ alert_data.summary.total_rejected }}\\nRejection Rate: {{ "%.2f"|format(alert_data.summary.rejection_rate * 100) }}%",
                    "short": false
                }{% endif %}
            ],
            "footer": "OPSC Sandwich Quality Inspection System"
        }
    ]
}"""
    
    def _get_teams_alert_template(self) -> str:
        """Get default Microsoft Teams alert template."""
        return """{
    "@type": "MessageCard",
    "@context": "http://schema.org/extensions",
    "themeColor": "{% if alert_severity == 'info' %}3498db{% elif alert_severity == 'warning' %}f39c12{% elif alert_severity == 'error' %}e74c3c{% elif alert_severity == 'critical' %}c0392b{% endif %}",
    "summary": "{{ alert_name }}",
    "sections": [
        {
            "activityTitle": "{{ alert_name }}",
            "activitySubtitle": "{{ alert_description }}",
            "facts": [
                {
                    "name": "Severity",
                    "value": "{{ alert_severity|upper }}"
                },
                {
                    "name": "Time",
                    "value": "{{ timestamp }}"
                },
                {
                    "name": "Host",
                    "value": "{{ hostname }}"
                },
                {
                    "name": "Alert Type",
                    "value": "{{ alert_type }}"
                }{% if alert_data.message %},
                {
                    "name": "Message",
                    "value": "{{ alert_data.message }}"
                }{% endif %}{% if alert_data.source_id %},
                {
                    "name": "Source ID",
                    "value": "{{ alert_data.source_id }}"
                }{% endif %}{% if alert_data.source_type %},
                {
                    "name": "Source Type",
                    "value": "{{ alert_data.source_type }}"
                }{% endif %}{% if alert_type == "defect_detected" and alert_data.defect_type %},
                {
                    "name": "Defect Type",
                    "value": "{{ alert_data.defect_type }}"
                }{% endif %}{% if alert_type == "defect_detected" and alert_data.confidence %},
                {
                    "name": "Confidence",
                    "value": "{{ "%.2f"|format(alert_data.confidence * 100) }}%"
                }{% endif %}{% if alert_type == "high_rejection_rate" %},
                {
                    "name": "Current Rate",
                    "value": "{{ "%.2f"|format(alert_data.current_rate * 100) }}%"
                },
                {
                    "name": "Threshold",
                    "value": "{{ "%.2f"|format(alert_data.threshold * 100) }}%"
                }{% endif %}{% if alert_type == "production_run_completed" and alert_data.summary %},
                {
                    "name": "Run ID",
                    "value": "{{ alert_data.run_id }}"
                },
                {
                    "name": "Product Type",
                    "value": "{{ alert_data.product_type }}"
                },
                {
                    "name": "Batch Number",
                    "value": "{{ alert_data.batch_number }}"
                },
                {
                    "name": "Total Inspected",
                    "value": "{{ alert_data.summary.total_inspected }}"
                },
                {
                    "name": "Total Rejected",
                    "value": "{{ alert_data.summary.total_rejected }}"
                },
                {
                    "name": "Rejection Rate",
                    "value": "{{ "%.2f"|format(alert_data.summary.rejection_rate * 100) }}%"
                }{% endif %}
            ],
            "markdown": true
        }
    ]
}"""
    
    def _get_sms_alert_template(self) -> str:
        """Get default SMS alert template."""
        return """[{{ alert_severity|upper }}] {{ alert_name }}: {% if alert_data.message %}{{ alert_data.message }}{% else %}{{ alert_description }}{% endif %}{% if alert_type == "defect_detected" and alert_data.defect_type %} - Defect: {{ alert_data.defect_type }}{% if alert_data.confidence %} ({{ "%.0f"|format(alert_data.confidence * 100) }}%){% endif %}{% endif %}{% if alert_type == "high_rejection_rate" %} - Rate: {{ "%.1f"|format(alert_data.current_rate * 100) }}% (Threshold: {{ "%.1f"|format(alert_data.threshold * 100) }}%){% endif %} - {{ timestamp }}"""
    
    def _get_webhook_alert_template(self) -> str:
        """Get default webhook alert template."""
        return """{
    "alert_type": "{{ alert_type }}",
    "alert_name": "{{ alert_name }}",
    "alert_description": "{{ alert_description }}",
    "alert_severity": "{{ alert_severity }}",
    "timestamp": "{{ timestamp }}",
    "hostname": "{{ hostname }}",
    "data": {{ alert_data|to_json }}
}"""


class AlertMonitor:
    """
    Alert monitor for OPSC Sandwich Quality Inspection System.
    
    Monitors system events, defect detection, and performance metrics to trigger alerts.
    """
    
    def __init__(self, alert_manager: AlertManager, db_path: str, config_path: str):
        """
        Initialize alert monitor.
        
        Args:
            alert_manager: Alert manager instance
            db_path: Path to SQLite database file
            config_path: Path to monitor configuration file
        """
        self.alert_manager = alert_manager
        self.db_path = db_path
        self.config_path = config_path
        
        # Initialize monitor thread
        self.monitor_thread = None
        self.monitor_thread_running = False
        
        # Initialize monitor configuration
        self.config = self._load_configuration()
        
        # Initialize monitor state
        self.state = {
            "last_check_times": {},
            "rejection_rate_windows": {},
            "camera_status": {},
            "jetson_status": {},
            "disk_space_status": {},
            "cpu_usage_history": {},
            "memory_usage_history": {}
        }
    
    def _load_configuration(self) -> Dict[str, Any]:
        """
        Load monitor configuration from file.
        
        Returns:
            Configuration dictionary
        """
        try:
            # Check if configuration file exists
            if not os.path.exists(self.config_path):
                # Create default configuration
                return self._create_default_configuration()
            
            # Load configuration
            with open(self.config_path, "r") as f:
                config = yaml.safe_load(f)
            
            logger.info(f"Loaded monitor configuration from {self.config_path}")
            
            return config
        except Exception as e:
            logger.error(f"Error loading monitor configuration: {e}")
            
            # Create default configuration
            return self._create_default_configuration()
    
    def _create_default_configuration(self) -> Dict[str, Any]:
        """
        Create default monitor configuration.
        
        Returns:
            Configuration dictionary
        """
        try:
            # Create default configuration
            config = {
                "check_intervals": {
                    "defect_detection": 1,  # seconds
                    "rejection_rate": 5,  # seconds
                    "camera_status": 30,  # seconds
                    "jetson_status": 30,  # seconds
                    "disk_space": 300,  # seconds
                    "cpu_usage": 60,  # seconds
                    "memory_usage": 60,  # seconds
                    "production_run": 10  # seconds
                },
                "rejection_rate": {
                    "window_sizes": {
                        "short": 50,
                        "medium": 100,
                        "long": 500
                    },
                    "thresholds": {
                        "warning": 0.1,  # 10%
                        "error": 0.2  # 20%
                    }
                },
                "disk_space": {
                    "paths": ["/", "/home"],
                    "thresholds": {
                        "warning": 0.1,  # 10% free
                        "error": 0.05  # 5% free
                    }
                },
                "cpu_usage": {
                    "thresholds": {
                        "warning": 0.8,  # 80% usage
                        "error": 0.9  # 90% usage
                    },
                    "duration": 300  # 5 minutes
                },
                "memory_usage": {
                    "thresholds": {
                        "warning": 0.8,  # 80% usage
                        "error": 0.9  # 90% usage
                    },
                    "duration": 300  # 5 minutes
                }
            }
            
            # Save configuration
            with open(self.config_path, "w") as f:
                yaml.dump(config, f, default_flow_style=False)
            
            logger.info(f"Created default monitor configuration at {self.config_path}")
            
            return config
        except Exception as e:
            logger.error(f"Error creating default monitor configuration: {e}")
            
            # Return minimal configuration
            return {
                "check_intervals": {
                    "defect_detection": 1,
                    "rejection_rate": 5,
                    "camera_status": 30,
                    "jetson_status": 30,
                    "disk_space": 300,
                    "cpu_usage": 60,
                    "memory_usage": 60,
                    "production_run": 10
                }
            }
    
    def start_monitor(self):
        """Start background monitor thread."""
        if self.monitor_thread is not None and self.monitor_thread.is_alive():
            logger.warning("Monitor thread is already running")
            return
        
        self.monitor_thread_running = True
        self.monitor_thread = threading.Thread(target=self._monitor_worker, daemon=True)
        self.monitor_thread.start()
        
        logger.info("Started monitor thread")
    
    def stop_monitor(self):
        """Stop background monitor thread."""
        if self.monitor_thread is None or not self.monitor_thread.is_alive():
            logger.warning("Monitor thread is not running")
            return
        
        self.monitor_thread_running = False
        self.monitor_thread.join(timeout=5.0)
        
        logger.info("Stopped monitor thread")
    
    def _monitor_worker(self):
        """Background worker thread for monitoring."""
        logger.info("Monitor thread started")
        
        while self.monitor_thread_running:
            try:
                # Get current time
                now = time.time()
                
                # Check defect detection
                self._check_defect_detection(now)
                
                # Check rejection rate
                self._check_rejection_rate(now)
                
                # Check camera status
                self._check_camera_status(now)
                
                # Check Jetson status
                self._check_jetson_status(now)
                
                # Check disk space
                self._check_disk_space(now)
                
                # Check CPU usage
                self._check_cpu_usage(now)
                
                # Check memory usage
                self._check_memory_usage(now)
                
                # Check production run status
                self._check_production_run_status(now)
                
                # Sleep briefly
                time.sleep(0.1)
            except Exception as e:
                logger.error(f"Error in monitor thread: {e}")
                time.sleep(1.0)
        
        logger.info("Monitor thread stopped")
    
    def _check_defect_detection(self, now: float):
        """
        Check for new defect detections.
        
        Args:
            now: Current time
        """
        try:
            # Get check interval
            interval = self.config.get("check_intervals", {}).get("defect_detection", 1)
            
            # Get last check time
            last_check = self.state["last_check_times"].get("defect_detection", 0)
            
            # Check if it's time to check
            if now - last_check < interval:
                return
            
            # Update last check time
            self.state["last_check_times"]["defect_detection"] = now
            
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Get alert config
            alert_config = self.alert_manager.alert_configs.get("defect_detected")
            if not alert_config or not alert_config.enabled:
                return
            
            # Get parameters
            min_confidence = alert_config.parameters.get("min_confidence", 0.7)
            include_image = alert_config.parameters.get("include_image", True)
            defect_types = alert_config.parameters.get("defect_types", [])
            
            # Build query
            query = """
            SELECT ir.*, dt.name as defect_name, dt.severity, pr.product_type, pr.batch_number
            FROM inspection_results ir
            LEFT JOIN defect_types dt ON ir.defect_type = dt.defect_code
            LEFT JOIN production_runs pr ON ir.run_id = pr.run_id
            WHERE ir.defect_type IS NOT NULL
            AND ir.timestamp > datetime(?, 'unixepoch')
            AND ir.confidence >= ?
            """
            params = [last_check, min_confidence]
            
            if defect_types:
                placeholders = ", ".join(["?" for _ in defect_types])
                query += f" AND ir.defect_type IN ({placeholders})"
                params.extend(defect_types)
            
            # Execute query
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            # Close connection
            conn.close()
            
            # Process results
            for row in rows:
                # Convert row to dictionary
                result = dict(row)
                
                # Prepare alert data
                alert_data = {
                    "source_id": result["id"],
                    "source_type": "inspection_result",
                    "defect_type": result["defect_type"],
                    "defect_name": result.get("defect_name"),
                    "confidence": result["confidence"],
                    "camera_id": result["camera_id"],
                    "run_id": result["run_id"],
                    "product_type": result.get("product_type"),
                    "batch_number": result.get("batch_number"),
                    "timestamp": result["timestamp"],
                    "message": f"Defect detected: {result.get('defect_name') or result['defect_type']} (Confidence: {result['confidence']:.2%})"
                }
                
                # Add image path if available and requested
                if include_image and result.get("image_path") and os.path.exists(result["image_path"]):
                    alert_data["image_path"] = result["image_path"]
                
                # Trigger alert
                self.alert_manager.trigger_alert("defect_detected", alert_data)
        except Exception as e:
            logger.error(f"Error checking defect detection: {e}")
    
    def _check_rejection_rate(self, now: float):
        """
        Check rejection rate.
        
        Args:
            now: Current time
        """
        try:
            # Get check interval
            interval = self.config.get("check_intervals", {}).get("rejection_rate", 5)
            
            # Get last check time
            last_check = self.state["last_check_times"].get("rejection_rate", 0)
            
            # Check if it's time to check
            if now - last_check < interval:
                return
            
            # Update last check time
            self.state["last_check_times"]["rejection_rate"] = now
            
            # Get alert config
            alert_config = self.alert_manager.alert_configs.get("high_rejection_rate")
            if not alert_config or not alert_config.enabled:
                return
            
            # Get parameters
            threshold = alert_config.parameters.get("threshold", 0.1)
            window_size = alert_config.parameters.get("window_size", 100)
            
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Get active production runs
            cursor.execute(
                """
                SELECT run_id FROM production_runs
                WHERE status = 'active'
                """
            )
            active_runs = [row["run_id"] for row in cursor.fetchall()]
            
            # Process each active run
            for run_id in active_runs:
                # Get window key
                window_key = f"run_{run_id}"
                
                # Initialize window if needed
                if window_key not in self.state["rejection_rate_windows"]:
                    self.state["rejection_rate_windows"][window_key] = []
                
                # Get recent inspection results
                cursor.execute(
                    """
                    SELECT rejected FROM inspection_results
                    WHERE run_id = ?
                    AND timestamp > datetime(?, 'unixepoch')
                    ORDER BY timestamp DESC
                    """,
                    (run_id, last_check)
                )
                new_results = [row["rejected"] for row in cursor.fetchall()]
                
                # Update window
                window = self.state["rejection_rate_windows"][window_key]
                window.extend(new_results)
                
                # Trim window to size
                if len(window) > window_size:
                    window = window[-window_size:]
                
                # Update window in state
                self.state["rejection_rate_windows"][window_key] = window
                
                # Calculate rejection rate
                if len(window) >= window_size:
                    rejection_count = sum(window)
                    rejection_rate = rejection_count / len(window)
                    
                    # Check if rate exceeds threshold
                    if rejection_rate >= threshold:
                        # Get run details
                        cursor.execute(
                            """
                            SELECT * FROM production_runs
                            WHERE run_id = ?
                            """,
                            (run_id,)
                        )
                        run = dict(cursor.fetchone())
                        
                        # Prepare alert data
                        alert_data = {
                            "source_id": run_id,
                            "source_type": "production_run",
                            "current_rate": rejection_rate,
                            "threshold": threshold,
                            "window_size": window_size,
                            "run_id": run_id,
                            "product_type": run.get("product_type"),
                            "batch_number": run.get("batch_number"),
                            "message": f"High rejection rate: {rejection_rate:.2%} (Threshold: {threshold:.2%})"
                        }
                        
                        # Trigger alert
                        self.alert_manager.trigger_alert("high_rejection_rate", alert_data)
            
            # Clean up old windows
            for key in list(self.state["rejection_rate_windows"].keys()):
                if key.startswith("run_") and key[4:] not in active_runs:
                    del self.state["rejection_rate_windows"][key]
            
            # Close connection
            conn.close()
        except Exception as e:
            logger.error(f"Error checking rejection rate: {e}")
    
    def _check_camera_status(self, now: float):
        """
        Check camera status.
        
        Args:
            now: Current time
        """
        try:
            # Get check interval
            interval = self.config.get("check_intervals", {}).get("camera_status", 30)
            
            # Get last check time
            last_check = self.state["last_check_times"].get("camera_status", 0)
            
            # Check if it's time to check
            if now - last_check < interval:
                return
            
            # Update last check time
            self.state["last_check_times"]["camera_status"] = now
            
            # Get alert config
            alert_config = self.alert_manager.alert_configs.get("camera_offline")
            if not alert_config or not alert_config.enabled:
                return
            
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Get camera status
            cursor.execute(
                """
                SELECT camera_id, status, last_heartbeat, ip_address, model, serial_number
                FROM cameras
                """
            )
            cameras = [dict(row) for row in cursor.fetchall()]
            
            # Close connection
            conn.close()
            
            # Process each camera
            for camera in cameras:
                camera_id = camera["camera_id"]
                status = camera["status"]
                last_heartbeat = camera["last_heartbeat"]
                
                # Convert last heartbeat to timestamp
                if last_heartbeat:
                    try:
                        last_heartbeat_dt = datetime.datetime.fromisoformat(last_heartbeat.replace("Z", "+00:00"))
                        last_heartbeat_ts = last_heartbeat_dt.timestamp()
                    except (ValueError, TypeError):
                        last_heartbeat_ts = 0
                else:
                    last_heartbeat_ts = 0
                
                # Check if camera is offline
                is_offline = status != "online" or (now - last_heartbeat_ts > 60)  # 1 minute timeout
                
                # Get previous status
                prev_status = self.state["camera_status"].get(camera_id, {}).get("status")
                
                # Update status in state
                self.state["camera_status"][camera_id] = {
                    "status": "offline" if is_offline else "online",
                    "last_heartbeat": last_heartbeat_ts
                }
                
                # Check for status change to offline
                if is_offline and (prev_status is None or prev_status == "online"):
                    # Prepare alert data
                    alert_data = {
                        "source_id": camera_id,
                        "source_type": "camera",
                        "camera_id": camera_id,
                        "ip_address": camera.get("ip_address"),
                        "model": camera.get("model"),
                        "serial_number": camera.get("serial_number"),
                        "last_heartbeat": last_heartbeat,
                        "message": f"Camera {camera_id} is offline"
                    }
                    
                    # Trigger alert
                    self.alert_manager.trigger_alert("camera_offline", alert_data)
        except Exception as e:
            logger.error(f"Error checking camera status: {e}")
    
    def _check_jetson_status(self, now: float):
        """
        Check Jetson status.
        
        Args:
            now: Current time
        """
        try:
            # Get check interval
            interval = self.config.get("check_intervals", {}).get("jetson_status", 30)
            
            # Get last check time
            last_check = self.state["last_check_times"].get("jetson_status", 0)
            
            # Check if it's time to check
            if now - last_check < interval:
                return
            
            # Update last check time
            self.state["last_check_times"]["jetson_status"] = now
            
            # Get alert config
            alert_config = self.alert_manager.alert_configs.get("jetson_offline")
            if not alert_config or not alert_config.enabled:
                return
            
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Get Jetson status
            cursor.execute(
                """
                SELECT device_id, status, last_heartbeat, ip_address, model, serial_number
                FROM jetson_devices
                """
            )
            devices = [dict(row) for row in cursor.fetchall()]
            
            # Close connection
            conn.close()
            
            # Process each device
            for device in devices:
                device_id = device["device_id"]
                status = device["status"]
                last_heartbeat = device["last_heartbeat"]
                
                # Convert last heartbeat to timestamp
                if last_heartbeat:
                    try:
                        last_heartbeat_dt = datetime.datetime.fromisoformat(last_heartbeat.replace("Z", "+00:00"))
                        last_heartbeat_ts = last_heartbeat_dt.timestamp()
                    except (ValueError, TypeError):
                        last_heartbeat_ts = 0
                else:
                    last_heartbeat_ts = 0
                
                # Check if device is offline
                is_offline = status != "online" or (now - last_heartbeat_ts > 60)  # 1 minute timeout
                
                # Get previous status
                prev_status = self.state["jetson_status"].get(device_id, {}).get("status")
                
                # Update status in state
                self.state["jetson_status"][device_id] = {
                    "status": "offline" if is_offline else "online",
                    "last_heartbeat": last_heartbeat_ts
                }
                
                # Check for status change to offline
                if is_offline and (prev_status is None or prev_status == "online"):
                    # Prepare alert data
                    alert_data = {
                        "source_id": device_id,
                        "source_type": "jetson_device",
                        "device_id": device_id,
                        "ip_address": device.get("ip_address"),
                        "model": device.get("model"),
                        "serial_number": device.get("serial_number"),
                        "last_heartbeat": last_heartbeat,
                        "message": f"Jetson device {device_id} is offline"
                    }
                    
                    # Trigger alert
                    self.alert_manager.trigger_alert("jetson_offline", alert_data)
        except Exception as e:
            logger.error(f"Error checking Jetson status: {e}")
    
    def _check_disk_space(self, now: float):
        """
        Check disk space.
        
        Args:
            now: Current time
        """
        try:
            # Get check interval
            interval = self.config.get("check_intervals", {}).get("disk_space", 300)
            
            # Get last check time
            last_check = self.state["last_check_times"].get("disk_space", 0)
            
            # Check if it's time to check
            if now - last_check < interval:
                return
            
            # Update last check time
            self.state["last_check_times"]["disk_space"] = now
            
            # Get alert config
            alert_config = self.alert_manager.alert_configs.get("low_disk_space")
            if not alert_config or not alert_config.enabled:
                return
            
            # Get parameters
            threshold = alert_config.parameters.get("threshold", 0.1)
            
            # Get paths to check
            paths = self.config.get("disk_space", {}).get("paths", ["/", "/home"])
            
            # Check each path
            for path in paths:
                try:
                    # Get disk usage
                    usage = self._get_disk_usage(path)
                    
                    # Check if free space is below threshold
                    if usage["free_percent"] < threshold:
                        # Get previous status
                        prev_status = self.state["disk_space_status"].get(path, {}).get("status")
                        
                        # Update status in state
                        self.state["disk_space_status"][path] = {
                            "status": "low",
                            "free_percent": usage["free_percent"],
                            "total_gb": usage["total_gb"],
                            "free_gb": usage["free_gb"]
                        }
                        
                        # Check for status change to low
                        if prev_status is None or prev_status != "low":
                            # Prepare alert data
                            alert_data = {
                                "source_id": f"disk_{path}",
                                "source_type": "disk",
                                "path": path,
                                "free_percent": usage["free_percent"],
                                "total_gb": usage["total_gb"],
                                "free_gb": usage["free_gb"],
                                "threshold": threshold,
                                "message": f"Low disk space on {path}: {usage['free_gb']:.2f} GB ({usage['free_percent']:.2%}) free"
                            }
                            
                            # Trigger alert
                            self.alert_manager.trigger_alert("low_disk_space", alert_data)
                    else:
                        # Update status in state
                        self.state["disk_space_status"][path] = {
                            "status": "normal",
                            "free_percent": usage["free_percent"],
                            "total_gb": usage["total_gb"],
                            "free_gb": usage["free_gb"]
                        }
                except Exception as e:
                    logger.error(f"Error checking disk space for path {path}: {e}")
        except Exception as e:
            logger.error(f"Error checking disk space: {e}")
    
    def _get_disk_usage(self, path: str) -> Dict[str, float]:
        """
        Get disk usage for a path.
        
        Args:
            path: Path to check
        
        Returns:
            Dictionary with disk usage information
        """
        import shutil
        
        # Get disk usage
        usage = shutil.disk_usage(path)
        
        # Calculate values
        total_gb = usage.total / (1024 ** 3)
        free_gb = usage.free / (1024 ** 3)
        free_percent = usage.free / usage.total
        
        return {
            "total_gb": total_gb,
            "free_gb": free_gb,
            "free_percent": free_percent
        }
    
    def _check_cpu_usage(self, now: float):
        """
        Check CPU usage.
        
        Args:
            now: Current time
        """
        try:
            # Get check interval
            interval = self.config.get("check_intervals", {}).get("cpu_usage", 60)
            
            # Get last check time
            last_check = self.state["last_check_times"].get("cpu_usage", 0)
            
            # Check if it's time to check
            if now - last_check < interval:
                return
            
            # Update last check time
            self.state["last_check_times"]["cpu_usage"] = now
            
            # Get alert config
            alert_config = self.alert_manager.alert_configs.get("high_cpu_usage")
            if not alert_config or not alert_config.enabled:
                return
            
            # Get parameters
            threshold = alert_config.parameters.get("threshold", 0.9)
            duration = alert_config.parameters.get("duration", 300)
            
            # Get CPU usage
            import psutil
            cpu_percent = psutil.cpu_percent(interval=1) / 100.0
            
            # Update CPU usage history
            if "cpu" not in self.state["cpu_usage_history"]:
                self.state["cpu_usage_history"]["cpu"] = []
            
            history = self.state["cpu_usage_history"]["cpu"]
            history.append((now, cpu_percent))
            
            # Remove old entries
            cutoff = now - duration
            history = [entry for entry in history if entry[0] >= cutoff]
            
            # Update history in state
            self.state["cpu_usage_history"]["cpu"] = history
            
            # Check if CPU usage is consistently high
            if len(history) >= 3:  # Require at least 3 data points
                high_count = sum(1 for _, usage in history if usage >= threshold)
                high_percent = high_count / len(history)
                
                if high_percent >= 0.8:  # 80% of samples are high
                    # Prepare alert data
                    alert_data = {
                        "source_id": "cpu",
                        "source_type": "system",
                        "current_usage": cpu_percent,
                        "average_usage": sum(usage for _, usage in history) / len(history),
                        "threshold": threshold,
                        "duration": duration,
                        "message": f"High CPU usage: {cpu_percent:.2%} (Threshold: {threshold:.2%})"
                    }
                    
                    # Trigger alert
                    self.alert_manager.trigger_alert("high_cpu_usage", alert_data)
        except Exception as e:
            logger.error(f"Error checking CPU usage: {e}")
    
    def _check_memory_usage(self, now: float):
        """
        Check memory usage.
        
        Args:
            now: Current time
        """
        try:
            # Get check interval
            interval = self.config.get("check_intervals", {}).get("memory_usage", 60)
            
            # Get last check time
            last_check = self.state["last_check_times"].get("memory_usage", 0)
            
            # Check if it's time to check
            if now - last_check < interval:
                return
            
            # Update last check time
            self.state["last_check_times"]["memory_usage"] = now
            
            # Get alert config
            alert_config = self.alert_manager.alert_configs.get("high_memory_usage")
            if not alert_config or not alert_config.enabled:
                return
            
            # Get parameters
            threshold = alert_config.parameters.get("threshold", 0.9)
            duration = alert_config.parameters.get("duration", 300)
            
            # Get memory usage
            import psutil
            memory = psutil.virtual_memory()
            memory_percent = memory.percent / 100.0
            
            # Update memory usage history
            if "memory" not in self.state["memory_usage_history"]:
                self.state["memory_usage_history"]["memory"] = []
            
            history = self.state["memory_usage_history"]["memory"]
            history.append((now, memory_percent))
            
            # Remove old entries
            cutoff = now - duration
            history = [entry for entry in history if entry[0] >= cutoff]
            
            # Update history in state
            self.state["memory_usage_history"]["memory"] = history
            
            # Check if memory usage is consistently high
            if len(history) >= 3:  # Require at least 3 data points
                high_count = sum(1 for _, usage in history if usage >= threshold)
                high_percent = high_count / len(history)
                
                if high_percent >= 0.8:  # 80% of samples are high
                    # Prepare alert data
                    alert_data = {
                        "source_id": "memory",
                        "source_type": "system",
                        "current_usage": memory_percent,
                        "average_usage": sum(usage for _, usage in history) / len(history),
                        "threshold": threshold,
                        "duration": duration,
                        "total_gb": memory.total / (1024 ** 3),
                        "available_gb": memory.available / (1024 ** 3),
                        "message": f"High memory usage: {memory_percent:.2%} (Threshold: {threshold:.2%})"
                    }
                    
                    # Trigger alert
                    self.alert_manager.trigger_alert("high_memory_usage", alert_data)
        except Exception as e:
            logger.error(f"Error checking memory usage: {e}")
    
    def _check_production_run_status(self, now: float):
        """
        Check production run status.
        
        Args:
            now: Current time
        """
        try:
            # Get check interval
            interval = self.config.get("check_intervals", {}).get("production_run", 10)
            
            # Get last check time
            last_check = self.state["last_check_times"].get("production_run", 0)
            
            # Check if it's time to check
            if now - last_check < interval:
                return
            
            # Update last check time
            self.state["last_check_times"]["production_run"] = now
            
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Get production runs with status changes
            cursor.execute(
                """
                SELECT * FROM production_runs
                WHERE status_changed_at > datetime(?, 'unixepoch')
                """,
                (last_check,)
            )
            runs = [dict(row) for row in cursor.fetchall()]
            
            # Process each run
            for run in runs:
                run_id = run["run_id"]
                status = run["status"]
                
                if status == "active":
                    # Check if we should trigger production_run_started alert
                    alert_config = self.alert_manager.alert_configs.get("production_run_started")
                    if alert_config and alert_config.enabled:
                        # Prepare alert data
                        alert_data = {
                            "source_id": run_id,
                            "source_type": "production_run",
                            "run_id": run_id,
                            "product_type": run["product_type"],
                            "batch_number": run["batch_number"],
                            "start_time": run["start_time"],
                            "operator": run["operator"],
                            "message": f"Production run started: {run_id} ({run['product_type']}, Batch: {run['batch_number']})"
                        }
                        
                        # Trigger alert
                        self.alert_manager.trigger_alert("production_run_started", alert_data)
                
                elif status == "completed":
                    # Check if we should trigger production_run_completed alert
                    alert_config = self.alert_manager.alert_configs.get("production_run_completed")
                    if alert_config and alert_config.enabled:
                        # Get run summary
                        if alert_config.parameters.get("include_summary", True):
                            # Get inspection results
                            cursor.execute(
                                """
                                SELECT COUNT(*) as total, SUM(rejected) as rejected
                                FROM inspection_results
                                WHERE run_id = ?
                                """,
                                (run_id,)
                            )
                            summary_row = cursor.fetchone()
                            
                            if summary_row:
                                total_inspected = summary_row["total"] or 0
                                total_rejected = summary_row["rejected"] or 0
                                rejection_rate = total_rejected / total_inspected if total_inspected > 0 else 0
                                
                                summary = {
                                    "total_inspected": total_inspected,
                                    "total_rejected": total_rejected,
                                    "rejection_rate": rejection_rate
                                }
                            else:
                                summary = {
                                    "total_inspected": 0,
                                    "total_rejected": 0,
                                    "rejection_rate": 0
                                }
                        else:
                            summary = None
                        
                        # Calculate duration
                        try:
                            start_time = datetime.datetime.fromisoformat(run["start_time"].replace("Z", "+00:00"))
                            end_time = datetime.datetime.fromisoformat(run["end_time"].replace("Z", "+00:00"))
                            duration = end_time - start_time
                            duration_str = str(duration)
                        except (ValueError, TypeError):
                            duration_str = "Unknown"
                        
                        # Prepare alert data
                        alert_data = {
                            "source_id": run_id,
                            "source_type": "production_run",
                            "run_id": run_id,
                            "product_type": run["product_type"],
                            "batch_number": run["batch_number"],
                            "start_time": run["start_time"],
                            "end_time": run["end_time"],
                            "duration": duration_str,
                            "operator": run["operator"],
                            "summary": summary,
                            "message": f"Production run completed: {run_id} ({run['product_type']}, Batch: {run['batch_number']})"
                        }
                        
                        # Trigger alert
                        self.alert_manager.trigger_alert("production_run_completed", alert_data)
            
            # Close connection
            conn.close()
        except Exception as e:
            logger.error(f"Error checking production run status: {e}")


# Example usage
if __name__ == "__main__":
    # Setup logging
    logging.basicConfig(level=logging.INFO)
    
    # Create alert manager
    alert_manager = AlertManager(
        db_path="data/database/sandwich_inspection.db",
        config_path="config/alerts.yaml",
        templates_dir="data/alerts/templates",
        output_dir="data/alerts/output"
    )
    
    # Start alert worker
    alert_manager.start_alert_worker()
    
    # Create alert monitor
    alert_monitor = AlertMonitor(
        alert_manager=alert_manager,
        db_path="data/database/sandwich_inspection.db",
        config_path="config/alert_monitor.yaml"
    )
    
    # Start alert monitor
    alert_monitor.start_monitor()
    
    # Trigger test alert
    alert_id = alert_manager.trigger_alert(
        "system_error",
        {
            "message": "Test system error alert",
            "source_id": "test",
            "source_type": "test"
        }
    )
    print(f"Triggered test alert: {alert_id}")
    
    # Wait for alert to be processed
    time.sleep(5)
    
    # Get alert status
    status = alert_manager.get_alert_status(alert_id)
    print(f"Alert status: {status}")
    
    # Stop alert worker and monitor
    alert_manager.stop_alert_worker()
    alert_monitor.stop_monitor()
