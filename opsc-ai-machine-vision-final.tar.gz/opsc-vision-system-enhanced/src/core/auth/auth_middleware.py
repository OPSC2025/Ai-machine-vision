"""
Authentication middleware for Streamlit UI integration.
Provides authentication and authorization for the OPSC Sandwich Quality Inspection System UI.

Version: 1.0.0
Last Updated: 2025-04-21
"""

import os
import sys
import time
import json
import logging
import hashlib
import secrets
import datetime
from typing import Dict, List, Optional, Tuple, Union, Any, Callable
import streamlit as st
from functools import wraps

# Add project root to path
project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if project_root not in sys.path:
    sys.path.append(project_root)

# Import authentication manager
from src.core.auth.authentication import AuthenticationManager, UserRole, UserStatus, User

# Setup logging
logger = logging.getLogger(__name__)

class AuthMiddleware:
    """
    Authentication middleware for Streamlit UI.
    
    Provides authentication and authorization for the OPSC Sandwich Quality Inspection System UI.
    """
    
    def __init__(self, auth_manager: AuthenticationManager):
        """
        Initialize authentication middleware.
        
        Args:
            auth_manager: Authentication manager instance
        """
        self.auth_manager = auth_manager
        
        # Initialize session state
        if "authenticated" not in st.session_state:
            st.session_state.authenticated = False
        if "user" not in st.session_state:
            st.session_state.user = None
        if "token" not in st.session_state:
            st.session_state.token = None
    
    def login_page(self):
        """Display login page and handle authentication."""
        st.title("OPSC Sandwich Quality Inspection System")
        
        # Check if already authenticated
        if st.session_state.authenticated:
            st.success(f"Logged in as {st.session_state.user.username}")
            if st.button("Logout"):
                self.logout()
            return True
        
        # Display login form
        with st.form("login_form"):
            st.subheader("Login")
            username = st.text_input("Username")
            password = st.text_input("Password", type="password")
            submit = st.form_submit_button("Login")
            
            if submit:
                if not username or not password:
                    st.error("Please enter username and password")
                    return False
                
                # Get client info
                ip_address = None
                user_agent = None
                
                # Authenticate user
                token = self.auth_manager.authenticate(username, password, ip_address, user_agent)
                if token:
                    # Get user
                    user = self.auth_manager.validate_token(token)
                    if user:
                        # Set session state
                        st.session_state.authenticated = True
                        st.session_state.user = user
                        st.session_state.token = token
                        
                        st.success(f"Welcome, {user.full_name or user.username}!")
                        st.experimental_rerun()
                        return True
                    else:
                        st.error("Authentication failed: Invalid token")
                        return False
                else:
                    st.error("Authentication failed: Invalid username or password")
                    return False
        
        return False
    
    def logout(self):
        """Logout current user."""
        if st.session_state.authenticated and st.session_state.token:
            # Logout user
            self.auth_manager.logout(st.session_state.token)
            
            # Clear session state
            st.session_state.authenticated = False
            st.session_state.user = None
            st.session_state.token = None
            
            st.success("Logged out successfully")
            st.experimental_rerun()
    
    def require_auth(self, page_func: Callable):
        """
        Decorator to require authentication for a page.
        
        Args:
            page_func: Page function to decorate
        
        Returns:
            Decorated function
        """
        @wraps(page_func)
        def wrapper(*args, **kwargs):
            # Check if authenticated
            if not st.session_state.authenticated or not st.session_state.user:
                # Display login page
                if not self.login_page():
                    return
            
            # Call page function
            return page_func(*args, **kwargs)
        
        return wrapper
    
    def require_role(self, roles: Union[UserRole, List[UserRole]]):
        """
        Decorator to require specific role(s) for a page.
        
        Args:
            roles: Required role(s)
        
        Returns:
            Decorator function
        """
        if isinstance(roles, UserRole):
            roles = [roles]
        
        def decorator(page_func: Callable):
            @wraps(page_func)
            def wrapper(*args, **kwargs):
                # Check if authenticated
                if not st.session_state.authenticated or not st.session_state.user:
                    # Display login page
                    if not self.login_page():
                        return
                
                # Check if user has required role
                user_role = st.session_state.user.role
                if user_role not in roles and UserRole.ADMIN not in roles:
                    st.error(f"Access denied: You need one of these roles: {', '.join([r.value for r in roles])}")
                    return
                
                # Call page function
                return page_func(*args, **kwargs)
            
            return wrapper
        
        return decorator
    
    def user_management_page(self):
        """Display user management page."""
        st.title("User Management")
        
        # Check if authenticated and has admin role
        if not st.session_state.authenticated or not st.session_state.user:
            st.error("You must be logged in to access this page")
            return
        
        if st.session_state.user.role != UserRole.ADMIN:
            st.error("You must be an administrator to access this page")
            return
        
        # Display user list
        st.subheader("Users")
        users = self.auth_manager.list_users()
        
        # Create user table
        user_data = []
        for user in users:
            user_data.append({
                "Username": user.username,
                "Email": user.email,
                "Full Name": user.full_name or "",
                "Role": user.role.value,
                "Status": user.status.value,
                "Last Login": user.last_login.strftime("%Y-%m-%d %H:%M:%S") if user.last_login else "Never"
            })
        
        if user_data:
            st.dataframe(user_data)
        else:
            st.info("No users found")
        
        # Create new user form
        st.subheader("Create New User")
        with st.form("create_user_form"):
            new_username = st.text_input("Username")
            new_email = st.text_input("Email")
            new_full_name = st.text_input("Full Name")
            new_password = st.text_input("Password", type="password")
            new_role = st.selectbox("Role", [r.value for r in UserRole])
            
            submit = st.form_submit_button("Create User")
            
            if submit:
                if not new_username or not new_email or not new_password:
                    st.error("Username, email, and password are required")
                else:
                    try:
                        # Create user
                        user = self.auth_manager.create_user(
                            username=new_username,
                            email=new_email,
                            password=new_password,
                            role=UserRole(new_role),
                            full_name=new_full_name
                        )
                        
                        st.success(f"User '{new_username}' created successfully")
                        st.experimental_rerun()
                    except ValueError as e:
                        st.error(f"Error creating user: {e}")
        
        # Reset password form
        st.subheader("Reset User Password")
        with st.form("reset_password_form"):
            reset_username = st.selectbox("User", [user.username for user in users])
            reset_password = st.text_input("New Password", type="password")
            
            submit = st.form_submit_button("Reset Password")
            
            if submit:
                if not reset_password:
                    st.error("New password is required")
                else:
                    # Reset password
                    if self.auth_manager.reset_password(reset_username, reset_password):
                        st.success(f"Password for user '{reset_username}' reset successfully")
                    else:
                        st.error(f"Error resetting password for user '{reset_username}'")
        
        # Update user status form
        st.subheader("Update User Status")
        with st.form("update_status_form"):
            update_username = st.selectbox("User", [user.username for user in users], key="update_status_user")
            update_status = st.selectbox("Status", [s.value for s in UserStatus])
            
            submit = st.form_submit_button("Update Status")
            
            if submit:
                # Update user status
                if self.auth_manager.update_user(update_username, status=UserStatus(update_status)):
                    st.success(f"Status for user '{update_username}' updated successfully")
                    st.experimental_rerun()
                else:
                    st.error(f"Error updating status for user '{update_username}'")
        
        # Delete user form
        st.subheader("Delete User")
        with st.form("delete_user_form"):
            delete_username = st.selectbox("User", [user.username for user in users if user.username != st.session_state.user.username], key="delete_user")
            
            submit = st.form_submit_button("Delete User")
            
            if submit:
                # Confirm deletion
                if st.button(f"Confirm deletion of user '{delete_username}'"):
                    # Delete user
                    if self.auth_manager.delete_user(delete_username):
                        st.success(f"User '{delete_username}' deleted successfully")
                        st.experimental_rerun()
                    else:
                        st.error(f"Error deleting user '{delete_username}'")
        
        # Display active sessions
        st.subheader("Active Sessions")
        sessions = self.auth_manager.list_active_sessions()
        
        # Create session table
        session_data = []
        for session in sessions:
            session_data.append({
                "Username": session["username"],
                "Created": session["created_at"],
                "Expires": session["expires_at"],
                "IP Address": session["ip_address"] or "Unknown",
                "User Agent": session["user_agent"] or "Unknown"
            })
        
        if session_data:
            st.dataframe(session_data)
        else:
            st.info("No active sessions found")
        
        # Display audit log
        st.subheader("Audit Log")
        audit_log = self.auth_manager.get_audit_log(limit=100)
        
        # Create audit log table
        audit_data = []
        for entry in audit_log:
            audit_data.append({
                "Timestamp": entry["timestamp"],
                "Username": entry["username"] or "System",
                "Action": entry["action"],
                "Details": entry["details"],
                "IP Address": entry["ip_address"] or "Unknown"
            })
        
        if audit_data:
            st.dataframe(audit_data)
        else:
            st.info("No audit log entries found")
    
    def profile_page(self):
        """Display user profile page."""
        st.title("User Profile")
        
        # Check if authenticated
        if not st.session_state.authenticated or not st.session_state.user:
            st.error("You must be logged in to access this page")
            return
        
        # Display user information
        user = st.session_state.user
        st.subheader("User Information")
        st.write(f"**Username:** {user.username}")
        st.write(f"**Email:** {user.email}")
        st.write(f"**Full Name:** {user.full_name or 'Not set'}")
        st.write(f"**Role:** {user.role.value}")
        st.write(f"**Status:** {user.status.value}")
        st.write(f"**Last Login:** {user.last_login.strftime('%Y-%m-%d %H:%M:%S') if user.last_login else 'Never'}")
        st.write(f"**Account Created:** {user.created_at.strftime('%Y-%m-%d %H:%M:%S') if user.created_at else 'Unknown'}")
        
        # Change password form
        st.subheader("Change Password")
        with st.form("change_password_form"):
            current_password = st.text_input("Current Password", type="password")
            new_password = st.text_input("New Password", type="password")
            confirm_password = st.text_input("Confirm New Password", type="password")
            
            submit = st.form_submit_button("Change Password")
            
            if submit:
                if not current_password or not new_password or not confirm_password:
                    st.error("All fields are required")
                elif new_password != confirm_password:
                    st.error("New passwords do not match")
                else:
                    # Change password
                    if self.auth_manager.change_password(user.username, current_password, new_password):
                        st.success("Password changed successfully")
                    else:
                        st.error("Error changing password: Invalid current password")
        
        # Update profile form
        st.subheader("Update Profile")
        with st.form("update_profile_form"):
            update_email = st.text_input("Email", value=user.email)
            update_full_name = st.text_input("Full Name", value=user.full_name or "")
            
            submit = st.form_submit_button("Update Profile")
            
            if submit:
                if not update_email:
                    st.error("Email is required")
                else:
                    # Update user profile
                    updated_user = self.auth_manager.update_user(
                        username=user.username,
                        email=update_email,
                        full_name=update_full_name
                    )
                    
                    if updated_user:
                        # Update session state
                        st.session_state.user = updated_user
                        
                        st.success("Profile updated successfully")
                        st.experimental_rerun()
                    else:
                        st.error("Error updating profile")


# Example usage
if __name__ == "__main__":
    # Setup logging
    logging.basicConfig(level=logging.INFO)
    
    # Create authentication manager
    from src.core.auth.authentication import AuthenticationManager
    auth_manager = AuthenticationManager("auth.db")
    
    # Create authentication middleware
    auth_middleware = AuthMiddleware(auth_manager)
    
    # Define a page that requires authentication
    @auth_middleware.require_auth
    def main_page():
        st.title("Main Page")
        st.write(f"Welcome, {st.session_state.user.full_name or st.session_state.user.username}!")
    
    # Define a page that requires admin role
    @auth_middleware.require_role(UserRole.ADMIN)
    def admin_page():
        st.title("Admin Page")
        st.write("This page is only accessible to administrators.")
    
    # Create a simple navigation
    st.sidebar.title("Navigation")
    page = st.sidebar.radio("Go to", ["Main", "Admin", "Profile", "User Management"])
    
    if page == "Main":
        main_page()
    elif page == "Admin":
        admin_page()
    elif page == "Profile":
        auth_middleware.profile_page()
    elif page == "User Management":
        auth_middleware.user_management_page()
