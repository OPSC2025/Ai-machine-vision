"""
Authentication system for OPSC Sandwich Quality Inspection System.
Provides user management, authentication, and authorization functionality.

Version: 1.0.0
Last Updated: 2025-04-21
"""

import os
import sys
import time
import json
import logging
import hashlib
import secrets
import datetime
from typing import Dict, List, Optional, Tuple, Union, Any
from dataclasses import dataclass, field
from enum import Enum
import sqlite3
import jwt

# Setup logging
logger = logging.getLogger(__name__)

# User roles
class UserRole(str, Enum):
    ADMIN = "admin"
    OPERATOR = "operator"
    VIEWER = "viewer"

# User status
class UserStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    LOCKED = "locked"

@dataclass
class User:
    """User data class."""
    username: str
    email: str
    role: UserRole
    status: UserStatus
    full_name: Optional[str] = None
    password_hash: Optional[str] = None
    salt: Optional[str] = None
    last_login: Optional[datetime.datetime] = None
    created_at: Optional[datetime.datetime] = None
    updated_at: Optional[datetime.datetime] = None
    failed_login_attempts: int = 0
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert user to dictionary."""
        return {
            "username": self.username,
            "email": self.email,
            "role": self.role.value if isinstance(self.role, UserRole) else self.role,
            "status": self.status.value if isinstance(self.status, UserStatus) else self.status,
            "full_name": self.full_name,
            "last_login": self.last_login.isoformat() if self.last_login else None,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "failed_login_attempts": self.failed_login_attempts
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'User':
        """Create user from dictionary."""
        return cls(
            username=data["username"],
            email=data["email"],
            role=UserRole(data["role"]) if isinstance(data["role"], str) else data["role"],
            status=UserStatus(data["status"]) if isinstance(data["status"], str) else data["status"],
            full_name=data.get("full_name"),
            password_hash=data.get("password_hash"),
            salt=data.get("salt"),
            last_login=datetime.datetime.fromisoformat(data["last_login"]) if data.get("last_login") else None,
            created_at=datetime.datetime.fromisoformat(data["created_at"]) if data.get("created_at") else None,
            updated_at=datetime.datetime.fromisoformat(data["updated_at"]) if data.get("updated_at") else None,
            failed_login_attempts=data.get("failed_login_attempts", 0)
        )

class AuthenticationManager:
    """
    Authentication manager for OPSC Sandwich Quality Inspection System.
    
    Provides user management, authentication, and authorization functionality.
    """
    
    def __init__(self, db_path: str, token_secret: Optional[str] = None, token_expiry: int = 86400):
        """
        Initialize authentication manager.
        
        Args:
            db_path: Path to SQLite database file
            token_secret: Secret key for JWT token generation (if None, a random key will be generated)
            token_expiry: Token expiry time in seconds (default: 24 hours)
        """
        self.db_path = db_path
        self.token_secret = token_secret or secrets.token_hex(32)
        self.token_expiry = token_expiry
        
        # Initialize database
        self._init_db()
    
    def _init_db(self):
        """Initialize database schema."""
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Create users table if it doesn't exist
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                username TEXT PRIMARY KEY,
                email TEXT UNIQUE,
                full_name TEXT,
                password_hash TEXT,
                salt TEXT,
                role TEXT,
                status TEXT,
                last_login TEXT,
                created_at TEXT,
                updated_at TEXT,
                failed_login_attempts INTEGER DEFAULT 0
            )
            ''')
            
            # Create sessions table if it doesn't exist
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS sessions (
                token TEXT PRIMARY KEY,
                username TEXT,
                created_at TEXT,
                expires_at TEXT,
                ip_address TEXT,
                user_agent TEXT,
                FOREIGN KEY (username) REFERENCES users (username)
            )
            ''')
            
            # Create audit log table if it doesn't exist
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS audit_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT,
                username TEXT,
                action TEXT,
                details TEXT,
                ip_address TEXT
            )
            ''')
            
            # Commit changes
            conn.commit()
            
            # Check if admin user exists, create if not
            cursor.execute("SELECT COUNT(*) FROM users WHERE username = 'admin'")
            if cursor.fetchone()[0] == 0:
                # Create default admin user
                self.create_user(
                    username="admin",
                    email="admin@example.com",
                    password="admin123",  # This should be changed immediately
                    role=UserRole.ADMIN,
                    full_name="System Administrator"
                )
                logger.warning("Created default admin user. Please change the password immediately.")
            
            # Close connection
            conn.close()
            
            logger.info("Authentication database initialized successfully.")
        except Exception as e:
            logger.error(f"Error initializing authentication database: {e}")
            raise
    
    def _hash_password(self, password: str, salt: Optional[str] = None) -> Tuple[str, str]:
        """
        Hash password with salt.
        
        Args:
            password: Plain text password
            salt: Salt for password hashing (if None, a new salt will be generated)
        
        Returns:
            Tuple of (password_hash, salt)
        """
        # Generate salt if not provided
        if salt is None:
            salt = secrets.token_hex(16)
        
        # Hash password with salt
        password_hash = hashlib.pbkdf2_hmac(
            'sha256',
            password.encode('utf-8'),
            salt.encode('utf-8'),
            100000
        ).hex()
        
        return password_hash, salt
    
    def create_user(self, username: str, email: str, password: str, role: UserRole, full_name: Optional[str] = None) -> User:
        """
        Create a new user.
        
        Args:
            username: Username
            email: Email address
            password: Plain text password
            role: User role
            full_name: Full name (optional)
        
        Returns:
            Created user
        
        Raises:
            ValueError: If username or email already exists
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Check if username already exists
            cursor.execute("SELECT COUNT(*) FROM users WHERE username = ?", (username,))
            if cursor.fetchone()[0] > 0:
                raise ValueError(f"Username '{username}' already exists")
            
            # Check if email already exists
            cursor.execute("SELECT COUNT(*) FROM users WHERE email = ?", (email,))
            if cursor.fetchone()[0] > 0:
                raise ValueError(f"Email '{email}' already exists")
            
            # Hash password
            password_hash, salt = self._hash_password(password)
            
            # Get current timestamp
            now = datetime.datetime.now()
            
            # Create user
            user = User(
                username=username,
                email=email,
                role=role,
                status=UserStatus.ACTIVE,
                full_name=full_name,
                password_hash=password_hash,
                salt=salt,
                created_at=now,
                updated_at=now
            )
            
            # Insert user into database
            cursor.execute('''
            INSERT INTO users (username, email, full_name, password_hash, salt, role, status, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                user.username,
                user.email,
                user.full_name,
                user.password_hash,
                user.salt,
                user.role.value,
                user.status.value,
                user.created_at.isoformat(),
                user.updated_at.isoformat()
            ))
            
            # Commit changes
            conn.commit()
            
            # Log action
            self._log_audit("create_user", f"Created user '{username}'", username=username)
            
            # Close connection
            conn.close()
            
            logger.info(f"Created user '{username}' with role '{role.value}'")
            
            return user
        except Exception as e:
            logger.error(f"Error creating user: {e}")
            raise
    
    def get_user(self, username: str) -> Optional[User]:
        """
        Get user by username.
        
        Args:
            username: Username
        
        Returns:
            User if found, None otherwise
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Get user from database
            cursor.execute('''
            SELECT username, email, full_name, password_hash, salt, role, status, last_login, created_at, updated_at, failed_login_attempts
            FROM users
            WHERE username = ?
            ''', (username,))
            
            row = cursor.fetchone()
            
            # Close connection
            conn.close()
            
            if row is None:
                return None
            
            # Create user object
            user = User(
                username=row[0],
                email=row[1],
                full_name=row[2],
                password_hash=row[3],
                salt=row[4],
                role=UserRole(row[5]),
                status=UserStatus(row[6]),
                last_login=datetime.datetime.fromisoformat(row[7]) if row[7] else None,
                created_at=datetime.datetime.fromisoformat(row[8]) if row[8] else None,
                updated_at=datetime.datetime.fromisoformat(row[9]) if row[9] else None,
                failed_login_attempts=row[10]
            )
            
            return user
        except Exception as e:
            logger.error(f"Error getting user: {e}")
            return None
    
    def update_user(self, username: str, email: Optional[str] = None, role: Optional[UserRole] = None,
                   status: Optional[UserStatus] = None, full_name: Optional[str] = None) -> Optional[User]:
        """
        Update user.
        
        Args:
            username: Username
            email: New email address (optional)
            role: New user role (optional)
            status: New user status (optional)
            full_name: New full name (optional)
        
        Returns:
            Updated user if successful, None otherwise
        """
        try:
            # Get current user
            user = self.get_user(username)
            if user is None:
                logger.error(f"User '{username}' not found")
                return None
            
            # Update user fields
            if email is not None:
                user.email = email
            if role is not None:
                user.role = role
            if status is not None:
                user.status = status
            if full_name is not None:
                user.full_name = full_name
            
            # Update timestamp
            user.updated_at = datetime.datetime.now()
            
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Update user in database
            cursor.execute('''
            UPDATE users
            SET email = ?, role = ?, status = ?, full_name = ?, updated_at = ?
            WHERE username = ?
            ''', (
                user.email,
                user.role.value,
                user.status.value,
                user.full_name,
                user.updated_at.isoformat(),
                user.username
            ))
            
            # Commit changes
            conn.commit()
            
            # Log action
            self._log_audit("update_user", f"Updated user '{username}'", username=username)
            
            # Close connection
            conn.close()
            
            logger.info(f"Updated user '{username}'")
            
            return user
        except Exception as e:
            logger.error(f"Error updating user: {e}")
            return None
    
    def delete_user(self, username: str) -> bool:
        """
        Delete user.
        
        Args:
            username: Username
        
        Returns:
            True if successful, False otherwise
        """
        try:
            # Check if user exists
            user = self.get_user(username)
            if user is None:
                logger.error(f"User '{username}' not found")
                return False
            
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Delete user from database
            cursor.execute("DELETE FROM users WHERE username = ?", (username,))
            
            # Delete user sessions
            cursor.execute("DELETE FROM sessions WHERE username = ?", (username,))
            
            # Commit changes
            conn.commit()
            
            # Log action
            self._log_audit("delete_user", f"Deleted user '{username}'", username=username)
            
            # Close connection
            conn.close()
            
            logger.info(f"Deleted user '{username}'")
            
            return True
        except Exception as e:
            logger.error(f"Error deleting user: {e}")
            return False
    
    def change_password(self, username: str, current_password: str, new_password: str) -> bool:
        """
        Change user password.
        
        Args:
            username: Username
            current_password: Current password
            new_password: New password
        
        Returns:
            True if successful, False otherwise
        """
        try:
            # Get user
            user = self.get_user(username)
            if user is None:
                logger.error(f"User '{username}' not found")
                return False
            
            # Verify current password
            password_hash, _ = self._hash_password(current_password, user.salt)
            if password_hash != user.password_hash:
                logger.error(f"Invalid current password for user '{username}'")
                return False
            
            # Hash new password
            password_hash, salt = self._hash_password(new_password)
            
            # Update timestamp
            updated_at = datetime.datetime.now()
            
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Update password in database
            cursor.execute('''
            UPDATE users
            SET password_hash = ?, salt = ?, updated_at = ?
            WHERE username = ?
            ''', (
                password_hash,
                salt,
                updated_at.isoformat(),
                username
            ))
            
            # Commit changes
            conn.commit()
            
            # Log action
            self._log_audit("change_password", f"Changed password for user '{username}'", username=username)
            
            # Close connection
            conn.close()
            
            logger.info(f"Changed password for user '{username}'")
            
            return True
        except Exception as e:
            logger.error(f"Error changing password: {e}")
            return False
    
    def reset_password(self, username: str, new_password: str) -> bool:
        """
        Reset user password (admin function).
        
        Args:
            username: Username
            new_password: New password
        
        Returns:
            True if successful, False otherwise
        """
        try:
            # Get user
            user = self.get_user(username)
            if user is None:
                logger.error(f"User '{username}' not found")
                return False
            
            # Hash new password
            password_hash, salt = self._hash_password(new_password)
            
            # Update timestamp
            updated_at = datetime.datetime.now()
            
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Update password in database
            cursor.execute('''
            UPDATE users
            SET password_hash = ?, salt = ?, updated_at = ?, failed_login_attempts = 0, status = ?
            WHERE username = ?
            ''', (
                password_hash,
                salt,
                updated_at.isoformat(),
                UserStatus.ACTIVE.value,
                username
            ))
            
            # Commit changes
            conn.commit()
            
            # Log action
            self._log_audit("reset_password", f"Reset password for user '{username}'", username=username)
            
            # Close connection
            conn.close()
            
            logger.info(f"Reset password for user '{username}'")
            
            return True
        except Exception as e:
            logger.error(f"Error resetting password: {e}")
            return False
    
    def authenticate(self, username: str, password: str, ip_address: Optional[str] = None, user_agent: Optional[str] = None) -> Optional[str]:
        """
        Authenticate user and generate JWT token.
        
        Args:
            username: Username
            password: Password
            ip_address: Client IP address (optional)
            user_agent: Client user agent (optional)
        
        Returns:
            JWT token if authentication successful, None otherwise
        """
        try:
            # Get user
            user = self.get_user(username)
            if user is None:
                logger.error(f"User '{username}' not found")
                return None
            
            # Check if user is active
            if user.status != UserStatus.ACTIVE:
                logger.error(f"User '{username}' is not active (status: {user.status.value})")
                return None
            
            # Verify password
            password_hash, _ = self._hash_password(password, user.salt)
            if password_hash != user.password_hash:
                # Increment failed login attempts
                self._increment_failed_login(username)
                logger.error(f"Invalid password for user '{username}'")
                return None
            
            # Reset failed login attempts
            self._reset_failed_login(username)
            
            # Update last login timestamp
            self._update_last_login(username)
            
            # Generate token
            token = self._generate_token(username)
            
            # Store session
            self._store_session(token, username, ip_address, user_agent)
            
            # Log action
            self._log_audit("login", f"User '{username}' logged in", username=username, ip_address=ip_address)
            
            logger.info(f"User '{username}' authenticated successfully")
            
            return token
        except Exception as e:
            logger.error(f"Error authenticating user: {e}")
            return None
    
    def validate_token(self, token: str) -> Optional[User]:
        """
        Validate JWT token and return user.
        
        Args:
            token: JWT token
        
        Returns:
            User if token is valid, None otherwise
        """
        try:
            # Decode token
            payload = jwt.decode(token, self.token_secret, algorithms=["HS256"])
            
            # Check if token is expired
            if "exp" in payload and payload["exp"] < time.time():
                logger.error("Token expired")
                return None
            
            # Get username from token
            username = payload.get("sub")
            if not username:
                logger.error("Invalid token: missing subject")
                return None
            
            # Check if session exists
            if not self._check_session(token):
                logger.error(f"Session not found for token")
                return None
            
            # Get user
            user = self.get_user(username)
            if user is None:
                logger.error(f"User '{username}' not found")
                return None
            
            # Check if user is active
            if user.status != UserStatus.ACTIVE:
                logger.error(f"User '{username}' is not active (status: {user.status.value})")
                return None
            
            return user
        except jwt.InvalidTokenError:
            logger.error("Invalid token")
            return None
        except Exception as e:
            logger.error(f"Error validating token: {e}")
            return None
    
    def logout(self, token: str) -> bool:
        """
        Logout user by invalidating token.
        
        Args:
            token: JWT token
        
        Returns:
            True if successful, False otherwise
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Get username from session
            cursor.execute("SELECT username FROM sessions WHERE token = ?", (token,))
            row = cursor.fetchone()
            
            if row is None:
                logger.error(f"Session not found for token")
                return False
            
            username = row[0]
            
            # Delete session
            cursor.execute("DELETE FROM sessions WHERE token = ?", (token,))
            
            # Commit changes
            conn.commit()
            
            # Log action
            self._log_audit("logout", f"User '{username}' logged out", username=username)
            
            # Close connection
            conn.close()
            
            logger.info(f"User '{username}' logged out")
            
            return True
        except Exception as e:
            logger.error(f"Error logging out: {e}")
            return False
    
    def list_users(self) -> List[User]:
        """
        List all users.
        
        Returns:
            List of users
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Get users from database
            cursor.execute('''
            SELECT username, email, full_name, password_hash, salt, role, status, last_login, created_at, updated_at, failed_login_attempts
            FROM users
            ORDER BY username
            ''')
            
            rows = cursor.fetchall()
            
            # Close connection
            conn.close()
            
            # Create user objects
            users = []
            for row in rows:
                user = User(
                    username=row[0],
                    email=row[1],
                    full_name=row[2],
                    password_hash=row[3],
                    salt=row[4],
                    role=UserRole(row[5]),
                    status=UserStatus(row[6]),
                    last_login=datetime.datetime.fromisoformat(row[7]) if row[7] else None,
                    created_at=datetime.datetime.fromisoformat(row[8]) if row[8] else None,
                    updated_at=datetime.datetime.fromisoformat(row[9]) if row[9] else None,
                    failed_login_attempts=row[10]
                )
                users.append(user)
            
            return users
        except Exception as e:
            logger.error(f"Error listing users: {e}")
            return []
    
    def list_active_sessions(self) -> List[Dict[str, Any]]:
        """
        List all active sessions.
        
        Returns:
            List of sessions
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Get sessions from database
            cursor.execute('''
            SELECT token, username, created_at, expires_at, ip_address, user_agent
            FROM sessions
            ORDER BY created_at DESC
            ''')
            
            rows = cursor.fetchall()
            
            # Close connection
            conn.close()
            
            # Create session objects
            sessions = []
            for row in rows:
                session = {
                    "token": row[0],
                    "username": row[1],
                    "created_at": row[2],
                    "expires_at": row[3],
                    "ip_address": row[4],
                    "user_agent": row[5]
                }
                sessions.append(session)
            
            return sessions
        except Exception as e:
            logger.error(f"Error listing sessions: {e}")
            return []
    
    def get_audit_log(self, limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        """
        Get audit log entries.
        
        Args:
            limit: Maximum number of entries to return
            offset: Offset for pagination
        
        Returns:
            List of audit log entries
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Get audit log entries from database
            cursor.execute('''
            SELECT id, timestamp, username, action, details, ip_address
            FROM audit_log
            ORDER BY timestamp DESC
            LIMIT ? OFFSET ?
            ''', (limit, offset))
            
            rows = cursor.fetchall()
            
            # Close connection
            conn.close()
            
            # Create audit log entry objects
            entries = []
            for row in rows:
                entry = {
                    "id": row[0],
                    "timestamp": row[1],
                    "username": row[2],
                    "action": row[3],
                    "details": row[4],
                    "ip_address": row[5]
                }
                entries.append(entry)
            
            return entries
        except Exception as e:
            logger.error(f"Error getting audit log: {e}")
            return []
    
    def _generate_token(self, username: str) -> str:
        """
        Generate JWT token for user.
        
        Args:
            username: Username
        
        Returns:
            JWT token
        """
        # Get current timestamp
        now = int(time.time())
        
        # Create token payload
        payload = {
            "sub": username,
            "iat": now,
            "exp": now + self.token_expiry
        }
        
        # Generate token
        token = jwt.encode(payload, self.token_secret, algorithm="HS256")
        
        return token
    
    def _store_session(self, token: str, username: str, ip_address: Optional[str] = None, user_agent: Optional[str] = None):
        """
        Store session in database.
        
        Args:
            token: JWT token
            username: Username
            ip_address: Client IP address (optional)
            user_agent: Client user agent (optional)
        """
        try:
            # Get current timestamp
            now = datetime.datetime.now()
            
            # Calculate expiry timestamp
            expires_at = now + datetime.timedelta(seconds=self.token_expiry)
            
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Insert session into database
            cursor.execute('''
            INSERT INTO sessions (token, username, created_at, expires_at, ip_address, user_agent)
            VALUES (?, ?, ?, ?, ?, ?)
            ''', (
                token,
                username,
                now.isoformat(),
                expires_at.isoformat(),
                ip_address,
                user_agent
            ))
            
            # Commit changes
            conn.commit()
            
            # Close connection
            conn.close()
        except Exception as e:
            logger.error(f"Error storing session: {e}")
            raise
    
    def _check_session(self, token: str) -> bool:
        """
        Check if session exists and is valid.
        
        Args:
            token: JWT token
        
        Returns:
            True if session exists and is valid, False otherwise
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Get session from database
            cursor.execute('''
            SELECT expires_at
            FROM sessions
            WHERE token = ?
            ''', (token,))
            
            row = cursor.fetchone()
            
            # Close connection
            conn.close()
            
            if row is None:
                return False
            
            # Check if session is expired
            expires_at = datetime.datetime.fromisoformat(row[0])
            if expires_at < datetime.datetime.now():
                return False
            
            return True
        except Exception as e:
            logger.error(f"Error checking session: {e}")
            return False
    
    def _update_last_login(self, username: str):
        """
        Update user's last login timestamp.
        
        Args:
            username: Username
        """
        try:
            # Get current timestamp
            now = datetime.datetime.now()
            
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Update last login timestamp
            cursor.execute('''
            UPDATE users
            SET last_login = ?
            WHERE username = ?
            ''', (
                now.isoformat(),
                username
            ))
            
            # Commit changes
            conn.commit()
            
            # Close connection
            conn.close()
        except Exception as e:
            logger.error(f"Error updating last login: {e}")
    
    def _increment_failed_login(self, username: str):
        """
        Increment failed login attempts for user.
        
        Args:
            username: Username
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Get current failed login attempts
            cursor.execute('''
            SELECT failed_login_attempts
            FROM users
            WHERE username = ?
            ''', (username,))
            
            row = cursor.fetchone()
            if row is None:
                return
            
            failed_attempts = row[0] + 1
            
            # Update failed login attempts
            cursor.execute('''
            UPDATE users
            SET failed_login_attempts = ?
            WHERE username = ?
            ''', (
                failed_attempts,
                username
            ))
            
            # Lock account if too many failed attempts
            if failed_attempts >= 5:
                cursor.execute('''
                UPDATE users
                SET status = ?
                WHERE username = ?
                ''', (
                    UserStatus.LOCKED.value,
                    username
                ))
                
                # Log action
                self._log_audit("lock_account", f"Account locked due to too many failed login attempts", username=username)
                
                logger.warning(f"Account '{username}' locked due to too many failed login attempts")
            
            # Commit changes
            conn.commit()
            
            # Close connection
            conn.close()
        except Exception as e:
            logger.error(f"Error incrementing failed login attempts: {e}")
    
    def _reset_failed_login(self, username: str):
        """
        Reset failed login attempts for user.
        
        Args:
            username: Username
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Reset failed login attempts
            cursor.execute('''
            UPDATE users
            SET failed_login_attempts = 0
            WHERE username = ?
            ''', (username,))
            
            # Commit changes
            conn.commit()
            
            # Close connection
            conn.close()
        except Exception as e:
            logger.error(f"Error resetting failed login attempts: {e}")
    
    def _log_audit(self, action: str, details: str, username: Optional[str] = None, ip_address: Optional[str] = None):
        """
        Log audit event.
        
        Args:
            action: Action performed
            details: Action details
            username: Username (optional)
            ip_address: Client IP address (optional)
        """
        try:
            # Get current timestamp
            now = datetime.datetime.now()
            
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Insert audit log entry
            cursor.execute('''
            INSERT INTO audit_log (timestamp, username, action, details, ip_address)
            VALUES (?, ?, ?, ?, ?)
            ''', (
                now.isoformat(),
                username,
                action,
                details,
                ip_address
            ))
            
            # Commit changes
            conn.commit()
            
            # Close connection
            conn.close()
        except Exception as e:
            logger.error(f"Error logging audit event: {e}")


# Example usage
if __name__ == "__main__":
    # Setup logging
    logging.basicConfig(level=logging.INFO)
    
    # Create authentication manager
    auth_manager = AuthenticationManager("auth.db")
    
    # Create test user
    try:
        user = auth_manager.create_user(
            username="testuser",
            email="test@example.com",
            password="password123",
            role=UserRole.OPERATOR,
            full_name="Test User"
        )
        print(f"Created user: {user.to_dict()}")
    except ValueError as e:
        print(f"Error creating user: {e}")
    
    # Authenticate user
    token = auth_manager.authenticate("testuser", "password123")
    if token:
        print(f"Authentication successful. Token: {token}")
        
        # Validate token
        user = auth_manager.validate_token(token)
        if user:
            print(f"Token validation successful. User: {user.to_dict()}")
        else:
            print("Token validation failed")
        
        # Logout
        if auth_manager.logout(token):
            print("Logout successful")
        else:
            print("Logout failed")
    else:
        print("Authentication failed")
