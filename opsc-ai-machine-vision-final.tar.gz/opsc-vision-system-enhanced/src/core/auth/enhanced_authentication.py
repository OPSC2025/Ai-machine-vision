"""
Enhanced Authentication system for OPSC Sandwich Quality Inspection System.
Provides advanced user management, authentication, authorization, and security features.

Version: 2.0.0
Last Updated: 2025-04-22
"""

import os
import sys
import time
import json
import logging
import hashlib
import secrets
import datetime
import ipaddress
import re
import base64
from typing import Dict, List, Optional, Tuple, Union, Any, Set
from dataclasses import dataclass, field
from enum import Enum
import sqlite3
import jwt
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.backends import default_backend
import pyotp
import qrcode
from io import BytesIO

# Setup logging
logger = logging.getLogger(__name__)

# User roles with hierarchical permissions
class UserRole(str, Enum):
    ADMIN = "admin"  # Full system access
    SUPERVISOR = "supervisor"  # Production management and reporting
    OPERATOR = "operator"  # Machine operation and basic reporting
    MAINTENANCE = "maintenance"  # System maintenance and diagnostics
    QUALITY = "quality"  # Quality control and inspection
    VIEWER = "viewer"  # Read-only access to dashboards and reports

# User status
class UserStatus(str, Enum):
    ACTIVE = "active"  # User is active and can log in
    INACTIVE = "inactive"  # User is inactive and cannot log in
    LOCKED = "locked"  # User is locked due to failed login attempts
    PENDING = "pending"  # User is pending approval
    PASSWORD_RESET = "password_reset"  # User must reset password on next login

# Authentication methods
class AuthMethod(str, Enum):
    PASSWORD = "password"  # Standard password authentication
    TOTP = "totp"  # Time-based one-time password (2FA)
    SSO = "sso"  # Single sign-on
    API_KEY = "api_key"  # API key for programmatic access

# Permission scopes
class PermissionScope(str, Enum):
    # System management
    SYSTEM_ADMIN = "system:admin"  # Full system administration
    SYSTEM_CONFIG = "system:config"  # System configuration
    SYSTEM_MONITOR = "system:monitor"  # System monitoring
    
    # User management
    USER_ADMIN = "user:admin"  # User administration
    USER_VIEW = "user:view"  # View user information
    
    # Production management
    PRODUCTION_ADMIN = "production:admin"  # Production administration
    PRODUCTION_START = "production:start"  # Start production runs
    PRODUCTION_STOP = "production:stop"  # Stop production runs
    PRODUCTION_VIEW = "production:view"  # View production information
    
    # Camera management
    CAMERA_ADMIN = "camera:admin"  # Camera administration
    CAMERA_CONFIG = "camera:config"  # Camera configuration
    CAMERA_VIEW = "camera:view"  # View camera feeds
    
    # Model management
    MODEL_ADMIN = "model:admin"  # Model administration
    MODEL_TRAIN = "model:train"  # Train models
    MODEL_DEPLOY = "model:deploy"  # Deploy models
    MODEL_VIEW = "model:view"  # View model information
    
    # Defect management
    DEFECT_ADMIN = "defect:admin"  # Defect administration
    DEFECT_ANNOTATE = "defect:annotate"  # Annotate defects
    DEFECT_VIEW = "defect:view"  # View defect information
    
    # Reporting
    REPORT_ADMIN = "report:admin"  # Report administration
    REPORT_CREATE = "report:create"  # Create reports
    REPORT_VIEW = "report:view"  # View reports
    
    # API access
    API_ADMIN = "api:admin"  # API administration
    API_WRITE = "api:write"  # Write API access
    API_READ = "api:read"  # Read API access

# Role to permission mapping
ROLE_PERMISSIONS = {
    UserRole.ADMIN: {
        PermissionScope.SYSTEM_ADMIN,
        PermissionScope.SYSTEM_CONFIG,
        PermissionScope.SYSTEM_MONITOR,
        PermissionScope.USER_ADMIN,
        PermissionScope.USER_VIEW,
        PermissionScope.PRODUCTION_ADMIN,
        PermissionScope.PRODUCTION_START,
        PermissionScope.PRODUCTION_STOP,
        PermissionScope.PRODUCTION_VIEW,
        PermissionScope.CAMERA_ADMIN,
        PermissionScope.CAMERA_CONFIG,
        PermissionScope.CAMERA_VIEW,
        PermissionScope.MODEL_ADMIN,
        PermissionScope.MODEL_TRAIN,
        PermissionScope.MODEL_DEPLOY,
        PermissionScope.MODEL_VIEW,
        PermissionScope.DEFECT_ADMIN,
        PermissionScope.DEFECT_ANNOTATE,
        PermissionScope.DEFECT_VIEW,
        PermissionScope.REPORT_ADMIN,
        PermissionScope.REPORT_CREATE,
        PermissionScope.REPORT_VIEW,
        PermissionScope.API_ADMIN,
        PermissionScope.API_WRITE,
        PermissionScope.API_READ
    },
    UserRole.SUPERVISOR: {
        PermissionScope.SYSTEM_MONITOR,
        PermissionScope.USER_VIEW,
        PermissionScope.PRODUCTION_ADMIN,
        PermissionScope.PRODUCTION_START,
        PermissionScope.PRODUCTION_STOP,
        PermissionScope.PRODUCTION_VIEW,
        PermissionScope.CAMERA_CONFIG,
        PermissionScope.CAMERA_VIEW,
        PermissionScope.MODEL_DEPLOY,
        PermissionScope.MODEL_VIEW,
        PermissionScope.DEFECT_ADMIN,
        PermissionScope.DEFECT_ANNOTATE,
        PermissionScope.DEFECT_VIEW,
        PermissionScope.REPORT_CREATE,
        PermissionScope.REPORT_VIEW,
        PermissionScope.API_READ
    },
    UserRole.OPERATOR: {
        PermissionScope.SYSTEM_MONITOR,
        PermissionScope.PRODUCTION_START,
        PermissionScope.PRODUCTION_STOP,
        PermissionScope.PRODUCTION_VIEW,
        PermissionScope.CAMERA_VIEW,
        PermissionScope.MODEL_VIEW,
        PermissionScope.DEFECT_VIEW,
        PermissionScope.REPORT_VIEW
    },
    UserRole.MAINTENANCE: {
        PermissionScope.SYSTEM_MONITOR,
        PermissionScope.SYSTEM_CONFIG,
        PermissionScope.CAMERA_CONFIG,
        PermissionScope.CAMERA_VIEW,
        PermissionScope.PRODUCTION_VIEW,
        PermissionScope.DEFECT_VIEW,
        PermissionScope.REPORT_VIEW
    },
    UserRole.QUALITY: {
        PermissionScope.SYSTEM_MONITOR,
        PermissionScope.PRODUCTION_VIEW,
        PermissionScope.CAMERA_VIEW,
        PermissionScope.MODEL_VIEW,
        PermissionScope.DEFECT_ADMIN,
        PermissionScope.DEFECT_ANNOTATE,
        PermissionScope.DEFECT_VIEW,
        PermissionScope.REPORT_CREATE,
        PermissionScope.REPORT_VIEW
    },
    UserRole.VIEWER: {
        PermissionScope.SYSTEM_MONITOR,
        PermissionScope.PRODUCTION_VIEW,
        PermissionScope.CAMERA_VIEW,
        PermissionScope.DEFECT_VIEW,
        PermissionScope.REPORT_VIEW
    }
}

@dataclass
class User:
    """Enhanced User data class."""
    username: str
    email: str
    role: UserRole
    status: UserStatus
    full_name: Optional[str] = None
    password_hash: Optional[str] = None
    salt: Optional[str] = None
    last_login: Optional[datetime.datetime] = None
    created_at: Optional[datetime.datetime] = None
    updated_at: Optional[datetime.datetime] = None
    failed_login_attempts: int = 0
    last_failed_login: Optional[datetime.datetime] = None
    password_changed_at: Optional[datetime.datetime] = None
    auth_methods: List[AuthMethod] = field(default_factory=lambda: [AuthMethod.PASSWORD])
    totp_secret: Optional[str] = None
    custom_permissions: Set[PermissionScope] = field(default_factory=set)
    api_keys: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert user to dictionary."""
        return {
            "username": self.username,
            "email": self.email,
            "role": self.role.value if isinstance(self.role, UserRole) else self.role,
            "status": self.status.value if isinstance(self.status, UserStatus) else self.status,
            "full_name": self.full_name,
            "last_login": self.last_login.isoformat() if self.last_login else None,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "failed_login_attempts": self.failed_login_attempts,
            "last_failed_login": self.last_failed_login.isoformat() if self.last_failed_login else None,
            "password_changed_at": self.password_changed_at.isoformat() if self.password_changed_at else None,
            "auth_methods": [method.value if isinstance(method, AuthMethod) else method for method in self.auth_methods],
            "totp_enabled": AuthMethod.TOTP in self.auth_methods,
            "custom_permissions": [perm.value if isinstance(perm, PermissionScope) else perm for perm in self.custom_permissions],
            "api_keys_count": len(self.api_keys)
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'User':
        """Create user from dictionary."""
        # Convert auth methods
        auth_methods = []
        for method in data.get("auth_methods", [AuthMethod.PASSWORD.value]):
            if isinstance(method, str):
                auth_methods.append(AuthMethod(method))
            else:
                auth_methods.append(method)
        
        # Convert custom permissions
        custom_permissions = set()
        for perm in data.get("custom_permissions", []):
            if isinstance(perm, str):
                custom_permissions.add(PermissionScope(perm))
            else:
                custom_permissions.add(perm)
        
        return cls(
            username=data["username"],
            email=data["email"],
            role=UserRole(data["role"]) if isinstance(data["role"], str) else data["role"],
            status=UserStatus(data["status"]) if isinstance(data["status"], str) else data["status"],
            full_name=data.get("full_name"),
            password_hash=data.get("password_hash"),
            salt=data.get("salt"),
            last_login=datetime.datetime.fromisoformat(data["last_login"]) if data.get("last_login") else None,
            created_at=datetime.datetime.fromisoformat(data["created_at"]) if data.get("created_at") else None,
            updated_at=datetime.datetime.fromisoformat(data["updated_at"]) if data.get("updated_at") else None,
            failed_login_attempts=data.get("failed_login_attempts", 0),
            last_failed_login=datetime.datetime.fromisoformat(data["last_failed_login"]) if data.get("last_failed_login") else None,
            password_changed_at=datetime.datetime.fromisoformat(data["password_changed_at"]) if data.get("password_changed_at") else None,
            auth_methods=auth_methods,
            totp_secret=data.get("totp_secret"),
            custom_permissions=custom_permissions,
            api_keys=data.get("api_keys", {})
        )
    
    def has_permission(self, permission: PermissionScope) -> bool:
        """
        Check if user has a specific permission.
        
        Args:
            permission: Permission to check
            
        Returns:
            bool: True if user has permission, False otherwise
        """
        # Check custom permissions first
        if permission in self.custom_permissions:
            return True
        
        # Check role-based permissions
        if self.role in ROLE_PERMISSIONS and permission in ROLE_PERMISSIONS[self.role]:
            return True
        
        return False

class EnhancedAuthenticationManager:
    """
    Enhanced Authentication manager for OPSC Sandwich Quality Inspection System.
    
    Provides advanced user management, authentication, authorization, and security features.
    """
    
    def __init__(self, db_path: str, token_secret: Optional[str] = None, token_expiry: int = 86400,
                 max_failed_attempts: int = 5, lockout_duration: int = 1800, password_expiry_days: int = 90,
                 min_password_length: int = 10, require_password_complexity: bool = True,
                 encryption_key: Optional[str] = None):
        """
        Initialize enhanced authentication manager.
        
        Args:
            db_path: Path to SQLite database file
            token_secret: Secret key for JWT token generation (if None, a random key will be generated)
            token_expiry: Token expiry time in seconds (default: 24 hours)
            max_failed_attempts: Maximum number of failed login attempts before account lockout
            lockout_duration: Account lockout duration in seconds
            password_expiry_days: Password expiry in days
            min_password_length: Minimum password length
            require_password_complexity: Whether to require password complexity
            encryption_key: Key for encrypting sensitive data (if None, a random key will be generated)
        """
        self.db_path = db_path
        self.token_secret = token_secret or secrets.token_hex(32)
        self.token_expiry = token_expiry
        self.max_failed_attempts = max_failed_attempts
        self.lockout_duration = lockout_duration
        self.password_expiry_days = password_expiry_days
        self.min_password_length = min_password_length
        self.require_password_complexity = require_password_complexity
        
        # Initialize encryption
        self.encryption_key = encryption_key or Fernet.generate_key().decode()
        self.fernet = Fernet(self.encryption_key.encode() if isinstance(self.encryption_key, str) else self.encryption_key)
        
        # Initialize database
        self._init_db()
    
    def _init_db(self):
        """Initialize database schema."""
        try:
            # Create database directory if it doesn't exist
            os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
            
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Create users table if it doesn't exist
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                username TEXT PRIMARY KEY,
                email TEXT UNIQUE,
                full_name TEXT,
                password_hash TEXT,
                salt TEXT,
                role TEXT,
                status TEXT,
                last_login TEXT,
                created_at TEXT,
                updated_at TEXT,
                failed_login_attempts INTEGER DEFAULT 0,
                last_failed_login TEXT,
                password_changed_at TEXT,
                auth_methods TEXT,
                totp_secret TEXT,
                custom_permissions TEXT,
                api_keys TEXT
            )
            ''')
            
            # Create sessions table if it doesn't exist
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS sessions (
                token TEXT PRIMARY KEY,
                username TEXT,
                created_at TEXT,
                expires_at TEXT,
                ip_address TEXT,
                user_agent TEXT,
                device_id TEXT,
                last_activity TEXT,
                FOREIGN KEY (username) REFERENCES users (username)
            )
            ''')
            
            # Create audit log table if it doesn't exist
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS audit_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT,
                username TEXT,
                action TEXT,
                details TEXT,
                ip_address TEXT,
                user_agent TEXT,
                status TEXT
            )
            ''')
            
            # Create API keys table if it doesn't exist
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS api_keys (
                key_id TEXT PRIMARY KEY,
                username TEXT,
                api_key TEXT,
                name TEXT,
                created_at TEXT,
                expires_at TEXT,
                last_used TEXT,
                permissions TEXT,
                enabled INTEGER DEFAULT 1,
                FOREIGN KEY (username) REFERENCES users (username)
            )
            ''')
            
            # Create IP whitelist table if it doesn't exist
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS ip_whitelist (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ip_address TEXT,
                description TEXT,
                created_at TEXT,
                created_by TEXT
            )
            ''')
            
            # Create IP blacklist table if it doesn't exist
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS ip_blacklist (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ip_address TEXT,
                reason TEXT,
                created_at TEXT,
                created_by TEXT,
                expires_at TEXT
            )
            ''')
            
            # Commit changes
            conn.commit()
            
            # Check if admin user exists, create if not
            cursor.execute("SELECT COUNT(*) FROM users WHERE username = 'admin'")
            if cursor.fetchone()[0] == 0:
                # Create default admin user
                self.create_user(
                    username="admin",
                    email="admin@example.com",
                    password="Admin@123456",  # This should be changed immediately
                    role=UserRole.ADMIN,
                    full_name="System Administrator"
                )
                logger.warning("Created default admin user. Please change the password immediately.")
            
            # Close connection
            conn.close()
            
            logger.info("Authentication database initialized successfully.")
        except Exception as e:
            logger.error(f"Error initializing authentication database: {e}")
            raise
    
    def _hash_password(self, password: str, salt: Optional[str] = None) -> Tuple[str, str]:
        """
        Hash password with salt using PBKDF2.
        
        Args:
            password: Plain text password
            salt: Salt for password hashing (if None, a new salt will be generated)
        
        Returns:
            Tuple of (password_hash, salt)
        """
        # Generate salt if not provided
        if salt is None:
            salt = secrets.token_hex(16)
        
        # Hash password with salt using PBKDF2
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt.encode('utf-8'),
            iterations=100000,
            backend=default_backend()
        )
        password_hash = base64.b64encode(kdf.derive(password.encode('utf-8'))).decode('utf-8')
        
        return password_hash, salt
    
    def _encrypt_data(self, data: str) -> str:
        """
        Encrypt sensitive data.
        
        Args:
            data: Data to encrypt
            
        Returns:
            Encrypted data
        """
        return self.fernet.encrypt(data.encode('utf-8')).decode('utf-8')
    
    def _decrypt_data(self, encrypted_data: str) -> str:
        """
        Decrypt sensitive data.
        
        Args:
            encrypted_data: Encrypted data
            
        Returns:
            Decrypted data
        """
        return self.fernet.decrypt(encrypted_data.encode('utf-8')).decode('utf-8')
    
    def _validate_password_complexity(self, password: str) -> Tuple[bool, str]:
        """
        Validate password complexity.
        
        Args:
            password: Password to validate
            
        Returns:
            Tuple of (is_valid, error_message)
        """
        if len(password) < self.min_password_length:
            return False, f"Password must be at least {self.min_password_length} characters long"
        
        if self.require_password_complexity:
            # Check for at least one uppercase letter
            if not any(c.isupper() for c in password):
                return False, "Password must contain at least one uppercase letter"
            
            # Check for at least one lowercase letter
            if not any(c.islower() for c in password):
                return False, "Password must contain at least one lowercase letter"
            
            # Check for at least one digit
            if not any(c.isdigit() for c in password):
                return False, "Password must contain at least one digit"
            
            # Check for at least one special character
            if not any(c in "!@#$%^&*()_+-=[]{}|;:,.<>?/" for c in password):
                return False, "Password must contain at least one special character"
        
        return True, ""
    
    def _log_audit(self, action: str, details: str, username: Optional[str] = None, 
                  ip_address: Optional[str] = None, user_agent: Optional[str] = None,
                  status: str = "success"):
        """
        Log audit event.
        
        Args:
            action: Action performed
            details: Details of the action
            username: Username of the user performing the action
            ip_address: IP address of the user
            user_agent: User agent of the user
            status: Status of the action (success or failure)
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Insert audit log entry
            cursor.execute('''
            INSERT INTO audit_log (timestamp, username, action, details, ip_address, user_agent, status)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (
                datetime.datetime.now().isoformat(),
                username,
                action,
                details,
                ip_address,
                user_agent,
                status
            ))
            
            # Commit changes
            conn.commit()
            
            # Close connection
            conn.close()
        except Exception as e:
            logger.error(f"Error logging audit event: {e}")
    
    def _is_ip_allowed(self, ip_address: Optional[str]) -> bool:
        """
        Check if IP address is allowed.
        
        Args:
            ip_address: IP address to check
            
        Returns:
            bool: True if IP is allowed, False otherwise
        """
        if ip_address is None:
            return True
        
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Check if IP is in blacklist
            cursor.execute('''
            SELECT COUNT(*) FROM ip_blacklist 
            WHERE ip_address = ? AND (expires_at IS NULL OR expires_at > ?)
            ''', (ip_address, datetime.datetime.now().isoformat()))
            
            if cursor.fetchone()[0] > 0:
                # IP is blacklisted
                conn.close()
                return False
            
            # Check if whitelist is enabled (has entries)
            cursor.execute("SELECT COUNT(*) FROM ip_whitelist")
            whitelist_count = cursor.fetchone()[0]
            
            if whitelist_count > 0:
                # Whitelist is enabled, check if IP is in whitelist
                cursor.execute("SELECT COUNT(*) FROM ip_whitelist WHERE ip_address = ?", (ip_address,))
                if cursor.fetchone()[0] == 0:
                    # IP is not in whitelist
                    conn.close()
                    return False
            
            # Close connection
            conn.close()
            
            return True
        except Exception as e:
            logger.error(f"Error checking IP allowance: {e}")
            return False
    
    def create_user(self, username: str, email: str, password: str, role: UserRole, 
                   full_name: Optional[str] = None, auth_methods: List[AuthMethod] = None,
                   custom_permissions: Set[PermissionScope] = None) -> User:
        """
        Create a new user.
        
        Args:
            username: Username
            email: Email address
            password: Plain text password
            role: User role
            full_name: Full name (optional)
            auth_methods: Authentication methods (optional)
            custom_permissions: Custom permissions (optional)
        
        Returns:
            Created user
        
        Raises:
            ValueError: If username or email already exists, or if password doesn't meet requirements
        """
        try:
            # Validate username
            if not re.match(r'^[a-zA-Z0-9_-]{3,32}$', username):
                raise ValueError("Username must be 3-32 characters and contain only letters, numbers, underscores, and hyphens")
            
            # Validate email
            if not re.match(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$', email):
                raise ValueError("Invalid email address")
            
            # Validate password complexity
            is_valid, error_message = self._validate_password_complexity(password)
            if not is_valid:
                raise ValueError(error_message)
            
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Check if username already exists
            cursor.execute("SELECT COUNT(*) FROM users WHERE username = ?", (username,))
            if cursor.fetchone()[0] > 0:
                raise ValueError(f"Username '{username}' already exists")
            
            # Check if email already exists
            cursor.execute("SELECT COUNT(*) FROM users WHERE email = ?", (email,))
            if cursor.fetchone()[0] > 0:
                raise ValueError(f"Email '{email}' already exists")
            
            # Hash password
            password_hash, salt = self._hash_password(password)
            
            # Get current timestamp
            now = datetime.datetime.now()
            
            # Set default auth methods if not provided
            if auth_methods is None:
                auth_methods = [AuthMethod.PASSWORD]
            
            # Create user
            user = User(
                username=username,
                email=email,
                role=role,
                status=UserStatus.ACTIVE,
                full_name=full_name,
                password_hash=password_hash,
                salt=salt,
                created_at=now,
                updated_at=now,
                password_changed_at=now,
                auth_methods=auth_methods,
                custom_permissions=custom_permissions or set()
            )
            
            # Insert user into database
            cursor.execute('''
            INSERT INTO users (
                username, email, full_name, password_hash, salt, role, status, 
                created_at, updated_at, password_changed_at, auth_methods, custom_permissions
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                user.username,
                user.email,
                user.full_name,
                user.password_hash,
                user.salt,
                user.role.value,
                user.status.value,
                user.created_at.isoformat(),
                user.updated_at.isoformat(),
                user.password_changed_at.isoformat(),
                json.dumps([method.value for method in user.auth_methods]),
                json.dumps([perm.value for perm in user.custom_permissions])
            ))
            
            # Commit changes
            conn.commit()
            
            # Log action
            self._log_audit("create_user", f"Created user '{username}' with role '{role.value}'", username=username)
            
            # Close connection
            conn.close()
            
            logger.info(f"Created user '{username}' with role '{role.value}'")
            
            return user
        except Exception as e:
            logger.error(f"Error creating user: {e}")
            raise
    
    def get_user(self, username: str) -> Optional[User]:
        """
        Get user by username.
        
        Args:
            username: Username
        
        Returns:
            User if found, None otherwise
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Get user from database
            cursor.execute('''
            SELECT username, email, full_name, password_hash, salt, role, status, 
                   last_login, created_at, updated_at, failed_login_attempts, 
                   last_failed_login, password_changed_at, auth_methods, 
                   totp_secret, custom_permissions, api_keys
            FROM users
            WHERE username = ?
            ''', (username,))
            
            row = cursor.fetchone()
            
            # Close connection
            conn.close()
            
            if row is None:
                return None
            
            # Parse JSON fields
            auth_methods = json.loads(row[13]) if row[13] else [AuthMethod.PASSWORD.value]
            custom_permissions = json.loads(row[15]) if row[15] else []
            api_keys = json.loads(row[16]) if row[16] else {}
            
            # Create user object
            user = User(
                username=row[0],
                email=row[1],
                full_name=row[2],
                password_hash=row[3],
                salt=row[4],
                role=UserRole(row[5]),
                status=UserStatus(row[6]),
                last_login=datetime.datetime.fromisoformat(row[7]) if row[7] else None,
                created_at=datetime.datetime.fromisoformat(row[8]) if row[8] else None,
                updated_at=datetime.datetime.fromisoformat(row[9]) if row[9] else None,
                failed_login_attempts=row[10],
                last_failed_login=datetime.datetime.fromisoformat(row[11]) if row[11] else None,
                password_changed_at=datetime.datetime.fromisoformat(row[12]) if row[12] else None,
                auth_methods=[AuthMethod(method) for method in auth_methods],
                totp_secret=row[14],
                custom_permissions={PermissionScope(perm) for perm in custom_permissions},
                api_keys=api_keys
            )
            
            return user
        except Exception as e:
            logger.error(f"Error getting user: {e}")
            return None
    
    def update_user(self, username: str, email: Optional[str] = None, role: Optional[UserRole] = None,
                   status: Optional[UserStatus] = None, full_name: Optional[str] = None,
                   auth_methods: Optional[List[AuthMethod]] = None,
                   custom_permissions: Optional[Set[PermissionScope]] = None) -> Optional[User]:
        """
        Update user.
        
        Args:
            username: Username
            email: New email address (optional)
            role: New user role (optional)
            status: New user status (optional)
            full_name: New full name (optional)
            auth_methods: New authentication methods (optional)
            custom_permissions: New custom permissions (optional)
        
        Returns:
            Updated user if successful, None otherwise
        """
        try:
            # Get current user
            user = self.get_user(username)
            if user is None:
                logger.error(f"User '{username}' not found")
                return None
            
            # Update user fields
            if email is not None:
                # Validate email
                if not re.match(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$', email):
                    raise ValueError("Invalid email address")
                user.email = email
            
            if role is not None:
                user.role = role
            
            if status is not None:
                user.status = status
            
            if full_name is not None:
                user.full_name = full_name
            
            if auth_methods is not None:
                user.auth_methods = auth_methods
            
            if custom_permissions is not None:
                user.custom_permissions = custom_permissions
            
            # Update timestamp
            user.updated_at = datetime.datetime.now()
            
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Update user in database
            cursor.execute('''
            UPDATE users
            SET email = ?, role = ?, status = ?, full_name = ?, updated_at = ?,
                auth_methods = ?, custom_permissions = ?
            WHERE username = ?
            ''', (
                user.email,
                user.role.value,
                user.status.value,
                user.full_name,
                user.updated_at.isoformat(),
                json.dumps([method.value for method in user.auth_methods]),
                json.dumps([perm.value for perm in user.custom_permissions]),
                user.username
            ))
            
            # Commit changes
            conn.commit()
            
            # Log action
            self._log_audit("update_user", f"Updated user '{username}'", username=username)
            
            # Close connection
            conn.close()
            
            logger.info(f"Updated user '{username}'")
            
            return user
        except Exception as e:
            logger.error(f"Error updating user: {e}")
            raise
    
    def delete_user(self, username: str) -> bool:
        """
        Delete user.
        
        Args:
            username: Username
        
        Returns:
            True if successful, False otherwise
        """
        try:
            # Check if user exists
            user = self.get_user(username)
            if user is None:
                logger.error(f"User '{username}' not found")
                return False
            
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Delete user from database
            cursor.execute("DELETE FROM users WHERE username = ?", (username,))
            
            # Delete user sessions
            cursor.execute("DELETE FROM sessions WHERE username = ?", (username,))
            
            # Delete user API keys
            cursor.execute("DELETE FROM api_keys WHERE username = ?", (username,))
            
            # Commit changes
            conn.commit()
            
            # Log action
            self._log_audit("delete_user", f"Deleted user '{username}'", username=username)
            
            # Close connection
            conn.close()
            
            logger.info(f"Deleted user '{username}'")
            
            return True
        except Exception as e:
            logger.error(f"Error deleting user: {e}")
            return False
    
    def change_password(self, username: str, current_password: str, new_password: str) -> bool:
        """
        Change user password.
        
        Args:
            username: Username
            current_password: Current password
            new_password: New password
        
        Returns:
            True if successful, False otherwise
        """
        try:
            # Get user
            user = self.get_user(username)
            if user is None:
                logger.error(f"User '{username}' not found")
                return False
            
            # Verify current password
            password_hash, _ = self._hash_password(current_password, user.salt)
            if password_hash != user.password_hash:
                logger.error(f"Invalid current password for user '{username}'")
                
                # Log failed attempt
                self._log_audit(
                    "change_password", 
                    f"Failed password change for user '{username}': Invalid current password",
                    username=username,
                    status="failure"
                )
                
                return False
            
            # Validate password complexity
            is_valid, error_message = self._validate_password_complexity(new_password)
            if not is_valid:
                logger.error(f"Password complexity validation failed: {error_message}")
                
                # Log failed attempt
                self._log_audit(
                    "change_password", 
                    f"Failed password change for user '{username}': {error_message}",
                    username=username,
                    status="failure"
                )
                
                return False
            
            # Hash new password
            password_hash, salt = self._hash_password(new_password)
            
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Update password in database
            cursor.execute('''
            UPDATE users
            SET password_hash = ?, salt = ?, password_changed_at = ?, updated_at = ?,
                status = CASE WHEN status = ? THEN ? ELSE status END
            WHERE username = ?
            ''', (
                password_hash,
                salt,
                datetime.datetime.now().isoformat(),
                datetime.datetime.now().isoformat(),
                UserStatus.PASSWORD_RESET.value,
                UserStatus.ACTIVE.value,
                username
            ))
            
            # Commit changes
            conn.commit()
            
            # Log action
            self._log_audit("change_password", f"Changed password for user '{username}'", username=username)
            
            # Close connection
            conn.close()
            
            logger.info(f"Changed password for user '{username}'")
            
            return True
        except Exception as e:
            logger.error(f"Error changing password: {e}")
            return False
    
    def reset_password(self, username: str, new_password: str, admin_username: Optional[str] = None) -> bool:
        """
        Reset user password (admin function).
        
        Args:
            username: Username
            new_password: New password
            admin_username: Username of admin performing the reset
        
        Returns:
            True if successful, False otherwise
        """
        try:
            # Get user
            user = self.get_user(username)
            if user is None:
                logger.error(f"User '{username}' not found")
                return False
            
            # Validate password complexity
            is_valid, error_message = self._validate_password_complexity(new_password)
            if not is_valid:
                logger.error(f"Password complexity validation failed: {error_message}")
                return False
            
            # Hash new password
            password_hash, salt = self._hash_password(new_password)
            
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Update password in database
            cursor.execute('''
            UPDATE users
            SET password_hash = ?, salt = ?, password_changed_at = ?, updated_at = ?,
                status = ?, failed_login_attempts = 0
            WHERE username = ?
            ''', (
                password_hash,
                salt,
                datetime.datetime.now().isoformat(),
                datetime.datetime.now().isoformat(),
                UserStatus.PASSWORD_RESET.value,
                username
            ))
            
            # Commit changes
            conn.commit()
            
            # Log action
            self._log_audit(
                "reset_password", 
                f"Reset password for user '{username}'", 
                username=admin_username
            )
            
            # Close connection
            conn.close()
            
            logger.info(f"Reset password for user '{username}'")
            
            return True
        except Exception as e:
            logger.error(f"Error resetting password: {e}")
            return False
    
    def authenticate(self, username: str, password: str, ip_address: Optional[str] = None, 
                    user_agent: Optional[str] = None, totp_code: Optional[str] = None) -> Optional[str]:
        """
        Authenticate user and generate token.
        
        Args:
            username: Username
            password: Password
            ip_address: IP address of client
            user_agent: User agent of client
            totp_code: TOTP code for two-factor authentication
        
        Returns:
            JWT token if authentication successful, None otherwise
        """
        try:
            # Check if IP is allowed
            if not self._is_ip_allowed(ip_address):
                logger.warning(f"Authentication attempt from blacklisted IP: {ip_address}")
                
                # Log failed attempt
                self._log_audit(
                    "authenticate", 
                    f"Authentication attempt from blacklisted IP: {ip_address}",
                    username=username,
                    ip_address=ip_address,
                    user_agent=user_agent,
                    status="failure"
                )
                
                return None
            
            # Get user
            user = self.get_user(username)
            if user is None:
                logger.warning(f"Authentication attempt for non-existent user: {username}")
                
                # Log failed attempt
                self._log_audit(
                    "authenticate", 
                    f"Authentication attempt for non-existent user: {username}",
                    username=username,
                    ip_address=ip_address,
                    user_agent=user_agent,
                    status="failure"
                )
                
                return None
            
            # Check if user is active
            if user.status != UserStatus.ACTIVE and user.status != UserStatus.PASSWORD_RESET:
                logger.warning(f"Authentication attempt for inactive user: {username}")
                
                # Log failed attempt
                self._log_audit(
                    "authenticate", 
                    f"Authentication attempt for inactive user: {username}",
                    username=username,
                    ip_address=ip_address,
                    user_agent=user_agent,
                    status="failure"
                )
                
                return None
            
            # Check if account is locked
            if user.status == UserStatus.LOCKED:
                # Check if lockout period has expired
                if user.last_failed_login and (datetime.datetime.now() - user.last_failed_login).total_seconds() > self.lockout_duration:
                    # Unlock account
                    self.update_user(username, status=UserStatus.ACTIVE)
                else:
                    logger.warning(f"Authentication attempt for locked user: {username}")
                    
                    # Log failed attempt
                    self._log_audit(
                        "authenticate", 
                        f"Authentication attempt for locked user: {username}",
                        username=username,
                        ip_address=ip_address,
                        user_agent=user_agent,
                        status="failure"
                    )
                    
                    return None
            
            # Verify password
            password_hash, _ = self._hash_password(password, user.salt)
            if password_hash != user.password_hash:
                # Increment failed login attempts
                conn = sqlite3.connect(self.db_path)
                cursor = conn.cursor()
                
                cursor.execute('''
                UPDATE users
                SET failed_login_attempts = failed_login_attempts + 1,
                    last_failed_login = ?,
                    status = CASE WHEN failed_login_attempts + 1 >= ? THEN ? ELSE status END
                WHERE username = ?
                ''', (
                    datetime.datetime.now().isoformat(),
                    self.max_failed_attempts,
                    UserStatus.LOCKED.value,
                    username
                ))
                
                conn.commit()
                conn.close()
                
                logger.warning(f"Failed authentication attempt for user: {username}")
                
                # Log failed attempt
                self._log_audit(
                    "authenticate", 
                    f"Failed authentication attempt for user: {username}",
                    username=username,
                    ip_address=ip_address,
                    user_agent=user_agent,
                    status="failure"
                )
                
                return None
            
            # Check if TOTP is required
            if AuthMethod.TOTP in user.auth_methods:
                if not totp_code:
                    logger.warning(f"TOTP code required for user: {username}")
                    
                    # Log failed attempt
                    self._log_audit(
                        "authenticate", 
                        f"TOTP code required for user: {username}",
                        username=username,
                        ip_address=ip_address,
                        user_agent=user_agent,
                        status="failure"
                    )
                    
                    return None
                
                # Verify TOTP code
                if not self.verify_totp(username, totp_code):
                    logger.warning(f"Invalid TOTP code for user: {username}")
                    
                    # Log failed attempt
                    self._log_audit(
                        "authenticate", 
                        f"Invalid TOTP code for user: {username}",
                        username=username,
                        ip_address=ip_address,
                        user_agent=user_agent,
                        status="failure"
                    )
                    
                    return None
            
            # Check if password has expired
            if user.password_changed_at:
                password_age = (datetime.datetime.now() - user.password_changed_at).days
                if password_age > self.password_expiry_days:
                    # Update user status to require password reset
                    self.update_user(username, status=UserStatus.PASSWORD_RESET)
                    user.status = UserStatus.PASSWORD_RESET
            
            # Generate token
            token_payload = {
                "sub": username,
                "role": user.role.value,
                "iat": datetime.datetime.now().timestamp(),
                "exp": (datetime.datetime.now() + datetime.timedelta(seconds=self.token_expiry)).timestamp()
            }
            
            token = jwt.encode(token_payload, self.token_secret, algorithm="HS256")
            
            # Generate device ID
            device_id = hashlib.sha256(f"{ip_address}:{user_agent}".encode()).hexdigest()
            
            # Store session
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
            INSERT INTO sessions (token, username, created_at, expires_at, ip_address, user_agent, device_id, last_activity)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                token,
                username,
                datetime.datetime.now().isoformat(),
                (datetime.datetime.now() + datetime.timedelta(seconds=self.token_expiry)).isoformat(),
                ip_address,
                user_agent,
                device_id,
                datetime.datetime.now().isoformat()
            ))
            
            # Reset failed login attempts
            cursor.execute('''
            UPDATE users
            SET failed_login_attempts = 0,
                last_login = ?,
                updated_at = ?
            WHERE username = ?
            ''', (
                datetime.datetime.now().isoformat(),
                datetime.datetime.now().isoformat(),
                username
            ))
            
            conn.commit()
            conn.close()
            
            # Log successful authentication
            self._log_audit(
                "authenticate", 
                f"Successful authentication for user: {username}",
                username=username,
                ip_address=ip_address,
                user_agent=user_agent
            )
            
            logger.info(f"Successful authentication for user: {username}")
            
            return token
        except Exception as e:
            logger.error(f"Error authenticating user: {e}")
            return None
    
    def validate_token(self, token: str, update_activity: bool = True) -> Optional[User]:
        """
        Validate JWT token and return user.
        
        Args:
            token: JWT token
            update_activity: Whether to update last activity timestamp
        
        Returns:
            User if token is valid, None otherwise
        """
        try:
            # Verify token
            try:
                payload = jwt.decode(token, self.token_secret, algorithms=["HS256"])
            except jwt.ExpiredSignatureError:
                logger.warning("Token expired")
                return None
            except jwt.InvalidTokenError:
                logger.warning("Invalid token")
                return None
            
            # Get username from token
            username = payload.get("sub")
            if not username:
                logger.warning("Token missing subject")
                return None
            
            # Check if token is in database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
            SELECT username, expires_at FROM sessions WHERE token = ?
            ''', (token,))
            
            row = cursor.fetchone()
            if not row:
                logger.warning("Token not found in database")
                conn.close()
                return None
            
            # Check if token has expired
            expires_at = datetime.datetime.fromisoformat(row[1])
            if expires_at < datetime.datetime.now():
                logger.warning("Token expired")
                
                # Remove expired token
                cursor.execute("DELETE FROM sessions WHERE token = ?", (token,))
                conn.commit()
                conn.close()
                
                return None
            
            # Update last activity
            if update_activity:
                cursor.execute('''
                UPDATE sessions
                SET last_activity = ?
                WHERE token = ?
                ''', (
                    datetime.datetime.now().isoformat(),
                    token
                ))
                conn.commit()
            
            conn.close()
            
            # Get user
            user = self.get_user(username)
            if not user:
                logger.warning(f"User not found: {username}")
                return None
            
            # Check if user is active
            if user.status != UserStatus.ACTIVE and user.status != UserStatus.PASSWORD_RESET:
                logger.warning(f"User is not active: {username}")
                return None
            
            return user
        except Exception as e:
            logger.error(f"Error validating token: {e}")
            return None
    
    def logout(self, token: str) -> bool:
        """
        Logout user by invalidating token.
        
        Args:
            token: JWT token
        
        Returns:
            True if successful, False otherwise
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Get username from session
            cursor.execute("SELECT username FROM sessions WHERE token = ?", (token,))
            row = cursor.fetchone()
            
            if not row:
                logger.warning("Token not found in database")
                conn.close()
                return False
            
            username = row[0]
            
            # Delete session
            cursor.execute("DELETE FROM sessions WHERE token = ?", (token,))
            
            # Commit changes
            conn.commit()
            
            # Log action
            self._log_audit("logout", f"User logged out: {username}", username=username)
            
            # Close connection
            conn.close()
            
            logger.info(f"User logged out: {username}")
            
            return True
        except Exception as e:
            logger.error(f"Error logging out: {e}")
            return False
    
    def list_users(self) -> List[User]:
        """
        List all users.
        
        Returns:
            List of users
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Get all users
            cursor.execute('''
            SELECT username FROM users ORDER BY username
            ''')
            
            rows = cursor.fetchall()
            
            # Close connection
            conn.close()
            
            # Get user objects
            users = []
            for row in rows:
                user = self.get_user(row[0])
                if user:
                    users.append(user)
            
            return users
        except Exception as e:
            logger.error(f"Error listing users: {e}")
            return []
    
    def list_active_sessions(self) -> List[Dict[str, Any]]:
        """
        List all active sessions.
        
        Returns:
            List of active sessions
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Get all active sessions
            cursor.execute('''
            SELECT token, username, created_at, expires_at, ip_address, user_agent, device_id, last_activity
            FROM sessions
            WHERE expires_at > ?
            ORDER BY last_activity DESC
            ''', (datetime.datetime.now().isoformat(),))
            
            rows = cursor.fetchall()
            
            # Close connection
            conn.close()
            
            # Convert to dictionaries
            sessions = []
            for row in rows:
                sessions.append({
                    "token": row[0],
                    "username": row[1],
                    "created_at": row[2],
                    "expires_at": row[3],
                    "ip_address": row[4],
                    "user_agent": row[5],
                    "device_id": row[6],
                    "last_activity": row[7]
                })
            
            return sessions
        except Exception as e:
            logger.error(f"Error listing active sessions: {e}")
            return []
    
    def get_audit_log(self, username: Optional[str] = None, action: Optional[str] = None, 
                     start_date: Optional[datetime.datetime] = None, 
                     end_date: Optional[datetime.datetime] = None,
                     limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        """
        Get audit log entries.
        
        Args:
            username: Filter by username (optional)
            action: Filter by action (optional)
            start_date: Filter by start date (optional)
            end_date: Filter by end date (optional)
            limit: Maximum number of entries to return
            offset: Offset for pagination
        
        Returns:
            List of audit log entries
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Build query
            query = "SELECT id, timestamp, username, action, details, ip_address, user_agent, status FROM audit_log"
            params = []
            
            # Add filters
            filters = []
            if username:
                filters.append("username = ?")
                params.append(username)
            
            if action:
                filters.append("action = ?")
                params.append(action)
            
            if start_date:
                filters.append("timestamp >= ?")
                params.append(start_date.isoformat())
            
            if end_date:
                filters.append("timestamp <= ?")
                params.append(end_date.isoformat())
            
            if filters:
                query += " WHERE " + " AND ".join(filters)
            
            # Add order and limit
            query += " ORDER BY timestamp DESC LIMIT ? OFFSET ?"
            params.extend([limit, offset])
            
            # Execute query
            cursor.execute(query, params)
            
            rows = cursor.fetchall()
            
            # Close connection
            conn.close()
            
            # Convert to dictionaries
            entries = []
            for row in rows:
                entries.append({
                    "id": row[0],
                    "timestamp": row[1],
                    "username": row[2],
                    "action": row[3],
                    "details": row[4],
                    "ip_address": row[5],
                    "user_agent": row[6],
                    "status": row[7]
                })
            
            return entries
        except Exception as e:
            logger.error(f"Error getting audit log: {e}")
            return []
    
    def setup_totp(self, username: str, password: str) -> Tuple[bool, Optional[str], Optional[str]]:
        """
        Setup TOTP (Time-based One-Time Password) for a user.
        
        Args:
            username: Username
            password: Password for verification
        
        Returns:
            Tuple of (success, secret, qr_code_url)
        """
        try:
            # Get user
            user = self.get_user(username)
            if not user:
                logger.error(f"User not found: {username}")
                return False, None, None
            
            # Verify password
            password_hash, _ = self._hash_password(password, user.salt)
            if password_hash != user.password_hash:
                logger.error(f"Invalid password for user: {username}")
                return False, None, None
            
            # Generate TOTP secret
            totp_secret = pyotp.random_base32()
            
            # Encrypt secret
            encrypted_secret = self._encrypt_data(totp_secret)
            
            # Update user
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Add TOTP to auth methods if not already present
            auth_methods = user.auth_methods
            if AuthMethod.TOTP not in auth_methods:
                auth_methods.append(AuthMethod.TOTP)
            
            cursor.execute('''
            UPDATE users
            SET totp_secret = ?, auth_methods = ?, updated_at = ?
            WHERE username = ?
            ''', (
                encrypted_secret,
                json.dumps([method.value for method in auth_methods]),
                datetime.datetime.now().isoformat(),
                username
            ))
            
            conn.commit()
            conn.close()
            
            # Generate QR code URL
            totp = pyotp.TOTP(totp_secret)
            provisioning_uri = totp.provisioning_uri(
                name=username,
                issuer_name="OPSC Sandwich Quality Inspection System"
            )
            
            # Log action
            self._log_audit("setup_totp", f"TOTP setup for user: {username}", username=username)
            
            logger.info(f"TOTP setup for user: {username}")
            
            return True, totp_secret, provisioning_uri
        except Exception as e:
            logger.error(f"Error setting up TOTP: {e}")
            return False, None, None
    
    def verify_totp(self, username: str, totp_code: str) -> bool:
        """
        Verify TOTP code.
        
        Args:
            username: Username
            totp_code: TOTP code
        
        Returns:
            True if code is valid, False otherwise
        """
        try:
            # Get user
            user = self.get_user(username)
            if not user:
                logger.error(f"User not found: {username}")
                return False
            
            # Check if TOTP is enabled
            if AuthMethod.TOTP not in user.auth_methods or not user.totp_secret:
                logger.error(f"TOTP not enabled for user: {username}")
                return False
            
            # Decrypt TOTP secret
            totp_secret = self._decrypt_data(user.totp_secret)
            
            # Verify TOTP code
            totp = pyotp.TOTP(totp_secret)
            if totp.verify(totp_code):
                return True
            
            logger.warning(f"Invalid TOTP code for user: {username}")
            return False
        except Exception as e:
            logger.error(f"Error verifying TOTP: {e}")
            return False
    
    def disable_totp(self, username: str, password: str) -> bool:
        """
        Disable TOTP for a user.
        
        Args:
            username: Username
            password: Password for verification
        
        Returns:
            True if successful, False otherwise
        """
        try:
            # Get user
            user = self.get_user(username)
            if not user:
                logger.error(f"User not found: {username}")
                return False
            
            # Verify password
            password_hash, _ = self._hash_password(password, user.salt)
            if password_hash != user.password_hash:
                logger.error(f"Invalid password for user: {username}")
                return False
            
            # Update user
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Remove TOTP from auth methods
            auth_methods = [method for method in user.auth_methods if method != AuthMethod.TOTP]
            
            cursor.execute('''
            UPDATE users
            SET totp_secret = NULL, auth_methods = ?, updated_at = ?
            WHERE username = ?
            ''', (
                json.dumps([method.value for method in auth_methods]),
                datetime.datetime.now().isoformat(),
                username
            ))
            
            conn.commit()
            conn.close()
            
            # Log action
            self._log_audit("disable_totp", f"TOTP disabled for user: {username}", username=username)
            
            logger.info(f"TOTP disabled for user: {username}")
            
            return True
        except Exception as e:
            logger.error(f"Error disabling TOTP: {e}")
            return False
    
    def create_api_key(self, username: str, name: str, permissions: List[PermissionScope], 
                      expires_in_days: Optional[int] = None) -> Tuple[bool, Optional[str]]:
        """
        Create API key for a user.
        
        Args:
            username: Username
            name: Name of the API key
            permissions: List of permissions for the API key
            expires_in_days: Number of days until the API key expires (optional)
        
        Returns:
            Tuple of (success, api_key)
        """
        try:
            # Get user
            user = self.get_user(username)
            if not user:
                logger.error(f"User not found: {username}")
                return False, None
            
            # Generate API key
            key_id = secrets.token_hex(8)
            api_key = f"opsc_{key_id}_{secrets.token_urlsafe(32)}"
            
            # Calculate expiry date
            expires_at = None
            if expires_in_days:
                expires_at = (datetime.datetime.now() + datetime.timedelta(days=expires_in_days)).isoformat()
            
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Insert API key
            cursor.execute('''
            INSERT INTO api_keys (key_id, username, api_key, name, created_at, expires_at, permissions, enabled)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                key_id,
                username,
                self._encrypt_data(api_key),  # Encrypt API key
                name,
                datetime.datetime.now().isoformat(),
                expires_at,
                json.dumps([perm.value for perm in permissions]),
                1
            ))
            
            # Update user's API keys
            user.api_keys[key_id] = {
                "name": name,
                "created_at": datetime.datetime.now().isoformat(),
                "expires_at": expires_at,
                "permissions": [perm.value for perm in permissions]
            }
            
            cursor.execute('''
            UPDATE users
            SET api_keys = ?, updated_at = ?
            WHERE username = ?
            ''', (
                json.dumps(user.api_keys),
                datetime.datetime.now().isoformat(),
                username
            ))
            
            conn.commit()
            conn.close()
            
            # Log action
            self._log_audit("create_api_key", f"API key '{name}' created for user: {username}", username=username)
            
            logger.info(f"API key '{name}' created for user: {username}")
            
            return True, api_key
        except Exception as e:
            logger.error(f"Error creating API key: {e}")
            return False, None
    
    def revoke_api_key(self, key_id: str, admin_username: Optional[str] = None) -> bool:
        """
        Revoke API key.
        
        Args:
            key_id: ID of the API key
            admin_username: Username of admin performing the revocation (optional)
        
        Returns:
            True if successful, False otherwise
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Get API key owner
            cursor.execute("SELECT username FROM api_keys WHERE key_id = ?", (key_id,))
            row = cursor.fetchone()
            
            if not row:
                logger.error(f"API key not found: {key_id}")
                conn.close()
                return False
            
            owner_username = row[0]
            
            # Delete API key
            cursor.execute("DELETE FROM api_keys WHERE key_id = ?", (key_id,))
            
            # Update user's API keys
            user = self.get_user(owner_username)
            if user and key_id in user.api_keys:
                user.api_keys.pop(key_id)
                
                cursor.execute('''
                UPDATE users
                SET api_keys = ?, updated_at = ?
                WHERE username = ?
                ''', (
                    json.dumps(user.api_keys),
                    datetime.datetime.now().isoformat(),
                    owner_username
                ))
            
            conn.commit()
            conn.close()
            
            # Log action
            self._log_audit(
                "revoke_api_key", 
                f"API key '{key_id}' revoked for user: {owner_username}",
                username=admin_username or owner_username
            )
            
            logger.info(f"API key '{key_id}' revoked for user: {owner_username}")
            
            return True
        except Exception as e:
            logger.error(f"Error revoking API key: {e}")
            return False
    
    def authenticate_api_key(self, api_key: str, ip_address: Optional[str] = None) -> Optional[Tuple[User, List[PermissionScope]]]:
        """
        Authenticate using API key.
        
        Args:
            api_key: API key
            ip_address: IP address of client
        
        Returns:
            Tuple of (user, permissions) if authentication successful, None otherwise
        """
        try:
            # Check if IP is allowed
            if not self._is_ip_allowed(ip_address):
                logger.warning(f"API authentication attempt from blacklisted IP: {ip_address}")
                return None
            
            # Extract key ID from API key
            if not api_key.startswith("opsc_"):
                logger.warning("Invalid API key format")
                return None
            
            parts = api_key.split("_", 2)
            if len(parts) != 3:
                logger.warning("Invalid API key format")
                return None
            
            key_id = parts[1]
            
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Get API key
            cursor.execute('''
            SELECT username, api_key, permissions, expires_at, enabled
            FROM api_keys
            WHERE key_id = ?
            ''', (key_id,))
            
            row = cursor.fetchone()
            if not row:
                logger.warning(f"API key not found: {key_id}")
                conn.close()
                return None
            
            username, encrypted_api_key, permissions_json, expires_at, enabled = row
            
            # Check if API key is enabled
            if not enabled:
                logger.warning(f"API key is disabled: {key_id}")
                conn.close()
                return None
            
            # Check if API key has expired
            if expires_at and datetime.datetime.fromisoformat(expires_at) < datetime.datetime.now():
                logger.warning(f"API key has expired: {key_id}")
                conn.close()
                return None
            
            # Decrypt and verify API key
            decrypted_api_key = self._decrypt_data(encrypted_api_key)
            if api_key != decrypted_api_key:
                logger.warning(f"Invalid API key: {key_id}")
                conn.close()
                return None
            
            # Get user
            user = self.get_user(username)
            if not user:
                logger.warning(f"User not found: {username}")
                conn.close()
                return None
            
            # Check if user is active
            if user.status != UserStatus.ACTIVE:
                logger.warning(f"User is not active: {username}")
                conn.close()
                return None
            
            # Parse permissions
            permissions = [PermissionScope(perm) for perm in json.loads(permissions_json)]
            
            # Update last used timestamp
            cursor.execute('''
            UPDATE api_keys
            SET last_used = ?
            WHERE key_id = ?
            ''', (
                datetime.datetime.now().isoformat(),
                key_id
            ))
            
            conn.commit()
            conn.close()
            
            # Log successful authentication
            self._log_audit(
                "authenticate_api_key", 
                f"Successful API key authentication for user: {username}",
                username=username,
                ip_address=ip_address
            )
            
            logger.info(f"Successful API key authentication for user: {username}")
            
            return user, permissions
        except Exception as e:
            logger.error(f"Error authenticating API key: {e}")
            return None
    
    def add_ip_to_whitelist(self, ip_address: str, description: str, admin_username: str) -> bool:
        """
        Add IP address to whitelist.
        
        Args:
            ip_address: IP address to add
            description: Description of the IP address
            admin_username: Username of admin performing the action
        
        Returns:
            True if successful, False otherwise
        """
        try:
            # Validate IP address
            try:
                ipaddress.ip_address(ip_address)
            except ValueError:
                logger.error(f"Invalid IP address: {ip_address}")
                return False
            
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Check if IP is already in whitelist
            cursor.execute("SELECT COUNT(*) FROM ip_whitelist WHERE ip_address = ?", (ip_address,))
            if cursor.fetchone()[0] > 0:
                logger.warning(f"IP address already in whitelist: {ip_address}")
                conn.close()
                return False
            
            # Add IP to whitelist
            cursor.execute('''
            INSERT INTO ip_whitelist (ip_address, description, created_at, created_by)
            VALUES (?, ?, ?, ?)
            ''', (
                ip_address,
                description,
                datetime.datetime.now().isoformat(),
                admin_username
            ))
            
            conn.commit()
            conn.close()
            
            # Log action
            self._log_audit(
                "add_ip_to_whitelist", 
                f"Added IP address to whitelist: {ip_address} ({description})",
                username=admin_username
            )
            
            logger.info(f"Added IP address to whitelist: {ip_address}")
            
            return True
        except Exception as e:
            logger.error(f"Error adding IP to whitelist: {e}")
            return False
    
    def remove_ip_from_whitelist(self, ip_address: str, admin_username: str) -> bool:
        """
        Remove IP address from whitelist.
        
        Args:
            ip_address: IP address to remove
            admin_username: Username of admin performing the action
        
        Returns:
            True if successful, False otherwise
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Remove IP from whitelist
            cursor.execute("DELETE FROM ip_whitelist WHERE ip_address = ?", (ip_address,))
            
            if cursor.rowcount == 0:
                logger.warning(f"IP address not found in whitelist: {ip_address}")
                conn.close()
                return False
            
            conn.commit()
            conn.close()
            
            # Log action
            self._log_audit(
                "remove_ip_from_whitelist", 
                f"Removed IP address from whitelist: {ip_address}",
                username=admin_username
            )
            
            logger.info(f"Removed IP address from whitelist: {ip_address}")
            
            return True
        except Exception as e:
            logger.error(f"Error removing IP from whitelist: {e}")
            return False
    
    def add_ip_to_blacklist(self, ip_address: str, reason: str, admin_username: str, 
                           expires_in_days: Optional[int] = None) -> bool:
        """
        Add IP address to blacklist.
        
        Args:
            ip_address: IP address to add
            reason: Reason for blacklisting
            admin_username: Username of admin performing the action
            expires_in_days: Number of days until the blacklist entry expires (optional)
        
        Returns:
            True if successful, False otherwise
        """
        try:
            # Validate IP address
            try:
                ipaddress.ip_address(ip_address)
            except ValueError:
                logger.error(f"Invalid IP address: {ip_address}")
                return False
            
            # Calculate expiry date
            expires_at = None
            if expires_in_days:
                expires_at = (datetime.datetime.now() + datetime.timedelta(days=expires_in_days)).isoformat()
            
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Check if IP is already in blacklist
            cursor.execute("SELECT COUNT(*) FROM ip_blacklist WHERE ip_address = ?", (ip_address,))
            if cursor.fetchone()[0] > 0:
                # Update existing entry
                cursor.execute('''
                UPDATE ip_blacklist
                SET reason = ?, created_at = ?, created_by = ?, expires_at = ?
                WHERE ip_address = ?
                ''', (
                    reason,
                    datetime.datetime.now().isoformat(),
                    admin_username,
                    expires_at,
                    ip_address
                ))
            else:
                # Add IP to blacklist
                cursor.execute('''
                INSERT INTO ip_blacklist (ip_address, reason, created_at, created_by, expires_at)
                VALUES (?, ?, ?, ?, ?)
                ''', (
                    ip_address,
                    reason,
                    datetime.datetime.now().isoformat(),
                    admin_username,
                    expires_at
                ))
            
            conn.commit()
            conn.close()
            
            # Log action
            self._log_audit(
                "add_ip_to_blacklist", 
                f"Added IP address to blacklist: {ip_address} ({reason})",
                username=admin_username
            )
            
            logger.info(f"Added IP address to blacklist: {ip_address}")
            
            return True
        except Exception as e:
            logger.error(f"Error adding IP to blacklist: {e}")
            return False
    
    def remove_ip_from_blacklist(self, ip_address: str, admin_username: str) -> bool:
        """
        Remove IP address from blacklist.
        
        Args:
            ip_address: IP address to remove
            admin_username: Username of admin performing the action
        
        Returns:
            True if successful, False otherwise
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Remove IP from blacklist
            cursor.execute("DELETE FROM ip_blacklist WHERE ip_address = ?", (ip_address,))
            
            if cursor.rowcount == 0:
                logger.warning(f"IP address not found in blacklist: {ip_address}")
                conn.close()
                return False
            
            conn.commit()
            conn.close()
            
            # Log action
            self._log_audit(
                "remove_ip_from_blacklist", 
                f"Removed IP address from blacklist: {ip_address}",
                username=admin_username
            )
            
            logger.info(f"Removed IP address from blacklist: {ip_address}")
            
            return True
        except Exception as e:
            logger.error(f"Error removing IP from blacklist: {e}")
            return False
    
    def get_ip_whitelist(self) -> List[Dict[str, Any]]:
        """
        Get IP whitelist.
        
        Returns:
            List of IP whitelist entries
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Get whitelist
            cursor.execute('''
            SELECT id, ip_address, description, created_at, created_by
            FROM ip_whitelist
            ORDER BY ip_address
            ''')
            
            rows = cursor.fetchall()
            
            # Close connection
            conn.close()
            
            # Convert to dictionaries
            whitelist = []
            for row in rows:
                whitelist.append({
                    "id": row[0],
                    "ip_address": row[1],
                    "description": row[2],
                    "created_at": row[3],
                    "created_by": row[4]
                })
            
            return whitelist
        except Exception as e:
            logger.error(f"Error getting IP whitelist: {e}")
            return []
    
    def get_ip_blacklist(self) -> List[Dict[str, Any]]:
        """
        Get IP blacklist.
        
        Returns:
            List of IP blacklist entries
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Get blacklist
            cursor.execute('''
            SELECT id, ip_address, reason, created_at, created_by, expires_at
            FROM ip_blacklist
            WHERE expires_at IS NULL OR expires_at > ?
            ORDER BY ip_address
            ''', (datetime.datetime.now().isoformat(),))
            
            rows = cursor.fetchall()
            
            # Close connection
            conn.close()
            
            # Convert to dictionaries
            blacklist = []
            for row in rows:
                blacklist.append({
                    "id": row[0],
                    "ip_address": row[1],
                    "reason": row[2],
                    "created_at": row[3],
                    "created_by": row[4],
                    "expires_at": row[5]
                })
            
            return blacklist
        except Exception as e:
            logger.error(f"Error getting IP blacklist: {e}")
            return []
    
    def cleanup_expired_sessions(self) -> int:
        """
        Clean up expired sessions.
        
        Returns:
            Number of sessions removed
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Delete expired sessions
            cursor.execute('''
            DELETE FROM sessions
            WHERE expires_at < ?
            ''', (datetime.datetime.now().isoformat(),))
            
            removed_count = cursor.rowcount
            
            conn.commit()
            conn.close()
            
            logger.info(f"Removed {removed_count} expired sessions")
            
            return removed_count
        except Exception as e:
            logger.error(f"Error cleaning up expired sessions: {e}")
            return 0
    
    def cleanup_expired_blacklist(self) -> int:
        """
        Clean up expired blacklist entries.
        
        Returns:
            Number of entries removed
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Delete expired blacklist entries
            cursor.execute('''
            DELETE FROM ip_blacklist
            WHERE expires_at < ?
            ''', (datetime.datetime.now().isoformat(),))
            
            removed_count = cursor.rowcount
            
            conn.commit()
            conn.close()
            
            logger.info(f"Removed {removed_count} expired blacklist entries")
            
            return removed_count
        except Exception as e:
            logger.error(f"Error cleaning up expired blacklist entries: {e}")
            return 0
    
    def get_user_permissions(self, username: str) -> Set[PermissionScope]:
        """
        Get all permissions for a user.
        
        Args:
            username: Username
        
        Returns:
            Set of permissions
        """
        try:
            # Get user
            user = self.get_user(username)
            if not user:
                logger.error(f"User not found: {username}")
                return set()
            
            # Get role-based permissions
            permissions = set()
            if user.role in ROLE_PERMISSIONS:
                permissions.update(ROLE_PERMISSIONS[user.role])
            
            # Add custom permissions
            permissions.update(user.custom_permissions)
            
            return permissions
        except Exception as e:
            logger.error(f"Error getting user permissions: {e}")
            return set()
    
    def has_permission(self, username: str, permission: PermissionScope) -> bool:
        """
        Check if user has a specific permission.
        
        Args:
            username: Username
            permission: Permission to check
        
        Returns:
            True if user has permission, False otherwise
        """
        try:
            # Get user
            user = self.get_user(username)
            if not user:
                logger.error(f"User not found: {username}")
                return False
            
            return user.has_permission(permission)
        except Exception as e:
            logger.error(f"Error checking permission: {e}")
            return False
    
    def generate_qr_code(self, data: str) -> bytes:
        """
        Generate QR code image.
        
        Args:
            data: Data to encode in QR code
        
        Returns:
            QR code image as bytes
        """
        try:
            # Generate QR code
            qr = qrcode.QRCode(
                version=1,
                error_correction=qrcode.constants.ERROR_CORRECT_L,
                box_size=10,
                border=4,
            )
            qr.add_data(data)
            qr.make(fit=True)
            
            # Create image
            img = qr.make_image(fill_color="black", back_color="white")
            
            # Convert to bytes
            buffer = BytesIO()
            img.save(buffer, format="PNG")
            
            return buffer.getvalue()
        except Exception as e:
            logger.error(f"Error generating QR code: {e}")
            raise
