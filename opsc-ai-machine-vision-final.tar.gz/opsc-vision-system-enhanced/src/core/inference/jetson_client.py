"""
Jetson client module for OPSC Sandwich Quality Inspection System.
Provides communication with ADLINK DLAP-211-JNX for AI inference.

Version: 1.0.0
Last Updated: 2025-04-20
"""

import os
import sys
import time
import threading
import queue
from typing import Dict, List, Optional, Tuple, Union, Any, Callable, Generator
import logging
import numpy as np
from dataclasses import dataclass, field
from enum import Enum
import json
import uuid
from pathlib import Path
import concurrent.futures
import datetime
import socket
import struct
import pickle
import zlib
import io
import base64
import hashlib
import tempfile
import asyncio
import grpc
from google.protobuf.json_format import MessageToDict

from ...utils.config import get_config
from ...utils.logging import setup_logging, log_exception
from ...utils.network import NetworkUtils
from ...utils.security import encrypt_data, decrypt_data, generate_token

# Import protobuf-generated modules
# These will be generated from the .proto files
try:
    import jetson_service_pb2
    import jetson_service_pb2_grpc
except ImportError:
    # Generate protobuf modules if they don't exist
    import subprocess
    import sys
    
    # Get the directory of this file
    current_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Create proto directory if it doesn't exist
    proto_dir = os.path.join(current_dir, "proto")
    os.makedirs(proto_dir, exist_ok=True)
    
    # Create jetson_service.proto file
    proto_file = os.path.join(proto_dir, "jetson_service.proto")
    
    with open(proto_file, "w") as f:
        f.write("""
syntax = "proto3";

package jetson_service;

// Service definition
service JetsonService {
    // Send image for inference
    rpc InferImage (InferImageRequest) returns (InferImageResponse) {}
    
    // Stream images for inference
    rpc StreamInference (stream InferImageRequest) returns (stream InferImageResponse) {}
    
    // Get system status
    rpc GetStatus (StatusRequest) returns (StatusResponse) {}
    
    // Update model
    rpc UpdateModel (UpdateModelRequest) returns (UpdateModelResponse) {}
    
    // Get available models
    rpc GetModels (GetModelsRequest) returns (GetModelsResponse) {}
    
    // Set model parameters
    rpc SetModelParameters (SetModelParametersRequest) returns (SetModelParametersResponse) {}
}

// Image format
enum ImageFormat {
    UNKNOWN = 0;
    RGB = 1;
    BGR = 2;
    GRAY = 3;
    RGBA = 4;
    BGRA = 5;
}

// Inference request
message InferImageRequest {
    // Image data (compressed)
    bytes image_data = 1;
    
    // Image format
    ImageFormat image_format = 2;
    
    // Image dimensions
    int32 width = 3;
    int32 height = 4;
    
    // Model ID
    string model_id = 5;
    
    // Confidence threshold
    float confidence_threshold = 6;
    
    // Request ID
    string request_id = 7;
    
    // Camera ID
    string camera_id = 8;
    
    // Timestamp
    int64 timestamp = 9;
    
    // Compression format (e.g., "jpeg", "png", "zlib")
    string compression = 10;
    
    // Additional parameters
    map<string, string> parameters = 11;
}

// Bounding box
message BoundingBox {
    float x = 1;
    float y = 2;
    float width = 3;
    float height = 4;
}

// Detection result
message Detection {
    // Class ID
    string class_id = 1;
    
    // Class name
    string class_name = 2;
    
    // Confidence score
    float confidence = 3;
    
    // Bounding box
    BoundingBox bounding_box = 4;
    
    // Additional attributes
    map<string, string> attributes = 5;
}

// Inference response
message InferImageResponse {
    // Request ID
    string request_id = 1;
    
    // Model ID
    string model_id = 2;
    
    // Detections
    repeated Detection detections = 3;
    
    // Processing time (ms)
    float processing_time = 4;
    
    // Status code
    int32 status_code = 5;
    
    // Status message
    string status_message = 6;
    
    // Camera ID
    string camera_id = 7;
    
    // Timestamp
    int64 timestamp = 8;
    
    // Additional information
    map<string, string> info = 9;
}

// Status request
message StatusRequest {
    // Request ID
    string request_id = 1;
}

// GPU status
message GpuStatus {
    // Utilization (%)
    float utilization = 1;
    
    // Memory usage (%)
    float memory_usage = 2;
    
    // Temperature (°C)
    float temperature = 3;
    
    // Power usage (W)
    float power_usage = 4;
    
    // Memory total (MB)
    float memory_total = 5;
    
    // Memory free (MB)
    float memory_free = 6;
}

// System status
message SystemStatus {
    // CPU utilization (%)
    float cpu_utilization = 1;
    
    // Memory usage (%)
    float memory_usage = 2;
    
    // Disk usage (%)
    float disk_usage = 3;
    
    // Temperature (°C)
    float temperature = 4;
    
    // Uptime (seconds)
    int64 uptime = 5;
    
    // GPU status
    GpuStatus gpu_status = 6;
}

// Model status
message ModelStatus {
    // Model ID
    string model_id = 1;
    
    // Model name
    string model_name = 2;
    
    // Model version
    string version = 3;
    
    // Is loaded
    bool is_loaded = 4;
    
    // Last used timestamp
    int64 last_used = 5;
    
    // Average inference time (ms)
    float avg_inference_time = 6;
    
    // Memory usage (MB)
    float memory_usage = 7;
    
    // Additional information
    map<string, string> info = 8;
}

// Status response
message StatusResponse {
    // Request ID
    string request_id = 1;
    
    // System status
    SystemStatus system_status = 2;
    
    // Model statuses
    repeated ModelStatus model_statuses = 3;
    
    // Status code
    int32 status_code = 4;
    
    // Status message
    string status_message = 5;
    
    // Timestamp
    int64 timestamp = 6;
}

// Update model request
message UpdateModelRequest {
    // Request ID
    string request_id = 1;
    
    // Model ID
    string model_id = 2;
    
    // Model name
    string model_name = 3;
    
    // Model version
    string version = 4;
    
    // Model data (compressed)
    bytes model_data = 5;
    
    // Model format (e.g., "onnx", "trt", "roboflow")
    string model_format = 6;
    
    // Compression format (e.g., "zip", "tar.gz")
    string compression = 7;
    
    // Model configuration
    map<string, string> config = 8;
    
    // Force update
    bool force = 9;
}

// Update model response
message UpdateModelResponse {
    // Request ID
    string request_id = 1;
    
    // Model ID
    string model_id = 2;
    
    // Status code
    int32 status_code = 3;
    
    // Status message
    string status_message = 4;
    
    // Model information
    map<string, string> info = 5;
}

// Get models request
message GetModelsRequest {
    // Request ID
    string request_id = 1;
}

// Get models response
message GetModelsResponse {
    // Request ID
    string request_id = 1;
    
    // Model statuses
    repeated ModelStatus model_statuses = 2;
    
    // Status code
    int32 status_code = 3;
    
    // Status message
    string status_message = 4;
}

// Set model parameters request
message SetModelParametersRequest {
    // Request ID
    string request_id = 1;
    
    // Model ID
    string model_id = 2;
    
    // Parameters
    map<string, string> parameters = 3;
}

// Set model parameters response
message SetModelParametersResponse {
    // Request ID
    string request_id = 1;
    
    // Model ID
    string model_id = 2;
    
    // Status code
    int32 status_code = 3;
    
    // Status message
    string status_message = 4;
    
    // Updated parameters
    map<string, string> parameters = 5;
}
""")
    
    # Generate Python code from proto file
    subprocess.check_call([
        sys.executable, "-m", "grpc_tools.protoc",
        "-I", proto_dir,
        "--python_out=.", 
        "--grpc_python_out=.",
        proto_file
    ])
    
    # Import the generated modules
    import jetson_service_pb2
    import jetson_service_pb2_grpc

# Setup logging
logger = setup_logging(__name__)


class JetsonClientError(Exception):
    """Base exception for Jetson client errors."""
    pass


class ConnectionError(JetsonClientError):
    """Exception raised when connection to Jetson fails."""
    pass


class InferenceError(JetsonClientError):
    """Exception raised when inference fails."""
    pass


class ModelError(JetsonClientError):
    """Exception raised when model operations fail."""
    pass


class StatusError(JetsonClientError):
    """Exception raised when status request fails."""
    pass


@dataclass
class BoundingBox:
    """Bounding box for detection results."""
    x: float
    y: float
    width: float
    height: float
    
    @property
    def x1(self) -> float:
        """Get left coordinate."""
        return self.x
    
    @property
    def y1(self) -> float:
        """Get top coordinate."""
        return self.y
    
    @property
    def x2(self) -> float:
        """Get right coordinate."""
        return self.x + self.width
    
    @property
    def y2(self) -> float:
        """Get bottom coordinate."""
        return self.y + self.height
    
    @property
    def area(self) -> float:
        """Get area of bounding box."""
        return self.width * self.height
    
    @property
    def center(self) -> Tuple[float, float]:
        """Get center of bounding box."""
        return (self.x + self.width / 2, self.y + self.height / 2)
    
    def to_dict(self) -> Dict[str, float]:
        """Convert to dictionary."""
        return {
            "x": self.x,
            "y": self.y,
            "width": self.width,
            "height": self.height
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, float]) -> 'BoundingBox':
        """Create from dictionary."""
        return cls(
            x=data["x"],
            y=data["y"],
            width=data["width"],
            height=data["height"]
        )
    
    @classmethod
    def from_proto(cls, bbox: jetson_service_pb2.BoundingBox) -> 'BoundingBox':
        """Create from protobuf BoundingBox."""
        return cls(
            x=bbox.x,
            y=bbox.y,
            width=bbox.width,
            height=bbox.height
        )
    
    def to_proto(self) -> jetson_service_pb2.BoundingBox:
        """Convert to protobuf BoundingBox."""
        return jetson_service_pb2.BoundingBox(
            x=self.x,
            y=self.y,
            width=self.width,
            height=self.height
        )
    
    def iou(self, other: 'BoundingBox') -> float:
        """Calculate Intersection over Union with another bounding box."""
        # Calculate intersection area
        x_left = max(self.x1, other.x1)
        y_top = max(self.y1, other.y1)
        x_right = min(self.x2, other.x2)
        y_bottom = min(self.y2, other.y2)
        
        if x_right < x_left or y_bottom < y_top:
            return 0.0
        
        intersection_area = (x_right - x_left) * (y_bottom - y_top)
        
        # Calculate union area
        union_area = self.area + other.area - intersection_area
        
        return intersection_area / union_area


@dataclass
class Detection:
    """Detection result from inference."""
    class_id: str
    class_name: str
    confidence: float
    bounding_box: BoundingBox
    attributes: Dict[str, str] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "class_id": self.class_id,
            "class_name": self.class_name,
            "confidence": self.confidence,
            "bounding_box": self.bounding_box.to_dict(),
            "attributes": self.attributes
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Detection':
        """Create from dictionary."""
        return cls(
            class_id=data["class_id"],
            class_name=data["class_name"],
            confidence=data["confidence"],
            bounding_box=BoundingBox.from_dict(data["bounding_box"]),
            attributes=data.get("attributes", {})
        )
    
    @classmethod
    def from_proto(cls, detection: jetson_service_pb2.Detection) -> 'Detection':
        """Create from protobuf Detection."""
        return cls(
            class_id=detection.class_id,
            class_name=detection.class_name,
            confidence=detection.confidence,
            bounding_box=BoundingBox.from_proto(detection.bounding_box),
            attributes=dict(detection.attributes)
        )
    
    def to_proto(self) -> jetson_service_pb2.Detection:
        """Convert to protobuf Detection."""
        return jetson_service_pb2.Detection(
            class_id=self.class_id,
            class_name=self.class_name,
            confidence=self.confidence,
            bounding_box=self.bounding_box.to_proto(),
            attributes=self.attributes
        )


@dataclass
class InferenceResult:
    """Result of inference."""
    request_id: str
    model_id: str
    detections: List[Detection]
    processing_time: float
    status_code: int
    status_message: str
    camera_id: str
    timestamp: int
    info: Dict[str, str] = field(default_factory=dict)
    
    @property
    def success(self) -> bool:
        """Check if inference was successful."""
        return self.status_code == 0
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "request_id": self.request_id,
            "model_id": self.model_id,
            "detections": [d.to_dict() for d in self.detections],
            "processing_time": self.processing_time,
            "status_code": self.status_code,
            "status_message": self.status_message,
            "camera_id": self.camera_id,
            "timestamp": self.timestamp,
            "info": self.info
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'InferenceResult':
        """Create from dictionary."""
        return cls(
            request_id=data["request_id"],
            model_id=data["model_id"],
            detections=[Detection.from_dict(d) for d in data["detections"]],
            processing_time=data["processing_time"],
            status_code=data["status_code"],
            status_message=data["status_message"],
            camera_id=data["camera_id"],
            timestamp=data["timestamp"],
            info=data.get("info", {})
        )
    
    @classmethod
    def from_proto(cls, response: jetson_service_pb2.InferImageResponse) -> 'InferenceResult':
        """Create from protobuf InferImageResponse."""
        return cls(
            request_id=response.request_id,
            model_id=response.model_id,
            detections=[Detection.from_proto(d) for d in response.detections],
            processing_time=response.processing_time,
            status_code=response.status_code,
            status_message=response.status_message,
            camera_id=response.camera_id,
            timestamp=response.timestamp,
            info=dict(response.info)
        )


@dataclass
class GpuStatus:
    """GPU status information."""
    utilization: float
    memory_usage: float
    temperature: float
    power_usage: float
    memory_total: float
    memory_free: float
    
    @property
    def memory_used(self) -> float:
        """Get used memory in MB."""
        return self.memory_total - self.memory_free
    
    def to_dict(self) -> Dict[str, float]:
        """Convert to dictionary."""
        return {
            "utilization": self.utilization,
            "memory_usage": self.memory_usage,
            "temperature": self.temperature,
            "power_usage": self.power_usage,
            "memory_total": self.memory_total,
            "memory_free": self.memory_free,
            "memory_used": self.memory_used
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, float]) -> 'GpuStatus':
        """Create from dictionary."""
        return cls(
            utilization=data["utilization"],
            memory_usage=data["memory_usage"],
            temperature=data["temperature"],
            power_usage=data["power_usage"],
            memory_total=data["memory_total"],
            memory_free=data["memory_free"]
        )
    
    @classmethod
    def from_proto(cls, gpu_status: jetson_service_pb2.GpuStatus) -> 'GpuStatus':
        """Create from protobuf GpuStatus."""
        return cls(
            utilization=gpu_status.utilization,
            memory_usage=gpu_status.memory_usage,
            temperature=gpu_status.temperature,
            power_usage=gpu_status.power_usage,
            memory_total=gpu_status.memory_total,
            memory_free=gpu_status.memory_free
        )


@dataclass
class SystemStatus:
    """System status information."""
    cpu_utilization: float
    memory_usage: float
    disk_usage: float
    temperature: float
    uptime: int
    gpu_status: GpuStatus
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "cpu_utilization": self.cpu_utilization,
            "memory_usage": self.memory_usage,
            "disk_usage": self.disk_usage,
            "temperature": self.temperature,
            "uptime": self.uptime,
            "gpu_status": self.gpu_status.to_dict()
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'SystemStatus':
        """Create from dictionary."""
        return cls(
            cpu_utilization=data["cpu_utilization"],
            memory_usage=data["memory_usage"],
            disk_usage=data["disk_usage"],
            temperature=data["temperature"],
            uptime=data["uptime"],
            gpu_status=GpuStatus.from_dict(data["gpu_status"])
        )
    
    @classmethod
    def from_proto(cls, system_status: jetson_service_pb2.SystemStatus) -> 'SystemStatus':
        """Create from protobuf SystemStatus."""
        return cls(
            cpu_utilization=system_status.cpu_utilization,
            memory_usage=system_status.memory_usage,
            disk_usage=system_status.disk_usage,
            temperature=system_status.temperature,
            uptime=system_status.uptime,
            gpu_status=GpuStatus.from_proto(system_status.gpu_status)
        )


@dataclass
class ModelStatus:
    """Model status information."""
    model_id: str
    model_name: str
    version: str
    is_loaded: bool
    last_used: int
    avg_inference_time: float
    memory_usage: float
    info: Dict[str, str] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "model_id": self.model_id,
            "model_name": self.model_name,
            "version": self.version,
            "is_loaded": self.is_loaded,
            "last_used": self.last_used,
            "avg_inference_time": self.avg_inference_time,
            "memory_usage": self.memory_usage,
            "info": self.info
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ModelStatus':
        """Create from dictionary."""
        return cls(
            model_id=data["model_id"],
            model_name=data["model_name"],
            version=data["version"],
            is_loaded=data["is_loaded"],
            last_used=data["last_used"],
            avg_inference_time=data["avg_inference_time"],
            memory_usage=data["memory_usage"],
            info=data.get("info", {})
        )
    
    @classmethod
    def from_proto(cls, model_status: jetson_service_pb2.ModelStatus) -> 'ModelStatus':
        """Create from protobuf ModelStatus."""
        return cls(
            model_id=model_status.model_id,
            model_name=model_status.model_name,
            version=model_status.version,
            is_loaded=model_status.is_loaded,
            last_used=model_status.last_used,
            avg_inference_time=model_status.avg_inference_time,
            memory_usage=model_status.memory_usage,
            info=dict(model_status.info)
        )


@dataclass
class StatusResult:
    """Result of status request."""
    request_id: str
    system_status: SystemStatus
    model_statuses: List[ModelStatus]
    status_code: int
    status_message: str
    timestamp: int
    
    @property
    def success(self) -> bool:
        """Check if status request was successful."""
        return self.status_code == 0
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "request_id": self.request_id,
            "system_status": self.system_status.to_dict(),
            "model_statuses": [m.to_dict() for m in self.model_statuses],
            "status_code": self.status_code,
            "status_message": self.status_message,
            "timestamp": self.timestamp
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'StatusResult':
        """Create from dictionary."""
        return cls(
            request_id=data["request_id"],
            system_status=SystemStatus.from_dict(data["system_status"]),
            model_statuses=[ModelStatus.from_dict(m) for m in data["model_statuses"]],
            status_code=data["status_code"],
            status_message=data["status_message"],
            timestamp=data["timestamp"]
        )
    
    @classmethod
    def from_proto(cls, response: jetson_service_pb2.StatusResponse) -> 'StatusResult':
        """Create from protobuf StatusResponse."""
        return cls(
            request_id=response.request_id,
            system_status=SystemStatus.from_proto(response.system_status),
            model_statuses=[ModelStatus.from_proto(m) for m in response.model_statuses],
            status_code=response.status_code,
            status_message=response.status_message,
            timestamp=response.timestamp
        )


@dataclass
class UpdateModelResult:
    """Result of model update."""
    request_id: str
    model_id: str
    status_code: int
    status_message: str
    info: Dict[str, str] = field(default_factory=dict)
    
    @property
    def success(self) -> bool:
        """Check if model update was successful."""
        return self.status_code == 0
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "request_id": self.request_id,
            "model_id": self.model_id,
            "status_code": self.status_code,
            "status_message": self.status_message,
            "info": self.info
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'UpdateModelResult':
        """Create from dictionary."""
        return cls(
            request_id=data["request_id"],
            model_id=data["model_id"],
            status_code=data["status_code"],
            status_message=data["status_message"],
            info=data.get("info", {})
        )
    
    @classmethod
    def from_proto(cls, response: jetson_service_pb2.UpdateModelResponse) -> 'UpdateModelResult':
        """Create from protobuf UpdateModelResponse."""
        return cls(
            request_id=response.request_id,
            model_id=response.model_id,
            status_code=response.status_code,
            status_message=response.status_message,
            info=dict(response.info)
        )


@dataclass
class GetModelsResult:
    """Result of get models request."""
    request_id: str
    model_statuses: List[ModelStatus]
    status_code: int
    status_message: str
    
    @property
    def success(self) -> bool:
        """Check if get models request was successful."""
        return self.status_code == 0
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "request_id": self.request_id,
            "model_statuses": [m.to_dict() for m in self.model_statuses],
            "status_code": self.status_code,
            "status_message": self.status_message
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'GetModelsResult':
        """Create from dictionary."""
        return cls(
            request_id=data["request_id"],
            model_statuses=[ModelStatus.from_dict(m) for m in data["model_statuses"]],
            status_code=data["status_code"],
            status_message=data["status_message"]
        )
    
    @classmethod
    def from_proto(cls, response: jetson_service_pb2.GetModelsResponse) -> 'GetModelsResult':
        """Create from protobuf GetModelsResponse."""
        return cls(
            request_id=response.request_id,
            model_statuses=[ModelStatus.from_proto(m) for m in response.model_statuses],
            status_code=response.status_code,
            status_message=response.status_message
        )


@dataclass
class SetModelParametersResult:
    """Result of set model parameters request."""
    request_id: str
    model_id: str
    status_code: int
    status_message: str
    parameters: Dict[str, str] = field(default_factory=dict)
    
    @property
    def success(self) -> bool:
        """Check if set model parameters request was successful."""
        return self.status_code == 0
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "request_id": self.request_id,
            "model_id": self.model_id,
            "status_code": self.status_code,
            "status_message": self.status_message,
            "parameters": self.parameters
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'SetModelParametersResult':
        """Create from dictionary."""
        return cls(
            request_id=data["request_id"],
            model_id=data["model_id"],
            status_code=data["status_code"],
            status_message=data["status_message"],
            parameters=data.get("parameters", {})
        )
    
    @classmethod
    def from_proto(cls, response: jetson_service_pb2.SetModelParametersResponse) -> 'SetModelParametersResult':
        """Create from protobuf SetModelParametersResponse."""
        return cls(
            request_id=response.request_id,
            model_id=response.model_id,
            status_code=response.status_code,
            status_message=response.status_message,
            parameters=dict(response.parameters)
        )


class JetsonClient:
    """
    Client for communicating with ADLINK DLAP-211-JNX Jetson device.
    Provides methods for sending images for inference, getting system status,
    and managing models.
    """
    
    def __init__(self, host: Optional[str] = None, port: Optional[int] = None, use_ssl: Optional[bool] = None):
        """
        Initialize Jetson client.
        
        Args:
            host: Jetson host address. If None, uses the value from configuration.
            port: Jetson port. If None, uses the value from configuration.
            use_ssl: Whether to use SSL for communication. If None, uses the value from configuration.
        """
        # Load configuration
        self.config = get_config("jetson", {})
        
        # Set connection parameters
        self.host = host or self.config.get("host", "192.168.100.20")
        self.port = port or self.config.get("port", 50051)
        self.use_ssl = use_ssl if use_ssl is not None else self.config.get("use_ssl", False)
        
        # Set timeout
        self.timeout = self.config.get("timeout", 30.0)
        
        # Set retry parameters
        self.max_retries = self.config.get("max_retries", 3)
        self.retry_delay = self.config.get("retry_delay", 1.0)
        self.retry_backoff = self.config.get("retry_backoff", 2.0)
        
        # Set compression parameters
        self.compression = self.config.get("compression", "jpeg")
        self.compression_quality = self.config.get("compression_quality", 90)
        
        # Set batch parameters
        self.max_batch_size = self.config.get("max_batch_size", 8)
        
        # Initialize connection
        self.channel = None
        self.stub = None
        
        # Initialize connection lock
        self.connection_lock = threading.Lock()
        
        # Initialize connection status
        self.connected = False
        self.last_connection_attempt = 0
        self.connection_failures = 0
        
        # Initialize heartbeat thread
        self.heartbeat_interval = self.config.get("heartbeat_interval", 10.0)
        self.heartbeat_thread = None
        self.heartbeat_stop_event = threading.Event()
        
        # Initialize status cache
        self.status_cache = None
        self.status_cache_time = 0
        self.status_cache_ttl = self.config.get("status_cache_ttl", 5.0)
        
        # Initialize model cache
        self.model_cache = {}
        
        # Initialize request ID counter
        self.request_id_counter = 0
        self.request_id_lock = threading.Lock()
        
        # Initialize stream
        self.stream = None
        self.stream_lock = threading.Lock()
        
        # Initialize metrics
        self.metrics = {
            "inference_count": 0,
            "inference_time_total": 0.0,
            "inference_time_min": float('inf'),
            "inference_time_max": 0.0,
            "connection_attempts": 0,
            "connection_failures": 0,
            "reconnections": 0,
            "errors": 0
        }
        self.metrics_lock = threading.Lock()
        
        logger.info(f"Initialized Jetson client for {self.host}:{self.port}")
    
    def __enter__(self):
        """Enter context manager."""
        self.connect()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Exit context manager."""
        self.disconnect()
    
    def _generate_request_id(self) -> str:
        """
        Generate a unique request ID.
        
        Returns:
            Unique request ID.
        """
        with self.request_id_lock:
            self.request_id_counter += 1
            return f"{int(time.time())}-{self.request_id_counter}"
    
    def _update_metrics(self, key: str, value: Any) -> None:
        """
        Update metrics.
        
        Args:
            key: Metric key.
            value: Metric value.
        """
        with self.metrics_lock:
            if key in self.metrics:
                if isinstance(self.metrics[key], (int, float)) and isinstance(value, (int, float)):
                    self.metrics[key] += value
                else:
                    self.metrics[key] = value
    
    def _compress_image(self, image: np.ndarray) -> Tuple[bytes, str]:
        """
        Compress image for transmission.
        
        Args:
            image: Image to compress.
            
        Returns:
            Tuple of (compressed image data, compression format).
        """
        if self.compression == "jpeg":
            # Compress as JPEG
            encode_param = [int(cv2.IMWRITE_JPEG_QUALITY), self.compression_quality]
            _, buffer = cv2.imencode(".jpg", image, encode_param)
            return buffer.tobytes(), "jpeg"
        
        elif self.compression == "png":
            # Compress as PNG
            encode_param = [int(cv2.IMWRITE_PNG_COMPRESSION), min(9, self.compression_quality // 10)]
            _, buffer = cv2.imencode(".png", image, encode_param)
            return buffer.tobytes(), "png"
        
        elif self.compression == "zlib":
            # Compress with zlib
            buffer = image.tobytes()
            compressed = zlib.compress(buffer, level=min(9, self.compression_quality // 10))
            return compressed, "zlib"
        
        else:
            # No compression
            return image.tobytes(), "raw"
    
    def _get_image_format(self, image: np.ndarray) -> jetson_service_pb2.ImageFormat:
        """
        Get image format for protobuf.
        
        Args:
            image: Image to get format for.
            
        Returns:
            Image format enum value.
        """
        if len(image.shape) == 2:
            return jetson_service_pb2.ImageFormat.GRAY
        elif len(image.shape) == 3:
            if image.shape[2] == 3:
                # Assume BGR (OpenCV default)
                return jetson_service_pb2.ImageFormat.BGR
            elif image.shape[2] == 4:
                # Assume BGRA
                return jetson_service_pb2.ImageFormat.BGRA
        
        return jetson_service_pb2.ImageFormat.UNKNOWN
    
    def _create_inference_request(
        self,
        image: np.ndarray,
        model_id: str,
        confidence_threshold: float,
        camera_id: str,
        parameters: Optional[Dict[str, str]] = None
    ) -> jetson_service_pb2.InferImageRequest:
        """
        Create inference request.
        
        Args:
            image: Image to infer.
            model_id: Model ID.
            confidence_threshold: Confidence threshold.
            camera_id: Camera ID.
            parameters: Additional parameters.
            
        Returns:
            Inference request.
        """
        # Compress image
        image_data, compression = self._compress_image(image)
        
        # Get image format
        image_format = self._get_image_format(image)
        
        # Create request
        request = jetson_service_pb2.InferImageRequest(
            image_data=image_data,
            image_format=image_format,
            width=image.shape[1],
            height=image.shape[0],
            model_id=model_id,
            confidence_threshold=confidence_threshold,
            request_id=self._generate_request_id(),
            camera_id=camera_id,
            timestamp=int(time.time() * 1000),
            compression=compression,
            parameters=parameters or {}
        )
        
        return request
    
    def connect(self) -> bool:
        """
        Connect to Jetson device.
        
        Returns:
            True if connection was successful, False otherwise.
        """
        with self.connection_lock:
            # Check if already connected
            if self.connected:
                return True
            
            # Update connection attempt metrics
            self._update_metrics("connection_attempts", 1)
            self.last_connection_attempt = time.time()
            
            try:
                # Create channel
                target = f"{self.host}:{self.port}"
                
                if self.use_ssl:
                    # Create SSL credentials
                    credentials = grpc.ssl_channel_credentials()
                    self.channel = grpc.secure_channel(target, credentials)
                else:
                    # Create insecure channel
                    self.channel = grpc.insecure_channel(target)
                
                # Create stub
                self.stub = jetson_service_pb2_grpc.JetsonServiceStub(self.channel)
                
                # Test connection
                request = jetson_service_pb2.StatusRequest(
                    request_id=self._generate_request_id()
                )
                
                # Set timeout
                response = self.stub.GetStatus(request, timeout=self.timeout)
                
                # Update connection status
                self.connected = True
                self.connection_failures = 0
                
                # Start heartbeat thread
                self._start_heartbeat()
                
                logger.info(f"Connected to Jetson device at {self.host}:{self.port}")
                
                return True
            except Exception as e:
                # Update connection failure metrics
                self._update_metrics("connection_failures", 1)
                self.connection_failures += 1
                
                logger.error(f"Failed to connect to Jetson device at {self.host}:{self.port}: {e}")
                
                # Clean up
                if self.channel:
                    try:
                        self.channel.close()
                    except:
                        pass
                
                self.channel = None
                self.stub = None
                self.connected = False
                
                return False
    
    def disconnect(self) -> None:
        """Disconnect from Jetson device."""
        with self.connection_lock:
            # Stop heartbeat thread
            self._stop_heartbeat()
            
            # Close stream
            self._close_stream()
            
            # Close channel
            if self.channel:
                try:
                    self.channel.close()
                except:
                    pass
            
            # Reset connection status
            self.channel = None
            self.stub = None
            self.connected = False
            
            logger.info(f"Disconnected from Jetson device at {self.host}:{self.port}")
    
    def reconnect(self) -> bool:
        """
        Reconnect to Jetson device.
        
        Returns:
            True if reconnection was successful, False otherwise.
        """
        # Disconnect first
        self.disconnect()
        
        # Update reconnection metrics
        self._update_metrics("reconnections", 1)
        
        # Connect again
        return self.connect()
    
    def _start_heartbeat(self) -> None:
        """Start heartbeat thread."""
        # Stop existing heartbeat thread
        self._stop_heartbeat()
        
        # Reset stop event
        self.heartbeat_stop_event.clear()
        
        # Create and start heartbeat thread
        self.heartbeat_thread = threading.Thread(target=self._heartbeat_loop)
        self.heartbeat_thread.daemon = True
        self.heartbeat_thread.start()
        
        logger.debug("Started heartbeat thread")
    
    def _stop_heartbeat(self) -> None:
        """Stop heartbeat thread."""
        if self.heartbeat_thread and self.heartbeat_thread.is_alive():
            # Set stop event
            self.heartbeat_stop_event.set()
            
            # Wait for thread to stop
            self.heartbeat_thread.join(timeout=1.0)
            
            logger.debug("Stopped heartbeat thread")
        
        self.heartbeat_thread = None
    
    def _heartbeat_loop(self) -> None:
        """Heartbeat loop."""
        while not self.heartbeat_stop_event.is_set():
            try:
                # Check if connected
                if not self.connected:
                    break
                
                # Send heartbeat
                self.get_status(use_cache=False)
                
                # Wait for next heartbeat
                self.heartbeat_stop_event.wait(self.heartbeat_interval)
            except Exception as e:
                logger.warning(f"Heartbeat failed: {e}")
                
                # Wait before next attempt
                self.heartbeat_stop_event.wait(1.0)
    
    def _open_stream(self) -> None:
        """Open bidirectional stream for inference."""
        with self.stream_lock:
            # Check if already open
            if self.stream:
                return
            
            # Check if connected
            if not self.connected:
                if not self.connect():
                    raise ConnectionError("Not connected to Jetson device")
            
            # Open stream
            self.stream = self.stub.StreamInference()
            
            logger.debug("Opened inference stream")
    
    def _close_stream(self) -> None:
        """Close bidirectional stream."""
        with self.stream_lock:
            if self.stream:
                try:
                    self.stream.cancel()
                except:
                    pass
                
                self.stream = None
                
                logger.debug("Closed inference stream")
    
    def infer_image(
        self,
        image: np.ndarray,
        model_id: str,
        confidence_threshold: float = 0.5,
        camera_id: str = "default",
        parameters: Optional[Dict[str, str]] = None,
        retry: bool = True
    ) -> InferenceResult:
        """
        Send image for inference.
        
        Args:
            image: Image to infer.
            model_id: Model ID.
            confidence_threshold: Confidence threshold.
            camera_id: Camera ID.
            parameters: Additional parameters.
            retry: Whether to retry on failure.
            
        Returns:
            Inference result.
            
        Raises:
            ConnectionError: If not connected to Jetson device.
            InferenceError: If inference fails.
        """
        # Check if connected
        if not self.connected:
            if not self.connect():
                raise ConnectionError("Not connected to Jetson device")
        
        # Create request
        request = self._create_inference_request(
            image=image,
            model_id=model_id,
            confidence_threshold=confidence_threshold,
            camera_id=camera_id,
            parameters=parameters
        )
        
        # Send request
        for attempt in range(self.max_retries if retry else 1):
            try:
                # Record start time
                start_time = time.time()
                
                # Send request
                response = self.stub.InferImage(request, timeout=self.timeout)
                
                # Record end time
                end_time = time.time()
                inference_time = end_time - start_time
                
                # Update metrics
                self._update_metrics("inference_count", 1)
                self._update_metrics("inference_time_total", inference_time)
                
                with self.metrics_lock:
                    self.metrics["inference_time_min"] = min(self.metrics["inference_time_min"], inference_time)
                    self.metrics["inference_time_max"] = max(self.metrics["inference_time_max"], inference_time)
                
                # Create result
                result = InferenceResult.from_proto(response)
                
                # Check status
                if not result.success:
                    logger.warning(f"Inference failed: {result.status_message}")
                
                return result
            except grpc.RpcError as e:
                # Update error metrics
                self._update_metrics("errors", 1)
                
                logger.error(f"Inference RPC error: {e}")
                
                # Check if should retry
                if attempt < self.max_retries - 1 and retry:
                    # Calculate retry delay with exponential backoff
                    delay = self.retry_delay * (self.retry_backoff ** attempt)
                    
                    logger.info(f"Retrying inference in {delay:.2f}s (attempt {attempt + 1}/{self.max_retries})")
                    
                    # Wait before retry
                    time.sleep(delay)
                    
                    # Reconnect if needed
                    if not self.connected:
                        self.reconnect()
                else:
                    # Raise exception
                    raise InferenceError(f"Inference failed after {attempt + 1} attempts: {e}")
            except Exception as e:
                # Update error metrics
                self._update_metrics("errors", 1)
                
                logger.error(f"Inference error: {e}")
                
                # Check if should retry
                if attempt < self.max_retries - 1 and retry:
                    # Calculate retry delay with exponential backoff
                    delay = self.retry_delay * (self.retry_backoff ** attempt)
                    
                    logger.info(f"Retrying inference in {delay:.2f}s (attempt {attempt + 1}/{self.max_retries})")
                    
                    # Wait before retry
                    time.sleep(delay)
                    
                    # Reconnect if needed
                    if not self.connected:
                        self.reconnect()
                else:
                    # Raise exception
                    raise InferenceError(f"Inference failed after {attempt + 1} attempts: {e}")
    
    async def infer_image_async(
        self,
        image: np.ndarray,
        model_id: str,
        confidence_threshold: float = 0.5,
        camera_id: str = "default",
        parameters: Optional[Dict[str, str]] = None,
        retry: bool = True
    ) -> InferenceResult:
        """
        Send image for inference asynchronously.
        
        Args:
            image: Image to infer.
            model_id: Model ID.
            confidence_threshold: Confidence threshold.
            camera_id: Camera ID.
            parameters: Additional parameters.
            retry: Whether to retry on failure.
            
        Returns:
            Inference result.
            
        Raises:
            ConnectionError: If not connected to Jetson device.
            InferenceError: If inference fails.
        """
        # Run in thread pool
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            None,
            lambda: self.infer_image(
                image=image,
                model_id=model_id,
                confidence_threshold=confidence_threshold,
                camera_id=camera_id,
                parameters=parameters,
                retry=retry
            )
        )
    
    def infer_images_batch(
        self,
        images: Dict[str, np.ndarray],
        model_id: str,
        confidence_threshold: float = 0.5,
        parameters: Optional[Dict[str, str]] = None,
        retry: bool = True
    ) -> Dict[str, InferenceResult]:
        """
        Send multiple images for inference.
        
        Args:
            images: Dictionary of images by camera ID.
            model_id: Model ID.
            confidence_threshold: Confidence threshold.
            parameters: Additional parameters.
            retry: Whether to retry on failure.
            
        Returns:
            Dictionary of inference results by camera ID.
            
        Raises:
            ConnectionError: If not connected to Jetson device.
            InferenceError: If inference fails.
        """
        # Check if connected
        if not self.connected:
            if not self.connect():
                raise ConnectionError("Not connected to Jetson device")
        
        # Process images in batches
        results = {}
        
        # Create thread pool
        with concurrent.futures.ThreadPoolExecutor(max_workers=min(len(images), self.max_batch_size)) as executor:
            # Submit inference tasks
            futures = {}
            
            for camera_id, image in images.items():
                futures[camera_id] = executor.submit(
                    self.infer_image,
                    image=image,
                    model_id=model_id,
                    confidence_threshold=confidence_threshold,
                    camera_id=camera_id,
                    parameters=parameters,
                    retry=retry
                )
            
            # Collect results
            for camera_id, future in futures.items():
                try:
                    results[camera_id] = future.result()
                except Exception as e:
                    logger.error(f"Inference failed for camera {camera_id}: {e}")
                    # Skip this camera
        
        return results
    
    async def infer_images_batch_async(
        self,
        images: Dict[str, np.ndarray],
        model_id: str,
        confidence_threshold: float = 0.5,
        parameters: Optional[Dict[str, str]] = None,
        retry: bool = True
    ) -> Dict[str, InferenceResult]:
        """
        Send multiple images for inference asynchronously.
        
        Args:
            images: Dictionary of images by camera ID.
            model_id: Model ID.
            confidence_threshold: Confidence threshold.
            parameters: Additional parameters.
            retry: Whether to retry on failure.
            
        Returns:
            Dictionary of inference results by camera ID.
            
        Raises:
            ConnectionError: If not connected to Jetson device.
            InferenceError: If inference fails.
        """
        # Check if connected
        if not self.connected:
            if not self.connect():
                raise ConnectionError("Not connected to Jetson device")
        
        # Process images in parallel
        tasks = []
        
        for camera_id, image in images.items():
            tasks.append(
                self.infer_image_async(
                    image=image,
                    model_id=model_id,
                    confidence_threshold=confidence_threshold,
                    camera_id=camera_id,
                    parameters=parameters,
                    retry=retry
                )
            )
        
        # Wait for all tasks to complete
        results_list = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Create results dictionary
        results = {}
        
        for camera_id, result in zip(images.keys(), results_list):
            if isinstance(result, Exception):
                logger.error(f"Inference failed for camera {camera_id}: {result}")
                # Skip this camera
            else:
                results[camera_id] = result
        
        return results
    
    def stream_inference(
        self,
        images_generator: Generator[Tuple[str, np.ndarray], None, None],
        model_id: str,
        confidence_threshold: float = 0.5,
        parameters: Optional[Dict[str, str]] = None,
        retry: bool = True
    ) -> Generator[Tuple[str, InferenceResult], None, None]:
        """
        Stream images for inference.
        
        Args:
            images_generator: Generator yielding (camera_id, image) tuples.
            model_id: Model ID.
            confidence_threshold: Confidence threshold.
            parameters: Additional parameters.
            retry: Whether to retry on failure.
            
        Yields:
            Tuples of (camera_id, inference_result).
            
        Raises:
            ConnectionError: If not connected to Jetson device.
            InferenceError: If inference fails.
        """
        # Check if connected
        if not self.connected:
            if not self.connect():
                raise ConnectionError("Not connected to Jetson device")
        
        # Open stream
        self._open_stream()
        
        try:
            # Process images
            for camera_id, image in images_generator:
                # Create request
                request = self._create_inference_request(
                    image=image,
                    model_id=model_id,
                    confidence_threshold=confidence_threshold,
                    camera_id=camera_id,
                    parameters=parameters
                )
                
                # Send request
                for attempt in range(self.max_retries if retry else 1):
                    try:
                        # Record start time
                        start_time = time.time()
                        
                        # Send request
                        self.stream.write(request)
                        
                        # Get response
                        response = self.stream.read()
                        
                        # Record end time
                        end_time = time.time()
                        inference_time = end_time - start_time
                        
                        # Update metrics
                        self._update_metrics("inference_count", 1)
                        self._update_metrics("inference_time_total", inference_time)
                        
                        with self.metrics_lock:
                            self.metrics["inference_time_min"] = min(self.metrics["inference_time_min"], inference_time)
                            self.metrics["inference_time_max"] = max(self.metrics["inference_time_max"], inference_time)
                        
                        # Create result
                        result = InferenceResult.from_proto(response)
                        
                        # Check status
                        if not result.success:
                            logger.warning(f"Inference failed: {result.status_message}")
                        
                        # Yield result
                        yield camera_id, result
                        
                        # Break retry loop
                        break
                    except grpc.RpcError as e:
                        # Update error metrics
                        self._update_metrics("errors", 1)
                        
                        logger.error(f"Stream inference RPC error: {e}")
                        
                        # Check if should retry
                        if attempt < self.max_retries - 1 and retry:
                            # Calculate retry delay with exponential backoff
                            delay = self.retry_delay * (self.retry_backoff ** attempt)
                            
                            logger.info(f"Retrying stream inference in {delay:.2f}s (attempt {attempt + 1}/{self.max_retries})")
                            
                            # Wait before retry
                            time.sleep(delay)
                            
                            # Reconnect if needed
                            if not self.connected:
                                self.reconnect()
                                
                                # Reopen stream
                                self._open_stream()
                        else:
                            # Raise exception
                            raise InferenceError(f"Stream inference failed after {attempt + 1} attempts: {e}")
                    except Exception as e:
                        # Update error metrics
                        self._update_metrics("errors", 1)
                        
                        logger.error(f"Stream inference error: {e}")
                        
                        # Check if should retry
                        if attempt < self.max_retries - 1 and retry:
                            # Calculate retry delay with exponential backoff
                            delay = self.retry_delay * (self.retry_backoff ** attempt)
                            
                            logger.info(f"Retrying stream inference in {delay:.2f}s (attempt {attempt + 1}/{self.max_retries})")
                            
                            # Wait before retry
                            time.sleep(delay)
                            
                            # Reconnect if needed
                            if not self.connected:
                                self.reconnect()
                                
                                # Reopen stream
                                self._open_stream()
                        else:
                            # Raise exception
                            raise InferenceError(f"Stream inference failed after {attempt + 1} attempts: {e}")
        finally:
            # Close stream
            self._close_stream()
    
    def get_status(self, use_cache: bool = True) -> StatusResult:
        """
        Get system status.
        
        Args:
            use_cache: Whether to use cached status.
            
        Returns:
            Status result.
            
        Raises:
            ConnectionError: If not connected to Jetson device.
            StatusError: If status request fails.
        """
        # Check if can use cache
        if use_cache and self.status_cache and time.time() - self.status_cache_time < self.status_cache_ttl:
            return self.status_cache
        
        # Check if connected
        if not self.connected:
            if not self.connect():
                raise ConnectionError("Not connected to Jetson device")
        
        # Create request
        request = jetson_service_pb2.StatusRequest(
            request_id=self._generate_request_id()
        )
        
        # Send request
        for attempt in range(self.max_retries):
            try:
                # Send request
                response = self.stub.GetStatus(request, timeout=self.timeout)
                
                # Create result
                result = StatusResult.from_proto(response)
                
                # Check status
                if not result.success:
                    logger.warning(f"Status request failed: {result.status_message}")
                
                # Update cache
                self.status_cache = result
                self.status_cache_time = time.time()
                
                return result
            except grpc.RpcError as e:
                # Update error metrics
                self._update_metrics("errors", 1)
                
                logger.error(f"Status request RPC error: {e}")
                
                # Check if should retry
                if attempt < self.max_retries - 1:
                    # Calculate retry delay with exponential backoff
                    delay = self.retry_delay * (self.retry_backoff ** attempt)
                    
                    logger.info(f"Retrying status request in {delay:.2f}s (attempt {attempt + 1}/{self.max_retries})")
                    
                    # Wait before retry
                    time.sleep(delay)
                    
                    # Reconnect if needed
                    if not self.connected:
                        self.reconnect()
                else:
                    # Raise exception
                    raise StatusError(f"Status request failed after {attempt + 1} attempts: {e}")
            except Exception as e:
                # Update error metrics
                self._update_metrics("errors", 1)
                
                logger.error(f"Status request error: {e}")
                
                # Check if should retry
                if attempt < self.max_retries - 1:
                    # Calculate retry delay with exponential backoff
                    delay = self.retry_delay * (self.retry_backoff ** attempt)
                    
                    logger.info(f"Retrying status request in {delay:.2f}s (attempt {attempt + 1}/{self.max_retries})")
                    
                    # Wait before retry
                    time.sleep(delay)
                    
                    # Reconnect if needed
                    if not self.connected:
                        self.reconnect()
                else:
                    # Raise exception
                    raise StatusError(f"Status request failed after {attempt + 1} attempts: {e}")
    
    async def get_status_async(self, use_cache: bool = True) -> StatusResult:
        """
        Get system status asynchronously.
        
        Args:
            use_cache: Whether to use cached status.
            
        Returns:
            Status result.
            
        Raises:
            ConnectionError: If not connected to Jetson device.
            StatusError: If status request fails.
        """
        # Run in thread pool
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            None,
            lambda: self.get_status(use_cache=use_cache)
        )
    
    def update_model(
        self,
        model_id: str,
        model_path: str,
        model_name: Optional[str] = None,
        version: Optional[str] = None,
        model_format: Optional[str] = None,
        config: Optional[Dict[str, str]] = None,
        force: bool = False
    ) -> UpdateModelResult:
        """
        Update model on Jetson device.
        
        Args:
            model_id: Model ID.
            model_path: Path to model file.
            model_name: Model name.
            version: Model version.
            model_format: Model format.
            config: Model configuration.
            force: Whether to force update.
            
        Returns:
            Update model result.
            
        Raises:
            ConnectionError: If not connected to Jetson device.
            ModelError: If model update fails.
        """
        # Check if connected
        if not self.connected:
            if not self.connect():
                raise ConnectionError("Not connected to Jetson device")
        
        # Check if model file exists
        if not os.path.exists(model_path):
            raise ModelError(f"Model file not found: {model_path}")
        
        try:
            # Read model file
            with open(model_path, "rb") as f:
                model_data = f.read()
            
            # Get model format if not specified
            if model_format is None:
                # Try to determine from file extension
                _, ext = os.path.splitext(model_path)
                
                if ext.lower() in (".onnx", ".onnx.gz"):
                    model_format = "onnx"
                elif ext.lower() in (".trt", ".engine"):
                    model_format = "trt"
                elif ext.lower() in (".pt", ".pth"):
                    model_format = "pytorch"
                elif ext.lower() in (".pb", ".tflite"):
                    model_format = "tensorflow"
                else:
                    model_format = "unknown"
            
            # Get compression format
            _, ext = os.path.splitext(model_path)
            
            if ext.lower() in (".gz", ".gzip"):
                compression = "gzip"
            elif ext.lower() in (".zip"):
                compression = "zip"
            elif ext.lower() in (".tar", ".tar.gz", ".tgz"):
                compression = "tar"
            else:
                compression = "none"
            
            # Create request
            request = jetson_service_pb2.UpdateModelRequest(
                request_id=self._generate_request_id(),
                model_id=model_id,
                model_name=model_name or model_id,
                version=version or "1.0.0",
                model_data=model_data,
                model_format=model_format,
                compression=compression,
                config=config or {},
                force=force
            )
            
            # Send request
            for attempt in range(self.max_retries):
                try:
                    # Send request
                    response = self.stub.UpdateModel(request, timeout=self.timeout * 2)  # Longer timeout for model update
                    
                    # Create result
                    result = UpdateModelResult.from_proto(response)
                    
                    # Check status
                    if not result.success:
                        logger.warning(f"Model update failed: {result.status_message}")
                    
                    # Clear model cache
                    self.model_cache = {}
                    
                    return result
                except grpc.RpcError as e:
                    # Update error metrics
                    self._update_metrics("errors", 1)
                    
                    logger.error(f"Model update RPC error: {e}")
                    
                    # Check if should retry
                    if attempt < self.max_retries - 1:
                        # Calculate retry delay with exponential backoff
                        delay = self.retry_delay * (self.retry_backoff ** attempt)
                        
                        logger.info(f"Retrying model update in {delay:.2f}s (attempt {attempt + 1}/{self.max_retries})")
                        
                        # Wait before retry
                        time.sleep(delay)
                        
                        # Reconnect if needed
                        if not self.connected:
                            self.reconnect()
                    else:
                        # Raise exception
                        raise ModelError(f"Model update failed after {attempt + 1} attempts: {e}")
                except Exception as e:
                    # Update error metrics
                    self._update_metrics("errors", 1)
                    
                    logger.error(f"Model update error: {e}")
                    
                    # Check if should retry
                    if attempt < self.max_retries - 1:
                        # Calculate retry delay with exponential backoff
                        delay = self.retry_delay * (self.retry_backoff ** attempt)
                        
                        logger.info(f"Retrying model update in {delay:.2f}s (attempt {attempt + 1}/{self.max_retries})")
                        
                        # Wait before retry
                        time.sleep(delay)
                        
                        # Reconnect if needed
                        if not self.connected:
                            self.reconnect()
                    else:
                        # Raise exception
                        raise ModelError(f"Model update failed after {attempt + 1} attempts: {e}")
        except ModelError:
            raise
        except Exception as e:
            raise ModelError(f"Failed to update model: {e}")
    
    async def update_model_async(
        self,
        model_id: str,
        model_path: str,
        model_name: Optional[str] = None,
        version: Optional[str] = None,
        model_format: Optional[str] = None,
        config: Optional[Dict[str, str]] = None,
        force: bool = False
    ) -> UpdateModelResult:
        """
        Update model on Jetson device asynchronously.
        
        Args:
            model_id: Model ID.
            model_path: Path to model file.
            model_name: Model name.
            version: Model version.
            model_format: Model format.
            config: Model configuration.
            force: Whether to force update.
            
        Returns:
            Update model result.
            
        Raises:
            ConnectionError: If not connected to Jetson device.
            ModelError: If model update fails.
        """
        # Run in thread pool
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            None,
            lambda: self.update_model(
                model_id=model_id,
                model_path=model_path,
                model_name=model_name,
                version=version,
                model_format=model_format,
                config=config,
                force=force
            )
        )
    
    def get_models(self, use_cache: bool = True) -> GetModelsResult:
        """
        Get available models.
        
        Args:
            use_cache: Whether to use cached models.
            
        Returns:
            Get models result.
            
        Raises:
            ConnectionError: If not connected to Jetson device.
            ModelError: If get models request fails.
        """
        # Check if can use cache
        if use_cache and self.model_cache:
            # Create result from cache
            return GetModelsResult(
                request_id=self._generate_request_id(),
                model_statuses=list(self.model_cache.values()),
                status_code=0,
                status_message="Success (cached)"
            )
        
        # Check if connected
        if not self.connected:
            if not self.connect():
                raise ConnectionError("Not connected to Jetson device")
        
        # Create request
        request = jetson_service_pb2.GetModelsRequest(
            request_id=self._generate_request_id()
        )
        
        # Send request
        for attempt in range(self.max_retries):
            try:
                # Send request
                response = self.stub.GetModels(request, timeout=self.timeout)
                
                # Create result
                result = GetModelsResult.from_proto(response)
                
                # Check status
                if not result.success:
                    logger.warning(f"Get models request failed: {result.status_message}")
                
                # Update cache
                self.model_cache = {model.model_id: model for model in result.model_statuses}
                
                return result
            except grpc.RpcError as e:
                # Update error metrics
                self._update_metrics("errors", 1)
                
                logger.error(f"Get models RPC error: {e}")
                
                # Check if should retry
                if attempt < self.max_retries - 1:
                    # Calculate retry delay with exponential backoff
                    delay = self.retry_delay * (self.retry_backoff ** attempt)
                    
                    logger.info(f"Retrying get models in {delay:.2f}s (attempt {attempt + 1}/{self.max_retries})")
                    
                    # Wait before retry
                    time.sleep(delay)
                    
                    # Reconnect if needed
                    if not self.connected:
                        self.reconnect()
                else:
                    # Raise exception
                    raise ModelError(f"Get models failed after {attempt + 1} attempts: {e}")
            except Exception as e:
                # Update error metrics
                self._update_metrics("errors", 1)
                
                logger.error(f"Get models error: {e}")
                
                # Check if should retry
                if attempt < self.max_retries - 1:
                    # Calculate retry delay with exponential backoff
                    delay = self.retry_delay * (self.retry_backoff ** attempt)
                    
                    logger.info(f"Retrying get models in {delay:.2f}s (attempt {attempt + 1}/{self.max_retries})")
                    
                    # Wait before retry
                    time.sleep(delay)
                    
                    # Reconnect if needed
                    if not self.connected:
                        self.reconnect()
                else:
                    # Raise exception
                    raise ModelError(f"Get models failed after {attempt + 1} attempts: {e}")
    
    async def get_models_async(self, use_cache: bool = True) -> GetModelsResult:
        """
        Get available models asynchronously.
        
        Args:
            use_cache: Whether to use cached models.
            
        Returns:
            Get models result.
            
        Raises:
            ConnectionError: If not connected to Jetson device.
            ModelError: If get models request fails.
        """
        # Run in thread pool
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            None,
            lambda: self.get_models(use_cache=use_cache)
        )
    
    def set_model_parameters(
        self,
        model_id: str,
        parameters: Dict[str, str]
    ) -> SetModelParametersResult:
        """
        Set model parameters.
        
        Args:
            model_id: Model ID.
            parameters: Model parameters.
            
        Returns:
            Set model parameters result.
            
        Raises:
            ConnectionError: If not connected to Jetson device.
            ModelError: If set model parameters request fails.
        """
        # Check if connected
        if not self.connected:
            if not self.connect():
                raise ConnectionError("Not connected to Jetson device")
        
        # Create request
        request = jetson_service_pb2.SetModelParametersRequest(
            request_id=self._generate_request_id(),
            model_id=model_id,
            parameters=parameters
        )
        
        # Send request
        for attempt in range(self.max_retries):
            try:
                # Send request
                response = self.stub.SetModelParameters(request, timeout=self.timeout)
                
                # Create result
                result = SetModelParametersResult.from_proto(response)
                
                # Check status
                if not result.success:
                    logger.warning(f"Set model parameters failed: {result.status_message}")
                
                # Clear model cache
                self.model_cache = {}
                
                return result
            except grpc.RpcError as e:
                # Update error metrics
                self._update_metrics("errors", 1)
                
                logger.error(f"Set model parameters RPC error: {e}")
                
                # Check if should retry
                if attempt < self.max_retries - 1:
                    # Calculate retry delay with exponential backoff
                    delay = self.retry_delay * (self.retry_backoff ** attempt)
                    
                    logger.info(f"Retrying set model parameters in {delay:.2f}s (attempt {attempt + 1}/{self.max_retries})")
                    
                    # Wait before retry
                    time.sleep(delay)
                    
                    # Reconnect if needed
                    if not self.connected:
                        self.reconnect()
                else:
                    # Raise exception
                    raise ModelError(f"Set model parameters failed after {attempt + 1} attempts: {e}")
            except Exception as e:
                # Update error metrics
                self._update_metrics("errors", 1)
                
                logger.error(f"Set model parameters error: {e}")
                
                # Check if should retry
                if attempt < self.max_retries - 1:
                    # Calculate retry delay with exponential backoff
                    delay = self.retry_delay * (self.retry_backoff ** attempt)
                    
                    logger.info(f"Retrying set model parameters in {delay:.2f}s (attempt {attempt + 1}/{self.max_retries})")
                    
                    # Wait before retry
                    time.sleep(delay)
                    
                    # Reconnect if needed
                    if not self.connected:
                        self.reconnect()
                else:
                    # Raise exception
                    raise ModelError(f"Set model parameters failed after {attempt + 1} attempts: {e}")
    
    async def set_model_parameters_async(
        self,
        model_id: str,
        parameters: Dict[str, str]
    ) -> SetModelParametersResult:
        """
        Set model parameters asynchronously.
        
        Args:
            model_id: Model ID.
            parameters: Model parameters.
            
        Returns:
            Set model parameters result.
            
        Raises:
            ConnectionError: If not connected to Jetson device.
            ModelError: If set model parameters request fails.
        """
        # Run in thread pool
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            None,
            lambda: self.set_model_parameters(
                model_id=model_id,
                parameters=parameters
            )
        )
    
    def get_metrics(self) -> Dict[str, Any]:
        """
        Get client metrics.
        
        Returns:
            Dictionary of metrics.
        """
        with self.metrics_lock:
            # Calculate average inference time
            if self.metrics["inference_count"] > 0:
                avg_inference_time = self.metrics["inference_time_total"] / self.metrics["inference_count"]
            else:
                avg_inference_time = 0.0
            
            # Create metrics dictionary
            metrics = self.metrics.copy()
            metrics["avg_inference_time"] = avg_inference_time
            
            return metrics
    
    def reset_metrics(self) -> None:
        """Reset client metrics."""
        with self.metrics_lock:
            self.metrics = {
                "inference_count": 0,
                "inference_time_total": 0.0,
                "inference_time_min": float('inf'),
                "inference_time_max": 0.0,
                "connection_attempts": 0,
                "connection_failures": 0,
                "reconnections": 0,
                "errors": 0
            }


# Singleton instance
_jetson_client: Optional[JetsonClient] = None


def get_jetson_client() -> JetsonClient:
    """
    Get the singleton JetsonClient instance.
    
    Returns:
        JetsonClient instance.
    """
    global _jetson_client
    if _jetson_client is None:
        _jetson_client = JetsonClient()
    return _jetson_client


if __name__ == "__main__":
    # Setup logging for standalone execution
    logging.basicConfig(level=logging.INFO)
    
    # Example usage
    client = get_jetson_client()
    
    try:
        # Connect to Jetson device
        if client.connect():
            logger.info("Connected to Jetson device")
            
            # Get system status
            status = client.get_status()
            logger.info(f"System status: CPU {status.system_status.cpu_utilization:.1f}%, "
                        f"Memory {status.system_status.memory_usage:.1f}%, "
                        f"GPU {status.system_status.gpu_status.utilization:.1f}%")
            
            # Get available models
            models = client.get_models()
            logger.info(f"Available models: {len(models.model_statuses)}")
            
            for model in models.model_statuses:
                logger.info(f"  - {model.model_name} (ID: {model.model_id}, Version: {model.version})")
            
            # Disconnect
            client.disconnect()
            logger.info("Disconnected from Jetson device")
        else:
            logger.error("Failed to connect to Jetson device")
    except Exception as e:
        logger.error(f"Error in example: {e}")
