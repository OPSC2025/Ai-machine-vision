"""
Enhanced model manager for OPSC Sandwich Quality Inspection System.
Provides comprehensive functionality for model management, training, and inference.

Version: 2.0.0
Last Updated: 2025-04-22
"""

import os
import sys
import time
import json
import logging
import numpy as np
import cv2
from typing import Dict, List, Optional, Tuple, Union, Any, BinaryIO
from dataclasses import dataclass, field
import threading
import queue
import sqlite3
from pathlib import Path
import datetime
import uuid

# Import Roboflow client
from models.roboflow.roboflow_client import RoboflowClient, ModelVersion, Dataset, TrainingJob, ImageAnnotation
from models.roboflow.sandwich_defect_model import DetectionResult, SandwichDefectModel

# Setup logging
logger = logging.getLogger(__name__)

@dataclass
class ModelConfig:
    """Model configuration data class."""
    model_id: str
    name: str
    model_type: str
    workspace: str
    project: str
    version_id: int
    confidence_threshold: float
    overlap_threshold: float
    active: bool = True
    created_at: str = field(default_factory=lambda: datetime.datetime.now().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.datetime.now().isoformat())
    metrics: Dict[str, Any] = field(default_factory=dict)
    parameters: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "model_id": self.model_id,
            "name": self.name,
            "model_type": self.model_type,
            "workspace": self.workspace,
            "project": self.project,
            "version_id": self.version_id,
            "confidence_threshold": self.confidence_threshold,
            "overlap_threshold": self.overlap_threshold,
            "active": self.active,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "metrics": self.metrics,
            "parameters": self.parameters
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ModelConfig':
        """Create from dictionary."""
        return cls(
            model_id=data["model_id"],
            name=data["name"],
            model_type=data["model_type"],
            workspace=data["workspace"],
            project=data["project"],
            version_id=data["version_id"],
            confidence_threshold=data["confidence_threshold"],
            overlap_threshold=data["overlap_threshold"],
            active=data.get("active", True),
            created_at=data.get("created_at", datetime.datetime.now().isoformat()),
            updated_at=data.get("updated_at", datetime.datetime.now().isoformat()),
            metrics=data.get("metrics", {}),
            parameters=data.get("parameters", {})
        )


@dataclass
class TrainingConfig:
    """Training configuration data class."""
    config_id: str
    name: str
    dataset_id: str
    model_type: str
    epochs: int
    batch_size: int
    learning_rate: float
    augmentation: bool = True
    created_at: str = field(default_factory=lambda: datetime.datetime.now().isoformat())
    parameters: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "config_id": self.config_id,
            "name": self.name,
            "dataset_id": self.dataset_id,
            "model_type": self.model_type,
            "epochs": self.epochs,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "augmentation": self.augmentation,
            "created_at": self.created_at,
            "parameters": self.parameters
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'TrainingConfig':
        """Create from dictionary."""
        return cls(
            config_id=data["config_id"],
            name=data["name"],
            dataset_id=data["dataset_id"],
            model_type=data["model_type"],
            epochs=data["epochs"],
            batch_size=data["batch_size"],
            learning_rate=data["learning_rate"],
            augmentation=data.get("augmentation", True),
            created_at=data.get("created_at", datetime.datetime.now().isoformat()),
            parameters=data.get("parameters", {})
        )


@dataclass
class InferenceResult:
    """Inference result data class."""
    result_id: str
    model_id: str
    image_id: str
    timestamp: str
    detections: List[DetectionResult]
    inference_time: float
    has_defect: bool
    defect_types: List[str]
    confidence: float
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "result_id": self.result_id,
            "model_id": self.model_id,
            "image_id": self.image_id,
            "timestamp": self.timestamp,
            "detections": [d.to_dict() for d in self.detections],
            "inference_time": self.inference_time,
            "has_defect": self.has_defect,
            "defect_types": self.defect_types,
            "confidence": self.confidence
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'InferenceResult':
        """Create from dictionary."""
        return cls(
            result_id=data["result_id"],
            model_id=data["model_id"],
            image_id=data["image_id"],
            timestamp=data["timestamp"],
            detections=[DetectionResult.from_dict(d) for d in data["detections"]],
            inference_time=data["inference_time"],
            has_defect=data["has_defect"],
            defect_types=data["defect_types"],
            confidence=data["confidence"]
        )


class ModelManager:
    """
    Enhanced model manager for OPSC Sandwich Quality Inspection System.
    
    Provides comprehensive functionality for model management, training, and inference.
    """
    
    def __init__(self, db_path: str, models_dir: str, api_key: Optional[str] = None):
        """
        Initialize model manager.
        
        Args:
            db_path: Path to SQLite database file
            models_dir: Path to models directory
            api_key: Roboflow API key (if None, will look for ROBOFLOW_API_KEY env var)
        """
        self.db_path = db_path
        self.models_dir = models_dir
        self.api_key = api_key or os.environ.get("ROBOFLOW_API_KEY")
        
        # Create models directory if it doesn't exist
        os.makedirs(self.models_dir, exist_ok=True)
        
        # Initialize database
        self._init_database()
        
        # Initialize Roboflow client
        self.roboflow_client = RoboflowClient(api_key=self.api_key)
        
        # Initialize models cache
        self.models_cache = {}
        self.models_cache_lock = threading.Lock()
        
        # Load active models
        self._load_active_models()
        
        # Initialize inference queue and worker thread
        self.inference_queue = queue.Queue()
        self.inference_thread = None
        self.inference_thread_running = False
        self.inference_callbacks = {}
        
        # Start inference thread
        self._start_inference_thread()
        
        logger.info("Initialized model manager")
    
    def _init_database(self):
        """Initialize database tables."""
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Create models table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS models (
                    model_id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    model_type TEXT NOT NULL,
                    workspace TEXT NOT NULL,
                    project TEXT NOT NULL,
                    version_id INTEGER NOT NULL,
                    confidence_threshold REAL NOT NULL,
                    overlap_threshold REAL NOT NULL,
                    active INTEGER NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    metrics TEXT,
                    parameters TEXT
                )
            """)
            
            # Create training_configs table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS training_configs (
                    config_id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    dataset_id TEXT NOT NULL,
                    model_type TEXT NOT NULL,
                    epochs INTEGER NOT NULL,
                    batch_size INTEGER NOT NULL,
                    learning_rate REAL NOT NULL,
                    augmentation INTEGER NOT NULL,
                    created_at TEXT NOT NULL,
                    parameters TEXT
                )
            """)
            
            # Create training_jobs table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS training_jobs (
                    job_id TEXT PRIMARY KEY,
                    config_id TEXT NOT NULL,
                    status TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    completed_at TEXT,
                    progress REAL NOT NULL,
                    version_id INTEGER,
                    metrics TEXT,
                    FOREIGN KEY (config_id) REFERENCES training_configs (config_id)
                )
            """)
            
            # Create inference_results table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS inference_results (
                    result_id TEXT PRIMARY KEY,
                    model_id TEXT NOT NULL,
                    image_id TEXT NOT NULL,
                    timestamp TEXT NOT NULL,
                    detections TEXT NOT NULL,
                    inference_time REAL NOT NULL,
                    has_defect INTEGER NOT NULL,
                    defect_types TEXT NOT NULL,
                    confidence REAL NOT NULL,
                    FOREIGN KEY (model_id) REFERENCES models (model_id)
                )
            """)
            
            # Create datasets table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS datasets (
                    dataset_id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    image_count INTEGER NOT NULL,
                    annotation_count INTEGER NOT NULL,
                    split TEXT NOT NULL
                )
            """)
            
            # Commit changes
            conn.commit()
            
            # Close connection
            conn.close()
            
            logger.info("Initialized model database tables")
        except Exception as e:
            logger.error(f"Error initializing database: {e}")
            raise
    
    def _load_active_models(self):
        """Load active models from database."""
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Get active models
            cursor.execute("SELECT * FROM models WHERE active = 1")
            rows = cursor.fetchall()
            
            # Close connection
            conn.close()
            
            # Load models
            for row in rows:
                model_config = ModelConfig(
                    model_id=row["model_id"],
                    name=row["name"],
                    model_type=row["model_type"],
                    workspace=row["workspace"],
                    project=row["project"],
                    version_id=row["version_id"],
                    confidence_threshold=row["confidence_threshold"],
                    overlap_threshold=row["overlap_threshold"],
                    active=bool(row["active"]),
                    created_at=row["created_at"],
                    updated_at=row["updated_at"],
                    metrics=json.loads(row["metrics"]) if row["metrics"] else {},
                    parameters=json.loads(row["parameters"]) if row["parameters"] else {}
                )
                
                # Initialize model
                self._init_model(model_config)
            
            logger.info(f"Loaded {len(self.models_cache)} active models")
        except Exception as e:
            logger.error(f"Error loading active models: {e}")
    
    def _init_model(self, model_config: ModelConfig):
        """
        Initialize model from configuration.
        
        Args:
            model_config: Model configuration
        """
        try:
            # Create model instance
            model = SandwichDefectModel(
                workspace=model_config.workspace,
                project=model_config.project,
                version=model_config.version_id,
                api_key=self.api_key,
                model_format="tensorrt",
                local_inference=True,
                confidence_threshold=model_config.confidence_threshold,
                overlap_threshold=model_config.overlap_threshold
            )
            
            # Add to cache
            with self.models_cache_lock:
                self.models_cache[model_config.model_id] = {
                    "config": model_config,
                    "model": model
                }
            
            logger.info(f"Initialized model {model_config.name} (ID: {model_config.model_id})")
        except Exception as e:
            logger.error(f"Error initializing model {model_config.name} (ID: {model_config.model_id}): {e}")
    
    def _start_inference_thread(self):
        """Start inference worker thread."""
        if self.inference_thread is not None and self.inference_thread.is_alive():
            logger.warning("Inference thread is already running")
            return
        
        self.inference_thread_running = True
        self.inference_thread = threading.Thread(target=self._inference_worker, daemon=True)
        self.inference_thread.start()
        
        logger.info("Started inference worker thread")
    
    def _inference_worker(self):
        """Background worker thread for processing inference queue."""
        logger.info("Inference worker thread started")
        
        while self.inference_thread_running:
            try:
                # Get item from queue with timeout
                try:
                    item = self.inference_queue.get(timeout=1.0)
                except queue.Empty:
                    continue
                
                # Process item
                try:
                    model_id = item["model_id"]
                    image = item["image"]
                    image_id = item["image_id"]
                    callback_id = item.get("callback_id")
                    
                    # Get model
                    with self.models_cache_lock:
                        model_data = self.models_cache.get(model_id)
                    
                    if model_data is None:
                        logger.error(f"Model {model_id} not found in cache")
                        continue
                    
                    model = model_data["model"]
                    config = model_data["config"]
                    
                    # Perform inference
                    start_time = time.time()
                    detections = model.predict(image)
                    inference_time = time.time() - start_time
                    
                    # Create result
                    has_defect = len(detections) > 0
                    defect_types = list(set(d.defect_type for d in detections))
                    confidence = max([d.confidence for d in detections]) if detections else 0.0
                    
                    result = InferenceResult(
                        result_id=str(uuid.uuid4()),
                        model_id=model_id,
                        image_id=image_id,
                        timestamp=datetime.datetime.now().isoformat(),
                        detections=detections,
                        inference_time=inference_time,
                        has_defect=has_defect,
                        defect_types=defect_types,
                        confidence=confidence
                    )
                    
                    # Save result to database
                    self._save_inference_result(result)
                    
                    # Call callback if provided
                    if callback_id and callback_id in self.inference_callbacks:
                        callback = self.inference_callbacks.pop(callback_id)
                        callback(result)
                    
                    logger.debug(f"Processed inference for model {model_id}, image {image_id}")
                except Exception as e:
                    logger.error(f"Error processing inference: {e}")
                
                # Mark item as done
                self.inference_queue.task_done()
            except Exception as e:
                logger.error(f"Error in inference worker thread: {e}")
        
        logger.info("Inference worker thread stopped")
    
    def _save_inference_result(self, result: InferenceResult):
        """
        Save inference result to database.
        
        Args:
            result: Inference result
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Insert result
            cursor.execute("""
                INSERT INTO inference_results (
                    result_id, model_id, image_id, timestamp, detections, inference_time,
                    has_defect, defect_types, confidence
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                result.result_id,
                result.model_id,
                result.image_id,
                result.timestamp,
                json.dumps([d.to_dict() for d in result.detections]),
                result.inference_time,
                int(result.has_defect),
                json.dumps(result.defect_types),
                result.confidence
            ))
            
            # Commit changes
            conn.commit()
            
            # Close connection
            conn.close()
        except Exception as e:
            logger.error(f"Error saving inference result: {e}")
    
    # Model Management
    
    def create_model(self, name: str, workspace: str, project: str, version_id: int,
                    confidence_threshold: float = 0.7, overlap_threshold: float = 0.5,
                    model_type: str = "yolov8", parameters: Dict[str, Any] = None) -> Optional[ModelConfig]:
        """
        Create new model configuration.
        
        Args:
            name: Model name
            workspace: Roboflow workspace
            project: Roboflow project
            version_id: Roboflow model version
            confidence_threshold: Confidence threshold for detections
            overlap_threshold: Overlap threshold for NMS
            model_type: Model type (yolov8, fasterrcnn, etc.)
            parameters: Additional parameters
        
        Returns:
            Model configuration if successful, None otherwise
        """
        try:
            # Create model ID
            model_id = str(uuid.uuid4())
            
            # Create model configuration
            model_config = ModelConfig(
                model_id=model_id,
                name=name,
                model_type=model_type,
                workspace=workspace,
                project=project,
                version_id=version_id,
                confidence_threshold=confidence_threshold,
                overlap_threshold=overlap_threshold,
                active=True,
                created_at=datetime.datetime.now().isoformat(),
                updated_at=datetime.datetime.now().isoformat(),
                parameters=parameters or {}
            )
            
            # Get model metrics
            try:
                metrics = self.roboflow_client.evaluate_model(version_id)
                model_config.metrics = metrics
            except Exception as e:
                logger.warning(f"Error getting model metrics: {e}")
            
            # Save to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute("""
                INSERT INTO models (
                    model_id, name, model_type, workspace, project, version_id,
                    confidence_threshold, overlap_threshold, active, created_at, updated_at,
                    metrics, parameters
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                model_config.model_id,
                model_config.name,
                model_config.model_type,
                model_config.workspace,
                model_config.project,
                model_config.version_id,
                model_config.confidence_threshold,
                model_config.overlap_threshold,
                int(model_config.active),
                model_config.created_at,
                model_config.updated_at,
                json.dumps(model_config.metrics),
                json.dumps(model_config.parameters)
            ))
            
            conn.commit()
            conn.close()
            
            # Initialize model
            self._init_model(model_config)
            
            logger.info(f"Created model {name} (ID: {model_id})")
            return model_config
        except Exception as e:
            logger.error(f"Error creating model: {e}")
            return None
    
    def get_model(self, model_id: str) -> Optional[ModelConfig]:
        """
        Get model configuration.
        
        Args:
            model_id: Model ID
        
        Returns:
            Model configuration if found, None otherwise
        """
        try:
            # Check cache
            with self.models_cache_lock:
                if model_id in self.models_cache:
                    return self.models_cache[model_id]["config"]
            
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Get model
            cursor.execute("SELECT * FROM models WHERE model_id = ?", (model_id,))
            row = cursor.fetchone()
            
            # Close connection
            conn.close()
            
            if row is None:
                return None
            
            # Create model configuration
            model_config = ModelConfig(
                model_id=row["model_id"],
                name=row["name"],
                model_type=row["model_type"],
                workspace=row["workspace"],
                project=row["project"],
                version_id=row["version_id"],
                confidence_threshold=row["confidence_threshold"],
                overlap_threshold=row["overlap_threshold"],
                active=bool(row["active"]),
                created_at=row["created_at"],
                updated_at=row["updated_at"],
                metrics=json.loads(row["metrics"]) if row["metrics"] else {},
                parameters=json.loads(row["parameters"]) if row["parameters"] else {}
            )
            
            return model_config
        except Exception as e:
            logger.error(f"Error getting model {model_id}: {e}")
            return None
    
    def get_models(self, active_only: bool = False) -> List[ModelConfig]:
        """
        Get all model configurations.
        
        Args:
            active_only: Whether to return only active models
        
        Returns:
            List of model configurations
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Get models
            if active_only:
                cursor.execute("SELECT * FROM models WHERE active = 1")
            else:
                cursor.execute("SELECT * FROM models")
            
            rows = cursor.fetchall()
            
            # Close connection
            conn.close()
            
            # Create model configurations
            models = []
            for row in rows:
                model_config = ModelConfig(
                    model_id=row["model_id"],
                    name=row["name"],
                    model_type=row["model_type"],
                    workspace=row["workspace"],
                    project=row["project"],
                    version_id=row["version_id"],
                    confidence_threshold=row["confidence_threshold"],
                    overlap_threshold=row["overlap_threshold"],
                    active=bool(row["active"]),
                    created_at=row["created_at"],
                    updated_at=row["updated_at"],
                    metrics=json.loads(row["metrics"]) if row["metrics"] else {},
                    parameters=json.loads(row["parameters"]) if row["parameters"] else {}
                )
                models.append(model_config)
            
            return models
        except Exception as e:
            logger.error(f"Error getting models: {e}")
            return []
    
    def update_model(self, model_id: str, name: Optional[str] = None, active: Optional[bool] = None,
                    confidence_threshold: Optional[float] = None, overlap_threshold: Optional[float] = None,
                    parameters: Optional[Dict[str, Any]] = None) -> Optional[ModelConfig]:
        """
        Update model configuration.
        
        Args:
            model_id: Model ID
            name: New model name
            active: New active status
            confidence_threshold: New confidence threshold
            overlap_threshold: New overlap threshold
            parameters: New parameters
        
        Returns:
            Updated model configuration if successful, None otherwise
        """
        try:
            # Get current model configuration
            model_config = self.get_model(model_id)
            if model_config is None:
                logger.error(f"Model {model_id} not found")
                return None
            
            # Update fields
            if name is not None:
                model_config.name = name
            if active is not None:
                model_config.active = active
            if confidence_threshold is not None:
                model_config.confidence_threshold = confidence_threshold
            if overlap_threshold is not None:
                model_config.overlap_threshold = overlap_threshold
            if parameters is not None:
                model_config.parameters = parameters
            
            # Update timestamp
            model_config.updated_at = datetime.datetime.now().isoformat()
            
            # Save to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute("""
                UPDATE models
                SET name = ?, active = ?, confidence_threshold = ?, overlap_threshold = ?,
                    updated_at = ?, parameters = ?
                WHERE model_id = ?
            """, (
                model_config.name,
                int(model_config.active),
                model_config.confidence_threshold,
                model_config.overlap_threshold,
                model_config.updated_at,
                json.dumps(model_config.parameters),
                model_config.model_id
            ))
            
            conn.commit()
            conn.close()
            
            # Update cache
            with self.models_cache_lock:
                if model_id in self.models_cache:
                    # Update configuration
                    self.models_cache[model_id]["config"] = model_config
                    
                    # Update model parameters
                    model = self.models_cache[model_id]["model"]
                    model.confidence_threshold = model_config.confidence_threshold
                    model.overlap_threshold = model_config.overlap_threshold
                
                # If active status changed, update cache
                if active is not None:
                    if active and model_id not in self.models_cache:
                        # Initialize model
                        self._init_model(model_config)
                    elif not active and model_id in self.models_cache:
                        # Remove from cache
                        del self.models_cache[model_id]
            
            logger.info(f"Updated model {model_id}")
            return model_config
        except Exception as e:
            logger.error(f"Error updating model {model_id}: {e}")
            return None
    
    def delete_model(self, model_id: str) -> bool:
        """
        Delete model configuration.
        
        Args:
            model_id: Model ID
        
        Returns:
            True if successful, False otherwise
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Delete model
            cursor.execute("DELETE FROM models WHERE model_id = ?", (model_id,))
            
            # Commit changes
            conn.commit()
            
            # Close connection
            conn.close()
            
            # Remove from cache
            with self.models_cache_lock:
                if model_id in self.models_cache:
                    del self.models_cache[model_id]
            
            logger.info(f"Deleted model {model_id}")
            return True
        except Exception as e:
            logger.error(f"Error deleting model {model_id}: {e}")
            return False
    
    # Dataset Management
    
    def sync_datasets(self) -> List[Dataset]:
        """
        Synchronize datasets from Roboflow.
        
        Returns:
            List of datasets
        """
        try:
            # Get datasets from Roboflow
            datasets = self.roboflow_client.get_datasets(force_refresh=True)
            
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Update database
            for dataset in datasets:
                cursor.execute("""
                    INSERT OR REPLACE INTO datasets (
                        dataset_id, name, created_at, image_count, annotation_count, split
                    )
                    VALUES (?, ?, ?, ?, ?, ?)
                """, (
                    dataset.dataset_id,
                    dataset.name,
                    dataset.created_at,
                    dataset.image_count,
                    dataset.annotation_count,
                    json.dumps(dataset.split)
                ))
            
            # Commit changes
            conn.commit()
            
            # Close connection
            conn.close()
            
            logger.info(f"Synchronized {len(datasets)} datasets from Roboflow")
            return datasets
        except Exception as e:
            logger.error(f"Error synchronizing datasets: {e}")
            return []
    
    def get_datasets(self) -> List[Dataset]:
        """
        Get all datasets.
        
        Returns:
            List of datasets
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Get datasets
            cursor.execute("SELECT * FROM datasets")
            rows = cursor.fetchall()
            
            # Close connection
            conn.close()
            
            # Create dataset objects
            datasets = []
            for row in rows:
                dataset = Dataset(
                    dataset_id=row["dataset_id"],
                    name=row["name"],
                    created_at=row["created_at"],
                    image_count=row["image_count"],
                    annotation_count=row["annotation_count"],
                    split=json.loads(row["split"])
                )
                datasets.append(dataset)
            
            return datasets
        except Exception as e:
            logger.error(f"Error getting datasets: {e}")
            return []
    
    def create_dataset(self, name: str) -> Optional[Dataset]:
        """
        Create new dataset in Roboflow.
        
        Args:
            name: Dataset name
        
        Returns:
            Created dataset if successful, None otherwise
        """
        try:
            # Create dataset in Roboflow
            dataset = self.roboflow_client.create_dataset(name)
            if dataset is None:
                return None
            
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Insert dataset
            cursor.execute("""
                INSERT INTO datasets (
                    dataset_id, name, created_at, image_count, annotation_count, split
                )
                VALUES (?, ?, ?, ?, ?, ?)
            """, (
                dataset.dataset_id,
                dataset.name,
                dataset.created_at,
                dataset.image_count,
                dataset.annotation_count,
                json.dumps(dataset.split)
            ))
            
            # Commit changes
            conn.commit()
            
            # Close connection
            conn.close()
            
            logger.info(f"Created dataset {name} with ID {dataset.dataset_id}")
            return dataset
        except Exception as e:
            logger.error(f"Error creating dataset {name}: {e}")
            return None
    
    def upload_images_to_dataset(self, dataset_id: str, image_dir: str, annotation_dir: Optional[str] = None,
                               split: str = "train") -> Tuple[int, int]:
        """
        Upload images to dataset.
        
        Args:
            dataset_id: Dataset ID
            image_dir: Directory containing images
            annotation_dir: Directory containing annotations (optional)
            split: Dataset split (train, valid, test)
        
        Returns:
            Tuple of (success_count, failure_count)
        """
        try:
            # Upload images
            success_count, failure_count = self.roboflow_client.batch_upload_images(
                dataset_id, image_dir, annotation_dir, split
            )
            
            # Update dataset in database
            self.sync_datasets()
            
            logger.info(f"Uploaded {success_count} images to dataset {dataset_id}")
            return (success_count, failure_count)
        except Exception as e:
            logger.error(f"Error uploading images to dataset {dataset_id}: {e}")
            return (0, 0)
    
    # Training Management
    
    def create_training_config(self, name: str, dataset_id: str, model_type: str = "yolov8",
                             epochs: int = 100, batch_size: int = 16, learning_rate: float = 0.001,
                             augmentation: bool = True, parameters: Dict[str, Any] = None) -> Optional[TrainingConfig]:
        """
        Create training configuration.
        
        Args:
            name: Configuration name
            dataset_id: Dataset ID
            model_type: Model type (yolov8, fasterrcnn, etc.)
            epochs: Number of training epochs
            batch_size: Training batch size
            learning_rate: Training learning rate
            augmentation: Whether to use data augmentation
            parameters: Additional parameters
        
        Returns:
            Training configuration if successful, None otherwise
        """
        try:
            # Create config ID
            config_id = str(uuid.uuid4())
            
            # Create training configuration
            training_config = TrainingConfig(
                config_id=config_id,
                name=name,
                dataset_id=dataset_id,
                model_type=model_type,
                epochs=epochs,
                batch_size=batch_size,
                learning_rate=learning_rate,
                augmentation=augmentation,
                created_at=datetime.datetime.now().isoformat(),
                parameters=parameters or {}
            )
            
            # Save to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute("""
                INSERT INTO training_configs (
                    config_id, name, dataset_id, model_type, epochs, batch_size,
                    learning_rate, augmentation, created_at, parameters
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                training_config.config_id,
                training_config.name,
                training_config.dataset_id,
                training_config.model_type,
                training_config.epochs,
                training_config.batch_size,
                training_config.learning_rate,
                int(training_config.augmentation),
                training_config.created_at,
                json.dumps(training_config.parameters)
            ))
            
            conn.commit()
            conn.close()
            
            logger.info(f"Created training configuration {name} (ID: {config_id})")
            return training_config
        except Exception as e:
            logger.error(f"Error creating training configuration: {e}")
            return None
    
    def get_training_configs(self) -> List[TrainingConfig]:
        """
        Get all training configurations.
        
        Returns:
            List of training configurations
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Get configs
            cursor.execute("SELECT * FROM training_configs")
            rows = cursor.fetchall()
            
            # Close connection
            conn.close()
            
            # Create config objects
            configs = []
            for row in rows:
                config = TrainingConfig(
                    config_id=row["config_id"],
                    name=row["name"],
                    dataset_id=row["dataset_id"],
                    model_type=row["model_type"],
                    epochs=row["epochs"],
                    batch_size=row["batch_size"],
                    learning_rate=row["learning_rate"],
                    augmentation=bool(row["augmentation"]),
                    created_at=row["created_at"],
                    parameters=json.loads(row["parameters"]) if row["parameters"] else {}
                )
                configs.append(config)
            
            return configs
        except Exception as e:
            logger.error(f"Error getting training configurations: {e}")
            return []
    
    def start_training(self, config_id: str) -> Optional[str]:
        """
        Start model training.
        
        Args:
            config_id: Training configuration ID
        
        Returns:
            Job ID if successful, None otherwise
        """
        try:
            # Get training configuration
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            cursor.execute("SELECT * FROM training_configs WHERE config_id = ?", (config_id,))
            row = cursor.fetchone()
            
            if row is None:
                logger.error(f"Training configuration {config_id} not found")
                conn.close()
                return None
            
            # Create training configuration
            config = TrainingConfig(
                config_id=row["config_id"],
                name=row["name"],
                dataset_id=row["dataset_id"],
                model_type=row["model_type"],
                epochs=row["epochs"],
                batch_size=row["batch_size"],
                learning_rate=row["learning_rate"],
                augmentation=bool(row["augmentation"]),
                created_at=row["created_at"],
                parameters=json.loads(row["parameters"]) if row["parameters"] else {}
            )
            
            # Start training job
            job = self.roboflow_client.start_training(
                dataset_id=config.dataset_id,
                model_type=config.model_type,
                epochs=config.epochs,
                batch_size=config.batch_size,
                learning_rate=config.learning_rate
            )
            
            if job is None:
                logger.error(f"Failed to start training job for configuration {config_id}")
                conn.close()
                return None
            
            # Save job to database
            cursor.execute("""
                INSERT INTO training_jobs (
                    job_id, config_id, status, created_at, progress
                )
                VALUES (?, ?, ?, ?, ?)
            """, (
                job.job_id,
                config_id,
                job.status,
                job.created_at,
                job.progress
            ))
            
            conn.commit()
            conn.close()
            
            logger.info(f"Started training job {job.job_id} for configuration {config_id}")
            return job.job_id
        except Exception as e:
            logger.error(f"Error starting training for configuration {config_id}: {e}")
            return None
    
    def get_training_job_status(self, job_id: str) -> Dict[str, Any]:
        """
        Get training job status.
        
        Args:
            job_id: Training job ID
        
        Returns:
            Job status information
        """
        try:
            # Get job from Roboflow
            job = self.roboflow_client.get_training_job(job_id, force_refresh=True)
            if job is None:
                return {"status": "unknown", "progress": 0.0}
            
            # Update database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            if job.status in ["completed", "failed", "cancelled"]:
                # Job is complete
                cursor.execute("""
                    UPDATE training_jobs
                    SET status = ?, completed_at = ?, progress = ?, version_id = ?, metrics = ?
                    WHERE job_id = ?
                """, (
                    job.status,
                    job.completed_at or datetime.datetime.now().isoformat(),
                    job.progress,
                    job.version_id,
                    json.dumps(job.metrics),
                    job.job_id
                ))
                
                # If job completed successfully and version_id is available, create model
                if job.status == "completed" and job.version_id is not None:
                    # Get config ID
                    cursor.execute("SELECT config_id FROM training_jobs WHERE job_id = ?", (job.job_id,))
                    row = cursor.fetchone()
                    if row:
                        config_id = row[0]
                        
                        # Get training configuration
                        cursor.execute("SELECT * FROM training_configs WHERE config_id = ?", (config_id,))
                        config_row = cursor.fetchone()
                        
                        if config_row:
                            # Create model
                            model_name = f"{config_row[1]} v{job.version_id}"
                            self.create_model(
                                name=model_name,
                                workspace=self.roboflow_client.workspace,
                                project=self.roboflow_client.project,
                                version_id=job.version_id,
                                model_type=config_row[3]
                            )
            else:
                # Job is in progress
                cursor.execute("""
                    UPDATE training_jobs
                    SET status = ?, progress = ?
                    WHERE job_id = ?
                """, (
                    job.status,
                    job.progress,
                    job.job_id
                ))
            
            conn.commit()
            conn.close()
            
            return {
                "status": job.status,
                "progress": job.progress,
                "created_at": job.created_at,
                "completed_at": job.completed_at,
                "version_id": job.version_id,
                "metrics": job.metrics
            }
        except Exception as e:
            logger.error(f"Error getting training job status for {job_id}: {e}")
            return {"status": "error", "progress": 0.0, "error": str(e)}
    
    def get_training_jobs(self) -> List[Dict[str, Any]]:
        """
        Get all training jobs.
        
        Returns:
            List of training jobs
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Get jobs
            cursor.execute("""
                SELECT j.*, c.name as config_name
                FROM training_jobs j
                JOIN training_configs c ON j.config_id = c.config_id
            """)
            rows = cursor.fetchall()
            
            # Close connection
            conn.close()
            
            # Create job objects
            jobs = []
            for row in rows:
                job = {
                    "job_id": row["job_id"],
                    "config_id": row["config_id"],
                    "config_name": row["config_name"],
                    "status": row["status"],
                    "created_at": row["created_at"],
                    "completed_at": row["completed_at"],
                    "progress": row["progress"],
                    "version_id": row["version_id"],
                    "metrics": json.loads(row["metrics"]) if row["metrics"] else {}
                }
                jobs.append(job)
            
            return jobs
        except Exception as e:
            logger.error(f"Error getting training jobs: {e}")
            return []
    
    # Inference
    
    def predict(self, model_id: str, image: Union[str, np.ndarray], image_id: Optional[str] = None,
               callback: Optional[callable] = None) -> Optional[str]:
        """
        Perform inference on image.
        
        Args:
            model_id: Model ID
            image: Image path or numpy array
            image_id: Image ID (if None, will generate random ID)
            callback: Callback function to call with result
        
        Returns:
            Request ID if successful, None otherwise
        """
        try:
            # Check if model exists
            with self.models_cache_lock:
                if model_id not in self.models_cache:
                    logger.error(f"Model {model_id} not found in cache")
                    return None
            
            # Generate image ID if not provided
            if image_id is None:
                image_id = str(uuid.uuid4())
            
            # Load image if path provided
            if isinstance(image, str):
                image = cv2.imread(image)
                if image is None:
                    logger.error(f"Failed to load image from {image}")
                    return None
            
            # Generate request ID
            request_id = str(uuid.uuid4())
            
            # Store callback if provided
            if callback:
                self.inference_callbacks[request_id] = callback
            
            # Add to inference queue
            self.inference_queue.put({
                "model_id": model_id,
                "image": image,
                "image_id": image_id,
                "callback_id": request_id if callback else None
            })
            
            logger.debug(f"Queued inference request {request_id} for model {model_id}")
            return request_id
        except Exception as e:
            logger.error(f"Error queuing inference request: {e}")
            return None
    
    def predict_sync(self, model_id: str, image: Union[str, np.ndarray], image_id: Optional[str] = None) -> Optional[InferenceResult]:
        """
        Perform synchronous inference on image.
        
        Args:
            model_id: Model ID
            image: Image path or numpy array
            image_id: Image ID (if None, will generate random ID)
        
        Returns:
            Inference result if successful, None otherwise
        """
        try:
            # Check if model exists
            with self.models_cache_lock:
                if model_id not in self.models_cache:
                    logger.error(f"Model {model_id} not found in cache")
                    return None
                
                model_data = self.models_cache[model_id]
            
            model = model_data["model"]
            config = model_data["config"]
            
            # Generate image ID if not provided
            if image_id is None:
                image_id = str(uuid.uuid4())
            
            # Load image if path provided
            if isinstance(image, str):
                image = cv2.imread(image)
                if image is None:
                    logger.error(f"Failed to load image from {image}")
                    return None
            
            # Perform inference
            start_time = time.time()
            detections = model.predict(image)
            inference_time = time.time() - start_time
            
            # Create result
            has_defect = len(detections) > 0
            defect_types = list(set(d.defect_type for d in detections))
            confidence = max([d.confidence for d in detections]) if detections else 0.0
            
            result = InferenceResult(
                result_id=str(uuid.uuid4()),
                model_id=model_id,
                image_id=image_id,
                timestamp=datetime.datetime.now().isoformat(),
                detections=detections,
                inference_time=inference_time,
                has_defect=has_defect,
                defect_types=defect_types,
                confidence=confidence
            )
            
            # Save result to database
            self._save_inference_result(result)
            
            return result
        except Exception as e:
            logger.error(f"Error performing synchronous inference: {e}")
            return None
    
    def get_inference_results(self, limit: int = 100, offset: int = 0, 
                            model_id: Optional[str] = None, has_defect: Optional[bool] = None) -> List[InferenceResult]:
        """
        Get inference results.
        
        Args:
            limit: Maximum number of results to return
            offset: Result offset
            model_id: Filter by model ID
            has_defect: Filter by defect status
        
        Returns:
            List of inference results
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Build query
            query = "SELECT * FROM inference_results"
            params = []
            
            # Add filters
            filters = []
            if model_id is not None:
                filters.append("model_id = ?")
                params.append(model_id)
            if has_defect is not None:
                filters.append("has_defect = ?")
                params.append(int(has_defect))
            
            if filters:
                query += " WHERE " + " AND ".join(filters)
            
            # Add order and limit
            query += " ORDER BY timestamp DESC LIMIT ? OFFSET ?"
            params.extend([limit, offset])
            
            # Execute query
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            # Close connection
            conn.close()
            
            # Create result objects
            results = []
            for row in rows:
                result = InferenceResult(
                    result_id=row["result_id"],
                    model_id=row["model_id"],
                    image_id=row["image_id"],
                    timestamp=row["timestamp"],
                    detections=[DetectionResult.from_dict(d) for d in json.loads(row["detections"])],
                    inference_time=row["inference_time"],
                    has_defect=bool(row["has_defect"]),
                    defect_types=json.loads(row["defect_types"]),
                    confidence=row["confidence"]
                )
                results.append(result)
            
            return results
        except Exception as e:
            logger.error(f"Error getting inference results: {e}")
            return []
    
    def get_defect_statistics(self, start_time: Optional[str] = None, end_time: Optional[str] = None,
                            model_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Get defect statistics.
        
        Args:
            start_time: Start time (ISO format)
            end_time: End time (ISO format)
            model_id: Filter by model ID
        
        Returns:
            Statistics dictionary
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Build query
            query = "SELECT * FROM inference_results"
            params = []
            
            # Add filters
            filters = []
            if start_time is not None:
                filters.append("timestamp >= ?")
                params.append(start_time)
            if end_time is not None:
                filters.append("timestamp <= ?")
                params.append(end_time)
            if model_id is not None:
                filters.append("model_id = ?")
                params.append(model_id)
            
            if filters:
                query += " WHERE " + " AND ".join(filters)
            
            # Execute query
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            # Close connection
            conn.close()
            
            # Calculate statistics
            total_count = len(rows)
            defect_count = sum(1 for row in rows if row["has_defect"])
            defect_rate = defect_count / total_count if total_count > 0 else 0
            
            # Count defect types
            defect_types = {}
            for row in rows:
                if row["has_defect"]:
                    for defect_type in json.loads(row["defect_types"]):
                        defect_types[defect_type] = defect_types.get(defect_type, 0) + 1
            
            # Calculate average inference time
            avg_inference_time = sum(row["inference_time"] for row in rows) / total_count if total_count > 0 else 0
            
            # Calculate average confidence
            defect_confidences = [row["confidence"] for row in rows if row["has_defect"]]
            avg_confidence = sum(defect_confidences) / len(defect_confidences) if defect_confidences else 0
            
            return {
                "total_count": total_count,
                "defect_count": defect_count,
                "defect_rate": defect_rate,
                "defect_types": defect_types,
                "avg_inference_time": avg_inference_time,
                "avg_confidence": avg_confidence
            }
        except Exception as e:
            logger.error(f"Error getting defect statistics: {e}")
            return {
                "total_count": 0,
                "defect_count": 0,
                "defect_rate": 0,
                "defect_types": {},
                "avg_inference_time": 0,
                "avg_confidence": 0
            }
    
    # Utility Methods
    
    def visualize_detections(self, image: Union[str, np.ndarray], result: InferenceResult) -> np.ndarray:
        """
        Visualize detections on image.
        
        Args:
            image: Image path or numpy array
            result: Inference result
        
        Returns:
            Image with visualized detections
        """
        try:
            # Load image if path provided
            if isinstance(image, str):
                image = cv2.imread(image)
                if image is None:
                    logger.error(f"Failed to load image from {image}")
                    return None
            
            # Get model
            with self.models_cache_lock:
                if result.model_id not in self.models_cache:
                    logger.error(f"Model {result.model_id} not found in cache")
                    return image
                
                model = self.models_cache[result.model_id]["model"]
            
            # Visualize detections
            return model.visualize_detections(image, result.detections)
        except Exception as e:
            logger.error(f"Error visualizing detections: {e}")
            return image
    
    def cleanup(self):
        """Clean up resources."""
        try:
            # Stop inference thread
            if self.inference_thread and self.inference_thread.is_alive():
                self.inference_thread_running = False
                self.inference_thread.join(timeout=5.0)
            
            # Stop Roboflow client job monitoring
            self.roboflow_client.stop_job_monitoring()
            
            logger.info("Cleaned up model manager resources")
        except Exception as e:
            logger.error(f"Error cleaning up resources: {e}")


# Example usage
if __name__ == "__main__":
    # Set up logging
    logging.basicConfig(level=logging.INFO)
    
    # Create model manager
    manager = ModelManager(
        db_path="data/database/models.db",
        models_dir="models/weights"
    )
    
    # Get active models
    models = manager.get_models(active_only=True)
    print(f"Found {len(models)} active models")
    
    # Clean up
    manager.cleanup()
