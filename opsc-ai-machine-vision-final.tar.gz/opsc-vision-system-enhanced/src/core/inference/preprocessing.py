"""
Image preprocessing module for OPSC Sandwich Quality Inspection System.
Provides preprocessing pipeline for sandwich defect detection.

Version: 1.0.0
Last Updated: 2025-04-20
"""

import os
import sys
import time
import threading
import queue
from typing import Dict, List, Optional, Tuple, Union, Any, Callable, Generator
import logging
import numpy as np
from dataclasses import dataclass, field
from enum import Enum
import json
import uuid
from pathlib import Path
import concurrent.futures
import datetime

import cv2

from ...utils.config import get_config
from ...utils.logging import setup_logging, log_exception
from ..camera.pylon_wrapper import CameraImage
from ..camera.basler_manager import get_camera_manager
from ..camera.calibration import get_camera_calibration, CalibrationError

# Setup logging
logger = setup_logging(__name__)


class PreprocessingError(Exception):
    """Base exception for preprocessing-related errors."""
    pass


class InvalidImageError(PreprocessingError):
    """Exception raised when an image is invalid."""
    pass


class ProcessingStepError(PreprocessingError):
    """Exception raised when a processing step fails."""
    pass


class PreprocessingStepType(Enum):
    """Preprocessing step type."""
    FORMAT_CONVERSION = 0
    CALIBRATION_CORRECTION = 1
    CROP = 2
    RESIZE = 3
    COLOR_CONVERSION = 4
    NORMALIZATION = 5
    ENHANCEMENT = 6
    NOISE_REDUCTION = 7
    EDGE_ENHANCEMENT = 8
    CUSTOM = 9


@dataclass
class PreprocessingStep:
    """Preprocessing step configuration."""
    type: PreprocessingStepType
    params: Dict[str, Any] = field(default_factory=dict)
    enabled: bool = True
    name: Optional[str] = None
    description: Optional[str] = None


@dataclass
class PreprocessingResult:
    """Result of preprocessing pipeline."""
    original_image: np.ndarray
    processed_image: np.ndarray
    camera_id: str
    timestamp: datetime.datetime
    processing_time: float
    steps_applied: List[str]
    metadata: Dict[str, Any] = field(default_factory=dict)


class PreprocessingPipeline:
    """
    Image preprocessing pipeline for sandwich defect detection.
    Provides a configurable pipeline for preparing images for AI inference.
    """

    def __init__(self, config_path: Optional[str] = None):
        """
        Initialize preprocessing pipeline.
        
        Args:
            config_path: Path to preprocessing configuration file. If None, uses default configuration.
        """
        # Load configuration
        if config_path is None:
            self.config = get_config("preprocessing", {})
        else:
            import yaml
            with open(config_path, "r") as f:
                self.config = yaml.safe_load(f)
        
        # Get camera calibration
        self.camera_calibration = get_camera_calibration()
        
        # Initialize preprocessing steps
        self.steps: List[PreprocessingStep] = []
        self._initialize_steps()
        
        # Initialize GPU context if available
        self.use_gpu = self.config.get("use_gpu", False)
        if self.use_gpu:
            try:
                # Check if CUDA is available
                if cv2.cuda.getCudaEnabledDeviceCount() > 0:
                    cv2.cuda.setDevice(0)
                    logger.info("Using GPU for preprocessing")
                else:
                    logger.warning("CUDA is not available, falling back to CPU")
                    self.use_gpu = False
            except Exception as e:
                logger.warning(f"Error initializing GPU: {e}")
                self.use_gpu = False
        
        # Initialize thread pool for parallel processing
        self.max_workers = self.config.get("max_workers", 4)
        self.executor = concurrent.futures.ThreadPoolExecutor(max_workers=self.max_workers)
        
        logger.info(f"Initialized preprocessing pipeline with {len(self.steps)} steps")
    
    def _initialize_steps(self) -> None:
        """Initialize preprocessing steps from configuration."""
        try:
            # Get steps from configuration
            steps_config = self.config.get("steps", [])
            
            # Create preprocessing steps
            for step_config in steps_config:
                step_type = step_config.get("type")
                step_params = step_config.get("params", {})
                step_enabled = step_config.get("enabled", True)
                step_name = step_config.get("name")
                step_description = step_config.get("description")
                
                # Convert string type to enum
                if isinstance(step_type, str):
                    try:
                        step_type = PreprocessingStepType[step_type]
                    except KeyError:
                        logger.warning(f"Unknown preprocessing step type: {step_type}")
                        continue
                
                # Create preprocessing step
                step = PreprocessingStep(
                    type=step_type,
                    params=step_params,
                    enabled=step_enabled,
                    name=step_name,
                    description=step_description
                )
                
                self.steps.append(step)
            
            # If no steps are configured, add default steps
            if not self.steps:
                logger.info("No preprocessing steps configured, adding default steps")
                self._add_default_steps()
        except Exception as e:
            logger.error(f"Error initializing preprocessing steps: {e}")
            # Add default steps if initialization fails
            self._add_default_steps()
    
    def _add_default_steps(self) -> None:
        """Add default preprocessing steps."""
        # Format conversion
        self.steps.append(PreprocessingStep(
            type=PreprocessingStepType.FORMAT_CONVERSION,
            params={},
            name="Format Conversion",
            description="Convert image format to BGR"
        ))
        
        # Calibration correction
        self.steps.append(PreprocessingStep(
            type=PreprocessingStepType.CALIBRATION_CORRECTION,
            params={},
            name="Calibration Correction",
            description="Apply lens distortion correction"
        ))
        
        # Crop
        self.steps.append(PreprocessingStep(
            type=PreprocessingStepType.CROP,
            params={"margin": 50},
            name="Crop",
            description="Crop image to remove borders"
        ))
        
        # Resize
        self.steps.append(PreprocessingStep(
            type=PreprocessingStepType.RESIZE,
            params={"width": 640, "height": 640},
            name="Resize",
            description="Resize image to model input size"
        ))
        
        # Color conversion
        self.steps.append(PreprocessingStep(
            type=PreprocessingStepType.COLOR_CONVERSION,
            params={"code": "COLOR_BGR2RGB"},
            name="Color Conversion",
            description="Convert color space to RGB"
        ))
        
        # Normalization
        self.steps.append(PreprocessingStep(
            type=PreprocessingStepType.NORMALIZATION,
            params={"scale": 1.0/255.0, "mean": [0.485, 0.456, 0.406], "std": [0.229, 0.224, 0.225]},
            name="Normalization",
            description="Normalize pixel values"
        ))
    
    def add_step(self, step: PreprocessingStep) -> None:
        """
        Add a preprocessing step to the pipeline.
        
        Args:
            step: Preprocessing step to add.
        """
        self.steps.append(step)
        logger.info(f"Added preprocessing step: {step.name or step.type.name}")
    
    def remove_step(self, index: int) -> None:
        """
        Remove a preprocessing step from the pipeline.
        
        Args:
            index: Index of the step to remove.
            
        Raises:
            IndexError: If the index is out of range.
        """
        if 0 <= index < len(self.steps):
            step = self.steps.pop(index)
            logger.info(f"Removed preprocessing step: {step.name or step.type.name}")
        else:
            raise IndexError(f"Step index out of range: {index}")
    
    def enable_step(self, index: int) -> None:
        """
        Enable a preprocessing step.
        
        Args:
            index: Index of the step to enable.
            
        Raises:
            IndexError: If the index is out of range.
        """
        if 0 <= index < len(self.steps):
            self.steps[index].enabled = True
            logger.info(f"Enabled preprocessing step: {self.steps[index].name or self.steps[index].type.name}")
        else:
            raise IndexError(f"Step index out of range: {index}")
    
    def disable_step(self, index: int) -> None:
        """
        Disable a preprocessing step.
        
        Args:
            index: Index of the step to disable.
            
        Raises:
            IndexError: If the index is out of range.
        """
        if 0 <= index < len(self.steps):
            self.steps[index].enabled = False
            logger.info(f"Disabled preprocessing step: {self.steps[index].name or self.steps[index].type.name}")
        else:
            raise IndexError(f"Step index out of range: {index}")
    
    def get_steps(self) -> List[PreprocessingStep]:
        """
        Get all preprocessing steps.
        
        Returns:
            List of preprocessing steps.
        """
        return self.steps.copy()
    
    def _apply_format_conversion(self, image: np.ndarray, params: Dict[str, Any]) -> np.ndarray:
        """
        Apply format conversion to an image.
        
        Args:
            image: Input image.
            params: Format conversion parameters.
            
        Returns:
            Converted image.
        """
        try:
            # Check if image is already in the correct format
            if len(image.shape) == 2:
                # Convert grayscale to BGR
                return cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
            elif len(image.shape) == 3 and image.shape[2] == 3:
                # Already BGR
                return image.copy()
            elif len(image.shape) == 3 and image.shape[2] == 4:
                # Convert BGRA to BGR
                return cv2.cvtColor(image, cv2.COLOR_BGRA2BGR)
            else:
                raise InvalidImageError(f"Unsupported image format: {image.shape}")
        except Exception as e:
            logger.error(f"Error in format conversion: {e}")
            raise ProcessingStepError(f"Format conversion failed: {e}")
    
    def _apply_calibration_correction(self, image: np.ndarray, params: Dict[str, Any], camera_id: str) -> np.ndarray:
        """
        Apply calibration correction to an image.
        
        Args:
            image: Input image.
            params: Calibration correction parameters.
            camera_id: Camera ID.
            
        Returns:
            Corrected image.
        """
        try:
            # Check if calibration data is available
            if self.camera_calibration is None:
                logger.warning(f"Calibration data not available for camera {camera_id}")
                return image.copy()
            
            # Apply undistortion
            try:
                return self.camera_calibration.undistort_image(camera_id, image)
            except CalibrationError as e:
                logger.warning(f"Calibration correction failed for camera {camera_id}: {e}")
                return image.copy()
        except Exception as e:
            logger.error(f"Error in calibration correction: {e}")
            raise ProcessingStepError(f"Calibration correction failed: {e}")
    
    def _apply_crop(self, image: np.ndarray, params: Dict[str, Any]) -> np.ndarray:
        """
        Apply cropping to an image.
        
        Args:
            image: Input image.
            params: Crop parameters.
            
        Returns:
            Cropped image.
        """
        try:
            # Get crop parameters
            x = params.get("x", 0)
            y = params.get("y", 0)
            width = params.get("width", image.shape[1] - x)
            height = params.get("height", image.shape[0] - y)
            margin = params.get("margin", 0)
            
            # Apply margin if specified
            if margin > 0:
                x = margin
                y = margin
                width = image.shape[1] - 2 * margin
                height = image.shape[0] - 2 * margin
            
            # Validate crop parameters
            if x < 0 or y < 0 or width <= 0 or height <= 0 or x + width > image.shape[1] or y + height > image.shape[0]:
                logger.warning(f"Invalid crop parameters: x={x}, y={y}, width={width}, height={height}, image_shape={image.shape}")
                return image.copy()
            
            # Apply crop
            return image[y:y+height, x:x+width].copy()
        except Exception as e:
            logger.error(f"Error in crop: {e}")
            raise ProcessingStepError(f"Crop failed: {e}")
    
    def _apply_resize(self, image: np.ndarray, params: Dict[str, Any]) -> np.ndarray:
        """
        Apply resizing to an image.
        
        Args:
            image: Input image.
            params: Resize parameters.
            
        Returns:
            Resized image.
        """
        try:
            # Get resize parameters
            width = params.get("width", image.shape[1])
            height = params.get("height", image.shape[0])
            interpolation_str = params.get("interpolation", "INTER_LINEAR")
            
            # Convert interpolation string to OpenCV constant
            interpolation = getattr(cv2, interpolation_str, cv2.INTER_LINEAR)
            
            # Apply resize
            if self.use_gpu:
                gpu_image = cv2.cuda_GpuMat()
                gpu_image.upload(image)
                gpu_result = cv2.cuda.resize(gpu_image, (width, height), interpolation=interpolation)
                return gpu_result.download()
            else:
                return cv2.resize(image, (width, height), interpolation=interpolation)
        except Exception as e:
            logger.error(f"Error in resize: {e}")
            raise ProcessingStepError(f"Resize failed: {e}")
    
    def _apply_color_conversion(self, image: np.ndarray, params: Dict[str, Any]) -> np.ndarray:
        """
        Apply color conversion to an image.
        
        Args:
            image: Input image.
            params: Color conversion parameters.
            
        Returns:
            Color converted image.
        """
        try:
            # Get color conversion parameters
            code_str = params.get("code", "COLOR_BGR2RGB")
            
            # Convert code string to OpenCV constant
            code = getattr(cv2, code_str, cv2.COLOR_BGR2RGB)
            
            # Apply color conversion
            if self.use_gpu:
                gpu_image = cv2.cuda_GpuMat()
                gpu_image.upload(image)
                gpu_result = cv2.cuda.cvtColor(gpu_image, code)
                return gpu_result.download()
            else:
                return cv2.cvtColor(image, code)
        except Exception as e:
            logger.error(f"Error in color conversion: {e}")
            raise ProcessingStepError(f"Color conversion failed: {e}")
    
    def _apply_normalization(self, image: np.ndarray, params: Dict[str, Any]) -> np.ndarray:
        """
        Apply normalization to an image.
        
        Args:
            image: Input image.
            params: Normalization parameters.
            
        Returns:
            Normalized image.
        """
        try:
            # Get normalization parameters
            scale = params.get("scale", 1.0/255.0)
            mean = params.get("mean", [0.0, 0.0, 0.0])
            std = params.get("std", [1.0, 1.0, 1.0])
            
            # Convert to float32
            result = image.astype(np.float32)
            
            # Apply scaling
            result *= scale
            
            # Apply mean subtraction and std division
            if len(mean) == 3 and len(std) == 3:
                # Apply per-channel normalization
                for i in range(min(3, result.shape[2])):
                    result[:, :, i] = (result[:, :, i] - mean[i]) / std[i]
            else:
                # Apply global normalization
                result = (result - mean[0]) / std[0]
            
            return result
        except Exception as e:
            logger.error(f"Error in normalization: {e}")
            raise ProcessingStepError(f"Normalization failed: {e}")
    
    def _apply_enhancement(self, image: np.ndarray, params: Dict[str, Any]) -> np.ndarray:
        """
        Apply enhancement to an image.
        
        Args:
            image: Input image.
            params: Enhancement parameters.
            
        Returns:
            Enhanced image.
        """
        try:
            # Get enhancement parameters
            enhancement_type = params.get("type", "clahe")
            
            if enhancement_type == "clahe":
                # Apply CLAHE (Contrast Limited Adaptive Histogram Equalization)
                clip_limit = params.get("clip_limit", 2.0)
                tile_grid_size = params.get("tile_grid_size", (8, 8))
                
                # Convert to LAB color space for CLAHE
                lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)
                
                # Apply CLAHE to L channel
                clahe = cv2.createCLAHE(clipLimit=clip_limit, tileGridSize=tile_grid_size)
                lab[:, :, 0] = clahe.apply(lab[:, :, 0])
                
                # Convert back to BGR
                return cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)
            
            elif enhancement_type == "unsharp_mask":
                # Apply unsharp masking
                sigma = params.get("sigma", 1.5)
                amount = params.get("amount", 1.5)
                threshold = params.get("threshold", 0)
                
                # Create blurred version
                blurred = cv2.GaussianBlur(image, (0, 0), sigma)
                
                # Calculate unsharp mask
                sharpened = cv2.addWeighted(image, 1.0 + amount, blurred, -amount, 0)
                
                # Apply threshold if specified
                if threshold > 0:
                    low_contrast_mask = np.absolute(image - blurred) < threshold
                    np.copyto(sharpened, image, where=low_contrast_mask)
                
                return sharpened
            
            elif enhancement_type == "gamma_correction":
                # Apply gamma correction
                gamma = params.get("gamma", 1.2)
                
                # Create lookup table
                inv_gamma = 1.0 / gamma
                table = np.array([((i / 255.0) ** inv_gamma) * 255 for i in range(256)]).astype(np.uint8)
                
                # Apply gamma correction using lookup table
                return cv2.LUT(image, table)
            
            else:
                logger.warning(f"Unknown enhancement type: {enhancement_type}")
                return image.copy()
        except Exception as e:
            logger.error(f"Error in enhancement: {e}")
            raise ProcessingStepError(f"Enhancement failed: {e}")
    
    def _apply_noise_reduction(self, image: np.ndarray, params: Dict[str, Any]) -> np.ndarray:
        """
        Apply noise reduction to an image.
        
        Args:
            image: Input image.
            params: Noise reduction parameters.
            
        Returns:
            Noise reduced image.
        """
        try:
            # Get noise reduction parameters
            method = params.get("method", "gaussian")
            
            if method == "gaussian":
                # Apply Gaussian blur
                kernel_size = params.get("kernel_size", (5, 5))
                sigma = params.get("sigma", 0)
                
                if self.use_gpu:
                    gpu_image = cv2.cuda_GpuMat()
                    gpu_image.upload(image)
                    gpu_result = cv2.cuda.GaussianBlur(gpu_image, kernel_size, sigma)
                    return gpu_result.download()
                else:
                    return cv2.GaussianBlur(image, kernel_size, sigma)
            
            elif method == "median":
                # Apply median blur
                kernel_size = params.get("kernel_size", 5)
                
                if self.use_gpu:
                    gpu_image = cv2.cuda_GpuMat()
                    gpu_image.upload(image)
                    gpu_result = cv2.cuda.createMedianFilter(cv2.CV_8UC3, kernel_size).apply(gpu_image)
                    return gpu_result.download()
                else:
                    return cv2.medianBlur(image, kernel_size)
            
            elif method == "bilateral":
                # Apply bilateral filter
                d = params.get("d", 9)
                sigma_color = params.get("sigma_color", 75)
                sigma_space = params.get("sigma_space", 75)
                
                return cv2.bilateralFilter(image, d, sigma_color, sigma_space)
            
            elif method == "nlm":
                # Apply non-local means denoising
                h = params.get("h", 10)
                template_window_size = params.get("template_window_size", 7)
                search_window_size = params.get("search_window_size", 21)
                
                return cv2.fastNlMeansDenoisingColored(
                    image, None, h, h, template_window_size, search_window_size
                )
            
            else:
                logger.warning(f"Unknown noise reduction method: {method}")
                return image.copy()
        except Exception as e:
            logger.error(f"Error in noise reduction: {e}")
            raise ProcessingStepError(f"Noise reduction failed: {e}")
    
    def _apply_edge_enhancement(self, image: np.ndarray, params: Dict[str, Any]) -> np.ndarray:
        """
        Apply edge enhancement to an image.
        
        Args:
            image: Input image.
            params: Edge enhancement parameters.
            
        Returns:
            Edge enhanced image.
        """
        try:
            # Get edge enhancement parameters
            method = params.get("method", "sobel")
            blend = params.get("blend", True)
            blend_alpha = params.get("blend_alpha", 0.5)
            
            # Convert to grayscale for edge detection
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            
            if method == "sobel":
                # Apply Sobel edge detection
                scale = params.get("scale", 1)
                delta = params.get("delta", 0)
                ksize = params.get("ksize", 3)
                
                # Compute gradients
                grad_x = cv2.Sobel(gray, cv2.CV_16S, 1, 0, ksize=ksize, scale=scale, delta=delta)
                grad_y = cv2.Sobel(gray, cv2.CV_16S, 0, 1, ksize=ksize, scale=scale, delta=delta)
                
                # Convert to absolute values
                abs_grad_x = cv2.convertScaleAbs(grad_x)
                abs_grad_y = cv2.convertScaleAbs(grad_y)
                
                # Combine gradients
                edges = cv2.addWeighted(abs_grad_x, 0.5, abs_grad_y, 0.5, 0)
            
            elif method == "canny":
                # Apply Canny edge detection
                threshold1 = params.get("threshold1", 100)
                threshold2 = params.get("threshold2", 200)
                
                edges = cv2.Canny(gray, threshold1, threshold2)
            
            elif method == "laplacian":
                # Apply Laplacian edge detection
                ksize = params.get("ksize", 3)
                
                # Apply Laplacian
                laplacian = cv2.Laplacian(gray, cv2.CV_16S, ksize=ksize)
                
                # Convert to absolute values
                edges = cv2.convertScaleAbs(laplacian)
            
            else:
                logger.warning(f"Unknown edge enhancement method: {method}")
                return image.copy()
            
            # Blend with original image if requested
            if blend:
                # Convert edges to 3-channel
                edges_3ch = cv2.cvtColor(edges, cv2.COLOR_GRAY2BGR)
                
                # Blend with original image
                return cv2.addWeighted(image, 1.0, edges_3ch, blend_alpha, 0)
            else:
                # Return edges as grayscale
                return cv2.cvtColor(edges, cv2.COLOR_GRAY2BGR)
        except Exception as e:
            logger.error(f"Error in edge enhancement: {e}")
            raise ProcessingStepError(f"Edge enhancement failed: {e}")
    
    def _apply_custom(self, image: np.ndarray, params: Dict[str, Any]) -> np.ndarray:
        """
        Apply custom processing to an image.
        
        Args:
            image: Input image.
            params: Custom processing parameters.
            
        Returns:
            Processed image.
        """
        try:
            # Get custom processing parameters
            function_name = params.get("function")
            
            if function_name == "sandwich_specific_enhancement":
                # Apply sandwich-specific enhancement
                
                # Convert to HSV for better color manipulation
                hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
                
                # Enhance saturation for better filling detection
                hsv[:, :, 1] = np.clip(hsv[:, :, 1] * 1.2, 0, 255).astype(np.uint8)
                
                # Convert back to BGR
                enhanced = cv2.cvtColor(hsv, cv2.COLOR_HSV2BGR)
                
                # Apply CLAHE for better texture visibility
                lab = cv2.cvtColor(enhanced, cv2.COLOR_BGR2LAB)
                clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
                lab[:, :, 0] = clahe.apply(lab[:, :, 0])
                enhanced = cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)
                
                # Apply slight sharpening for edge detection
                kernel = np.array([[-1, -1, -1],
                                   [-1,  9, -1],
                                   [-1, -1, -1]])
                enhanced = cv2.filter2D(enhanced, -1, kernel)
                
                return enhanced
            
            elif function_name == "filling_leakage_enhancement":
                # Apply filling leakage enhancement
                
                # Convert to HSV for color-based detection
                hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
                
                # Extract saturation channel (helps with filling detection)
                saturation = hsv[:, :, 1]
                
                # Apply adaptive thresholding to highlight potential leakage
                adaptive_thresh = cv2.adaptiveThreshold(
                    saturation, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, -2
                )
                
                # Create mask for potential leakage areas
                mask = cv2.bitwise_not(adaptive_thresh)
                
                # Create highlighted image
                highlighted = image.copy()
                highlighted[mask > 0] = [0, 0, 255]  # Red for potential leakage
                
                # Blend with original
                alpha = 0.3
                return cv2.addWeighted(image, 1 - alpha, highlighted, alpha, 0)
            
            elif function_name == "mold_detection_enhancement":
                # Apply mold detection enhancement
                
                # Convert to LAB color space
                lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)
                
                # Apply CLAHE to L channel
                clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
                lab[:, :, 0] = clahe.apply(lab[:, :, 0])
                
                # Enhance a and b channels for better color discrimination
                lab[:, :, 1] = np.clip(lab[:, :, 1] * 1.2, 0, 255).astype(np.uint8)
                lab[:, :, 2] = np.clip(lab[:, :, 2] * 1.2, 0, 255).astype(np.uint8)
                
                # Convert back to BGR
                enhanced = cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)
                
                # Apply bilateral filter to preserve edges while reducing noise
                enhanced = cv2.bilateralFilter(enhanced, 9, 75, 75)
                
                return enhanced
            
            elif function_name == "sandwich_size_measurement":
                # Apply sandwich size measurement enhancement
                
                # Convert to grayscale
                gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
                
                # Apply Gaussian blur to reduce noise
                blurred = cv2.GaussianBlur(gray, (5, 5), 0)
                
                # Apply Canny edge detection
                edges = cv2.Canny(blurred, 50, 150)
                
                # Dilate edges to close gaps
                kernel = np.ones((3, 3), np.uint8)
                dilated = cv2.dilate(edges, kernel, iterations=1)
                
                # Find contours
                contours, _ = cv2.findContours(dilated, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
                
                # Create output image
                result = image.copy()
                
                # Draw contours
                cv2.drawContours(result, contours, -1, (0, 255, 0), 2)
                
                # Find largest contour (assumed to be the sandwich)
                if contours:
                    largest_contour = max(contours, key=cv2.contourArea)
                    
                    # Get bounding rectangle
                    x, y, w, h = cv2.boundingRect(largest_contour)
                    
                    # Draw bounding rectangle
                    cv2.rectangle(result, (x, y), (x + w, y + h), (255, 0, 0), 2)
                    
                    # Add size information
                    cv2.putText(result, f"Width: {w}px", (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 0, 0), 2)
                    cv2.putText(result, f"Height: {h}px", (x, y - 30), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 0, 0), 2)
                
                return result
            
            else:
                logger.warning(f"Unknown custom function: {function_name}")
                return image.copy()
        except Exception as e:
            logger.error(f"Error in custom processing: {e}")
            raise ProcessingStepError(f"Custom processing failed: {e}")
    
    def process_image(self, image: np.ndarray, camera_id: str) -> PreprocessingResult:
        """
        Process an image through the preprocessing pipeline.
        
        Args:
            image: Input image.
            camera_id: Camera ID.
            
        Returns:
            Preprocessing result.
            
        Raises:
            InvalidImageError: If the image is invalid.
            ProcessingStepError: If a processing step fails.
        """
        try:
            # Check if image is valid
            if image is None or image.size == 0:
                raise InvalidImageError("Image is empty")
            
            # Create a copy of the original image
            original_image = image.copy()
            processed_image = image.copy()
            
            # Record start time
            start_time = time.time()
            
            # Apply preprocessing steps
            steps_applied = []
            
            for step in self.steps:
                if not step.enabled:
                    continue
                
                step_name = step.name or step.type.name
                
                try:
                    if step.type == PreprocessingStepType.FORMAT_CONVERSION:
                        processed_image = self._apply_format_conversion(processed_image, step.params)
                    elif step.type == PreprocessingStepType.CALIBRATION_CORRECTION:
                        processed_image = self._apply_calibration_correction(processed_image, step.params, camera_id)
                    elif step.type == PreprocessingStepType.CROP:
                        processed_image = self._apply_crop(processed_image, step.params)
                    elif step.type == PreprocessingStepType.RESIZE:
                        processed_image = self._apply_resize(processed_image, step.params)
                    elif step.type == PreprocessingStepType.COLOR_CONVERSION:
                        processed_image = self._apply_color_conversion(processed_image, step.params)
                    elif step.type == PreprocessingStepType.NORMALIZATION:
                        processed_image = self._apply_normalization(processed_image, step.params)
                    elif step.type == PreprocessingStepType.ENHANCEMENT:
                        processed_image = self._apply_enhancement(processed_image, step.params)
                    elif step.type == PreprocessingStepType.NOISE_REDUCTION:
                        processed_image = self._apply_noise_reduction(processed_image, step.params)
                    elif step.type == PreprocessingStepType.EDGE_ENHANCEMENT:
                        processed_image = self._apply_edge_enhancement(processed_image, step.params)
                    elif step.type == PreprocessingStepType.CUSTOM:
                        processed_image = self._apply_custom(processed_image, step.params)
                    
                    steps_applied.append(step_name)
                except ProcessingStepError as e:
                    logger.warning(f"Step '{step_name}' failed: {e}")
                    # Continue with next step
            
            # Record end time
            end_time = time.time()
            processing_time = end_time - start_time
            
            # Create preprocessing result
            result = PreprocessingResult(
                original_image=original_image,
                processed_image=processed_image,
                camera_id=camera_id,
                timestamp=datetime.datetime.now(),
                processing_time=processing_time,
                steps_applied=steps_applied
            )
            
            logger.debug(f"Processed image from camera {camera_id} in {processing_time:.3f}s with {len(steps_applied)} steps")
            
            return result
        except Exception as e:
            logger.error(f"Error processing image from camera {camera_id}: {e}")
            raise
    
    def process_images_batch(self, images: Dict[str, np.ndarray]) -> Dict[str, PreprocessingResult]:
        """
        Process a batch of images through the preprocessing pipeline.
        
        Args:
            images: Dictionary of images by camera ID.
            
        Returns:
            Dictionary of preprocessing results by camera ID.
        """
        try:
            # Process images in parallel
            futures = {}
            results = {}
            
            for camera_id, image in images.items():
                futures[camera_id] = self.executor.submit(self.process_image, image, camera_id)
            
            # Collect results
            for camera_id, future in futures.items():
                try:
                    results[camera_id] = future.result()
                except Exception as e:
                    logger.error(f"Error processing image from camera {camera_id}: {e}")
                    # Skip this camera
            
            return results
        except Exception as e:
            logger.error(f"Error processing batch of images: {e}")
            raise
    
    def visualize_preprocessing_steps(self, image: np.ndarray, camera_id: str) -> Dict[str, np.ndarray]:
        """
        Visualize preprocessing steps on an image.
        
        Args:
            image: Input image.
            camera_id: Camera ID.
            
        Returns:
            Dictionary of images for each preprocessing step.
        """
        try:
            # Check if image is valid
            if image is None or image.size == 0:
                raise InvalidImageError("Image is empty")
            
            # Create a copy of the original image
            original_image = image.copy()
            processed_image = image.copy()
            
            # Apply preprocessing steps and save intermediate results
            step_results = {"Original": original_image}
            
            for step in self.steps:
                if not step.enabled:
                    continue
                
                step_name = step.name or step.type.name
                
                try:
                    if step.type == PreprocessingStepType.FORMAT_CONVERSION:
                        processed_image = self._apply_format_conversion(processed_image, step.params)
                    elif step.type == PreprocessingStepType.CALIBRATION_CORRECTION:
                        processed_image = self._apply_calibration_correction(processed_image, step.params, camera_id)
                    elif step.type == PreprocessingStepType.CROP:
                        processed_image = self._apply_crop(processed_image, step.params)
                    elif step.type == PreprocessingStepType.RESIZE:
                        processed_image = self._apply_resize(processed_image, step.params)
                    elif step.type == PreprocessingStepType.COLOR_CONVERSION:
                        processed_image = self._apply_color_conversion(processed_image, step.params)
                    elif step.type == PreprocessingStepType.NORMALIZATION:
                        # For visualization, scale normalized image back to 0-255 range
                        normalized = self._apply_normalization(processed_image, step.params)
                        
                        # Scale back for visualization
                        min_val = normalized.min()
                        max_val = normalized.max()
                        if max_val > min_val:
                            processed_image = (255 * (normalized - min_val) / (max_val - min_val)).astype(np.uint8)
                        else:
                            processed_image = normalized.astype(np.uint8)
                    elif step.type == PreprocessingStepType.ENHANCEMENT:
                        processed_image = self._apply_enhancement(processed_image, step.params)
                    elif step.type == PreprocessingStepType.NOISE_REDUCTION:
                        processed_image = self._apply_noise_reduction(processed_image, step.params)
                    elif step.type == PreprocessingStepType.EDGE_ENHANCEMENT:
                        processed_image = self._apply_edge_enhancement(processed_image, step.params)
                    elif step.type == PreprocessingStepType.CUSTOM:
                        processed_image = self._apply_custom(processed_image, step.params)
                    
                    # Save intermediate result
                    step_results[step_name] = processed_image.copy()
                except ProcessingStepError as e:
                    logger.warning(f"Step '{step_name}' failed: {e}")
                    # Continue with next step
            
            return step_results
        except Exception as e:
            logger.error(f"Error visualizing preprocessing steps for camera {camera_id}: {e}")
            raise
    
    def create_visualization_grid(self, step_results: Dict[str, np.ndarray], grid_size: Optional[Tuple[int, int]] = None) -> np.ndarray:
        """
        Create a visualization grid from preprocessing step results.
        
        Args:
            step_results: Dictionary of images for each preprocessing step.
            grid_size: Grid size as (rows, cols). If None, calculated automatically.
            
        Returns:
            Visualization grid image.
        """
        try:
            # Get number of steps
            num_steps = len(step_results)
            
            if num_steps == 0:
                raise ValueError("No preprocessing steps to visualize")
            
            # Calculate grid size if not specified
            if grid_size is None:
                cols = min(4, num_steps)
                rows = (num_steps + cols - 1) // cols
                grid_size = (rows, cols)
            else:
                rows, cols = grid_size
            
            # Get image size
            first_image = next(iter(step_results.values()))
            height, width = first_image.shape[:2]
            
            # Create grid image
            grid_image = np.zeros((rows * height, cols * width, 3), dtype=np.uint8)
            
            # Add images to grid
            for i, (step_name, step_image) in enumerate(step_results.items()):
                if i >= rows * cols:
                    break
                
                # Calculate position
                row = i // cols
                col = i % cols
                
                # Ensure image is 3-channel
                if len(step_image.shape) == 2:
                    step_image = cv2.cvtColor(step_image, cv2.COLOR_GRAY2BGR)
                elif step_image.shape[2] == 4:
                    step_image = cv2.cvtColor(step_image, cv2.COLOR_BGRA2BGR)
                
                # Resize image if needed
                if step_image.shape[:2] != (height, width):
                    step_image = cv2.resize(step_image, (width, height))
                
                # Add image to grid
                grid_image[row*height:(row+1)*height, col*width:(col+1)*width] = step_image
                
                # Add step name
                cv2.putText(
                    grid_image,
                    step_name,
                    (col*width + 10, row*height + 30),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.8,
                    (255, 255, 255),
                    2
                )
            
            return grid_image
        except Exception as e:
            logger.error(f"Error creating visualization grid: {e}")
            raise
    
    def save_preprocessing_config(self, file_path: str) -> None:
        """
        Save preprocessing configuration to a file.
        
        Args:
            file_path: Path to save the configuration to.
        """
        try:
            # Create configuration dictionary
            config = {
                "use_gpu": self.use_gpu,
                "max_workers": self.max_workers,
                "steps": []
            }
            
            # Add steps
            for step in self.steps:
                step_config = {
                    "type": step.type.name,
                    "params": step.params,
                    "enabled": step.enabled,
                    "name": step.name,
                    "description": step.description
                }
                
                config["steps"].append(step_config)
            
            # Save configuration
            import yaml
            with open(file_path, "w") as f:
                yaml.dump(config, f, default_flow_style=False)
            
            logger.info(f"Saved preprocessing configuration to {file_path}")
        except Exception as e:
            logger.error(f"Error saving preprocessing configuration: {e}")
            raise
    
    def load_preprocessing_config(self, file_path: str) -> None:
        """
        Load preprocessing configuration from a file.
        
        Args:
            file_path: Path to load the configuration from.
        """
        try:
            # Load configuration
            import yaml
            with open(file_path, "r") as f:
                config = yaml.safe_load(f)
            
            # Update GPU usage
            self.use_gpu = config.get("use_gpu", False)
            
            # Update max workers
            self.max_workers = config.get("max_workers", 4)
            
            # Update executor
            self.executor.shutdown(wait=True)
            self.executor = concurrent.futures.ThreadPoolExecutor(max_workers=self.max_workers)
            
            # Clear existing steps
            self.steps.clear()
            
            # Add steps
            for step_config in config.get("steps", []):
                step_type_str = step_config.get("type")
                step_params = step_config.get("params", {})
                step_enabled = step_config.get("enabled", True)
                step_name = step_config.get("name")
                step_description = step_config.get("description")
                
                # Convert string type to enum
                try:
                    step_type = PreprocessingStepType[step_type_str]
                except (KeyError, TypeError):
                    logger.warning(f"Unknown preprocessing step type: {step_type_str}")
                    continue
                
                # Create preprocessing step
                step = PreprocessingStep(
                    type=step_type,
                    params=step_params,
                    enabled=step_enabled,
                    name=step_name,
                    description=step_description
                )
                
                self.steps.append(step)
            
            logger.info(f"Loaded preprocessing configuration from {file_path} with {len(self.steps)} steps")
        except Exception as e:
            logger.error(f"Error loading preprocessing configuration: {e}")
            raise


# Singleton instance
_preprocessing_pipeline: Optional[PreprocessingPipeline] = None


def get_preprocessing_pipeline() -> PreprocessingPipeline:
    """
    Get the singleton PreprocessingPipeline instance.
    
    Returns:
        PreprocessingPipeline instance.
    """
    global _preprocessing_pipeline
    if _preprocessing_pipeline is None:
        _preprocessing_pipeline = PreprocessingPipeline()
    return _preprocessing_pipeline


if __name__ == "__main__":
    # Setup logging for standalone execution
    logging.basicConfig(level=logging.INFO)
    
    # Example usage
    preprocessing_pipeline = get_preprocessing_pipeline()
    
    try:
        # Create test image
        test_image = np.zeros((480, 640, 3), dtype=np.uint8)
        cv2.rectangle(test_image, (100, 100), (540, 380), (0, 255, 0), -1)
        cv2.circle(test_image, (320, 240), 100, (0, 0, 255), -1)
        
        # Process image
        result = preprocessing_pipeline.process_image(test_image, "test_camera")
        
        # Print processing information
        print(f"Processing time: {result.processing_time:.3f}s")
        print(f"Steps applied: {result.steps_applied}")
        
        # Visualize preprocessing steps
        step_results = preprocessing_pipeline.visualize_preprocessing_steps(test_image, "test_camera")
        grid_image = preprocessing_pipeline.create_visualization_grid(step_results)
        
        # Save visualization
        cv2.imwrite("preprocessing_visualization.png", grid_image)
        
        # Save configuration
        preprocessing_pipeline.save_preprocessing_config("preprocessing_config.yaml")
        
        logger.info("Example completed successfully")
    except Exception as e:
        logger.error(f"Error in example: {e}")
