"""
Performance optimization module for AI inference in OPSC Sandwich Quality Inspection System.
Provides functionality for optimizing model inference, including TensorRT conversion,
quantization, and parallel processing.

Version: 1.0.0
Last Updated: 2025-04-21
"""

import os
import sys
import time
import json
import logging
import datetime
import uuid
import numpy as np
import cv2
import threading
import queue
from typing import Dict, List, Optional, Tuple, Union, Any, BinaryIO, Callable
from dataclasses import dataclass, field
from pathlib import Path
from enum import Enum, auto
import onnx
import onnxruntime as ort
import torch
import tensorrt as trt
from cuda import cudart

# Setup logging
logger = logging.getLogger(__name__)

class OptimizationLevel(Enum):
    """Optimization level enum."""
    NONE = auto()
    FP32 = auto()
    FP16 = auto()
    INT8 = auto()


@dataclass
class OptimizationConfig:
    """Optimization configuration data class."""
    model_id: str
    model_name: str
    model_type: str  # "pytorch", "onnx", "tensorrt"
    input_shape: Tuple[int, ...]
    optimization_level: OptimizationLevel = OptimizationLevel.FP32
    enable_dynamic_shapes: bool = False
    enable_cuda_graphs: bool = False
    batch_size: int = 1
    workspace_size: int = 1 << 30  # 1GB
    calibration_dataset: Optional[str] = None
    calibration_batch_size: int = 8
    calibration_batches: int = 10
    parameters: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "model_id": self.model_id,
            "model_name": self.model_name,
            "model_type": self.model_type,
            "input_shape": self.input_shape,
            "optimization_level": self.optimization_level.name,
            "enable_dynamic_shapes": self.enable_dynamic_shapes,
            "enable_cuda_graphs": self.enable_cuda_graphs,
            "batch_size": self.batch_size,
            "workspace_size": self.workspace_size,
            "calibration_dataset": self.calibration_dataset,
            "calibration_batch_size": self.calibration_batch_size,
            "calibration_batches": self.calibration_batches,
            "parameters": self.parameters
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'OptimizationConfig':
        """Create from dictionary."""
        optimization_level_str = data.get("optimization_level", "FP32")
        try:
            optimization_level = OptimizationLevel[optimization_level_str]
        except KeyError:
            optimization_level = OptimizationLevel.FP32
            logger.warning(f"Invalid optimization level: {optimization_level_str}, defaulting to FP32")
        
        return cls(
            model_id=data.get("model_id"),
            model_name=data.get("model_name"),
            model_type=data.get("model_type"),
            input_shape=tuple(data.get("input_shape")),
            optimization_level=optimization_level,
            enable_dynamic_shapes=data.get("enable_dynamic_shapes", False),
            enable_cuda_graphs=data.get("enable_cuda_graphs", False),
            batch_size=data.get("batch_size", 1),
            workspace_size=data.get("workspace_size", 1 << 30),
            calibration_dataset=data.get("calibration_dataset"),
            calibration_batch_size=data.get("calibration_batch_size", 8),
            calibration_batches=data.get("calibration_batches", 10),
            parameters=data.get("parameters", {})
        )


@dataclass
class OptimizationResult:
    """Optimization result data class."""
    model_id: str
    optimized_model_path: str
    original_model_path: str
    optimization_level: OptimizationLevel
    input_shape: Tuple[int, ...]
    output_shapes: List[Tuple[int, ...]]
    throughput_fps: float
    latency_ms: float
    memory_mb: float
    timestamp: str = field(default_factory=lambda: datetime.datetime.now().isoformat())
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "model_id": self.model_id,
            "optimized_model_path": self.optimized_model_path,
            "original_model_path": self.original_model_path,
            "optimization_level": self.optimization_level.name,
            "input_shape": self.input_shape,
            "output_shapes": self.output_shapes,
            "throughput_fps": self.throughput_fps,
            "latency_ms": self.latency_ms,
            "memory_mb": self.memory_mb,
            "timestamp": self.timestamp
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'OptimizationResult':
        """Create from dictionary."""
        optimization_level_str = data.get("optimization_level", "FP32")
        try:
            optimization_level = OptimizationLevel[optimization_level_str]
        except KeyError:
            optimization_level = OptimizationLevel.FP32
            logger.warning(f"Invalid optimization level: {optimization_level_str}, defaulting to FP32")
        
        return cls(
            model_id=data.get("model_id"),
            optimized_model_path=data.get("optimized_model_path"),
            original_model_path=data.get("original_model_path"),
            optimization_level=optimization_level,
            input_shape=tuple(data.get("input_shape")),
            output_shapes=[tuple(shape) for shape in data.get("output_shapes", [])],
            throughput_fps=data.get("throughput_fps", 0.0),
            latency_ms=data.get("latency_ms", 0.0),
            memory_mb=data.get("memory_mb", 0.0),
            timestamp=data.get("timestamp", datetime.datetime.now().isoformat())
        )


class INT8Calibrator(trt.IInt8EntropyCalibrator2):
    """INT8 calibrator for TensorRT."""
    
    def __init__(self, calibration_dataset: str, input_shape: Tuple[int, ...], batch_size: int, batches: int, input_name: str = "input"):
        """
        Initialize INT8 calibrator.
        
        Args:
            calibration_dataset: Path to calibration dataset directory
            input_shape: Input shape (N, C, H, W)
            batch_size: Batch size
            batches: Number of batches to use for calibration
            input_name: Input tensor name
        """
        super().__init__()
        self.calibration_dataset = calibration_dataset
        self.input_shape = input_shape
        self.batch_size = batch_size
        self.batches = batches
        self.input_name = input_name
        
        # Load calibration images
        self.calibration_files = []
        for root, _, files in os.walk(calibration_dataset):
            for file in files:
                if file.lower().endswith((".jpg", ".jpeg", ".png", ".bmp")):
                    self.calibration_files.append(os.path.join(root, file))
        
        # Shuffle files
        np.random.shuffle(self.calibration_files)
        
        # Limit to required number of batches
        max_files = batch_size * batches
        if len(self.calibration_files) > max_files:
            self.calibration_files = self.calibration_files[:max_files]
        
        # Allocate device memory
        self.device_input = None
        
        # Create host buffer
        self.batch_idx = 0
        self.host_buffer = np.zeros((batch_size,) + input_shape[1:], dtype=np.float32)
        
        logger.info(f"Initialized INT8 calibrator with {len(self.calibration_files)} images")
    
    def get_batch_size(self):
        """Get batch size."""
        return self.batch_size
    
    def get_batch(self, names):
        """Get next batch for calibration."""
        if self.batch_idx >= self.batches:
            return None
        
        # Load batch of images
        start_idx = self.batch_idx * self.batch_size
        end_idx = min(start_idx + self.batch_size, len(self.calibration_files))
        
        if start_idx >= len(self.calibration_files):
            return None
        
        # Reset host buffer
        self.host_buffer.fill(0)
        
        # Load and preprocess images
        for i, idx in enumerate(range(start_idx, end_idx)):
            if idx >= len(self.calibration_files):
                break
            
            # Load image
            img_path = self.calibration_files[idx]
            img = cv2.imread(img_path)
            
            if img is None:
                logger.warning(f"Failed to load image: {img_path}")
                continue
            
            # Preprocess image
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            img = cv2.resize(img, (self.input_shape[2], self.input_shape[3]))
            img = img.astype(np.float32) / 255.0
            img = img.transpose(2, 0, 1)  # HWC to CHW
            
            # Add to batch
            self.host_buffer[i] = img
        
        # Copy to device
        if self.device_input is None:
            self.device_input = cudart.cudaMalloc(self.host_buffer.nbytes)[1]
        
        cudart.cudaMemcpy(self.device_input, self.host_buffer.ctypes.data, self.host_buffer.nbytes, cudart.cudaMemcpyKind.cudaMemcpyHostToDevice)
        
        # Increment batch index
        self.batch_idx += 1
        
        return {self.input_name: self.device_input}
    
    def read_calibration_cache(self):
        """Read calibration cache."""
        cache_path = os.path.join(self.calibration_dataset, "calibration.cache")
        if os.path.exists(cache_path):
            with open(cache_path, "rb") as f:
                return f.read()
        
        return None
    
    def write_calibration_cache(self, cache):
        """Write calibration cache."""
        cache_path = os.path.join(self.calibration_dataset, "calibration.cache")
        with open(cache_path, "wb") as f:
            f.write(cache)


class ModelOptimizer:
    """
    Model optimizer for OPSC Sandwich Quality Inspection System.
    
    Provides functionality for optimizing model inference, including TensorRT conversion,
    quantization, and parallel processing.
    """
    
    def __init__(self, models_dir: str, output_dir: str):
        """
        Initialize model optimizer.
        
        Args:
            models_dir: Path to models directory
            output_dir: Path to output directory for optimized models
        """
        self.models_dir = models_dir
        self.output_dir = output_dir
        
        # Create output directory if it doesn't exist
        os.makedirs(self.output_dir, exist_ok=True)
        
        # Initialize TensorRT logger
        self.trt_logger = trt.Logger(trt.Logger.WARNING)
        
        # Initialize ONNX Runtime session options
        self.ort_session_options = ort.SessionOptions()
        self.ort_session_options.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
        
        # Initialize optimization queue and worker thread
        self.optimization_queue = queue.Queue()
        self.optimization_thread = None
        self.optimization_thread_running = False
        
        # Initialize results cache
        self.results_cache = {}
    
    def start_optimization_worker(self):
        """Start background optimization worker thread."""
        if self.optimization_thread is not None and self.optimization_thread.is_alive():
            logger.warning("Optimization worker thread is already running")
            return
        
        self.optimization_thread_running = True
        self.optimization_thread = threading.Thread(target=self._optimization_worker, daemon=True)
        self.optimization_thread.start()
        
        logger.info("Started optimization worker thread")
    
    def stop_optimization_worker(self):
        """Stop background optimization worker thread."""
        if self.optimization_thread is None or not self.optimization_thread.is_alive():
            logger.warning("Optimization worker thread is not running")
            return
        
        self.optimization_thread_running = False
        self.optimization_thread.join(timeout=5.0)
        
        logger.info("Stopped optimization worker thread")
    
    def _optimization_worker(self):
        """Background worker thread for processing optimization queue."""
        logger.info("Optimization worker thread started")
        
        while self.optimization_thread_running:
            try:
                # Get item from queue with timeout
                try:
                    item = self.optimization_queue.get(timeout=1.0)
                except queue.Empty:
                    continue
                
                # Process item
                try:
                    config = item.get("config")
                    callback = item.get("callback")
                    
                    logger.info(f"Processing optimization: {config.model_id}")
                    
                    # Perform optimization
                    try:
                        result = self.optimize_model(config)
                        
                        # Cache result
                        self.results_cache[config.model_id] = result
                        
                        # Call callback if provided
                        if callback:
                            callback(result)
                    except Exception as e:
                        logger.error(f"Error optimizing model {config.model_id}: {e}")
                        
                        # Call callback with None if provided
                        if callback:
                            callback(None)
                    
                    # Mark item as done
                    self.optimization_queue.task_done()
                except Exception as e:
                    logger.error(f"Error processing optimization item: {e}")
                    
                    # Mark item as done
                    self.optimization_queue.task_done()
            except Exception as e:
                logger.error(f"Error in optimization worker thread: {e}")
        
        logger.info("Optimization worker thread stopped")
    
    def queue_optimization(self, config: OptimizationConfig, callback: Optional[Callable[[Optional[OptimizationResult]], None]] = None):
        """
        Queue model optimization.
        
        Args:
            config: Optimization configuration
            callback: Callback function to call with optimization result
        """
        try:
            # Add item to optimization queue
            self.optimization_queue.put({
                "config": config,
                "callback": callback
            })
            
            logger.info(f"Queued optimization: {config.model_id}")
        except Exception as e:
            logger.error(f"Error queuing optimization: {e}")
    
    def optimize_model(self, config: OptimizationConfig) -> OptimizationResult:
        """
        Optimize model based on configuration.
        
        Args:
            config: Optimization configuration
        
        Returns:
            Optimization result
        """
        try:
            # Get model path
            model_path = os.path.join(self.models_dir, config.model_name)
            if not os.path.exists(model_path):
                raise FileNotFoundError(f"Model not found: {model_path}")
            
            # Create output directory
            output_dir = os.path.join(self.output_dir, config.model_id)
            os.makedirs(output_dir, exist_ok=True)
            
            # Optimize based on model type
            if config.model_type == "pytorch":
                result = self._optimize_pytorch_model(config, model_path, output_dir)
            elif config.model_type == "onnx":
                result = self._optimize_onnx_model(config, model_path, output_dir)
            elif config.model_type == "tensorrt":
                result = self._optimize_tensorrt_model(config, model_path, output_dir)
            else:
                raise ValueError(f"Unsupported model type: {config.model_type}")
            
            logger.info(f"Optimized model: {config.model_id}")
            
            return result
        except Exception as e:
            logger.error(f"Error optimizing model: {e}")
            raise
    
    def _optimize_pytorch_model(self, config: OptimizationConfig, model_path: str, output_dir: str) -> OptimizationResult:
        """
        Optimize PyTorch model.
        
        Args:
            config: Optimization configuration
            model_path: Path to PyTorch model
            output_dir: Output directory
        
        Returns:
            Optimization result
        """
        try:
            # Load PyTorch model
            model = torch.load(model_path, map_location="cuda")
            model.eval()
            
            # Create dummy input
            dummy_input = torch.randn(config.input_shape, device="cuda")
            
            # Export to ONNX
            onnx_path = os.path.join(output_dir, f"{config.model_name}.onnx")
            torch.onnx.export(
                model,
                dummy_input,
                onnx_path,
                input_names=["input"],
                output_names=["output"],
                dynamic_axes={"input": {0: "batch_size"}, "output": {0: "batch_size"}} if config.enable_dynamic_shapes else None,
                opset_version=13,
                do_constant_folding=True
            )
            
            # Optimize ONNX model
            onnx_config = OptimizationConfig(
                model_id=config.model_id,
                model_name=f"{config.model_name}.onnx",
                model_type="onnx",
                input_shape=config.input_shape,
                optimization_level=config.optimization_level,
                enable_dynamic_shapes=config.enable_dynamic_shapes,
                enable_cuda_graphs=config.enable_cuda_graphs,
                batch_size=config.batch_size,
                workspace_size=config.workspace_size,
                calibration_dataset=config.calibration_dataset,
                calibration_batch_size=config.calibration_batch_size,
                calibration_batches=config.calibration_batches,
                parameters=config.parameters
            )
            
            return self._optimize_onnx_model(onnx_config, onnx_path, output_dir)
        except Exception as e:
            logger.error(f"Error optimizing PyTorch model: {e}")
            raise
    
    def _optimize_onnx_model(self, config: OptimizationConfig, model_path: str, output_dir: str) -> OptimizationResult:
        """
        Optimize ONNX model.
        
        Args:
            config: Optimization configuration
            model_path: Path to ONNX model
            output_dir: Output directory
        
        Returns:
            Optimization result
        """
        try:
            # Load and check ONNX model
            onnx_model = onnx.load(model_path)
            onnx.checker.check_model(onnx_model)
            
            # Optimize ONNX model
            optimized_model = onnx.optimizer.optimize(onnx_model)
            
            # Save optimized ONNX model
            optimized_onnx_path = os.path.join(output_dir, f"{os.path.basename(model_path)}")
            onnx.save(optimized_model, optimized_onnx_path)
            
            # Create ONNX Runtime session
            session = ort.InferenceSession(
                optimized_onnx_path,
                providers=["CUDAExecutionProvider", "CPUExecutionProvider"],
                sess_options=self.ort_session_options
            )
            
            # Get input and output details
            input_name = session.get_inputs()[0].name
            output_names = [output.name for output in session.get_outputs()]
            
            # Create dummy input
            dummy_input = np.random.randn(*config.input_shape).astype(np.float32)
            
            # Benchmark inference
            latency_ms, throughput_fps, memory_mb, output_shapes = self._benchmark_onnx_inference(
                session, input_name, output_names, dummy_input, config.batch_size
            )
            
            # Convert to TensorRT if requested
            if config.optimization_level != OptimizationLevel.NONE:
                # Create TensorRT config
                trt_config = OptimizationConfig(
                    model_id=config.model_id,
                    model_name=os.path.basename(optimized_onnx_path),
                    model_type="tensorrt",
                    input_shape=config.input_shape,
                    optimization_level=config.optimization_level,
                    enable_dynamic_shapes=config.enable_dynamic_shapes,
                    enable_cuda_graphs=config.enable_cuda_graphs,
                    batch_size=config.batch_size,
                    workspace_size=config.workspace_size,
                    calibration_dataset=config.calibration_dataset,
                    calibration_batch_size=config.calibration_batch_size,
                    calibration_batches=config.calibration_batches,
                    parameters=config.parameters
                )
                
                # Optimize with TensorRT
                return self._optimize_tensorrt_model(trt_config, optimized_onnx_path, output_dir)
            
            # Create optimization result
            result = OptimizationResult(
                model_id=config.model_id,
                optimized_model_path=optimized_onnx_path,
                original_model_path=model_path,
                optimization_level=OptimizationLevel.NONE,
                input_shape=config.input_shape,
                output_shapes=output_shapes,
                throughput_fps=throughput_fps,
                latency_ms=latency_ms,
                memory_mb=memory_mb
            )
            
            return result
        except Exception as e:
            logger.error(f"Error optimizing ONNX model: {e}")
            raise
    
    def _optimize_tensorrt_model(self, config: OptimizationConfig, model_path: str, output_dir: str) -> OptimizationResult:
        """
        Optimize model with TensorRT.
        
        Args:
            config: Optimization configuration
            model_path: Path to model (ONNX or TensorRT)
            output_dir: Output directory
        
        Returns:
            Optimization result
        """
        try:
            # Check if model is already TensorRT engine
            if model_path.endswith(".engine"):
                # Load TensorRT engine
                with open(model_path, "rb") as f:
                    engine_data = f.read()
                
                # Create runtime and engine
                runtime = trt.Runtime(self.trt_logger)
                engine = runtime.deserialize_cuda_engine(engine_data)
                
                # Create execution context
                context = engine.create_execution_context()
                
                # Get input and output details
                input_idx = engine.get_binding_index("input")
                output_idxs = [i for i in range(engine.num_bindings) if i != input_idx]
                
                # Create dummy input
                dummy_input = np.random.randn(*config.input_shape).astype(np.float32)
                
                # Benchmark inference
                latency_ms, throughput_fps, memory_mb, output_shapes = self._benchmark_tensorrt_inference(
                    engine, context, input_idx, output_idxs, dummy_input, config.batch_size
                )
                
                # Create optimization result
                result = OptimizationResult(
                    model_id=config.model_id,
                    optimized_model_path=model_path,
                    original_model_path=model_path,
                    optimization_level=config.optimization_level,
                    input_shape=config.input_shape,
                    output_shapes=output_shapes,
                    throughput_fps=throughput_fps,
                    latency_ms=latency_ms,
                    memory_mb=memory_mb
                )
                
                return result
            
            # Create TensorRT builder and network
            builder = trt.Builder(self.trt_logger)
            network = builder.create_network(1 << int(trt.NetworkDefinitionCreationFlag.EXPLICIT_BATCH))
            
            # Create ONNX parser
            parser = trt.OnnxParser(network, self.trt_logger)
            
            # Parse ONNX model
            with open(model_path, "rb") as f:
                if not parser.parse(f.read()):
                    for error in range(parser.num_errors):
                        logger.error(f"ONNX parsing error: {parser.get_error(error)}")
                    raise RuntimeError("Failed to parse ONNX model")
            
            # Create config
            builder_config = builder.create_builder_config()
            builder_config.max_workspace_size = config.workspace_size
            
            # Set optimization level
            if config.optimization_level == OptimizationLevel.FP16:
                if builder.platform_has_fast_fp16:
                    builder_config.set_flag(trt.BuilderFlag.FP16)
                else:
                    logger.warning("Platform does not support fast FP16, using FP32 instead")
            elif config.optimization_level == OptimizationLevel.INT8:
                if builder.platform_has_fast_int8:
                    builder_config.set_flag(trt.BuilderFlag.INT8)
                    
                    # Set INT8 calibrator if calibration dataset is provided
                    if config.calibration_dataset:
                        calibrator = INT8Calibrator(
                            calibration_dataset=config.calibration_dataset,
                            input_shape=config.input_shape,
                            batch_size=config.calibration_batch_size,
                            batches=config.calibration_batches
                        )
                        builder_config.int8_calibrator = calibrator
                    else:
                        logger.warning("INT8 calibration dataset not provided, using dynamic range")
                else:
                    logger.warning("Platform does not support fast INT8, using FP32 instead")
            
            # Set dynamic shapes if enabled
            if config.enable_dynamic_shapes:
                profile = builder.create_optimization_profile()
                input_name = network.get_input(0).name
                input_shape = config.input_shape
                min_shape = (1,) + input_shape[1:]
                opt_shape = input_shape
                max_shape = (config.batch_size * 2,) + input_shape[1:]
                profile.set_shape(input_name, min_shape, opt_shape, max_shape)
                builder_config.add_optimization_profile(profile)
            
            # Build engine
            engine = builder.build_engine(network, builder_config)
            if engine is None:
                raise RuntimeError("Failed to build TensorRT engine")
            
            # Save engine
            engine_path = os.path.join(output_dir, f"{os.path.splitext(os.path.basename(model_path))[0]}.engine")
            with open(engine_path, "wb") as f:
                f.write(engine.serialize())
            
            # Create execution context
            context = engine.create_execution_context()
            
            # Get input and output details
            input_idx = engine.get_binding_index("input")
            output_idxs = [i for i in range(engine.num_bindings) if i != input_idx]
            
            # Create dummy input
            dummy_input = np.random.randn(*config.input_shape).astype(np.float32)
            
            # Benchmark inference
            latency_ms, throughput_fps, memory_mb, output_shapes = self._benchmark_tensorrt_inference(
                engine, context, input_idx, output_idxs, dummy_input, config.batch_size
            )
            
            # Create optimization result
            result = OptimizationResult(
                model_id=config.model_id,
                optimized_model_path=engine_path,
                original_model_path=model_path,
                optimization_level=config.optimization_level,
                input_shape=config.input_shape,
                output_shapes=output_shapes,
                throughput_fps=throughput_fps,
                latency_ms=latency_ms,
                memory_mb=memory_mb
            )
            
            return result
        except Exception as e:
            logger.error(f"Error optimizing TensorRT model: {e}")
            raise
    
    def _benchmark_onnx_inference(self, session, input_name: str, output_names: List[str], dummy_input: np.ndarray, batch_size: int, iterations: int = 100, warmup: int = 10) -> Tuple[float, float, float, List[Tuple[int, ...]]]:
        """
        Benchmark ONNX inference.
        
        Args:
            session: ONNX Runtime session
            input_name: Input tensor name
            output_names: Output tensor names
            dummy_input: Dummy input data
            batch_size: Batch size
            iterations: Number of iterations
            warmup: Number of warmup iterations
        
        Returns:
            Tuple of latency (ms), throughput (FPS), memory usage (MB), and output shapes
        """
        try:
            # Prepare input
            input_dict = {input_name: dummy_input}
            
            # Warmup
            for _ in range(warmup):
                outputs = session.run(output_names, input_dict)
            
            # Benchmark
            start_time = time.time()
            for _ in range(iterations):
                outputs = session.run(output_names, input_dict)
            end_time = time.time()
            
            # Calculate metrics
            total_time = end_time - start_time
            latency_ms = (total_time / iterations) * 1000
            throughput_fps = (iterations * batch_size) / total_time
            
            # Get output shapes
            output_shapes = [output.shape for output in outputs]
            
            # Estimate memory usage (rough approximation)
            input_size = dummy_input.nbytes
            output_size = sum(output.nbytes for output in outputs)
            model_size = os.path.getsize(session._model_path)
            memory_mb = (input_size + output_size + model_size) / (1024 * 1024)
            
            return latency_ms, throughput_fps, memory_mb, output_shapes
        except Exception as e:
            logger.error(f"Error benchmarking ONNX inference: {e}")
            raise
    
    def _benchmark_tensorrt_inference(self, engine, context, input_idx: int, output_idxs: List[int], dummy_input: np.ndarray, batch_size: int, iterations: int = 100, warmup: int = 10) -> Tuple[float, float, float, List[Tuple[int, ...]]]:
        """
        Benchmark TensorRT inference.
        
        Args:
            engine: TensorRT engine
            context: TensorRT execution context
            input_idx: Input binding index
            output_idxs: Output binding indices
            dummy_input: Dummy input data
            batch_size: Batch size
            iterations: Number of iterations
            warmup: Number of warmup iterations
        
        Returns:
            Tuple of latency (ms), throughput (FPS), memory usage (MB), and output shapes
        """
        try:
            # Allocate device memory
            d_input = cudart.cudaMalloc(dummy_input.nbytes)[1]
            
            # Allocate output memory
            outputs = []
            d_outputs = []
            output_shapes = []
            
            for output_idx in output_idxs:
                shape = engine.get_binding_shape(output_idx)
                if shape[0] == -1:  # Dynamic shape
                    shape = (batch_size,) + shape[1:]
                    context.set_binding_shape(output_idx, shape)
                
                output_shapes.append(shape)
                output = np.empty(shape, dtype=np.float32)
                d_output = cudart.cudaMalloc(output.nbytes)[1]
                outputs.append(output)
                d_outputs.append(d_output)
            
            # Prepare bindings
            bindings = [int(d_input)] + [int(d_output) for d_output in d_outputs]
            
            # Copy input to device
            cudart.cudaMemcpy(d_input, dummy_input.ctypes.data, dummy_input.nbytes, cudart.cudaMemcpyKind.cudaMemcpyHostToDevice)
            
            # Warmup
            for _ in range(warmup):
                context.execute_v2(bindings)
            
            # Benchmark
            start_time = time.time()
            for _ in range(iterations):
                context.execute_v2(bindings)
            
            # Synchronize
            cudart.cudaDeviceSynchronize()
            
            end_time = time.time()
            
            # Copy outputs to host
            for i, d_output in enumerate(d_outputs):
                cudart.cudaMemcpy(outputs[i].ctypes.data, d_output, outputs[i].nbytes, cudart.cudaMemcpyKind.cudaMemcpyDeviceToHost)
            
            # Calculate metrics
            total_time = end_time - start_time
            latency_ms = (total_time / iterations) * 1000
            throughput_fps = (iterations * batch_size) / total_time
            
            # Estimate memory usage (rough approximation)
            input_size = dummy_input.nbytes
            output_size = sum(output.nbytes for output in outputs)
            engine_size = engine.serialize().nbytes
            memory_mb = (input_size + output_size + engine_size) / (1024 * 1024)
            
            # Free device memory
            cudart.cudaFree(d_input)
            for d_output in d_outputs:
                cudart.cudaFree(d_output)
            
            return latency_ms, throughput_fps, memory_mb, output_shapes
        except Exception as e:
            logger.error(f"Error benchmarking TensorRT inference: {e}")
            raise
    
    def get_optimization_result(self, model_id: str) -> Optional[OptimizationResult]:
        """
        Get optimization result.
        
        Args:
            model_id: Model ID
        
        Returns:
            Optimization result or None if not found
        """
        return self.results_cache.get(model_id)
    
    def list_optimization_results(self) -> List[OptimizationResult]:
        """
        List all optimization results.
        
        Returns:
            List of optimization results
        """
        return list(self.results_cache.values())
    
    def save_optimization_result(self, result: OptimizationResult, file_path: str) -> bool:
        """
        Save optimization result to file.
        
        Args:
            result: Optimization result
            file_path: Output file path
        
        Returns:
            True if successful, False otherwise
        """
        try:
            with open(file_path, "w") as f:
                json.dump(result.to_dict(), f, indent=2)
            
            return True
        except Exception as e:
            logger.error(f"Error saving optimization result: {e}")
            return False
    
    def load_optimization_result(self, file_path: str) -> Optional[OptimizationResult]:
        """
        Load optimization result from file.
        
        Args:
            file_path: Input file path
        
        Returns:
            Optimization result or None if loading failed
        """
        try:
            with open(file_path, "r") as f:
                data = json.load(f)
            
            result = OptimizationResult.from_dict(data)
            
            # Add to cache
            self.results_cache[result.model_id] = result
            
            return result
        except Exception as e:
            logger.error(f"Error loading optimization result: {e}")
            return None


class BatchProcessor:
    """
    Batch processor for efficient inference.
    
    Provides functionality for batching inputs and processing them efficiently.
    """
    
    def __init__(self, batch_size: int, max_latency_ms: float = 100.0):
        """
        Initialize batch processor.
        
        Args:
            batch_size: Maximum batch size
            max_latency_ms: Maximum latency in milliseconds
        """
        self.batch_size = batch_size
        self.max_latency_ms = max_latency_ms
        
        # Initialize batch queue and worker thread
        self.batch_queue = queue.Queue()
        self.batch_thread = None
        self.batch_thread_running = False
        
        # Initialize result dictionary
        self.results = {}
        self.results_lock = threading.Lock()
        
        # Initialize processing function
        self.process_batch_fn = None
    
    def start_batch_worker(self, process_batch_fn: Callable[[List[np.ndarray]], List[np.ndarray]]):
        """
        Start background batch worker thread.
        
        Args:
            process_batch_fn: Function to process batch of inputs
        """
        if self.batch_thread is not None and self.batch_thread.is_alive():
            logger.warning("Batch worker thread is already running")
            return
        
        self.process_batch_fn = process_batch_fn
        self.batch_thread_running = True
        self.batch_thread = threading.Thread(target=self._batch_worker, daemon=True)
        self.batch_thread.start()
        
        logger.info("Started batch worker thread")
    
    def stop_batch_worker(self):
        """Stop background batch worker thread."""
        if self.batch_thread is None or not self.batch_thread.is_alive():
            logger.warning("Batch worker thread is not running")
            return
        
        self.batch_thread_running = False
        self.batch_thread.join(timeout=5.0)
        
        logger.info("Stopped batch worker thread")
    
    def _batch_worker(self):
        """Background worker thread for processing batch queue."""
        logger.info("Batch worker thread started")
        
        while self.batch_thread_running:
            try:
                # Collect batch
                batch_items = []
                batch_ids = []
                
                # Get first item with timeout
                try:
                    item = self.batch_queue.get(timeout=1.0)
                    batch_items.append(item["input"])
                    batch_ids.append(item["id"])
                except queue.Empty:
                    continue
                
                # Collect more items up to batch size or max latency
                start_time = time.time()
                while len(batch_items) < self.batch_size:
                    elapsed_ms = (time.time() - start_time) * 1000
                    if elapsed_ms > self.max_latency_ms:
                        break
                    
                    try:
                        item = self.batch_queue.get(timeout=max(0.001, (self.max_latency_ms - elapsed_ms) / 1000))
                        batch_items.append(item["input"])
                        batch_ids.append(item["id"])
                    except queue.Empty:
                        break
                
                # Process batch
                if batch_items:
                    try:
                        # Process batch
                        batch_results = self.process_batch_fn(batch_items)
                        
                        # Store results
                        with self.results_lock:
                            for i, batch_id in enumerate(batch_ids):
                                self.results[batch_id] = batch_results[i]
                        
                        # Mark items as done
                        for _ in range(len(batch_items)):
                            self.batch_queue.task_done()
                    except Exception as e:
                        logger.error(f"Error processing batch: {e}")
                        
                        # Mark items as done
                        for _ in range(len(batch_items)):
                            self.batch_queue.task_done()
            except Exception as e:
                logger.error(f"Error in batch worker thread: {e}")
        
        logger.info("Batch worker thread stopped")
    
    def process(self, input_data: np.ndarray, timeout_ms: float = 1000.0) -> Optional[np.ndarray]:
        """
        Process input data.
        
        Args:
            input_data: Input data
            timeout_ms: Timeout in milliseconds
        
        Returns:
            Processed output or None if timeout
        """
        try:
            # Generate unique ID
            batch_id = str(uuid.uuid4())
            
            # Add to batch queue
            self.batch_queue.put({
                "id": batch_id,
                "input": input_data
            })
            
            # Wait for result
            start_time = time.time()
            while (time.time() - start_time) * 1000 < timeout_ms:
                # Check if result is available
                with self.results_lock:
                    if batch_id in self.results:
                        result = self.results[batch_id]
                        del self.results[batch_id]
                        return result
                
                # Sleep briefly
                time.sleep(0.001)
            
            logger.warning(f"Timeout waiting for batch result: {batch_id}")
            return None
        except Exception as e:
            logger.error(f"Error processing input: {e}")
            return None


class ParallelInferenceEngine:
    """
    Parallel inference engine for efficient model inference.
    
    Provides functionality for running multiple models in parallel.
    """
    
    def __init__(self, num_streams: int = 2):
        """
        Initialize parallel inference engine.
        
        Args:
            num_streams: Number of parallel inference streams
        """
        self.num_streams = num_streams
        
        # Initialize inference queues and worker threads
        self.inference_queues = [queue.Queue() for _ in range(num_streams)]
        self.inference_threads = [None] * num_streams
        self.inference_thread_running = [False] * num_streams
        
        # Initialize result dictionary
        self.results = {}
        self.results_lock = threading.Lock()
        
        # Initialize processing functions
        self.process_fns = [None] * num_streams
    
    def start_inference_workers(self, process_fns: List[Callable[[np.ndarray], np.ndarray]]):
        """
        Start background inference worker threads.
        
        Args:
            process_fns: List of functions to process inputs
        """
        if len(process_fns) != self.num_streams:
            raise ValueError(f"Number of processing functions ({len(process_fns)}) must match number of streams ({self.num_streams})")
        
        for i in range(self.num_streams):
            if self.inference_threads[i] is not None and self.inference_threads[i].is_alive():
                logger.warning(f"Inference worker thread {i} is already running")
                continue
            
            self.process_fns[i] = process_fns[i]
            self.inference_thread_running[i] = True
            self.inference_threads[i] = threading.Thread(target=self._inference_worker, args=(i,), daemon=True)
            self.inference_threads[i].start()
            
            logger.info(f"Started inference worker thread {i}")
    
    def stop_inference_workers(self):
        """Stop background inference worker threads."""
        for i in range(self.num_streams):
            if self.inference_threads[i] is None or not self.inference_threads[i].is_alive():
                logger.warning(f"Inference worker thread {i} is not running")
                continue
            
            self.inference_thread_running[i] = False
            self.inference_threads[i].join(timeout=5.0)
            
            logger.info(f"Stopped inference worker thread {i}")
    
    def _inference_worker(self, stream_idx: int):
        """
        Background worker thread for processing inference queue.
        
        Args:
            stream_idx: Stream index
        """
        logger.info(f"Inference worker thread {stream_idx} started")
        
        while self.inference_thread_running[stream_idx]:
            try:
                # Get item from queue with timeout
                try:
                    item = self.inference_queues[stream_idx].get(timeout=1.0)
                except queue.Empty:
                    continue
                
                # Process item
                try:
                    # Process input
                    result = self.process_fns[stream_idx](item["input"])
                    
                    # Store result
                    with self.results_lock:
                        self.results[item["id"]] = result
                    
                    # Mark item as done
                    self.inference_queues[stream_idx].task_done()
                except Exception as e:
                    logger.error(f"Error processing inference item: {e}")
                    
                    # Mark item as done
                    self.inference_queues[stream_idx].task_done()
            except Exception as e:
                logger.error(f"Error in inference worker thread {stream_idx}: {e}")
        
        logger.info(f"Inference worker thread {stream_idx} stopped")
    
    def process(self, input_data: np.ndarray, stream_idx: int, timeout_ms: float = 1000.0) -> Optional[np.ndarray]:
        """
        Process input data on specified stream.
        
        Args:
            input_data: Input data
            stream_idx: Stream index
            timeout_ms: Timeout in milliseconds
        
        Returns:
            Processed output or None if timeout
        """
        try:
            if stream_idx < 0 or stream_idx >= self.num_streams:
                raise ValueError(f"Invalid stream index: {stream_idx}")
            
            # Generate unique ID
            inference_id = str(uuid.uuid4())
            
            # Add to inference queue
            self.inference_queues[stream_idx].put({
                "id": inference_id,
                "input": input_data
            })
            
            # Wait for result
            start_time = time.time()
            while (time.time() - start_time) * 1000 < timeout_ms:
                # Check if result is available
                with self.results_lock:
                    if inference_id in self.results:
                        result = self.results[inference_id]
                        del self.results[inference_id]
                        return result
                
                # Sleep briefly
                time.sleep(0.001)
            
            logger.warning(f"Timeout waiting for inference result: {inference_id}")
            return None
        except Exception as e:
            logger.error(f"Error processing input: {e}")
            return None


# Example usage
if __name__ == "__main__":
    # Setup logging
    logging.basicConfig(level=logging.INFO)
    
    # Create model optimizer
    optimizer = ModelOptimizer(
        models_dir="models",
        output_dir="models/optimized"
    )
    
    # Start optimization worker
    optimizer.start_optimization_worker()
    
    # Create optimization configuration
    config = OptimizationConfig(
        model_id="sandwich_detector",
        model_name="sandwich_detector.onnx",
        model_type="onnx",
        input_shape=(1, 3, 640, 640),
        optimization_level=OptimizationLevel.FP16,
        enable_dynamic_shapes=True,
        batch_size=4
    )
    
    # Queue optimization
    def optimization_callback(result):
        if result:
            print(f"Optimization complete: {result.model_id}")
            print(f"Throughput: {result.throughput_fps:.2f} FPS")
            print(f"Latency: {result.latency_ms:.2f} ms")
        else:
            print("Optimization failed")
    
    optimizer.queue_optimization(config, optimization_callback)
    
    # Wait for optimization to complete
    time.sleep(10)
    
    # Stop optimization worker
    optimizer.stop_optimization_worker()
    
    # Create batch processor
    batch_processor = BatchProcessor(batch_size=4, max_latency_ms=50.0)
    
    # Define batch processing function
    def process_batch(batch_inputs):
        # Simulate batch processing
        batch_outputs = []
        for input_data in batch_inputs:
            # Process input
            output = input_data * 2  # Dummy processing
            batch_outputs.append(output)
        return batch_outputs
    
    # Start batch worker
    batch_processor.start_batch_worker(process_batch)
    
    # Process inputs
    for i in range(10):
        input_data = np.random.randn(3, 640, 640).astype(np.float32)
        result = batch_processor.process(input_data)
        if result is not None:
            print(f"Processed input {i}: {result.shape}")
    
    # Stop batch worker
    batch_processor.stop_batch_worker()
    
    # Create parallel inference engine
    engine = ParallelInferenceEngine(num_streams=2)
    
    # Define processing functions
    def process_stream1(input_data):
        # Simulate processing
        return input_data * 2  # Dummy processing
    
    def process_stream2(input_data):
        # Simulate processing
        return input_data * 3  # Dummy processing
    
    # Start inference workers
    engine.start_inference_workers([process_stream1, process_stream2])
    
    # Process inputs on different streams
    for i in range(10):
        input_data = np.random.randn(3, 640, 640).astype(np.float32)
        stream_idx = i % 2
        result = engine.process(input_data, stream_idx)
        if result is not None:
            print(f"Processed input {i} on stream {stream_idx}: {result.shape}")
    
    # Stop inference workers
    engine.stop_inference_workers()
