"""
Model training pipeline for OPSC Sandwich Quality Inspection System.
Provides comprehensive functionality for training and managing defect detection models.

Version: 1.0.0
Last Updated: 2025-04-22
"""

import os
import sys
import time
import json
import logging
import numpy as np
import cv2
from typing import Dict, List, Optional, Tuple, Union, Any, BinaryIO, Callable
from dataclasses import dataclass, field
import threading
import queue
import sqlite3
from pathlib import Path
import datetime
import uuid
import shutil
import yaml
import tempfile
import traceback

# Import Roboflow client and model manager
from models.roboflow.roboflow_client import RoboflowClient, Dataset, TrainingJob
from src.core.inference.model_manager import ModelManager, ModelConfig, TrainingConfig

# Setup logging
logger = logging.getLogger(__name__)

@dataclass
class TrainingPipeline:
    """Training pipeline configuration."""
    pipeline_id: str
    name: str
    description: str
    dataset_id: str
    model_type: str
    epochs: int
    batch_size: int
    learning_rate: float
    augmentation: bool
    validation_split: float
    auto_deploy: bool
    created_at: str = field(default_factory=lambda: datetime.datetime.now().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.datetime.now().isoformat())
    parameters: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "pipeline_id": self.pipeline_id,
            "name": self.name,
            "description": self.description,
            "dataset_id": self.dataset_id,
            "model_type": self.model_type,
            "epochs": self.epochs,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "augmentation": self.augmentation,
            "validation_split": self.validation_split,
            "auto_deploy": self.auto_deploy,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "parameters": self.parameters
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'TrainingPipeline':
        """Create from dictionary."""
        return cls(
            pipeline_id=data["pipeline_id"],
            name=data["name"],
            description=data["description"],
            dataset_id=data["dataset_id"],
            model_type=data["model_type"],
            epochs=data["epochs"],
            batch_size=data["batch_size"],
            learning_rate=data["learning_rate"],
            augmentation=data.get("augmentation", True),
            validation_split=data.get("validation_split", 0.2),
            auto_deploy=data.get("auto_deploy", False),
            created_at=data.get("created_at", datetime.datetime.now().isoformat()),
            updated_at=data.get("updated_at", datetime.datetime.now().isoformat()),
            parameters=data.get("parameters", {})
        )


@dataclass
class TrainingRun:
    """Training run information."""
    run_id: str
    pipeline_id: str
    job_id: str
    status: str
    created_at: str
    completed_at: Optional[str] = None
    progress: float = 0.0
    version_id: Optional[int] = None
    model_id: Optional[str] = None
    metrics: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "run_id": self.run_id,
            "pipeline_id": self.pipeline_id,
            "job_id": self.job_id,
            "status": self.status,
            "created_at": self.created_at,
            "completed_at": self.completed_at,
            "progress": self.progress,
            "version_id": self.version_id,
            "model_id": self.model_id,
            "metrics": self.metrics
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'TrainingRun':
        """Create from dictionary."""
        return cls(
            run_id=data["run_id"],
            pipeline_id=data["pipeline_id"],
            job_id=data["job_id"],
            status=data["status"],
            created_at=data["created_at"],
            completed_at=data.get("completed_at"),
            progress=data.get("progress", 0.0),
            version_id=data.get("version_id"),
            model_id=data.get("model_id"),
            metrics=data.get("metrics", {})
        )


@dataclass
class DataCollectionConfig:
    """Data collection configuration."""
    config_id: str
    name: str
    description: str
    dataset_id: str
    source_type: str  # 'camera', 'directory', 'production'
    source_params: Dict[str, Any]
    collection_interval: int  # seconds
    max_images: int
    require_annotation: bool
    auto_annotate: bool
    created_at: str = field(default_factory=lambda: datetime.datetime.now().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.datetime.now().isoformat())
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "config_id": self.config_id,
            "name": self.name,
            "description": self.description,
            "dataset_id": self.dataset_id,
            "source_type": self.source_type,
            "source_params": self.source_params,
            "collection_interval": self.collection_interval,
            "max_images": self.max_images,
            "require_annotation": self.require_annotation,
            "auto_annotate": self.auto_annotate,
            "created_at": self.created_at,
            "updated_at": self.updated_at
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'DataCollectionConfig':
        """Create from dictionary."""
        return cls(
            config_id=data["config_id"],
            name=data["name"],
            description=data["description"],
            dataset_id=data["dataset_id"],
            source_type=data["source_type"],
            source_params=data["source_params"],
            collection_interval=data["collection_interval"],
            max_images=data["max_images"],
            require_annotation=data["require_annotation"],
            auto_annotate=data["auto_annotate"],
            created_at=data.get("created_at", datetime.datetime.now().isoformat()),
            updated_at=data.get("updated_at", datetime.datetime.now().isoformat())
        )


class TrainingPipelineManager:
    """
    Model training pipeline manager for OPSC Sandwich Quality Inspection System.
    
    Provides comprehensive functionality for training and managing defect detection models.
    """
    
    def __init__(self, db_path: str, data_dir: str, model_manager: ModelManager, api_key: Optional[str] = None):
        """
        Initialize training pipeline manager.
        
        Args:
            db_path: Path to SQLite database file
            data_dir: Path to data directory
            model_manager: Model manager instance
            api_key: Roboflow API key (if None, will look for ROBOFLOW_API_KEY env var)
        """
        self.db_path = db_path
        self.data_dir = data_dir
        self.model_manager = model_manager
        self.api_key = api_key or os.environ.get("ROBOFLOW_API_KEY")
        
        # Create data directory if it doesn't exist
        os.makedirs(self.data_dir, exist_ok=True)
        
        # Initialize database
        self._init_database()
        
        # Initialize Roboflow client
        self.roboflow_client = RoboflowClient(api_key=self.api_key)
        
        # Initialize data collection threads
        self.collection_threads = {}
        self.collection_stop_events = {}
        
        # Initialize training monitoring thread
        self.training_monitor_thread = None
        self.training_monitor_running = False
        
        # Start training monitor
        self._start_training_monitor()
        
        logger.info("Initialized training pipeline manager")
    
    def _init_database(self):
        """Initialize database tables."""
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Create training_pipelines table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS training_pipelines (
                    pipeline_id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    description TEXT,
                    dataset_id TEXT NOT NULL,
                    model_type TEXT NOT NULL,
                    epochs INTEGER NOT NULL,
                    batch_size INTEGER NOT NULL,
                    learning_rate REAL NOT NULL,
                    augmentation INTEGER NOT NULL,
                    validation_split REAL NOT NULL,
                    auto_deploy INTEGER NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    parameters TEXT
                )
            """)
            
            # Create training_runs table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS training_runs (
                    run_id TEXT PRIMARY KEY,
                    pipeline_id TEXT NOT NULL,
                    job_id TEXT NOT NULL,
                    status TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    completed_at TEXT,
                    progress REAL NOT NULL,
                    version_id INTEGER,
                    model_id TEXT,
                    metrics TEXT,
                    FOREIGN KEY (pipeline_id) REFERENCES training_pipelines (pipeline_id)
                )
            """)
            
            # Create data_collection_configs table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS data_collection_configs (
                    config_id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    description TEXT,
                    dataset_id TEXT NOT NULL,
                    source_type TEXT NOT NULL,
                    source_params TEXT NOT NULL,
                    collection_interval INTEGER NOT NULL,
                    max_images INTEGER NOT NULL,
                    require_annotation INTEGER NOT NULL,
                    auto_annotate INTEGER NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
            """)
            
            # Create data_collection_sessions table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS data_collection_sessions (
                    session_id TEXT PRIMARY KEY,
                    config_id TEXT NOT NULL,
                    status TEXT NOT NULL,
                    start_time TEXT NOT NULL,
                    end_time TEXT,
                    images_collected INTEGER NOT NULL,
                    images_annotated INTEGER NOT NULL,
                    FOREIGN KEY (config_id) REFERENCES data_collection_configs (config_id)
                )
            """)
            
            # Commit changes
            conn.commit()
            
            # Close connection
            conn.close()
            
            logger.info("Initialized training pipeline database tables")
        except Exception as e:
            logger.error(f"Error initializing database: {e}")
            raise
    
    def _start_training_monitor(self):
        """Start training monitor thread."""
        if self.training_monitor_thread is not None and self.training_monitor_thread.is_alive():
            logger.warning("Training monitor thread is already running")
            return
        
        self.training_monitor_running = True
        self.training_monitor_thread = threading.Thread(target=self._training_monitor_worker, daemon=True)
        self.training_monitor_thread.start()
        
        logger.info("Started training monitor thread")
    
    def _training_monitor_worker(self):
        """Background worker thread for monitoring training runs."""
        logger.info("Training monitor thread started")
        
        while self.training_monitor_running:
            try:
                # Get active training runs
                conn = sqlite3.connect(self.db_path)
                conn.row_factory = sqlite3.Row
                cursor = conn.cursor()
                
                cursor.execute("""
                    SELECT * FROM training_runs
                    WHERE status IN ('queued', 'in_progress')
                """)
                
                active_runs = cursor.fetchall()
                conn.close()
                
                # Check status of each run
                for run in active_runs:
                    try:
                        # Get job status from Roboflow
                        job_status = self.model_manager.get_training_job_status(run["job_id"])
                        
                        # Update run status
                        self._update_training_run_status(
                            run["run_id"],
                            job_status["status"],
                            job_status["progress"],
                            job_status.get("version_id"),
                            job_status.get("metrics", {})
                        )
                        
                        # If job completed, handle completion
                        if job_status["status"] == "completed" and job_status.get("version_id") is not None:
                            self._handle_training_completion(run["run_id"], run["pipeline_id"], job_status["version_id"])
                    except Exception as e:
                        logger.error(f"Error monitoring training run {run['run_id']}: {e}")
                
                # Sleep before next check
                time.sleep(60)
            except Exception as e:
                logger.error(f"Error in training monitor thread: {e}")
                time.sleep(300)  # Longer sleep on error
        
        logger.info("Training monitor thread stopped")
    
    def _update_training_run_status(self, run_id: str, status: str, progress: float,
                                  version_id: Optional[int] = None, metrics: Optional[Dict[str, Any]] = None):
        """
        Update training run status.
        
        Args:
            run_id: Training run ID
            status: New status
            progress: Progress percentage
            version_id: Model version ID (if completed)
            metrics: Training metrics
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Update fields based on status
            if status in ["completed", "failed", "cancelled"]:
                # Job is complete
                cursor.execute("""
                    UPDATE training_runs
                    SET status = ?, completed_at = ?, progress = ?, version_id = ?, metrics = ?
                    WHERE run_id = ?
                """, (
                    status,
                    datetime.datetime.now().isoformat(),
                    progress,
                    version_id,
                    json.dumps(metrics or {}),
                    run_id
                ))
            else:
                # Job is in progress
                cursor.execute("""
                    UPDATE training_runs
                    SET status = ?, progress = ?
                    WHERE run_id = ?
                """, (
                    status,
                    progress,
                    run_id
                ))
            
            # Commit changes
            conn.commit()
            
            # Close connection
            conn.close()
            
            logger.info(f"Updated training run {run_id} status to {status} ({progress:.1f}%)")
        except Exception as e:
            logger.error(f"Error updating training run status: {e}")
    
    def _handle_training_completion(self, run_id: str, pipeline_id: str, version_id: int):
        """
        Handle training completion.
        
        Args:
            run_id: Training run ID
            pipeline_id: Training pipeline ID
            version_id: Model version ID
        """
        try:
            # Get pipeline configuration
            pipeline = self.get_pipeline(pipeline_id)
            if pipeline is None:
                logger.error(f"Pipeline {pipeline_id} not found")
                return
            
            # Create model if auto_deploy is enabled
            if pipeline.auto_deploy:
                # Create model
                model_name = f"{pipeline.name} v{version_id}"
                model_config = self.model_manager.create_model(
                    name=model_name,
                    workspace=self.roboflow_client.workspace,
                    project=self.roboflow_client.project,
                    version_id=version_id,
                    model_type=pipeline.model_type
                )
                
                if model_config:
                    # Update run with model ID
                    conn = sqlite3.connect(self.db_path)
                    cursor = conn.cursor()
                    
                    cursor.execute("""
                        UPDATE training_runs
                        SET model_id = ?
                        WHERE run_id = ?
                    """, (
                        model_config.model_id,
                        run_id
                    ))
                    
                    conn.commit()
                    conn.close()
                    
                    logger.info(f"Created and deployed model {model_name} (ID: {model_config.model_id}) from training run {run_id}")
                else:
                    logger.error(f"Failed to create model from training run {run_id}")
            else:
                logger.info(f"Auto-deploy disabled for pipeline {pipeline_id}, model not created")
        except Exception as e:
            logger.error(f"Error handling training completion: {e}")
    
    # Pipeline Management
    
    def create_pipeline(self, name: str, description: str, dataset_id: str, model_type: str = "yolov8",
                      epochs: int = 100, batch_size: int = 16, learning_rate: float = 0.001,
                      augmentation: bool = True, validation_split: float = 0.2,
                      auto_deploy: bool = False, parameters: Dict[str, Any] = None) -> Optional[TrainingPipeline]:
        """
        Create training pipeline.
        
        Args:
            name: Pipeline name
            description: Pipeline description
            dataset_id: Dataset ID
            model_type: Model type (yolov8, fasterrcnn, etc.)
            epochs: Number of training epochs
            batch_size: Training batch size
            learning_rate: Training learning rate
            augmentation: Whether to use data augmentation
            validation_split: Validation split ratio
            auto_deploy: Whether to automatically deploy trained models
            parameters: Additional parameters
        
        Returns:
            Training pipeline if successful, None otherwise
        """
        try:
            # Create pipeline ID
            pipeline_id = str(uuid.uuid4())
            
            # Create pipeline
            pipeline = TrainingPipeline(
                pipeline_id=pipeline_id,
                name=name,
                description=description,
                dataset_id=dataset_id,
                model_type=model_type,
                epochs=epochs,
                batch_size=batch_size,
                learning_rate=learning_rate,
                augmentation=augmentation,
                validation_split=validation_split,
                auto_deploy=auto_deploy,
                created_at=datetime.datetime.now().isoformat(),
                updated_at=datetime.datetime.now().isoformat(),
                parameters=parameters or {}
            )
            
            # Save to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute("""
                INSERT INTO training_pipelines (
                    pipeline_id, name, description, dataset_id, model_type,
                    epochs, batch_size, learning_rate, augmentation, validation_split,
                    auto_deploy, created_at, updated_at, parameters
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                pipeline.pipeline_id,
                pipeline.name,
                pipeline.description,
                pipeline.dataset_id,
                pipeline.model_type,
                pipeline.epochs,
                pipeline.batch_size,
                pipeline.learning_rate,
                int(pipeline.augmentation),
                pipeline.validation_split,
                int(pipeline.auto_deploy),
                pipeline.created_at,
                pipeline.updated_at,
                json.dumps(pipeline.parameters)
            ))
            
            conn.commit()
            conn.close()
            
            logger.info(f"Created training pipeline {name} (ID: {pipeline_id})")
            return pipeline
        except Exception as e:
            logger.error(f"Error creating training pipeline: {e}")
            return None
    
    def get_pipeline(self, pipeline_id: str) -> Optional[TrainingPipeline]:
        """
        Get training pipeline.
        
        Args:
            pipeline_id: Pipeline ID
        
        Returns:
            Training pipeline if found, None otherwise
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Get pipeline
            cursor.execute("SELECT * FROM training_pipelines WHERE pipeline_id = ?", (pipeline_id,))
            row = cursor.fetchone()
            
            # Close connection
            conn.close()
            
            if row is None:
                return None
            
            # Create pipeline
            pipeline = TrainingPipeline(
                pipeline_id=row["pipeline_id"],
                name=row["name"],
                description=row["description"],
                dataset_id=row["dataset_id"],
                model_type=row["model_type"],
                epochs=row["epochs"],
                batch_size=row["batch_size"],
                learning_rate=row["learning_rate"],
                augmentation=bool(row["augmentation"]),
                validation_split=row["validation_split"],
                auto_deploy=bool(row["auto_deploy"]),
                created_at=row["created_at"],
                updated_at=row["updated_at"],
                parameters=json.loads(row["parameters"]) if row["parameters"] else {}
            )
            
            return pipeline
        except Exception as e:
            logger.error(f"Error getting pipeline {pipeline_id}: {e}")
            return None
    
    def get_pipelines(self) -> List[TrainingPipeline]:
        """
        Get all training pipelines.
        
        Returns:
            List of training pipelines
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Get pipelines
            cursor.execute("SELECT * FROM training_pipelines")
            rows = cursor.fetchall()
            
            # Close connection
            conn.close()
            
            # Create pipelines
            pipelines = []
            for row in rows:
                pipeline = TrainingPipeline(
                    pipeline_id=row["pipeline_id"],
                    name=row["name"],
                    description=row["description"],
                    dataset_id=row["dataset_id"],
                    model_type=row["model_type"],
                    epochs=row["epochs"],
                    batch_size=row["batch_size"],
                    learning_rate=row["learning_rate"],
                    augmentation=bool(row["augmentation"]),
                    validation_split=row["validation_split"],
                    auto_deploy=bool(row["auto_deploy"]),
                    created_at=row["created_at"],
                    updated_at=row["updated_at"],
                    parameters=json.loads(row["parameters"]) if row["parameters"] else {}
                )
                pipelines.append(pipeline)
            
            return pipelines
        except Exception as e:
            logger.error(f"Error getting pipelines: {e}")
            return []
    
    def update_pipeline(self, pipeline_id: str, name: Optional[str] = None, description: Optional[str] = None,
                      dataset_id: Optional[str] = None, model_type: Optional[str] = None,
                      epochs: Optional[int] = None, batch_size: Optional[int] = None,
                      learning_rate: Optional[float] = None, augmentation: Optional[bool] = None,
                      validation_split: Optional[float] = None, auto_deploy: Optional[bool] = None,
                      parameters: Optional[Dict[str, Any]] = None) -> Optional[TrainingPipeline]:
        """
        Update training pipeline.
        
        Args:
            pipeline_id: Pipeline ID
            name: New pipeline name
            description: New pipeline description
            dataset_id: New dataset ID
            model_type: New model type
            epochs: New number of epochs
            batch_size: New batch size
            learning_rate: New learning rate
            augmentation: New augmentation setting
            validation_split: New validation split ratio
            auto_deploy: New auto-deploy setting
            parameters: New parameters
        
        Returns:
            Updated pipeline if successful, None otherwise
        """
        try:
            # Get current pipeline
            pipeline = self.get_pipeline(pipeline_id)
            if pipeline is None:
                logger.error(f"Pipeline {pipeline_id} not found")
                return None
            
            # Update fields
            if name is not None:
                pipeline.name = name
            if description is not None:
                pipeline.description = description
            if dataset_id is not None:
                pipeline.dataset_id = dataset_id
            if model_type is not None:
                pipeline.model_type = model_type
            if epochs is not None:
                pipeline.epochs = epochs
            if batch_size is not None:
                pipeline.batch_size = batch_size
            if learning_rate is not None:
                pipeline.learning_rate = learning_rate
            if augmentation is not None:
                pipeline.augmentation = augmentation
            if validation_split is not None:
                pipeline.validation_split = validation_split
            if auto_deploy is not None:
                pipeline.auto_deploy = auto_deploy
            if parameters is not None:
                pipeline.parameters = parameters
            
            # Update timestamp
            pipeline.updated_at = datetime.datetime.now().isoformat()
            
            # Save to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute("""
                UPDATE training_pipelines
                SET name = ?, description = ?, dataset_id = ?, model_type = ?,
                    epochs = ?, batch_size = ?, learning_rate = ?, augmentation = ?,
                    validation_split = ?, auto_deploy = ?, updated_at = ?, parameters = ?
                WHERE pipeline_id = ?
            """, (
                pipeline.name,
                pipeline.description,
                pipeline.dataset_id,
                pipeline.model_type,
                pipeline.epochs,
                pipeline.batch_size,
                pipeline.learning_rate,
                int(pipeline.augmentation),
                pipeline.validation_split,
                int(pipeline.auto_deploy),
                pipeline.updated_at,
                json.dumps(pipeline.parameters),
                pipeline.pipeline_id
            ))
            
            conn.commit()
            conn.close()
            
            logger.info(f"Updated pipeline {pipeline_id}")
            return pipeline
        except Exception as e:
            logger.error(f"Error updating pipeline {pipeline_id}: {e}")
            return None
    
    def delete_pipeline(self, pipeline_id: str) -> bool:
        """
        Delete training pipeline.
        
        Args:
            pipeline_id: Pipeline ID
        
        Returns:
            True if successful, False otherwise
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Delete pipeline
            cursor.execute("DELETE FROM training_pipelines WHERE pipeline_id = ?", (pipeline_id,))
            
            # Commit changes
            conn.commit()
            
            # Close connection
            conn.close()
            
            logger.info(f"Deleted pipeline {pipeline_id}")
            return True
        except Exception as e:
            logger.error(f"Error deleting pipeline {pipeline_id}: {e}")
            return False
    
    # Training Run Management
    
    def start_training(self, pipeline_id: str) -> Optional[str]:
        """
        Start training run.
        
        Args:
            pipeline_id: Pipeline ID
        
        Returns:
            Run ID if successful, None otherwise
        """
        try:
            # Get pipeline
            pipeline = self.get_pipeline(pipeline_id)
            if pipeline is None:
                logger.error(f"Pipeline {pipeline_id} not found")
                return None
            
            # Create training config
            training_config = self.model_manager.create_training_config(
                name=pipeline.name,
                dataset_id=pipeline.dataset_id,
                model_type=pipeline.model_type,
                epochs=pipeline.epochs,
                batch_size=pipeline.batch_size,
                learning_rate=pipeline.learning_rate,
                augmentation=pipeline.augmentation
            )
            
            if training_config is None:
                logger.error(f"Failed to create training configuration for pipeline {pipeline_id}")
                return None
            
            # Start training job
            job_id = self.model_manager.start_training(training_config.config_id)
            if job_id is None:
                logger.error(f"Failed to start training job for pipeline {pipeline_id}")
                return None
            
            # Create run ID
            run_id = str(uuid.uuid4())
            
            # Create training run
            run = TrainingRun(
                run_id=run_id,
                pipeline_id=pipeline_id,
                job_id=job_id,
                status="queued",
                created_at=datetime.datetime.now().isoformat(),
                progress=0.0
            )
            
            # Save to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute("""
                INSERT INTO training_runs (
                    run_id, pipeline_id, job_id, status, created_at, progress
                )
                VALUES (?, ?, ?, ?, ?, ?)
            """, (
                run.run_id,
                run.pipeline_id,
                run.job_id,
                run.status,
                run.created_at,
                run.progress
            ))
            
            conn.commit()
            conn.close()
            
            logger.info(f"Started training run {run_id} for pipeline {pipeline_id}")
            return run_id
        except Exception as e:
            logger.error(f"Error starting training for pipeline {pipeline_id}: {e}")
            return None
    
    def get_training_run(self, run_id: str) -> Optional[TrainingRun]:
        """
        Get training run.
        
        Args:
            run_id: Run ID
        
        Returns:
            Training run if found, None otherwise
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Get run
            cursor.execute("SELECT * FROM training_runs WHERE run_id = ?", (run_id,))
            row = cursor.fetchone()
            
            # Close connection
            conn.close()
            
            if row is None:
                return None
            
            # Create run
            run = TrainingRun(
                run_id=row["run_id"],
                pipeline_id=row["pipeline_id"],
                job_id=row["job_id"],
                status=row["status"],
                created_at=row["created_at"],
                completed_at=row["completed_at"],
                progress=row["progress"],
                version_id=row["version_id"],
                model_id=row["model_id"],
                metrics=json.loads(row["metrics"]) if row["metrics"] else {}
            )
            
            return run
        except Exception as e:
            logger.error(f"Error getting training run {run_id}: {e}")
            return None
    
    def get_training_runs(self, pipeline_id: Optional[str] = None, status: Optional[str] = None) -> List[TrainingRun]:
        """
        Get training runs.
        
        Args:
            pipeline_id: Filter by pipeline ID
            status: Filter by status
        
        Returns:
            List of training runs
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Build query
            query = "SELECT * FROM training_runs"
            params = []
            
            # Add filters
            filters = []
            if pipeline_id is not None:
                filters.append("pipeline_id = ?")
                params.append(pipeline_id)
            if status is not None:
                filters.append("status = ?")
                params.append(status)
            
            if filters:
                query += " WHERE " + " AND ".join(filters)
            
            # Add order
            query += " ORDER BY created_at DESC"
            
            # Execute query
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            # Close connection
            conn.close()
            
            # Create runs
            runs = []
            for row in rows:
                run = TrainingRun(
                    run_id=row["run_id"],
                    pipeline_id=row["pipeline_id"],
                    job_id=row["job_id"],
                    status=row["status"],
                    created_at=row["created_at"],
                    completed_at=row["completed_at"],
                    progress=row["progress"],
                    version_id=row["version_id"],
                    model_id=row["model_id"],
                    metrics=json.loads(row["metrics"]) if row["metrics"] else {}
                )
                runs.append(run)
            
            return runs
        except Exception as e:
            logger.error(f"Error getting training runs: {e}")
            return []
    
    def cancel_training_run(self, run_id: str) -> bool:
        """
        Cancel training run.
        
        Args:
            run_id: Run ID
        
        Returns:
            True if successful, False otherwise
        """
        try:
            # Get run
            run = self.get_training_run(run_id)
            if run is None:
                logger.error(f"Training run {run_id} not found")
                return False
            
            # Check if run can be cancelled
            if run.status not in ["queued", "in_progress"]:
                logger.error(f"Training run {run_id} cannot be cancelled (status: {run.status})")
                return False
            
            # TODO: Implement Roboflow job cancellation when API supports it
            # For now, just mark as cancelled in database
            
            # Update run status
            self._update_training_run_status(
                run_id,
                "cancelled",
                run.progress
            )
            
            logger.info(f"Cancelled training run {run_id}")
            return True
        except Exception as e:
            logger.error(f"Error cancelling training run {run_id}: {e}")
            return False
    
    def deploy_model_from_run(self, run_id: str, name: Optional[str] = None) -> Optional[str]:
        """
        Deploy model from training run.
        
        Args:
            run_id: Run ID
            name: Model name (if None, will use pipeline name + version)
        
        Returns:
            Model ID if successful, None otherwise
        """
        try:
            # Get run
            run = self.get_training_run(run_id)
            if run is None:
                logger.error(f"Training run {run_id} not found")
                return None
            
            # Check if run is completed
            if run.status != "completed":
                logger.error(f"Training run {run_id} is not completed (status: {run.status})")
                return None
            
            # Check if version ID is available
            if run.version_id is None:
                logger.error(f"Training run {run_id} has no version ID")
                return None
            
            # Get pipeline
            pipeline = self.get_pipeline(run.pipeline_id)
            if pipeline is None:
                logger.error(f"Pipeline {run.pipeline_id} not found")
                return None
            
            # Create model name if not provided
            if name is None:
                name = f"{pipeline.name} v{run.version_id}"
            
            # Create model
            model_config = self.model_manager.create_model(
                name=name,
                workspace=self.roboflow_client.workspace,
                project=self.roboflow_client.project,
                version_id=run.version_id,
                model_type=pipeline.model_type
            )
            
            if model_config is None:
                logger.error(f"Failed to create model from training run {run_id}")
                return None
            
            # Update run with model ID
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute("""
                UPDATE training_runs
                SET model_id = ?
                WHERE run_id = ?
            """, (
                model_config.model_id,
                run_id
            ))
            
            conn.commit()
            conn.close()
            
            logger.info(f"Deployed model {name} (ID: {model_config.model_id}) from training run {run_id}")
            return model_config.model_id
        except Exception as e:
            logger.error(f"Error deploying model from training run {run_id}: {e}")
            return None
    
    # Data Collection
    
    def create_data_collection_config(self, name: str, description: str, dataset_id: str,
                                    source_type: str, source_params: Dict[str, Any],
                                    collection_interval: int = 60, max_images: int = 100,
                                    require_annotation: bool = False, auto_annotate: bool = False) -> Optional[DataCollectionConfig]:
        """
        Create data collection configuration.
        
        Args:
            name: Configuration name
            description: Configuration description
            dataset_id: Dataset ID
            source_type: Source type ('camera', 'directory', 'production')
            source_params: Source parameters
            collection_interval: Collection interval in seconds
            max_images: Maximum number of images to collect
            require_annotation: Whether to require manual annotation
            auto_annotate: Whether to use existing models for auto-annotation
        
        Returns:
            Data collection configuration if successful, None otherwise
        """
        try:
            # Create config ID
            config_id = str(uuid.uuid4())
            
            # Create configuration
            config = DataCollectionConfig(
                config_id=config_id,
                name=name,
                description=description,
                dataset_id=dataset_id,
                source_type=source_type,
                source_params=source_params,
                collection_interval=collection_interval,
                max_images=max_images,
                require_annotation=require_annotation,
                auto_annotate=auto_annotate,
                created_at=datetime.datetime.now().isoformat(),
                updated_at=datetime.datetime.now().isoformat()
            )
            
            # Save to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute("""
                INSERT INTO data_collection_configs (
                    config_id, name, description, dataset_id, source_type,
                    source_params, collection_interval, max_images,
                    require_annotation, auto_annotate, created_at, updated_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                config.config_id,
                config.name,
                config.description,
                config.dataset_id,
                config.source_type,
                json.dumps(config.source_params),
                config.collection_interval,
                config.max_images,
                int(config.require_annotation),
                int(config.auto_annotate),
                config.created_at,
                config.updated_at
            ))
            
            conn.commit()
            conn.close()
            
            logger.info(f"Created data collection configuration {name} (ID: {config_id})")
            return config
        except Exception as e:
            logger.error(f"Error creating data collection configuration: {e}")
            return None
    
    def get_data_collection_config(self, config_id: str) -> Optional[DataCollectionConfig]:
        """
        Get data collection configuration.
        
        Args:
            config_id: Configuration ID
        
        Returns:
            Data collection configuration if found, None otherwise
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Get configuration
            cursor.execute("SELECT * FROM data_collection_configs WHERE config_id = ?", (config_id,))
            row = cursor.fetchone()
            
            # Close connection
            conn.close()
            
            if row is None:
                return None
            
            # Create configuration
            config = DataCollectionConfig(
                config_id=row["config_id"],
                name=row["name"],
                description=row["description"],
                dataset_id=row["dataset_id"],
                source_type=row["source_type"],
                source_params=json.loads(row["source_params"]),
                collection_interval=row["collection_interval"],
                max_images=row["max_images"],
                require_annotation=bool(row["require_annotation"]),
                auto_annotate=bool(row["auto_annotate"]),
                created_at=row["created_at"],
                updated_at=row["updated_at"]
            )
            
            return config
        except Exception as e:
            logger.error(f"Error getting data collection configuration {config_id}: {e}")
            return None
    
    def get_data_collection_configs(self) -> List[DataCollectionConfig]:
        """
        Get all data collection configurations.
        
        Returns:
            List of data collection configurations
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Get configurations
            cursor.execute("SELECT * FROM data_collection_configs")
            rows = cursor.fetchall()
            
            # Close connection
            conn.close()
            
            # Create configurations
            configs = []
            for row in rows:
                config = DataCollectionConfig(
                    config_id=row["config_id"],
                    name=row["name"],
                    description=row["description"],
                    dataset_id=row["dataset_id"],
                    source_type=row["source_type"],
                    source_params=json.loads(row["source_params"]),
                    collection_interval=row["collection_interval"],
                    max_images=row["max_images"],
                    require_annotation=bool(row["require_annotation"]),
                    auto_annotate=bool(row["auto_annotate"]),
                    created_at=row["created_at"],
                    updated_at=row["updated_at"]
                )
                configs.append(config)
            
            return configs
        except Exception as e:
            logger.error(f"Error getting data collection configurations: {e}")
            return []
    
    def start_data_collection(self, config_id: str) -> Optional[str]:
        """
        Start data collection session.
        
        Args:
            config_id: Configuration ID
        
        Returns:
            Session ID if successful, None otherwise
        """
        try:
            # Get configuration
            config = self.get_data_collection_config(config_id)
            if config is None:
                logger.error(f"Data collection configuration {config_id} not found")
                return None
            
            # Check if collection is already running
            if config_id in self.collection_threads and self.collection_threads[config_id].is_alive():
                logger.error(f"Data collection for configuration {config_id} is already running")
                return None
            
            # Create session ID
            session_id = str(uuid.uuid4())
            
            # Create session
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute("""
                INSERT INTO data_collection_sessions (
                    session_id, config_id, status, start_time, images_collected, images_annotated
                )
                VALUES (?, ?, ?, ?, ?, ?)
            """, (
                session_id,
                config_id,
                "running",
                datetime.datetime.now().isoformat(),
                0,
                0
            ))
            
            conn.commit()
            conn.close()
            
            # Create stop event
            stop_event = threading.Event()
            self.collection_stop_events[config_id] = stop_event
            
            # Start collection thread
            thread = threading.Thread(
                target=self._data_collection_worker,
                args=(config, session_id, stop_event),
                daemon=True
            )
            self.collection_threads[config_id] = thread
            thread.start()
            
            logger.info(f"Started data collection session {session_id} for configuration {config_id}")
            return session_id
        except Exception as e:
            logger.error(f"Error starting data collection for configuration {config_id}: {e}")
            return None
    
    def stop_data_collection(self, config_id: str) -> bool:
        """
        Stop data collection session.
        
        Args:
            config_id: Configuration ID
        
        Returns:
            True if successful, False otherwise
        """
        try:
            # Check if collection is running
            if config_id not in self.collection_threads or not self.collection_threads[config_id].is_alive():
                logger.error(f"Data collection for configuration {config_id} is not running")
                return False
            
            # Set stop event
            self.collection_stop_events[config_id].set()
            
            # Wait for thread to stop
            self.collection_threads[config_id].join(timeout=10.0)
            
            # Clean up
            del self.collection_threads[config_id]
            del self.collection_stop_events[config_id]
            
            logger.info(f"Stopped data collection for configuration {config_id}")
            return True
        except Exception as e:
            logger.error(f"Error stopping data collection for configuration {config_id}: {e}")
            return False
    
    def _data_collection_worker(self, config: DataCollectionConfig, session_id: str, stop_event: threading.Event):
        """
        Background worker thread for data collection.
        
        Args:
            config: Data collection configuration
            session_id: Session ID
            stop_event: Stop event
        """
        logger.info(f"Data collection worker started for session {session_id}")
        
        try:
            # Create session directory
            session_dir = os.path.join(self.data_dir, "collection", session_id)
            os.makedirs(session_dir, exist_ok=True)
            
            # Initialize counters
            images_collected = 0
            images_annotated = 0
            
            # Initialize source
            source = self._init_data_source(config.source_type, config.source_params)
            if source is None:
                logger.error(f"Failed to initialize data source for session {session_id}")
                self._update_collection_session(session_id, "failed", images_collected, images_annotated)
                return
            
            # Initialize annotation model if auto-annotate is enabled
            annotation_model = None
            if config.auto_annotate:
                # Get active models
                models = self.model_manager.get_models(active_only=True)
                if models:
                    # Use first active model
                    annotation_model = models[0].model_id
            
            # Collection loop
            while not stop_event.is_set() and images_collected < config.max_images:
                try:
                    # Get image from source
                    image = source.get_image()
                    if image is None:
                        logger.warning(f"Failed to get image from source for session {session_id}")
                        time.sleep(1)
                        continue
                    
                    # Save image
                    image_id = str(uuid.uuid4())
                    image_path = os.path.join(session_dir, f"{image_id}.jpg")
                    cv2.imwrite(image_path, image)
                    
                    # Auto-annotate if enabled
                    annotations = []
                    if config.auto_annotate and annotation_model:
                        # Perform inference
                        result = self.model_manager.predict_sync(annotation_model, image, image_id)
                        if result and result.detections:
                            # Convert detections to annotations
                            for detection in result.detections:
                                annotations.append({
                                    "class": detection.defect_type,
                                    "x": detection.bbox[0],
                                    "y": detection.bbox[1],
                                    "width": detection.bbox[2],
                                    "height": detection.bbox[3],
                                    "confidence": detection.confidence
                                })
                            
                            # Save annotations
                            annotation_path = os.path.join(session_dir, f"{image_id}.json")
                            with open(annotation_path, "w") as f:
                                json.dump(annotations, f)
                            
                            images_annotated += 1
                    
                    # Increment counter
                    images_collected += 1
                    
                    # Update session
                    self._update_collection_session(session_id, "running", images_collected, images_annotated)
                    
                    # Sleep
                    time.sleep(config.collection_interval)
                except Exception as e:
                    logger.error(f"Error in data collection loop for session {session_id}: {e}")
                    time.sleep(config.collection_interval)
            
            # Upload collected images to dataset
            if images_collected > 0:
                logger.info(f"Uploading {images_collected} images to dataset {config.dataset_id}")
                
                # Upload images
                success_count, failure_count = self.model_manager.upload_images_to_dataset(
                    config.dataset_id,
                    session_dir,
                    session_dir if config.auto_annotate else None
                )
                
                logger.info(f"Uploaded {success_count} images to dataset {config.dataset_id} ({failure_count} failed)")
            
            # Update session status
            status = "completed" if not stop_event.is_set() else "stopped"
            self._update_collection_session(session_id, status, images_collected, images_annotated)
            
            logger.info(f"Data collection worker completed for session {session_id}")
        except Exception as e:
            logger.error(f"Error in data collection worker for session {session_id}: {e}")
            traceback.print_exc()
            self._update_collection_session(session_id, "failed", images_collected, images_annotated)
    
    def _init_data_source(self, source_type: str, source_params: Dict[str, Any]) -> Any:
        """
        Initialize data source.
        
        Args:
            source_type: Source type
            source_params: Source parameters
        
        Returns:
            Data source if successful, None otherwise
        """
        try:
            if source_type == "camera":
                # Camera source
                from src.core.camera.basler_manager import BaslerManager
                
                # Get camera ID
                camera_id = source_params.get("camera_id")
                if camera_id is None:
                    logger.error("Camera ID not specified in source parameters")
                    return None
                
                # Create camera manager
                camera_manager = BaslerManager()
                
                # Connect to camera
                if not camera_manager.connect(camera_id):
                    logger.error(f"Failed to connect to camera {camera_id}")
                    return None
                
                # Create source object
                class CameraSource:
                    def get_image(self):
                        return camera_manager.capture_image(camera_id)
                
                return CameraSource()
            
            elif source_type == "directory":
                # Directory source
                directory = source_params.get("directory")
                if directory is None:
                    logger.error("Directory not specified in source parameters")
                    return None
                
                # Check if directory exists
                if not os.path.isdir(directory):
                    logger.error(f"Directory {directory} does not exist")
                    return None
                
                # Get image files
                image_files = []
                for ext in [".jpg", ".jpeg", ".png"]:
                    image_files.extend(list(Path(directory).glob(f"*{ext}")))
                
                if not image_files:
                    logger.error(f"No image files found in directory {directory}")
                    return None
                
                # Create source object
                class DirectorySource:
                    def __init__(self, files):
                        self.files = files
                        self.index = 0
                    
                    def get_image(self):
                        if not self.files:
                            return None
                        
                        # Get next file
                        file = self.files[self.index]
                        self.index = (self.index + 1) % len(self.files)
                        
                        # Read image
                        return cv2.imread(str(file))
                
                return DirectorySource(image_files)
            
            elif source_type == "production":
                # Production source (from defect detection system)
                from src.core.production.run_manager import ProductionRunManager
                
                # Get run manager
                run_manager = ProductionRunManager()
                
                # Create source object
                class ProductionSource:
                    def __init__(self, run_manager):
                        self.run_manager = run_manager
                        self.last_image = None
                    
                    def get_image(self):
                        # Get latest image from production
                        image = self.run_manager.get_latest_image()
                        
                        # Check if image is different from last one
                        if image is not None and self.last_image is not None:
                            # Compare images
                            if np.array_equal(image, self.last_image):
                                return None
                        
                        # Update last image
                        self.last_image = image
                        return image
                
                return ProductionSource(run_manager)
            
            else:
                logger.error(f"Unknown source type: {source_type}")
                return None
        except Exception as e:
            logger.error(f"Error initializing data source: {e}")
            return None
    
    def _update_collection_session(self, session_id: str, status: str, images_collected: int, images_annotated: int):
        """
        Update data collection session.
        
        Args:
            session_id: Session ID
            status: Session status
            images_collected: Number of images collected
            images_annotated: Number of images annotated
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Update session
            if status in ["completed", "failed", "stopped"]:
                cursor.execute("""
                    UPDATE data_collection_sessions
                    SET status = ?, end_time = ?, images_collected = ?, images_annotated = ?
                    WHERE session_id = ?
                """, (
                    status,
                    datetime.datetime.now().isoformat(),
                    images_collected,
                    images_annotated,
                    session_id
                ))
            else:
                cursor.execute("""
                    UPDATE data_collection_sessions
                    SET status = ?, images_collected = ?, images_annotated = ?
                    WHERE session_id = ?
                """, (
                    status,
                    images_collected,
                    images_annotated,
                    session_id
                ))
            
            # Commit changes
            conn.commit()
            
            # Close connection
            conn.close()
        except Exception as e:
            logger.error(f"Error updating collection session {session_id}: {e}")
    
    # Utility Methods
    
    def export_pipeline_config(self, pipeline_id: str, output_path: str) -> bool:
        """
        Export pipeline configuration to YAML file.
        
        Args:
            pipeline_id: Pipeline ID
            output_path: Output file path
        
        Returns:
            True if successful, False otherwise
        """
        try:
            # Get pipeline
            pipeline = self.get_pipeline(pipeline_id)
            if pipeline is None:
                logger.error(f"Pipeline {pipeline_id} not found")
                return False
            
            # Convert to dictionary
            config = pipeline.to_dict()
            
            # Write to file
            with open(output_path, "w") as f:
                yaml.dump(config, f, default_flow_style=False)
            
            logger.info(f"Exported pipeline {pipeline_id} configuration to {output_path}")
            return True
        except Exception as e:
            logger.error(f"Error exporting pipeline {pipeline_id} configuration: {e}")
            return False
    
    def import_pipeline_config(self, config_path: str) -> Optional[str]:
        """
        Import pipeline configuration from YAML file.
        
        Args:
            config_path: Configuration file path
        
        Returns:
            Pipeline ID if successful, None otherwise
        """
        try:
            # Read configuration
            with open(config_path, "r") as f:
                config = yaml.safe_load(f)
            
            # Create pipeline
            pipeline = self.create_pipeline(
                name=config["name"],
                description=config["description"],
                dataset_id=config["dataset_id"],
                model_type=config["model_type"],
                epochs=config["epochs"],
                batch_size=config["batch_size"],
                learning_rate=config["learning_rate"],
                augmentation=config["augmentation"],
                validation_split=config["validation_split"],
                auto_deploy=config["auto_deploy"],
                parameters=config["parameters"]
            )
            
            if pipeline is None:
                logger.error(f"Failed to create pipeline from configuration {config_path}")
                return None
            
            logger.info(f"Imported pipeline configuration from {config_path} (ID: {pipeline.pipeline_id})")
            return pipeline.pipeline_id
        except Exception as e:
            logger.error(f"Error importing pipeline configuration from {config_path}: {e}")
            return None
    
    def cleanup(self):
        """Clean up resources."""
        try:
            # Stop training monitor
            if self.training_monitor_thread and self.training_monitor_thread.is_alive():
                self.training_monitor_running = False
                self.training_monitor_thread.join(timeout=5.0)
            
            # Stop data collection threads
            for config_id in list(self.collection_threads.keys()):
                self.stop_data_collection(config_id)
            
            logger.info("Cleaned up training pipeline manager resources")
        except Exception as e:
            logger.error(f"Error cleaning up resources: {e}")


# Example usage
if __name__ == "__main__":
    # Set up logging
    logging.basicConfig(level=logging.INFO)
    
    # Create model manager
    model_manager = ModelManager(
        db_path="data/database/models.db",
        models_dir="models/weights"
    )
    
    # Create training pipeline manager
    pipeline_manager = TrainingPipelineManager(
        db_path="data/database/training.db",
        data_dir="data/training",
        model_manager=model_manager
    )
    
    # Create training pipeline
    pipeline = pipeline_manager.create_pipeline(
        name="Sandwich Defect Detection",
        description="Training pipeline for sandwich defect detection",
        dataset_id="sandwich-defects",
        model_type="yolov8",
        epochs=100,
        batch_size=16,
        learning_rate=0.001,
        augmentation=True,
        validation_split=0.2,
        auto_deploy=True
    )
    
    if pipeline:
        print(f"Created pipeline: {pipeline.name} (ID: {pipeline.pipeline_id})")
    
    # Clean up
    pipeline_manager.cleanup()
    model_manager.cleanup()
