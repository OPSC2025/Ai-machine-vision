import os
import time
import logging
import numpy as np
import cv2
from typing import List, Dict, Tuple, Optional, Any, Union
from dataclasses import dataclass
from concurrent.futures import ThreadPoolExecutor

from src.core.inference.model_manager import ModelManager
from src.utils.config import ConfigManager
from src.utils.logging import get_logger

@dataclass
class DetectionResult:
    """Data class to store detection results for a single image."""
    image_id: str
    timestamp: float
    camera_id: str
    defects: List[Dict[str, Any]]
    confidence_scores: List[float]
    bounding_boxes: List[List[int]]  # [x1, y1, x2, y2]
    defect_types: List[str]
    image_path: Optional[str] = None
    original_image: Optional[np.ndarray] = None
    annotated_image: Optional[np.ndarray] = None
    processing_time: float = 0.0
    is_rejected: bool = False
    rejection_reason: Optional[str] = None

class DefectDetectionSystem:
    """
    Comprehensive defect detection system for sandwich inspection using Roboflow models.
    
    This system processes images from multiple cameras, detects defects using AI models,
    and provides detailed results for visualization, reporting, and PLC integration.
    """
    
    def __init__(self, config_path: str = "config/models.yaml"):
        """
        Initialize the defect detection system.
        
        Args:
            config_path: Path to the model configuration file
        """
        self.logger = get_logger("DefectDetectionSystem")
        self.config_manager = ConfigManager()
        self.model_config = self.config_manager.load_config(config_path)
        
        # Initialize model manager
        self.model_manager = ModelManager()
        
        # Load defect configuration
        self.defect_types = self.model_config.get("defect_types", {})
        self.confidence_thresholds = self.model_config.get("confidence_thresholds", {})
        self.default_threshold = self.model_config.get("default_threshold", 0.5)
        
        # Initialize detection pipeline
        self._initialize_detection_pipeline()
        
        # Thread pool for parallel processing
        self.executor = ThreadPoolExecutor(max_workers=self.model_config.get("max_workers", 4))
        
        # Detection statistics
        self.detection_stats = {
            "total_processed": 0,
            "total_defects_detected": 0,
            "defects_by_type": {},
            "average_processing_time": 0.0,
            "false_positives": 0,
            "false_negatives": 0
        }
        
        # Initialize defect counters
        for defect_type in self.defect_types:
            self.detection_stats["defects_by_type"][defect_type] = 0
        
        self.logger.info(f"Defect Detection System initialized with {len(self.defect_types)} defect types")
    
    def _initialize_detection_pipeline(self):
        """Initialize the detection pipeline with the configured models."""
        try:
            # Load primary model
            primary_model = self.model_config.get("primary_model", {})
            self.primary_model_id = primary_model.get("model_id")
            self.primary_model_version = primary_model.get("version")
            
            if not self.primary_model_id:
                raise ValueError("Primary model ID not specified in configuration")
            
            self.model_manager.load_model(
                model_id=self.primary_model_id,
                version=self.primary_model_version
            )
            
            # Load specialized models if configured
            self.specialized_models = {}
            specialized_models = self.model_config.get("specialized_models", {})
            
            for defect_type, model_info in specialized_models.items():
                model_id = model_info.get("model_id")
                version = model_info.get("version")
                
                if model_id:
                    self.model_manager.load_model(model_id=model_id, version=version)
                    self.specialized_models[defect_type] = model_id
            
            self.logger.info(f"Detection pipeline initialized with primary model {self.primary_model_id} and {len(self.specialized_models)} specialized models")
        
        except Exception as e:
            self.logger.error(f"Failed to initialize detection pipeline: {str(e)}")
            raise
    
    def process_image(self, image: np.ndarray, camera_id: str, image_id: str = None) -> DetectionResult:
        """
        Process a single image to detect defects.
        
        Args:
            image: Input image as numpy array
            camera_id: ID of the camera that captured the image
            image_id: Optional unique identifier for the image
            
        Returns:
            DetectionResult object containing detection results
        """
        start_time = time.time()
        
        if image_id is None:
            image_id = f"{camera_id}_{int(start_time * 1000)}"
        
        try:
            # Preprocess image if needed
            preprocessed_image = self._preprocess_image(image, camera_id)
            
            # Run primary model inference
            primary_results = self.model_manager.infer(
                model_id=self.primary_model_id,
                image=preprocessed_image
            )
            
            # Process results
            defects = []
            confidence_scores = []
            bounding_boxes = []
            defect_types_detected = []
            
            # Process primary model results
            for detection in primary_results:
                defect_type = detection.get("class", "unknown")
                confidence = detection.get("confidence", 0.0)
                bbox = detection.get("bbox", [0, 0, 0, 0])
                
                # Check if confidence exceeds threshold for this defect type
                threshold = self.confidence_thresholds.get(defect_type, self.default_threshold)
                
                if confidence >= threshold:
                    # If we have a specialized model for this defect type, run it for confirmation
                    if defect_type in self.specialized_models:
                        # Extract region of interest
                        x1, y1, x2, y2 = bbox
                        roi = image[y1:y2, x1:x2]
                        
                        # Run specialized model
                        specialized_results = self.model_manager.infer(
                            model_id=self.specialized_models[defect_type],
                            image=roi
                        )
                        
                        # If specialized model confirms the defect
                        if specialized_results and specialized_results[0].get("confidence", 0.0) >= threshold:
                            defects.append(detection)
                            confidence_scores.append(confidence)
                            bounding_boxes.append(bbox)
                            defect_types_detected.append(defect_type)
                    else:
                        # No specialized model, use primary model result
                        defects.append(detection)
                        confidence_scores.append(confidence)
                        bounding_boxes.append(bbox)
                        defect_types_detected.append(defect_type)
            
            # Create annotated image for visualization
            annotated_image = self._annotate_image(image.copy(), defects)
            
            # Determine if the sandwich should be rejected
            is_rejected, rejection_reason = self._determine_rejection(defect_types_detected, confidence_scores)
            
            # Save image if defects were detected or based on sampling rate
            image_path = None
            if defects or np.random.random() < self.model_config.get("sampling_rate", 0.1):
                image_path = self._save_detection_image(image_id, annotated_image)
            
            # Update statistics
            self._update_statistics(defect_types_detected, time.time() - start_time)
            
            # Create and return result
            result = DetectionResult(
                image_id=image_id,
                timestamp=start_time,
                camera_id=camera_id,
                defects=defects,
                confidence_scores=confidence_scores,
                bounding_boxes=bounding_boxes,
                defect_types=defect_types_detected,
                image_path=image_path,
                annotated_image=annotated_image,
                processing_time=time.time() - start_time,
                is_rejected=is_rejected,
                rejection_reason=rejection_reason
            )
            
            return result
            
        except Exception as e:
            self.logger.error(f"Error processing image {image_id}: {str(e)}")
            # Return empty result with error information
            return DetectionResult(
                image_id=image_id,
                timestamp=start_time,
                camera_id=camera_id,
                defects=[{"error": str(e)}],
                confidence_scores=[],
                bounding_boxes=[],
                defect_types=["error"],
                processing_time=time.time() - start_time,
                is_rejected=True,
                rejection_reason=f"Processing error: {str(e)}"
            )
    
    def process_multiple_images(self, images: List[Tuple[np.ndarray, str, str]]) -> List[DetectionResult]:
        """
        Process multiple images in parallel.
        
        Args:
            images: List of tuples containing (image, camera_id, image_id)
            
        Returns:
            List of DetectionResult objects
        """
        try:
            # Submit all images for processing
            futures = [
                self.executor.submit(self.process_image, image, camera_id, image_id)
                for image, camera_id, image_id in images
            ]
            
            # Collect results
            results = [future.result() for future in futures]
            return results
            
        except Exception as e:
            self.logger.error(f"Error in batch processing: {str(e)}")
            return []
    
    def _preprocess_image(self, image: np.ndarray, camera_id: str) -> np.ndarray:
        """
        Preprocess image before inference.
        
        Args:
            image: Input image
            camera_id: Camera ID for camera-specific preprocessing
            
        Returns:
            Preprocessed image
        """
        # Get camera-specific preprocessing if available
        camera_config = self.model_config.get("camera_preprocessing", {}).get(camera_id, {})
        
        # Apply preprocessing steps
        try:
            # Resize if needed
            target_size = camera_config.get("resize", None)
            if target_size:
                image = cv2.resize(image, (target_size[0], target_size[1]))
            
            # Apply normalization
            if camera_config.get("normalize", True):
                image = image.astype(np.float32) / 255.0
            
            # Apply color correction if needed
            if camera_config.get("color_correction", False):
                # Apply camera-specific color correction matrix
                ccm = np.array(camera_config.get("color_matrix", [[1, 0, 0], [0, 1, 0], [0, 0, 1]]))
                image = cv2.transform(image, ccm)
            
            # Apply additional preprocessing based on configuration
            if camera_config.get("enhance_contrast", False):
                # Convert to LAB color space for better contrast enhancement
                if len(image.shape) == 3:
                    lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)
                    l, a, b = cv2.split(lab)
                    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
                    cl = clahe.apply(l)
                    enhanced_lab = cv2.merge((cl, a, b))
                    image = cv2.cvtColor(enhanced_lab, cv2.COLOR_LAB2BGR)
                else:
                    # Grayscale image
                    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
                    image = clahe.apply(image)
            
            return image
            
        except Exception as e:
            self.logger.warning(f"Error in preprocessing for camera {camera_id}: {str(e)}. Using original image.")
            return image
    
    def _annotate_image(self, image: np.ndarray, defects: List[Dict[str, Any]]) -> np.ndarray:
        """
        Create an annotated image with bounding boxes and labels for detected defects.
        
        Args:
            image: Original image
            defects: List of detected defects
            
        Returns:
            Annotated image
        """
        # Define colors for different defect types (BGR format)
        colors = {
            "improper_sealing": (0, 0, 255),    # Red
            "filling_leakage": (0, 165, 255),   # Orange
            "size_inconsistency": (0, 255, 255), # Yellow
            "mold": (0, 255, 0),                # Green
            "holes": (255, 0, 0),               # Blue
            "destroyed": (255, 0, 255),         # Purple
            "foreign_material": (255, 255, 0),  # Cyan
            "default": (255, 255, 255)          # White
        }
        
        # Draw bounding boxes and labels
        for defect in defects:
            defect_type = defect.get("class", "unknown")
            confidence = defect.get("confidence", 0.0)
            bbox = defect.get("bbox", [0, 0, 0, 0])
            
            # Get color for this defect type
            color = colors.get(defect_type, colors["default"])
            
            # Draw bounding box
            x1, y1, x2, y2 = [int(coord) for coord in bbox]
            cv2.rectangle(image, (x1, y1), (x2, y2), color, 2)
            
            # Draw label with confidence
            label = f"{defect_type}: {confidence:.2f}"
            label_size, baseline = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)
            y1 = max(y1, label_size[1])
            cv2.rectangle(image, (x1, y1 - label_size[1] - 10), (x1 + label_size[0], y1), color, -1)
            cv2.putText(image, label, (x1, y1 - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 1)
        
        return image
    
    def _determine_rejection(self, defect_types: List[str], confidence_scores: List[float]) -> Tuple[bool, Optional[str]]:
        """
        Determine if a sandwich should be rejected based on detected defects.
        
        Args:
            defect_types: List of detected defect types
            confidence_scores: Corresponding confidence scores
            
        Returns:
            Tuple of (is_rejected, rejection_reason)
        """
        if not defect_types:
            return False, None
        
        # Get rejection rules from config
        rejection_rules = self.model_config.get("rejection_rules", {})
        
        # Check critical defects that always cause rejection
        critical_defects = rejection_rules.get("critical_defects", [])
        for i, defect_type in enumerate(defect_types):
            if defect_type in critical_defects:
                return True, f"Critical defect: {defect_type} (confidence: {confidence_scores[i]:.2f})"
        
        # Check combined defects
        if len(defect_types) >= rejection_rules.get("max_combined_defects", 2):
            return True, f"Multiple defects: {', '.join(defect_types)}"
        
        # Check high confidence defects
        high_confidence_threshold = rejection_rules.get("high_confidence_threshold", 0.8)
        for i, score in enumerate(confidence_scores):
            if score >= high_confidence_threshold:
                return True, f"High confidence defect: {defect_types[i]} (confidence: {score:.2f})"
        
        # Check specific defect rules
        for i, defect_type in enumerate(defect_types):
            defect_rule = rejection_rules.get(defect_type, {})
            if defect_rule.get("always_reject", False):
                return True, f"Defect rule: {defect_type} (confidence: {confidence_scores[i]:.2f})"
            
            min_confidence = defect_rule.get("min_confidence", 0.0)
            if confidence_scores[i] >= min_confidence:
                return True, f"Defect above threshold: {defect_type} (confidence: {confidence_scores[i]:.2f}, threshold: {min_confidence:.2f})"
        
        # If we get here, no rejection rules were triggered
        return False, None
    
    def _save_detection_image(self, image_id: str, image: np.ndarray) -> str:
        """
        Save detection image to disk.
        
        Args:
            image_id: Unique image identifier
            image: Annotated image
            
        Returns:
            Path to saved image
        """
        # Create directory if it doesn't exist
        save_dir = self.model_config.get("image_save_dir", "data/images/detections")
        os.makedirs(save_dir, exist_ok=True)
        
        # Generate filename with timestamp
        timestamp = time.strftime("%Y%m%d-%H%M%S")
        filename = f"{timestamp}_{image_id}.jpg"
        filepath = os.path.join(save_dir, filename)
        
        # Save image
        cv2.imwrite(filepath, image)
        
        return filepath
    
    def _update_statistics(self, defect_types: List[str], processing_time: float):
        """
        Update detection statistics.
        
        Args:
            defect_types: List of detected defect types
            processing_time: Time taken to process the image
        """
        self.detection_stats["total_processed"] += 1
        self.detection_stats["total_defects_detected"] += len(defect_types)
        
        # Update defect type counters
        for defect_type in defect_types:
            if defect_type in self.detection_stats["defects_by_type"]:
                self.detection_stats["defects_by_type"][defect_type] += 1
        
        # Update average processing time
        n = self.detection_stats["total_processed"]
        prev_avg = self.detection_stats["average_processing_time"]
        self.detection_stats["average_processing_time"] = ((n - 1) * prev_avg + processing_time) / n
    
    def get_statistics(self) -> Dict[str, Any]:
        """
        Get current detection statistics.
        
        Returns:
            Dictionary of detection statistics
        """
        return self.detection_stats
    
    def reset_statistics(self):
        """Reset detection statistics."""
        self.detection_stats = {
            "total_processed": 0,
            "total_defects_detected": 0,
            "defects_by_type": {defect_type: 0 for defect_type in self.defect_types},
            "average_processing_time": 0.0,
            "false_positives": 0,
            "false_negatives": 0
        }
    
    def update_model(self, model_id: str, version: str = None):
        """
        Update a model to a new version.
        
        Args:
            model_id: ID of the model to update
            version: New version to use, or None for latest
        """
        try:
            self.model_manager.update_model(model_id=model_id, version=version)
            self.logger.info(f"Updated model {model_id} to version {version or 'latest'}")
        except Exception as e:
            self.logger.error(f"Failed to update model {model_id}: {str(e)}")
            raise
    
    def update_confidence_threshold(self, defect_type: str, threshold: float):
        """
        Update confidence threshold for a specific defect type.
        
        Args:
            defect_type: Defect type to update
            threshold: New confidence threshold (0.0-1.0)
        """
        if threshold < 0.0 or threshold > 1.0:
            raise ValueError("Confidence threshold must be between 0.0 and 1.0")
        
        self.confidence_thresholds[defect_type] = threshold
        self.logger.info(f"Updated confidence threshold for {defect_type} to {threshold}")
    
    def update_default_threshold(self, threshold: float):
        """
        Update default confidence threshold for all defect types.
        
        Args:
            threshold: New default confidence threshold (0.0-1.0)
        """
        if threshold < 0.0 or threshold > 1.0:
            raise ValueError("Confidence threshold must be between 0.0 and 1.0")
        
        self.default_threshold = threshold
        self.logger.info(f"Updated default confidence threshold to {threshold}")
    
    def get_defect_types(self) -> Dict[str, Dict[str, Any]]:
        """
        Get information about all defect types.
        
        Returns:
            Dictionary of defect types with their descriptions and thresholds
        """
        result = {}
        for defect_type, info in self.defect_types.items():
            result[defect_type] = {
                "description": info.get("description", ""),
                "threshold": self.confidence_thresholds.get(defect_type, self.default_threshold),
                "critical": defect_type in self.model_config.get("rejection_rules", {}).get("critical_defects", []),
                "specialized_model": defect_type in self.specialized_models
            }
        return result
    
    def get_model_info(self) -> Dict[str, Any]:
        """
        Get information about loaded models.
        
        Returns:
            Dictionary with model information
        """
        return {
            "primary_model": {
                "id": self.primary_model_id,
                "version": self.primary_model_version,
                "info": self.model_manager.get_model_info(self.primary_model_id)
            },
            "specialized_models": {
                defect_type: {
                    "id": model_id,
                    "info": self.model_manager.get_model_info(model_id)
                }
                for defect_type, model_id in self.specialized_models.items()
            }
        }
