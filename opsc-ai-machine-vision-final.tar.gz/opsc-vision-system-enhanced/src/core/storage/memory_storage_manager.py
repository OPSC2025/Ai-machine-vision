"""
Memory and storage management module for OPSC Sandwich Quality Inspection System.
Provides functionality for optimizing memory usage and storage management,
including image storage, data retention, and cleanup.

Version: 1.0.0
Last Updated: 2025-04-21
"""

import os
import sys
import time
import json
import logging
import datetime
import threading
import queue
import shutil
import hashlib
import glob
from typing import Dict, List, Optional, Tuple, Union, Any, Callable, Set
from dataclasses import dataclass, field
from enum import Enum, auto
from pathlib import Path
import numpy as np
import cv2
import psutil

# Setup logging
logger = logging.getLogger(__name__)

class StorageType(Enum):
    """Storage type enum."""
    LOCAL = auto()
    NETWORK = auto()
    CLOUD = auto()
    MEMORY = auto()


class RetentionPolicy(Enum):
    """Retention policy enum."""
    KEEP_ALL = auto()
    TIME_BASED = auto()
    COUNT_BASED = auto()
    SIZE_BASED = auto()
    HYBRID = auto()


@dataclass
class StorageConfig:
    """Storage configuration data class."""
    storage_id: str
    storage_name: str
    storage_type: StorageType
    base_path: str
    max_size_gb: float
    retention_policy: RetentionPolicy
    retention_days: int = 30
    retention_count: int = 10000
    compression_enabled: bool = True
    compression_level: int = 6
    encryption_enabled: bool = False
    encryption_key: Optional[str] = None
    subdirectory_format: str = "%Y/%m/%d"  # Datetime format for subdirectories
    file_format: str = "{prefix}_{timestamp}_{uuid}.{ext}"
    metadata_enabled: bool = True
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "storage_id": self.storage_id,
            "storage_name": self.storage_name,
            "storage_type": self.storage_type.name,
            "base_path": self.base_path,
            "max_size_gb": self.max_size_gb,
            "retention_policy": self.retention_policy.name,
            "retention_days": self.retention_days,
            "retention_count": self.retention_count,
            "compression_enabled": self.compression_enabled,
            "compression_level": self.compression_level,
            "encryption_enabled": self.encryption_enabled,
            "encryption_key": self.encryption_key,
            "subdirectory_format": self.subdirectory_format,
            "file_format": self.file_format,
            "metadata_enabled": self.metadata_enabled
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'StorageConfig':
        """Create from dictionary."""
        storage_type_str = data.get("storage_type", "LOCAL")
        try:
            storage_type = StorageType[storage_type_str]
        except KeyError:
            storage_type = StorageType.LOCAL
            logger.warning(f"Invalid storage type: {storage_type_str}, defaulting to LOCAL")
        
        retention_policy_str = data.get("retention_policy", "KEEP_ALL")
        try:
            retention_policy = RetentionPolicy[retention_policy_str]
        except KeyError:
            retention_policy = RetentionPolicy.KEEP_ALL
            logger.warning(f"Invalid retention policy: {retention_policy_str}, defaulting to KEEP_ALL")
        
        return cls(
            storage_id=data.get("storage_id", ""),
            storage_name=data.get("storage_name", ""),
            storage_type=storage_type,
            base_path=data.get("base_path", ""),
            max_size_gb=data.get("max_size_gb", 100.0),
            retention_policy=retention_policy,
            retention_days=data.get("retention_days", 30),
            retention_count=data.get("retention_count", 10000),
            compression_enabled=data.get("compression_enabled", True),
            compression_level=data.get("compression_level", 6),
            encryption_enabled=data.get("encryption_enabled", False),
            encryption_key=data.get("encryption_key"),
            subdirectory_format=data.get("subdirectory_format", "%Y/%m/%d"),
            file_format=data.get("file_format", "{prefix}_{timestamp}_{uuid}.{ext}"),
            metadata_enabled=data.get("metadata_enabled", True)
        )


@dataclass
class FileMetadata:
    """File metadata data class."""
    file_id: str
    file_path: str
    file_name: str
    file_size: int
    file_type: str
    creation_time: datetime.datetime
    last_access_time: datetime.datetime
    last_modified_time: datetime.datetime
    storage_id: str
    compression_enabled: bool
    encryption_enabled: bool
    checksum: str
    custom_metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "file_id": self.file_id,
            "file_path": self.file_path,
            "file_name": self.file_name,
            "file_size": self.file_size,
            "file_type": self.file_type,
            "creation_time": self.creation_time.isoformat(),
            "last_access_time": self.last_access_time.isoformat(),
            "last_modified_time": self.last_modified_time.isoformat(),
            "storage_id": self.storage_id,
            "compression_enabled": self.compression_enabled,
            "encryption_enabled": self.encryption_enabled,
            "checksum": self.checksum,
            "custom_metadata": self.custom_metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'FileMetadata':
        """Create from dictionary."""
        creation_time_str = data.get("creation_time")
        if creation_time_str:
            try:
                creation_time = datetime.datetime.fromisoformat(creation_time_str)
            except ValueError:
                creation_time = datetime.datetime.now()
                logger.warning(f"Invalid creation time format: {creation_time_str}, using current time")
        else:
            creation_time = datetime.datetime.now()
        
        last_access_time_str = data.get("last_access_time")
        if last_access_time_str:
            try:
                last_access_time = datetime.datetime.fromisoformat(last_access_time_str)
            except ValueError:
                last_access_time = datetime.datetime.now()
                logger.warning(f"Invalid last access time format: {last_access_time_str}, using current time")
        else:
            last_access_time = datetime.datetime.now()
        
        last_modified_time_str = data.get("last_modified_time")
        if last_modified_time_str:
            try:
                last_modified_time = datetime.datetime.fromisoformat(last_modified_time_str)
            except ValueError:
                last_modified_time = datetime.datetime.now()
                logger.warning(f"Invalid last modified time format: {last_modified_time_str}, using current time")
        else:
            last_modified_time = datetime.datetime.now()
        
        return cls(
            file_id=data.get("file_id", ""),
            file_path=data.get("file_path", ""),
            file_name=data.get("file_name", ""),
            file_size=data.get("file_size", 0),
            file_type=data.get("file_type", ""),
            creation_time=creation_time,
            last_access_time=last_access_time,
            last_modified_time=last_modified_time,
            storage_id=data.get("storage_id", ""),
            compression_enabled=data.get("compression_enabled", False),
            encryption_enabled=data.get("encryption_enabled", False),
            checksum=data.get("checksum", ""),
            custom_metadata=data.get("custom_metadata", {})
        )


@dataclass
class StorageMetrics:
    """Storage metrics data class."""
    storage_id: str
    total_size_bytes: int
    used_size_bytes: int
    free_size_bytes: int
    file_count: int
    oldest_file_time: Optional[datetime.datetime]
    newest_file_time: Optional[datetime.datetime]
    avg_file_size_bytes: int
    timestamp: datetime.datetime = field(default_factory=datetime.datetime.now)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "storage_id": self.storage_id,
            "total_size_bytes": self.total_size_bytes,
            "used_size_bytes": self.used_size_bytes,
            "free_size_bytes": self.free_size_bytes,
            "file_count": self.file_count,
            "oldest_file_time": self.oldest_file_time.isoformat() if self.oldest_file_time else None,
            "newest_file_time": self.newest_file_time.isoformat() if self.newest_file_time else None,
            "avg_file_size_bytes": self.avg_file_size_bytes,
            "timestamp": self.timestamp.isoformat()
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'StorageMetrics':
        """Create from dictionary."""
        oldest_file_time_str = data.get("oldest_file_time")
        if oldest_file_time_str:
            try:
                oldest_file_time = datetime.datetime.fromisoformat(oldest_file_time_str)
            except ValueError:
                oldest_file_time = None
                logger.warning(f"Invalid oldest file time format: {oldest_file_time_str}")
        else:
            oldest_file_time = None
        
        newest_file_time_str = data.get("newest_file_time")
        if newest_file_time_str:
            try:
                newest_file_time = datetime.datetime.fromisoformat(newest_file_time_str)
            except ValueError:
                newest_file_time = None
                logger.warning(f"Invalid newest file time format: {newest_file_time_str}")
        else:
            newest_file_time = None
        
        timestamp_str = data.get("timestamp")
        if timestamp_str:
            try:
                timestamp = datetime.datetime.fromisoformat(timestamp_str)
            except ValueError:
                timestamp = datetime.datetime.now()
                logger.warning(f"Invalid timestamp format: {timestamp_str}, using current time")
        else:
            timestamp = datetime.datetime.now()
        
        return cls(
            storage_id=data.get("storage_id", ""),
            total_size_bytes=data.get("total_size_bytes", 0),
            used_size_bytes=data.get("used_size_bytes", 0),
            free_size_bytes=data.get("free_size_bytes", 0),
            file_count=data.get("file_count", 0),
            oldest_file_time=oldest_file_time,
            newest_file_time=newest_file_time,
            avg_file_size_bytes=data.get("avg_file_size_bytes", 0),
            timestamp=timestamp
        )


class MemoryCache:
    """
    Memory cache for frequently accessed data.
    
    Provides in-memory caching with size limits and eviction policies.
    """
    
    def __init__(self, max_size_bytes: int = 1024 * 1024 * 100):  # 100 MB default
        """
        Initialize memory cache.
        
        Args:
            max_size_bytes: Maximum cache size in bytes
        """
        self.max_size_bytes = max_size_bytes
        self.current_size_bytes = 0
        self.cache: Dict[str, Tuple[Any, int, datetime.datetime]] = {}  # key -> (value, size, last_access)
        self.lock = threading.Lock()
        self.hits = 0
        self.misses = 0
    
    def get(self, key: str) -> Optional[Any]:
        """
        Get item from cache.
        
        Args:
            key: Cache key
        
        Returns:
            Cached value or None if not found
        """
        with self.lock:
            if key in self.cache:
                # Get item
                value, size, _ = self.cache[key]
                
                # Update last access time
                self.cache[key] = (value, size, datetime.datetime.now())
                
                # Increment hit count
                self.hits += 1
                
                return value
            
            # Increment miss count
            self.misses += 1
            
            return None
    
    def put(self, key: str, value: Any, size_bytes: Optional[int] = None) -> bool:
        """
        Put item in cache.
        
        Args:
            key: Cache key
            value: Value to cache
            size_bytes: Size of value in bytes or None to calculate automatically
        
        Returns:
            True if item was added, False if it couldn't be added
        """
        # Calculate size if not provided
        if size_bytes is None:
            if isinstance(value, (bytes, bytearray)):
                size_bytes = len(value)
            elif isinstance(value, str):
                size_bytes = len(value.encode('utf-8'))
            elif isinstance(value, np.ndarray):
                size_bytes = value.nbytes
            else:
                # Rough estimation for other types
                size_bytes = sys.getsizeof(value)
        
        # Check if item is too large for cache
        if size_bytes > self.max_size_bytes:
            logger.warning(f"Item too large for cache: {size_bytes} bytes > {self.max_size_bytes} bytes")
            return False
        
        with self.lock:
            # Check if key already exists
            if key in self.cache:
                # Get existing size
                _, existing_size, _ = self.cache[key]
                
                # Update current size
                self.current_size_bytes = self.current_size_bytes - existing_size + size_bytes
                
                # Update item
                self.cache[key] = (value, size_bytes, datetime.datetime.now())
            else:
                # Check if we need to make room
                if self.current_size_bytes + size_bytes > self.max_size_bytes:
                    # Evict items until we have enough space
                    self._evict(size_bytes)
                
                # Check if we have enough space now
                if self.current_size_bytes + size_bytes <= self.max_size_bytes:
                    # Add item
                    self.cache[key] = (value, size_bytes, datetime.datetime.now())
                    self.current_size_bytes += size_bytes
                else:
                    # Still not enough space
                    logger.warning(f"Not enough space in cache after eviction: {self.current_size_bytes} + {size_bytes} > {self.max_size_bytes}")
                    return False
            
            return True
    
    def _evict(self, required_bytes: int) -> None:
        """
        Evict items from cache to make room.
        
        Args:
            required_bytes: Number of bytes to free
        """
        # Sort items by last access time (oldest first)
        sorted_items = sorted(self.cache.items(), key=lambda x: x[1][2])
        
        # Evict items until we have enough space
        for key, (_, size, _) in sorted_items:
            # Remove item
            del self.cache[key]
            self.current_size_bytes -= size
            
            # Check if we have enough space now
            if self.current_size_bytes + required_bytes <= self.max_size_bytes:
                break
    
    def remove(self, key: str) -> bool:
        """
        Remove item from cache.
        
        Args:
            key: Cache key
        
        Returns:
            True if item was removed, False if not found
        """
        with self.lock:
            if key in self.cache:
                # Get size
                _, size, _ = self.cache[key]
                
                # Remove item
                del self.cache[key]
                self.current_size_bytes -= size
                
                return True
            
            return False
    
    def clear(self) -> None:
        """Clear cache."""
        with self.lock:
            self.cache.clear()
            self.current_size_bytes = 0
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Get cache statistics.
        
        Returns:
            Dictionary with cache statistics
        """
        with self.lock:
            total_requests = self.hits + self.misses
            hit_rate = self.hits / total_requests if total_requests > 0 else 0.0
            
            return {
                "max_size_bytes": self.max_size_bytes,
                "current_size_bytes": self.current_size_bytes,
                "usage_percent": (self.current_size_bytes / self.max_size_bytes) * 100 if self.max_size_bytes > 0 else 0,
                "item_count": len(self.cache),
                "hits": self.hits,
                "misses": self.misses,
                "hit_rate": hit_rate
            }


class ImageCache(MemoryCache):
    """
    Image cache for frequently accessed images.
    
    Provides in-memory caching for images with size limits and eviction policies.
    """
    
    def __init__(self, max_size_bytes: int = 1024 * 1024 * 200):  # 200 MB default
        """
        Initialize image cache.
        
        Args:
            max_size_bytes: Maximum cache size in bytes
        """
        super().__init__(max_size_bytes)
    
    def get_image(self, key: str) -> Optional[np.ndarray]:
        """
        Get image from cache.
        
        Args:
            key: Cache key
        
        Returns:
            Cached image or None if not found
        """
        return self.get(key)
    
    def put_image(self, key: str, image: np.ndarray) -> bool:
        """
        Put image in cache.
        
        Args:
            key: Cache key
            image: Image to cache
        
        Returns:
            True if image was added, False if it couldn't be added
        """
        # Calculate image size
        size_bytes = image.nbytes
        
        return self.put(key, image, size_bytes)
    
    def get_thumbnail(self, key: str, size: Tuple[int, int] = (100, 100)) -> Optional[np.ndarray]:
        """
        Get thumbnail from cache or generate if not found.
        
        Args:
            key: Cache key
            size: Thumbnail size (width, height)
        
        Returns:
            Cached thumbnail or None if original image not found
        """
        # Generate thumbnail key
        thumbnail_key = f"{key}_thumbnail_{size[0]}x{size[1]}"
        
        # Check if thumbnail is in cache
        thumbnail = self.get(thumbnail_key)
        if thumbnail is not None:
            return thumbnail
        
        # Get original image
        image = self.get(key)
        if image is None:
            return None
        
        # Generate thumbnail
        thumbnail = cv2.resize(image, size, interpolation=cv2.INTER_AREA)
        
        # Cache thumbnail
        self.put(thumbnail_key, thumbnail)
        
        return thumbnail


class StorageManager:
    """
    Storage manager for OPSC Sandwich Quality Inspection System.
    
    Provides functionality for managing file storage, including file operations,
    metadata management, and retention policies.
    """
    
    def __init__(self, config: StorageConfig):
        """
        Initialize storage manager.
        
        Args:
            config: Storage configuration
        """
        self.config = config
        
        # Create base directory if it doesn't exist
        os.makedirs(self.config.base_path, exist_ok=True)
        
        # Initialize metadata storage
        self.metadata_path = os.path.join(self.config.base_path, ".metadata")
        if self.config.metadata_enabled:
            os.makedirs(self.metadata_path, exist_ok=True)
        
        # Initialize metrics
        self.metrics = self._calculate_metrics()
        
        # Initialize locks
        self.file_lock = threading.Lock()
        
        # Initialize background thread for maintenance
        self.maintenance_thread = None
        self.maintenance_thread_running = False
        self.maintenance_interval = 3600  # 1 hour
    
    def start_maintenance_thread(self) -> None:
        """Start background maintenance thread."""
        if self.maintenance_thread is not None and self.maintenance_thread.is_alive():
            logger.warning(f"Maintenance thread for storage {self.config.storage_id} is already running")
            return
        
        self.maintenance_thread_running = True
        self.maintenance_thread = threading.Thread(target=self._maintenance_loop, daemon=True)
        self.maintenance_thread.start()
        
        logger.info(f"Started maintenance thread for storage {self.config.storage_id}")
    
    def stop_maintenance_thread(self) -> None:
        """Stop background maintenance thread."""
        if self.maintenance_thread is None or not self.maintenance_thread.is_alive():
            logger.warning(f"Maintenance thread for storage {self.config.storage_id} is not running")
            return
        
        self.maintenance_thread_running = False
        self.maintenance_thread.join(timeout=30.0)
        
        logger.info(f"Stopped maintenance thread for storage {self.config.storage_id}")
    
    def _maintenance_loop(self) -> None:
        """Maintenance loop for background thread."""
        logger.info(f"Maintenance thread for storage {self.config.storage_id} started")
        
        while self.maintenance_thread_running:
            try:
                # Apply retention policy
                self.apply_retention_policy()
                
                # Update metrics
                self.metrics = self._calculate_metrics()
                
                # Sleep until next maintenance
                for _ in range(self.maintenance_interval):
                    if not self.maintenance_thread_running:
                        break
                    time.sleep(1)
            except Exception as e:
                logger.error(f"Error in maintenance thread for storage {self.config.storage_id}: {e}")
                
                # Sleep before retry
                time.sleep(60)
        
        logger.info(f"Maintenance thread for storage {self.config.storage_id} stopped")
    
    def save_file(self, data: Union[bytes, np.ndarray], prefix: str, extension: str, metadata: Optional[Dict[str, Any]] = None) -> Optional[str]:
        """
        Save file to storage.
        
        Args:
            data: File data as bytes or NumPy array
            prefix: File name prefix
            extension: File extension
            metadata: Optional metadata
        
        Returns:
            File path or None if save failed
        """
        try:
            # Generate file path
            file_path = self._generate_file_path(prefix, extension)
            
            # Create directory if it doesn't exist
            os.makedirs(os.path.dirname(file_path), exist_ok=True)
            
            # Convert NumPy array to bytes if needed
            if isinstance(data, np.ndarray):
                # Determine file format based on extension
                if extension.lower() in ['.jpg', '.jpeg']:
                    _, data = cv2.imencode('.jpg', data, [cv2.IMWRITE_JPEG_QUALITY, 90])
                elif extension.lower() == '.png':
                    _, data = cv2.imencode('.png', data, [cv2.IMWRITE_PNG_COMPRESSION, self.config.compression_level])
                elif extension.lower() == '.bmp':
                    _, data = cv2.imencode('.bmp', data)
                else:
                    # Default to PNG
                    _, data = cv2.imencode('.png', data, [cv2.IMWRITE_PNG_COMPRESSION, self.config.compression_level])
                
                # Convert to bytes
                data = data.tobytes()
            
            # Apply compression if enabled
            if self.config.compression_enabled and not extension.lower() in ['.jpg', '.jpeg', '.png', '.gz', '.zip', '.bz2', '.xz']:
                import gzip
                data = gzip.compress(data, compresslevel=self.config.compression_level)
                file_path += '.gz'
            
            # Apply encryption if enabled
            if self.config.encryption_enabled and self.config.encryption_key:
                from cryptography.fernet import Fernet
                f = Fernet(self.config.encryption_key.encode())
                data = f.encrypt(data)
            
            # Save file
            with open(file_path, 'wb') as f:
                f.write(data)
            
            # Calculate checksum
            checksum = hashlib.md5(data).hexdigest()
            
            # Create file metadata
            file_id = os.path.basename(file_path)
            file_metadata = FileMetadata(
                file_id=file_id,
                file_path=file_path,
                file_name=os.path.basename(file_path),
                file_size=len(data),
                file_type=extension,
                creation_time=datetime.datetime.now(),
                last_access_time=datetime.datetime.now(),
                last_modified_time=datetime.datetime.now(),
                storage_id=self.config.storage_id,
                compression_enabled=self.config.compression_enabled,
                encryption_enabled=self.config.encryption_enabled,
                checksum=checksum,
                custom_metadata=metadata or {}
            )
            
            # Save metadata if enabled
            if self.config.metadata_enabled:
                self._save_metadata(file_id, file_metadata)
            
            # Update metrics
            self.metrics.file_count += 1
            self.metrics.used_size_bytes += len(data)
            if self.metrics.newest_file_time is None or file_metadata.creation_time > self.metrics.newest_file_time:
                self.metrics.newest_file_time = file_metadata.creation_time
            if self.metrics.oldest_file_time is None or file_metadata.creation_time < self.metrics.oldest_file_time:
                self.metrics.oldest_file_time = file_metadata.creation_time
            self.metrics.avg_file_size_bytes = self.metrics.used_size_bytes // self.metrics.file_count if self.metrics.file_count > 0 else 0
            
            return file_path
        except Exception as e:
            logger.error(f"Error saving file: {e}")
            return None
    
    def load_file(self, file_path: str) -> Optional[bytes]:
        """
        Load file from storage.
        
        Args:
            file_path: File path
        
        Returns:
            File data as bytes or None if load failed
        """
        try:
            # Check if file exists
            if not os.path.exists(file_path):
                logger.warning(f"File not found: {file_path}")
                return None
            
            # Get file ID
            file_id = os.path.basename(file_path)
            
            # Load metadata if available
            file_metadata = None
            if self.config.metadata_enabled:
                file_metadata = self._load_metadata(file_id)
            
            # Load file
            with open(file_path, 'rb') as f:
                data = f.read()
            
            # Decrypt if needed
            if file_metadata and file_metadata.encryption_enabled and self.config.encryption_key:
                from cryptography.fernet import Fernet
                f = Fernet(self.config.encryption_key.encode())
                data = f.decrypt(data)
            
            # Decompress if needed
            if file_path.endswith('.gz'):
                import gzip
                data = gzip.decompress(data)
            
            # Verify checksum if available
            if file_metadata and file_metadata.checksum:
                checksum = hashlib.md5(data).hexdigest()
                if checksum != file_metadata.checksum:
                    logger.warning(f"Checksum mismatch for file: {file_path}")
            
            # Update last access time
            if file_metadata:
                file_metadata.last_access_time = datetime.datetime.now()
                if self.config.metadata_enabled:
                    self._save_metadata(file_id, file_metadata)
            
            return data
        except Exception as e:
            logger.error(f"Error loading file: {e}")
            return None
    
    def load_image(self, file_path: str) -> Optional[np.ndarray]:
        """
        Load image from storage.
        
        Args:
            file_path: File path
        
        Returns:
            Image as NumPy array or None if load failed
        """
        try:
            # Load file
            data = self.load_file(file_path)
            if data is None:
                return None
            
            # Convert to NumPy array
            nparr = np.frombuffer(data, np.uint8)
            img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            
            return img
        except Exception as e:
            logger.error(f"Error loading image: {e}")
            return None
    
    def delete_file(self, file_path: str) -> bool:
        """
        Delete file from storage.
        
        Args:
            file_path: File path
        
        Returns:
            True if file was deleted, False otherwise
        """
        try:
            # Check if file exists
            if not os.path.exists(file_path):
                logger.warning(f"File not found: {file_path}")
                return False
            
            # Get file ID
            file_id = os.path.basename(file_path)
            
            # Get file size
            file_size = os.path.getsize(file_path)
            
            # Delete file
            os.remove(file_path)
            
            # Delete metadata if enabled
            if self.config.metadata_enabled:
                self._delete_metadata(file_id)
            
            # Update metrics
            self.metrics.file_count -= 1
            self.metrics.used_size_bytes -= file_size
            self.metrics.avg_file_size_bytes = self.metrics.used_size_bytes // self.metrics.file_count if self.metrics.file_count > 0 else 0
            
            return True
        except Exception as e:
            logger.error(f"Error deleting file: {e}")
            return False
    
    def get_file_metadata(self, file_path: str) -> Optional[FileMetadata]:
        """
        Get file metadata.
        
        Args:
            file_path: File path
        
        Returns:
            File metadata or None if not found
        """
        try:
            # Get file ID
            file_id = os.path.basename(file_path)
            
            # Load metadata if available
            if self.config.metadata_enabled:
                return self._load_metadata(file_id)
            
            # Create basic metadata from file
            if os.path.exists(file_path):
                stat = os.stat(file_path)
                
                return FileMetadata(
                    file_id=file_id,
                    file_path=file_path,
                    file_name=os.path.basename(file_path),
                    file_size=stat.st_size,
                    file_type=os.path.splitext(file_path)[1],
                    creation_time=datetime.datetime.fromtimestamp(stat.st_ctime),
                    last_access_time=datetime.datetime.fromtimestamp(stat.st_atime),
                    last_modified_time=datetime.datetime.fromtimestamp(stat.st_mtime),
                    storage_id=self.config.storage_id,
                    compression_enabled=file_path.endswith('.gz'),
                    encryption_enabled=False,
                    checksum="",
                    custom_metadata={}
                )
            
            return None
        except Exception as e:
            logger.error(f"Error getting file metadata: {e}")
            return None
    
    def list_files(self, prefix: Optional[str] = None, extension: Optional[str] = None, start_date: Optional[datetime.datetime] = None, end_date: Optional[datetime.datetime] = None) -> List[str]:
        """
        List files in storage.
        
        Args:
            prefix: File name prefix filter
            extension: File extension filter
            start_date: Start date filter
            end_date: End date filter
        
        Returns:
            List of file paths
        """
        try:
            # Get all files
            all_files = []
            for root, _, files in os.walk(self.config.base_path):
                # Skip metadata directory
                if root == self.metadata_path or os.path.commonpath([root, self.metadata_path]) == self.metadata_path:
                    continue
                
                for file in files:
                    file_path = os.path.join(root, file)
                    all_files.append(file_path)
            
            # Apply filters
            filtered_files = []
            for file_path in all_files:
                file_name = os.path.basename(file_path)
                
                # Apply prefix filter
                if prefix is not None and not file_name.startswith(prefix):
                    continue
                
                # Apply extension filter
                if extension is not None and not file_name.endswith(extension):
                    continue
                
                # Apply date filters if metadata is enabled
                if (start_date is not None or end_date is not None) and self.config.metadata_enabled:
                    # Get file metadata
                    file_id = os.path.basename(file_path)
                    metadata = self._load_metadata(file_id)
                    
                    if metadata:
                        # Apply start date filter
                        if start_date is not None and metadata.creation_time < start_date:
                            continue
                        
                        # Apply end date filter
                        if end_date is not None and metadata.creation_time > end_date:
                            continue
                
                filtered_files.append(file_path)
            
            return filtered_files
        except Exception as e:
            logger.error(f"Error listing files: {e}")
            return []
    
    def apply_retention_policy(self) -> int:
        """
        Apply retention policy to storage.
        
        Returns:
            Number of files deleted
        """
        try:
            # Skip if policy is KEEP_ALL
            if self.config.retention_policy == RetentionPolicy.KEEP_ALL:
                return 0
            
            # Get all files with metadata
            all_files = []
            for file_path in self.list_files():
                metadata = self.get_file_metadata(file_path)
                if metadata:
                    all_files.append((file_path, metadata))
            
            # Sort files by creation time (oldest first)
            all_files.sort(key=lambda x: x[1].creation_time)
            
            # Apply policy
            files_to_delete = []
            
            if self.config.retention_policy == RetentionPolicy.TIME_BASED:
                # Delete files older than retention days
                cutoff_date = datetime.datetime.now() - datetime.timedelta(days=self.config.retention_days)
                files_to_delete = [file_path for file_path, metadata in all_files if metadata.creation_time < cutoff_date]
            
            elif self.config.retention_policy == RetentionPolicy.COUNT_BASED:
                # Keep only the newest retention_count files
                if len(all_files) > self.config.retention_count:
                    files_to_delete = [file_path for file_path, _ in all_files[:-self.config.retention_count]]
            
            elif self.config.retention_policy == RetentionPolicy.SIZE_BASED:
                # Delete oldest files until under max size
                max_size_bytes = int(self.config.max_size_gb * 1024 * 1024 * 1024)
                current_size = sum(metadata.file_size for _, metadata in all_files)
                
                if current_size > max_size_bytes:
                    for file_path, metadata in all_files:
                        files_to_delete.append(file_path)
                        current_size -= metadata.file_size
                        
                        if current_size <= max_size_bytes:
                            break
            
            elif self.config.retention_policy == RetentionPolicy.HYBRID:
                # Apply all policies
                
                # First, apply time-based policy
                cutoff_date = datetime.datetime.now() - datetime.timedelta(days=self.config.retention_days)
                time_delete = {file_path for file_path, metadata in all_files if metadata.creation_time < cutoff_date}
                
                # Then, apply count-based policy on remaining files
                remaining_files = [(file_path, metadata) for file_path, metadata in all_files if file_path not in time_delete]
                count_delete = set()
                if len(remaining_files) > self.config.retention_count:
                    count_delete = {file_path for file_path, _ in remaining_files[:-self.config.retention_count]}
                
                # Finally, apply size-based policy on remaining files
                remaining_files = [(file_path, metadata) for file_path, metadata in all_files if file_path not in time_delete and file_path not in count_delete]
                size_delete = set()
                max_size_bytes = int(self.config.max_size_gb * 1024 * 1024 * 1024)
                current_size = sum(metadata.file_size for _, metadata in remaining_files)
                
                if current_size > max_size_bytes:
                    for file_path, metadata in remaining_files:
                        size_delete.add(file_path)
                        current_size -= metadata.file_size
                        
                        if current_size <= max_size_bytes:
                            break
                
                # Combine all files to delete
                files_to_delete = list(time_delete | count_delete | size_delete)
            
            # Delete files
            deleted_count = 0
            for file_path in files_to_delete:
                if self.delete_file(file_path):
                    deleted_count += 1
            
            logger.info(f"Applied retention policy to storage {self.config.storage_id}: deleted {deleted_count} files")
            
            return deleted_count
        except Exception as e:
            logger.error(f"Error applying retention policy: {e}")
            return 0
    
    def get_metrics(self) -> StorageMetrics:
        """
        Get storage metrics.
        
        Returns:
            Storage metrics
        """
        return self.metrics
    
    def _calculate_metrics(self) -> StorageMetrics:
        """
        Calculate storage metrics.
        
        Returns:
            Storage metrics
        """
        try:
            # Get disk usage
            disk_usage = shutil.disk_usage(self.config.base_path)
            
            # Count files and calculate total size
            file_count = 0
            used_size = 0
            oldest_time = None
            newest_time = None
            
            for file_path in self.list_files():
                file_count += 1
                file_size = os.path.getsize(file_path)
                used_size += file_size
                
                # Get file creation time
                stat = os.stat(file_path)
                creation_time = datetime.datetime.fromtimestamp(stat.st_ctime)
                
                if oldest_time is None or creation_time < oldest_time:
                    oldest_time = creation_time
                
                if newest_time is None or creation_time > newest_time:
                    newest_time = creation_time
            
            # Calculate average file size
            avg_file_size = used_size // file_count if file_count > 0 else 0
            
            return StorageMetrics(
                storage_id=self.config.storage_id,
                total_size_bytes=disk_usage.total,
                used_size_bytes=used_size,
                free_size_bytes=disk_usage.free,
                file_count=file_count,
                oldest_file_time=oldest_time,
                newest_file_time=newest_time,
                avg_file_size_bytes=avg_file_size
            )
        except Exception as e:
            logger.error(f"Error calculating metrics: {e}")
            
            # Return empty metrics
            return StorageMetrics(
                storage_id=self.config.storage_id,
                total_size_bytes=0,
                used_size_bytes=0,
                free_size_bytes=0,
                file_count=0,
                oldest_file_time=None,
                newest_file_time=None,
                avg_file_size_bytes=0
            )
    
    def _generate_file_path(self, prefix: str, extension: str) -> str:
        """
        Generate file path.
        
        Args:
            prefix: File name prefix
            extension: File extension
        
        Returns:
            File path
        """
        # Generate timestamp
        timestamp = datetime.datetime.now()
        
        # Generate subdirectory
        subdirectory = timestamp.strftime(self.config.subdirectory_format)
        
        # Generate UUID
        uid = str(uuid.uuid4())
        
        # Format file name
        file_name = self.config.file_format.format(
            prefix=prefix,
            timestamp=timestamp.strftime("%Y%m%d_%H%M%S"),
            uuid=uid,
            ext=extension.lstrip('.')
        )
        
        # Combine to get full path
        return os.path.join(self.config.base_path, subdirectory, file_name)
    
    def _save_metadata(self, file_id: str, metadata: FileMetadata) -> bool:
        """
        Save file metadata.
        
        Args:
            file_id: File ID
            metadata: File metadata
        
        Returns:
            True if metadata was saved, False otherwise
        """
        try:
            # Convert to dictionary
            metadata_dict = metadata.to_dict()
            
            # Generate metadata path
            metadata_path = os.path.join(self.metadata_path, f"{file_id}.json")
            
            # Save metadata
            with self.file_lock:
                with open(metadata_path, 'w') as f:
                    json.dump(metadata_dict, f, indent=2)
            
            return True
        except Exception as e:
            logger.error(f"Error saving metadata: {e}")
            return False
    
    def _load_metadata(self, file_id: str) -> Optional[FileMetadata]:
        """
        Load file metadata.
        
        Args:
            file_id: File ID
        
        Returns:
            File metadata or None if not found
        """
        try:
            # Generate metadata path
            metadata_path = os.path.join(self.metadata_path, f"{file_id}.json")
            
            # Check if metadata exists
            if not os.path.exists(metadata_path):
                return None
            
            # Load metadata
            with open(metadata_path, 'r') as f:
                metadata_dict = json.load(f)
            
            # Convert to FileMetadata
            return FileMetadata.from_dict(metadata_dict)
        except Exception as e:
            logger.error(f"Error loading metadata: {e}")
            return None
    
    def _delete_metadata(self, file_id: str) -> bool:
        """
        Delete file metadata.
        
        Args:
            file_id: File ID
        
        Returns:
            True if metadata was deleted, False otherwise
        """
        try:
            # Generate metadata path
            metadata_path = os.path.join(self.metadata_path, f"{file_id}.json")
            
            # Check if metadata exists
            if not os.path.exists(metadata_path):
                return True
            
            # Delete metadata
            with self.file_lock:
                os.remove(metadata_path)
            
            return True
        except Exception as e:
            logger.error(f"Error deleting metadata: {e}")
            return False


class MemoryManager:
    """
    Memory manager for OPSC Sandwich Quality Inspection System.
    
    Provides functionality for monitoring and managing memory usage.
    """
    
    def __init__(self, max_memory_percent: float = 80.0, check_interval: int = 60):
        """
        Initialize memory manager.
        
        Args:
            max_memory_percent: Maximum memory usage percentage
            check_interval: Memory check interval in seconds
        """
        self.max_memory_percent = max_memory_percent
        self.check_interval = check_interval
        
        # Initialize memory cache
        self.memory_cache = MemoryCache()
        
        # Initialize image cache
        self.image_cache = ImageCache()
        
        # Initialize metrics
        self.metrics = self._get_memory_metrics()
        
        # Initialize background thread for monitoring
        self.monitoring_thread = None
        self.monitoring_thread_running = False
        
        # Initialize callbacks
        self.high_memory_callbacks: List[Callable[[], None]] = []
    
    def start_monitoring_thread(self) -> None:
        """Start background monitoring thread."""
        if self.monitoring_thread is not None and self.monitoring_thread.is_alive():
            logger.warning("Memory monitoring thread is already running")
            return
        
        self.monitoring_thread_running = True
        self.monitoring_thread = threading.Thread(target=self._monitoring_loop, daemon=True)
        self.monitoring_thread.start()
        
        logger.info("Started memory monitoring thread")
    
    def stop_monitoring_thread(self) -> None:
        """Stop background monitoring thread."""
        if self.monitoring_thread is None or not self.monitoring_thread.is_alive():
            logger.warning("Memory monitoring thread is not running")
            return
        
        self.monitoring_thread_running = False
        self.monitoring_thread.join(timeout=30.0)
        
        logger.info("Stopped memory monitoring thread")
    
    def _monitoring_loop(self) -> None:
        """Monitoring loop for background thread."""
        logger.info("Memory monitoring thread started")
        
        while self.monitoring_thread_running:
            try:
                # Update metrics
                self.metrics = self._get_memory_metrics()
                
                # Check if memory usage is too high
                if self.metrics["memory_percent"] > self.max_memory_percent:
                    logger.warning(f"Memory usage is too high: {self.metrics['memory_percent']:.1f}% > {self.max_memory_percent:.1f}%")
                    
                    # Call high memory callbacks
                    for callback in self.high_memory_callbacks:
                        try:
                            callback()
                        except Exception as e:
                            logger.error(f"Error in high memory callback: {e}")
                    
                    # Clear caches
                    self.clear_caches()
                
                # Sleep until next check
                for _ in range(self.check_interval):
                    if not self.monitoring_thread_running:
                        break
                    time.sleep(1)
            except Exception as e:
                logger.error(f"Error in memory monitoring thread: {e}")
                
                # Sleep before retry
                time.sleep(60)
        
        logger.info("Memory monitoring thread stopped")
    
    def register_high_memory_callback(self, callback: Callable[[], None]) -> None:
        """
        Register callback for high memory usage.
        
        Args:
            callback: Callback function
        """
        self.high_memory_callbacks.append(callback)
    
    def clear_caches(self) -> None:
        """Clear all caches."""
        self.memory_cache.clear()
        self.image_cache.clear()
        
        # Run garbage collection
        import gc
        gc.collect()
        
        logger.info("Cleared all caches")
    
    def get_metrics(self) -> Dict[str, Any]:
        """
        Get memory metrics.
        
        Returns:
            Dictionary with memory metrics
        """
        return self.metrics
    
    def _get_memory_metrics(self) -> Dict[str, Any]:
        """
        Get memory metrics.
        
        Returns:
            Dictionary with memory metrics
        """
        try:
            # Get memory usage
            memory = psutil.virtual_memory()
            
            # Get process memory usage
            process = psutil.Process(os.getpid())
            process_memory = process.memory_info()
            
            return {
                "total_memory_bytes": memory.total,
                "available_memory_bytes": memory.available,
                "used_memory_bytes": memory.used,
                "memory_percent": memory.percent,
                "process_rss_bytes": process_memory.rss,
                "process_vms_bytes": process_memory.vms,
                "memory_cache_stats": self.memory_cache.get_stats(),
                "image_cache_stats": self.image_cache.get_stats(),
                "timestamp": datetime.datetime.now().isoformat()
            }
        except Exception as e:
            logger.error(f"Error getting memory metrics: {e}")
            
            # Return empty metrics
            return {
                "total_memory_bytes": 0,
                "available_memory_bytes": 0,
                "used_memory_bytes": 0,
                "memory_percent": 0.0,
                "process_rss_bytes": 0,
                "process_vms_bytes": 0,
                "memory_cache_stats": {},
                "image_cache_stats": {},
                "timestamp": datetime.datetime.now().isoformat()
            }


class StorageManagerFactory:
    """
    Factory for creating storage managers.
    
    Provides functionality for creating and managing multiple storage managers.
    """
    
    def __init__(self):
        """Initialize storage manager factory."""
        self.storage_managers: Dict[str, StorageManager] = {}
        self.lock = threading.Lock()
    
    def create_storage_manager(self, config: StorageConfig) -> StorageManager:
        """
        Create storage manager.
        
        Args:
            config: Storage configuration
        
        Returns:
            Storage manager
        """
        with self.lock:
            # Check if storage manager already exists
            if config.storage_id in self.storage_managers:
                return self.storage_managers[config.storage_id]
            
            # Create storage manager
            storage_manager = StorageManager(config)
            
            # Start maintenance thread
            storage_manager.start_maintenance_thread()
            
            # Add to storage managers
            self.storage_managers[config.storage_id] = storage_manager
            
            return storage_manager
    
    def get_storage_manager(self, storage_id: str) -> Optional[StorageManager]:
        """
        Get storage manager.
        
        Args:
            storage_id: Storage ID
        
        Returns:
            Storage manager or None if not found
        """
        with self.lock:
            return self.storage_managers.get(storage_id)
    
    def list_storage_managers(self) -> List[StorageManager]:
        """
        List all storage managers.
        
        Returns:
            List of storage managers
        """
        with self.lock:
            return list(self.storage_managers.values())
    
    def remove_storage_manager(self, storage_id: str) -> bool:
        """
        Remove storage manager.
        
        Args:
            storage_id: Storage ID
        
        Returns:
            True if storage manager was removed, False otherwise
        """
        with self.lock:
            if storage_id in self.storage_managers:
                # Stop maintenance thread
                self.storage_managers[storage_id].stop_maintenance_thread()
                
                # Remove from storage managers
                del self.storage_managers[storage_id]
                
                return True
            
            return False
    
    def shutdown(self) -> None:
        """Shutdown all storage managers."""
        with self.lock:
            for storage_manager in self.storage_managers.values():
                storage_manager.stop_maintenance_thread()
            
            self.storage_managers.clear()


class MemoryAndStorageManager:
    """
    Memory and storage manager for OPSC Sandwich Quality Inspection System.
    
    Provides functionality for managing memory and storage resources.
    """
    
    def __init__(self, max_memory_percent: float = 80.0):
        """
        Initialize memory and storage manager.
        
        Args:
            max_memory_percent: Maximum memory usage percentage
        """
        # Create memory manager
        self.memory_manager = MemoryManager(max_memory_percent=max_memory_percent)
        
        # Create storage manager factory
        self.storage_factory = StorageManagerFactory()
        
        # Initialize default storage managers
        self._initialize_default_storage_managers()
        
        # Register high memory callback
        self.memory_manager.register_high_memory_callback(self._handle_high_memory)
        
        # Start memory monitoring
        self.memory_manager.start_monitoring_thread()
    
    def _initialize_default_storage_managers(self) -> None:
        """Initialize default storage managers."""
        try:
            # Create base directories
            os.makedirs("data/images", exist_ok=True)
            os.makedirs("data/reports", exist_ok=True)
            os.makedirs("data/logs", exist_ok=True)
            
            # Create image storage
            image_config = StorageConfig(
                storage_id="images",
                storage_name="Image Storage",
                storage_type=StorageType.LOCAL,
                base_path="data/images",
                max_size_gb=10.0,
                retention_policy=RetentionPolicy.HYBRID,
                retention_days=30,
                retention_count=10000,
                compression_enabled=True,
                compression_level=6,
                encryption_enabled=False,
                subdirectory_format="%Y/%m/%d",
                file_format="{prefix}_{timestamp}_{uuid}.{ext}",
                metadata_enabled=True
            )
            self.storage_factory.create_storage_manager(image_config)
            
            # Create report storage
            report_config = StorageConfig(
                storage_id="reports",
                storage_name="Report Storage",
                storage_type=StorageType.LOCAL,
                base_path="data/reports",
                max_size_gb=5.0,
                retention_policy=RetentionPolicy.TIME_BASED,
                retention_days=90,
                compression_enabled=True,
                compression_level=9,
                encryption_enabled=False,
                subdirectory_format="%Y/%m",
                file_format="{prefix}_{timestamp}.{ext}",
                metadata_enabled=True
            )
            self.storage_factory.create_storage_manager(report_config)
            
            # Create log storage
            log_config = StorageConfig(
                storage_id="logs",
                storage_name="Log Storage",
                storage_type=StorageType.LOCAL,
                base_path="data/logs",
                max_size_gb=1.0,
                retention_policy=RetentionPolicy.TIME_BASED,
                retention_days=14,
                compression_enabled=True,
                compression_level=9,
                encryption_enabled=False,
                subdirectory_format="%Y/%m/%d",
                file_format="{prefix}_{timestamp}.{ext}",
                metadata_enabled=False
            )
            self.storage_factory.create_storage_manager(log_config)
        except Exception as e:
            logger.error(f"Error initializing default storage managers: {e}")
    
    def _handle_high_memory(self) -> None:
        """Handle high memory usage."""
        logger.warning("Handling high memory usage")
        
        # Clear memory caches
        self.memory_manager.clear_caches()
        
        # Apply retention policies to all storage managers
        for storage_manager in self.storage_factory.list_storage_managers():
            storage_manager.apply_retention_policy()
    
    def get_memory_metrics(self) -> Dict[str, Any]:
        """
        Get memory metrics.
        
        Returns:
            Dictionary with memory metrics
        """
        return self.memory_manager.get_metrics()
    
    def get_storage_metrics(self) -> Dict[str, Dict[str, Any]]:
        """
        Get storage metrics for all storage managers.
        
        Returns:
            Dictionary with storage metrics
        """
        metrics = {}
        
        for storage_manager in self.storage_factory.list_storage_managers():
            metrics[storage_manager.config.storage_id] = storage_manager.get_metrics().to_dict()
        
        return metrics
    
    def get_storage_manager(self, storage_id: str) -> Optional[StorageManager]:
        """
        Get storage manager.
        
        Args:
            storage_id: Storage ID
        
        Returns:
            Storage manager or None if not found
        """
        return self.storage_factory.get_storage_manager(storage_id)
    
    def create_storage_manager(self, config: StorageConfig) -> StorageManager:
        """
        Create storage manager.
        
        Args:
            config: Storage configuration
        
        Returns:
            Storage manager
        """
        return self.storage_factory.create_storage_manager(config)
    
    def save_image(self, image: np.ndarray, prefix: str = "image", metadata: Optional[Dict[str, Any]] = None) -> Optional[str]:
        """
        Save image to image storage.
        
        Args:
            image: Image as NumPy array
            prefix: File name prefix
            metadata: Optional metadata
        
        Returns:
            File path or None if save failed
        """
        # Get image storage manager
        storage_manager = self.storage_factory.get_storage_manager("images")
        if storage_manager is None:
            logger.error("Image storage manager not found")
            return None
        
        # Save image
        return storage_manager.save_file(image, prefix, ".png", metadata)
    
    def load_image(self, file_path: str) -> Optional[np.ndarray]:
        """
        Load image from storage.
        
        Args:
            file_path: File path
        
        Returns:
            Image as NumPy array or None if load failed
        """
        # Get storage manager for this file
        storage_id = self._get_storage_id_for_file(file_path)
        if storage_id is None:
            logger.error(f"Storage manager not found for file: {file_path}")
            return None
        
        storage_manager = self.storage_factory.get_storage_manager(storage_id)
        if storage_manager is None:
            logger.error(f"Storage manager not found: {storage_id}")
            return None
        
        # Load image
        return storage_manager.load_image(file_path)
    
    def save_report(self, report_data: bytes, prefix: str = "report", extension: str = ".pdf", metadata: Optional[Dict[str, Any]] = None) -> Optional[str]:
        """
        Save report to report storage.
        
        Args:
            report_data: Report data as bytes
            prefix: File name prefix
            extension: File extension
            metadata: Optional metadata
        
        Returns:
            File path or None if save failed
        """
        # Get report storage manager
        storage_manager = self.storage_factory.get_storage_manager("reports")
        if storage_manager is None:
            logger.error("Report storage manager not found")
            return None
        
        # Save report
        return storage_manager.save_file(report_data, prefix, extension, metadata)
    
    def load_report(self, file_path: str) -> Optional[bytes]:
        """
        Load report from storage.
        
        Args:
            file_path: File path
        
        Returns:
            Report data as bytes or None if load failed
        """
        # Get storage manager for this file
        storage_id = self._get_storage_id_for_file(file_path)
        if storage_id is None:
            logger.error(f"Storage manager not found for file: {file_path}")
            return None
        
        storage_manager = self.storage_factory.get_storage_manager(storage_id)
        if storage_manager is None:
            logger.error(f"Storage manager not found: {storage_id}")
            return None
        
        # Load report
        return storage_manager.load_file(file_path)
    
    def save_log(self, log_data: str, prefix: str = "log", metadata: Optional[Dict[str, Any]] = None) -> Optional[str]:
        """
        Save log to log storage.
        
        Args:
            log_data: Log data as string
            prefix: File name prefix
            metadata: Optional metadata
        
        Returns:
            File path or None if save failed
        """
        # Get log storage manager
        storage_manager = self.storage_factory.get_storage_manager("logs")
        if storage_manager is None:
            logger.error("Log storage manager not found")
            return None
        
        # Save log
        return storage_manager.save_file(log_data.encode('utf-8'), prefix, ".log", metadata)
    
    def load_log(self, file_path: str) -> Optional[str]:
        """
        Load log from storage.
        
        Args:
            file_path: File path
        
        Returns:
            Log data as string or None if load failed
        """
        # Get storage manager for this file
        storage_id = self._get_storage_id_for_file(file_path)
        if storage_id is None:
            logger.error(f"Storage manager not found for file: {file_path}")
            return None
        
        storage_manager = self.storage_factory.get_storage_manager(storage_id)
        if storage_manager is None:
            logger.error(f"Storage manager not found: {storage_id}")
            return None
        
        # Load log
        log_data = storage_manager.load_file(file_path)
        if log_data is None:
            return None
        
        return log_data.decode('utf-8')
    
    def delete_file(self, file_path: str) -> bool:
        """
        Delete file from storage.
        
        Args:
            file_path: File path
        
        Returns:
            True if file was deleted, False otherwise
        """
        # Get storage manager for this file
        storage_id = self._get_storage_id_for_file(file_path)
        if storage_id is None:
            logger.error(f"Storage manager not found for file: {file_path}")
            return False
        
        storage_manager = self.storage_factory.get_storage_manager(storage_id)
        if storage_manager is None:
            logger.error(f"Storage manager not found: {storage_id}")
            return False
        
        # Delete file
        return storage_manager.delete_file(file_path)
    
    def list_files(self, storage_id: str, prefix: Optional[str] = None, extension: Optional[str] = None, start_date: Optional[datetime.datetime] = None, end_date: Optional[datetime.datetime] = None) -> List[str]:
        """
        List files in storage.
        
        Args:
            storage_id: Storage ID
            prefix: File name prefix filter
            extension: File extension filter
            start_date: Start date filter
            end_date: End date filter
        
        Returns:
            List of file paths
        """
        # Get storage manager
        storage_manager = self.storage_factory.get_storage_manager(storage_id)
        if storage_manager is None:
            logger.error(f"Storage manager not found: {storage_id}")
            return []
        
        # List files
        return storage_manager.list_files(prefix, extension, start_date, end_date)
    
    def get_file_metadata(self, file_path: str) -> Optional[FileMetadata]:
        """
        Get file metadata.
        
        Args:
            file_path: File path
        
        Returns:
            File metadata or None if not found
        """
        # Get storage manager for this file
        storage_id = self._get_storage_id_for_file(file_path)
        if storage_id is None:
            logger.error(f"Storage manager not found for file: {file_path}")
            return None
        
        storage_manager = self.storage_factory.get_storage_manager(storage_id)
        if storage_manager is None:
            logger.error(f"Storage manager not found: {storage_id}")
            return None
        
        # Get file metadata
        return storage_manager.get_file_metadata(file_path)
    
    def apply_retention_policies(self) -> Dict[str, int]:
        """
        Apply retention policies to all storage managers.
        
        Returns:
            Dictionary with number of files deleted per storage
        """
        results = {}
        
        for storage_manager in self.storage_factory.list_storage_managers():
            storage_id = storage_manager.config.storage_id
            deleted_count = storage_manager.apply_retention_policy()
            results[storage_id] = deleted_count
        
        return results
    
    def _get_storage_id_for_file(self, file_path: str) -> Optional[str]:
        """
        Get storage ID for file.
        
        Args:
            file_path: File path
        
        Returns:
            Storage ID or None if not found
        """
        # Convert to absolute path
        file_path = os.path.abspath(file_path)
        
        # Check each storage manager
        for storage_manager in self.storage_factory.list_storage_managers():
            base_path = os.path.abspath(storage_manager.config.base_path)
            
            if file_path.startswith(base_path):
                return storage_manager.config.storage_id
        
        return None
    
    def shutdown(self) -> None:
        """Shutdown memory and storage manager."""
        # Stop memory monitoring
        self.memory_manager.stop_monitoring_thread()
        
        # Shutdown storage managers
        self.storage_factory.shutdown()


# Example usage
if __name__ == "__main__":
    # Setup logging
    logging.basicConfig(level=logging.INFO)
    
    # Create memory and storage manager
    manager = MemoryAndStorageManager(max_memory_percent=80.0)
    
    # Get memory metrics
    memory_metrics = manager.get_memory_metrics()
    print(f"Memory metrics: {memory_metrics}")
    
    # Get storage metrics
    storage_metrics = manager.get_storage_metrics()
    print(f"Storage metrics: {storage_metrics}")
    
    # Create test image
    test_image = np.zeros((480, 640, 3), dtype=np.uint8)
    cv2.rectangle(test_image, (100, 100), (300, 300), (0, 255, 0), 5)
    cv2.putText(test_image, "Test Image", (100, 400), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2)
    
    # Save test image
    image_path = manager.save_image(test_image, "test", {"description": "Test image"})
    print(f"Saved image: {image_path}")
    
    # Load test image
    loaded_image = manager.load_image(image_path)
    if loaded_image is not None:
        print(f"Loaded image: {loaded_image.shape}")
    
    # Get file metadata
    metadata = manager.get_file_metadata(image_path)
    if metadata:
        print(f"File metadata: {metadata.to_dict()}")
    
    # Create test report
    test_report = "This is a test report".encode('utf-8')
    
    # Save test report
    report_path = manager.save_report(test_report, "test", ".txt", {"description": "Test report"})
    print(f"Saved report: {report_path}")
    
    # Load test report
    loaded_report = manager.load_report(report_path)
    if loaded_report is not None:
        print(f"Loaded report: {loaded_report.decode('utf-8')}")
    
    # Create test log
    test_log = "This is a test log"
    
    # Save test log
    log_path = manager.save_log(test_log, "test", {"description": "Test log"})
    print(f"Saved log: {log_path}")
    
    # Load test log
    loaded_log = manager.load_log(log_path)
    if loaded_log is not None:
        print(f"Loaded log: {loaded_log}")
    
    # List files
    image_files = manager.list_files("images")
    print(f"Image files: {image_files}")
    
    report_files = manager.list_files("reports")
    print(f"Report files: {report_files}")
    
    log_files = manager.list_files("logs")
    print(f"Log files: {log_files}")
    
    # Apply retention policies
    results = manager.apply_retention_policies()
    print(f"Applied retention policies: {results}")
    
    # Shutdown
    manager.shutdown()
