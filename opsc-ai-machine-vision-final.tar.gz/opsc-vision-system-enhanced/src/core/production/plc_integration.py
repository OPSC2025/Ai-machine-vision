import time
import logging
import threading
import queue
import socket
import struct
import json
from typing import Dict, List, Tuple, Optional, Any, Union, Callable
from enum import Enum
from dataclasses import dataclass

from src.core.inference.defect_detection import DetectionResult
from src.utils.config import ConfigManager
from src.utils.logging import get_logger

class PLCProtocol(Enum):
    """Supported PLC communication protocols."""
    MODBUS_TCP = "modbus_tcp"
    ETHERNET_IP = "ethernet_ip"
    PROFINET = "profinet"
    OPC_UA = "opc_ua"
    CUSTOM_TCP = "custom_tcp"
    CUSTOM_UDP = "custom_udp"
    SIMULATION = "simulation"

@dataclass
class PLCCommand:
    """Data class to store PLC command information."""
    command_type: str
    timestamp: float
    parameters: Dict[str, Any]
    detection_result: Optional[DetectionResult] = None
    status: str = "pending"
    response: Optional[Dict[str, Any]] = None
    error: Optional[str] = None

@dataclass
class RejectionEvent:
    """Data class to store rejection event information."""
    timestamp: float
    detection_result: DetectionResult
    plc_command: PLCCommand
    status: str
    response_time: float
    error: Optional[str] = None

class PLCIntegrationManager:
    """
    PLC Integration Manager for controlling rejection mechanisms based on defect detection.
    
    This class handles communication with PLCs to trigger rejection mechanisms when
    defects are detected in sandwiches. It supports multiple PLC protocols and provides
    robust error handling and monitoring capabilities.
    """
    
    def __init__(self, config_path: str = "config/plc.yaml"):
        """
        Initialize the PLC Integration Manager.
        
        Args:
            config_path: Path to the PLC configuration file
        """
        self.logger = get_logger("PLCIntegrationManager")
        self.config_manager = ConfigManager()
        self.plc_config = self.config_manager.load_config(config_path)
        
        # Initialize PLC connection
        self.protocol = PLCProtocol(self.plc_config.get("protocol", "simulation"))
        self.connection_params = self.plc_config.get("connection", {})
        self.rejection_config = self.plc_config.get("rejection", {})
        self.monitoring_config = self.plc_config.get("monitoring", {})
        
        # Command queue for thread safety
        self.command_queue = queue.Queue()
        self.response_queue = queue.Queue()
        
        # Connection state
        self.connected = False
        self.connection = None
        self.connection_lock = threading.Lock()
        
        # Rejection statistics
        self.rejection_stats = {
            "total_rejections": 0,
            "successful_rejections": 0,
            "failed_rejections": 0,
            "rejection_by_defect": {},
            "average_response_time": 0.0,
            "last_rejection_time": None,
            "connection_errors": 0
        }
        
        # Initialize rejection counters
        defect_types = self.plc_config.get("defect_types", [])
        for defect_type in defect_types:
            self.rejection_stats["rejection_by_defect"][defect_type] = 0
        
        # Start worker threads
        self.running = True
        self.command_thread = threading.Thread(target=self._command_processor, daemon=True)
        self.command_thread.start()
        
        self.monitoring_thread = None
        if self.monitoring_config.get("enabled", True):
            self.monitoring_thread = threading.Thread(target=self._monitoring_loop, daemon=True)
            self.monitoring_thread.start()
        
        # Rejection event history
        self.rejection_history = []
        self.max_history_size = self.plc_config.get("max_history_size", 1000)
        
        # Callbacks
        self.rejection_callbacks = []
        
        self.logger.info(f"PLC Integration Manager initialized with protocol: {self.protocol.value}")
    
    def connect(self) -> bool:
        """
        Establish connection to the PLC.
        
        Returns:
            True if connection successful, False otherwise
        """
        with self.connection_lock:
            if self.connected:
                return True
            
            try:
                if self.protocol == PLCProtocol.SIMULATION:
                    self.logger.info("Using simulation mode for PLC communication")
                    self.connected = True
                    return True
                
                elif self.protocol == PLCProtocol.MODBUS_TCP:
                    import pymodbus
                    from pymodbus.client.sync import ModbusTcpClient
                    
                    host = self.connection_params.get("host", "localhost")
                    port = self.connection_params.get("port", 502)
                    unit_id = self.connection_params.get("unit_id", 1)
                    
                    self.logger.info(f"Connecting to Modbus TCP PLC at {host}:{port}")
                    self.connection = ModbusTcpClient(host=host, port=port)
                    if self.connection.connect():
                        self.connected = True
                        self.logger.info("Successfully connected to Modbus TCP PLC")
                        return True
                    else:
                        self.logger.error("Failed to connect to Modbus TCP PLC")
                        return False
                
                elif self.protocol == PLCProtocol.ETHERNET_IP:
                    import pycomm3
                    from pycomm3 import LogixDriver
                    
                    host = self.connection_params.get("host", "localhost")
                    slot = self.connection_params.get("slot", 0)
                    
                    self.logger.info(f"Connecting to EtherNet/IP PLC at {host}, slot {slot}")
                    self.connection = LogixDriver(host, slot=slot)
                    self.connection.open()
                    if self.connection.connected:
                        self.connected = True
                        self.logger.info("Successfully connected to EtherNet/IP PLC")
                        return True
                    else:
                        self.logger.error("Failed to connect to EtherNet/IP PLC")
                        return False
                
                elif self.protocol == PLCProtocol.OPC_UA:
                    from opcua import Client
                    
                    url = self.connection_params.get("url", "opc.tcp://localhost:4840")
                    username = self.connection_params.get("username")
                    password = self.connection_params.get("password")
                    
                    self.logger.info(f"Connecting to OPC UA server at {url}")
                    self.connection = Client(url)
                    
                    if username and password:
                        self.connection.set_user(username)
                        self.connection.set_password(password)
                    
                    self.connection.connect()
                    self.connected = True
                    self.logger.info("Successfully connected to OPC UA server")
                    return True
                
                elif self.protocol in [PLCProtocol.CUSTOM_TCP, PLCProtocol.CUSTOM_UDP]:
                    host = self.connection_params.get("host", "localhost")
                    port = self.connection_params.get("port", 9600)
                    timeout = self.connection_params.get("timeout", 5.0)
                    
                    if self.protocol == PLCProtocol.CUSTOM_TCP:
                        self.logger.info(f"Connecting to custom TCP PLC at {host}:{port}")
                        self.connection = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    else:
                        self.logger.info(f"Connecting to custom UDP PLC at {host}:{port}")
                        self.connection = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                    
                    self.connection.settimeout(timeout)
                    self.connection.connect((host, port))
                    self.connected = True
                    self.logger.info(f"Successfully connected to custom {self.protocol.value} PLC")
                    return True
                
                elif self.protocol == PLCProtocol.PROFINET:
                    # Note: This is a placeholder for PROFINET integration
                    # Actual implementation would require specific PROFINET libraries
                    self.logger.warning("PROFINET protocol support is limited. Using simulation mode.")
                    self.connected = True
                    return True
                
                else:
                    self.logger.error(f"Unsupported protocol: {self.protocol.value}")
                    return False
            
            except Exception as e:
                self.logger.error(f"Error connecting to PLC: {str(e)}")
                self.rejection_stats["connection_errors"] += 1
                return False
    
    def disconnect(self):
        """Disconnect from the PLC."""
        with self.connection_lock:
            if not self.connected:
                return
            
            try:
                if self.protocol == PLCProtocol.SIMULATION:
                    pass  # No actual connection to close
                
                elif self.protocol == PLCProtocol.MODBUS_TCP:
                    if self.connection:
                        self.connection.close()
                
                elif self.protocol == PLCProtocol.ETHERNET_IP:
                    if self.connection:
                        self.connection.close()
                
                elif self.protocol == PLCProtocol.OPC_UA:
                    if self.connection:
                        self.connection.disconnect()
                
                elif self.protocol in [PLCProtocol.CUSTOM_TCP, PLCProtocol.CUSTOM_UDP]:
                    if self.connection:
                        self.connection.close()
                
                self.connected = False
                self.logger.info("Disconnected from PLC")
            
            except Exception as e:
                self.logger.error(f"Error disconnecting from PLC: {str(e)}")
    
    def reject_sandwich(self, detection_result: DetectionResult) -> bool:
        """
        Trigger rejection mechanism for a defective sandwich.
        
        Args:
            detection_result: Detection result containing defect information
            
        Returns:
            True if rejection command was queued successfully, False otherwise
        """
        try:
            # Create rejection command
            command = PLCCommand(
                command_type="reject",
                timestamp=time.time(),
                parameters={
                    "camera_id": detection_result.camera_id,
                    "defect_types": detection_result.defect_types,
                    "confidence_scores": detection_result.confidence_scores,
                    "rejection_reason": detection_result.rejection_reason
                },
                detection_result=detection_result
            )
            
            # Add to command queue
            self.command_queue.put(command)
            
            return True
        
        except Exception as e:
            self.logger.error(f"Error queueing rejection command: {str(e)}")
            return False
    
    def _command_processor(self):
        """Worker thread to process PLC commands."""
        while self.running:
            try:
                # Get command from queue with timeout
                try:
                    command = self.command_queue.get(timeout=1.0)
                except queue.Empty:
                    continue
                
                # Process command
                if command.command_type == "reject":
                    self._process_rejection(command)
                elif command.command_type == "status":
                    self._process_status_request(command)
                elif command.command_type == "reset":
                    self._process_reset(command)
                else:
                    self.logger.warning(f"Unknown command type: {command.command_type}")
                
                # Mark command as done
                self.command_queue.task_done()
            
            except Exception as e:
                self.logger.error(f"Error in command processor: {str(e)}")
                time.sleep(1.0)  # Prevent tight loop on error
    
    def _process_rejection(self, command: PLCCommand):
        """
        Process a rejection command.
        
        Args:
            command: Rejection command to process
        """
        start_time = time.time()
        rejection_event = None
        
        try:
            # Ensure connection is established
            if not self.connected and not self.connect():
                command.status = "failed"
                command.error = "Failed to connect to PLC"
                self.rejection_stats["failed_rejections"] += 1
                
                rejection_event = RejectionEvent(
                    timestamp=start_time,
                    detection_result=command.detection_result,
                    plc_command=command,
                    status="failed",
                    response_time=time.time() - start_time,
                    error="Failed to connect to PLC"
                )
                return
            
            # Get rejection parameters
            camera_id = command.parameters.get("camera_id")
            defect_types = command.parameters.get("defect_types", [])
            
            # Get rejection configuration for this camera
            camera_config = self.rejection_config.get("cameras", {}).get(camera_id, {})
            rejection_address = camera_config.get("address", self.rejection_config.get("default_address"))
            rejection_value = camera_config.get("value", self.rejection_config.get("default_value", 1))
            reset_delay = camera_config.get("reset_delay", self.rejection_config.get("reset_delay", 0.5))
            
            # Execute rejection based on protocol
            if self.protocol == PLCProtocol.SIMULATION:
                # Simulate rejection
                self.logger.info(f"Simulating rejection for camera {camera_id}, defects: {defect_types}")
                time.sleep(0.1)  # Simulate communication delay
                success = True
            
            elif self.protocol == PLCProtocol.MODBUS_TCP:
                # Write to coil or register based on configuration
                if isinstance(rejection_address, int):
                    # Assume it's a coil address
                    response = self.connection.write_coil(rejection_address, True)
                    success = not response.isError()
                    
                    # Reset after delay if configured
                    if success and reset_delay > 0:
                        time.sleep(reset_delay)
                        self.connection.write_coil(rejection_address, False)
                else:
                    # Assume it's a register address
                    register_address, bit_position = self._parse_address(rejection_address)
                    if bit_position is not None:
                        # Read current value
                        response = self.connection.read_holding_registers(register_address, 1)
                        if response.isError():
                            raise Exception(f"Error reading register {register_address}")
                        
                        current_value = response.registers[0]
                        # Set bit
                        new_value = current_value | (1 << bit_position)
                        response = self.connection.write_register(register_address, new_value)
                        success = not response.isError()
                        
                        # Reset after delay if configured
                        if success and reset_delay > 0:
                            time.sleep(reset_delay)
                            reset_value = new_value & ~(1 << bit_position)
                            self.connection.write_register(register_address, reset_value)
                    else:
                        # Write value directly
                        response = self.connection.write_register(register_address, rejection_value)
                        success = not response.isError()
                        
                        # Reset after delay if configured
                        if success and reset_delay > 0:
                            time.sleep(reset_delay)
                            self.connection.write_register(register_address, 0)
            
            elif self.protocol == PLCProtocol.ETHERNET_IP:
                # Write to tag
                response = self.connection.write(rejection_address, rejection_value)
                success = response is not None and response.error is None
                
                # Reset after delay if configured
                if success and reset_delay > 0:
                    time.sleep(reset_delay)
                    self.connection.write(rejection_address, 0)
            
            elif self.protocol == PLCProtocol.OPC_UA:
                # Get node and write value
                node = self.connection.get_node(rejection_address)
                node.set_value(rejection_value)
                success = True
                
                # Reset after delay if configured
                if reset_delay > 0:
                    time.sleep(reset_delay)
                    node.set_value(0)
            
            elif self.protocol in [PLCProtocol.CUSTOM_TCP, PLCProtocol.CUSTOM_UDP]:
                # Create custom message
                message_format = self.connection_params.get("message_format", "json")
                
                if message_format == "json":
                    message = json.dumps({
                        "command": "reject",
                        "address": rejection_address,
                        "value": rejection_value,
                        "camera_id": camera_id,
                        "defect_types": defect_types,
                        "timestamp": time.time()
                    }).encode('utf-8')
                else:
                    # Binary format
                    format_string = self.connection_params.get("format_string", "!HHHH")
                    values = [
                        int(self.connection_params.get("command_code", 1)),  # Reject command
                        int(rejection_address),
                        int(rejection_value),
                        int(camera_id.split('_')[-1]) if camera_id else 0
                    ]
                    message = struct.pack(format_string, *values)
                
                # Send message
                self.connection.sendall(message)
                
                # Wait for response if configured
                if self.connection_params.get("wait_response", False):
                    response_timeout = self.connection_params.get("response_timeout", 1.0)
                    self.connection.settimeout(response_timeout)
                    response_data = self.connection.recv(1024)
                    
                    if message_format == "json":
                        response = json.loads(response_data.decode('utf-8'))
                        success = response.get("status") == "success"
                    else:
                        # Parse binary response
                        response_format = self.connection_params.get("response_format", "!HH")
                        unpacked = struct.unpack(response_format, response_data)
                        success = unpacked[0] == 0  # Assume first value is status code
                else:
                    success = True  # Assume success if not waiting for response
                
                # Reset after delay if configured
                if success and reset_delay > 0:
                    time.sleep(reset_delay)
                    
                    if message_format == "json":
                        reset_message = json.dumps({
                            "command": "reset",
                            "address": rejection_address,
                            "value": 0,
                            "camera_id": camera_id,
                            "timestamp": time.time()
                        }).encode('utf-8')
                    else:
                        reset_values = [
                            int(self.connection_params.get("reset_code", 2)),  # Reset command
                            int(rejection_address),
                            0,  # Reset value
                            int(camera_id.split('_')[-1]) if camera_id else 0
                        ]
                        reset_message = struct.pack(format_string, *reset_values)
                    
                    self.connection.sendall(reset_message)
            
            # Update command status
            command.status = "success" if success else "failed"
            if not success:
                command.error = "PLC rejection command failed"
            
            # Update statistics
            self.rejection_stats["total_rejections"] += 1
            if success:
                self.rejection_stats["successful_rejections"] += 1
                
                # Update defect type counters
                for defect_type in defect_types:
                    if defect_type in self.rejection_stats["rejection_by_defect"]:
                        self.rejection_stats["rejection_by_defect"][defect_type] += 1
            else:
                self.rejection_stats["failed_rejections"] += 1
            
            # Update response time statistics
            response_time = time.time() - start_time
            n = self.rejection_stats["total_rejections"]
            prev_avg = self.rejection_stats["average_response_time"]
            self.rejection_stats["average_response_time"] = ((n - 1) * prev_avg + response_time) / n
            
            # Update last rejection time
            self.rejection_stats["last_rejection_time"] = time.time()
            
            # Create rejection event
            rejection_event = RejectionEvent(
                timestamp=start_time,
                detection_result=command.detection_result,
                plc_command=command,
                status="success" if success else "failed",
                response_time=response_time,
                error=command.error
            )
            
            # Log rejection
            if success:
                self.logger.info(f"Successfully rejected sandwich from camera {camera_id} with defects: {defect_types}")
            else:
                self.logger.error(f"Failed to reject sandwich from camera {camera_id} with defects: {defect_types}")
        
        except Exception as e:
            # Update command status
            command.status = "failed"
            command.error = str(e)
            
            # Update statistics
            self.rejection_stats["total_rejections"] += 1
            self.rejection_stats["failed_rejections"] += 1
            
            # Create rejection event
            rejection_event = RejectionEvent(
                timestamp=start_time,
                detection_result=command.detection_result,
                plc_command=command,
                status="failed",
                response_time=time.time() - start_time,
                error=str(e)
            )
            
            self.logger.error(f"Error processing rejection command: {str(e)}")
        
        finally:
            # Add to history
            if rejection_event:
                self._add_to_history(rejection_event)
                
                # Notify callbacks
                for callback in self.rejection_callbacks:
                    try:
                        callback(rejection_event)
                    except Exception as e:
                        self.logger.error(f"Error in rejection callback: {str(e)}")
    
    def _process_status_request(self, command: PLCCommand):
        """
        Process a status request command.
        
        Args:
            command: Status request command to process
        """
        try:
            # Ensure connection is established
            if not self.connected and not self.connect():
                command.status = "failed"
                command.error = "Failed to connect to PLC"
                return
            
            # Get status based on protocol
            if self.protocol == PLCProtocol.SIMULATION:
                # Simulate status
                status = {
                    "connected": True,
                    "status": "running",
                    "error_code": 0,
                    "rejection_count": self.rejection_stats["total_rejections"]
                }
            
            elif self.protocol == PLCProtocol.MODBUS_TCP:
                # Read status registers
                status_address = self.monitoring_config.get("status_address", 0)
                count = self.monitoring_config.get("status_count", 4)
                
                response = self.connection.read_holding_registers(status_address, count)
                if response.isError():
                    raise Exception(f"Error reading status registers: {response}")
                
                status = {
                    "connected": True,
                    "registers": response.registers,
                    "status_code": response.registers[0] if response.registers else 0,
                    "error_code": response.registers[1] if len(response.registers) > 1 else 0,
                    "rejection_count": response.registers[2] if len(response.registers) > 2 else 0,
                    "system_state": response.registers[3] if len(response.registers) > 3 else 0
                }
            
            elif self.protocol == PLCProtocol.ETHERNET_IP:
                # Read status tags
                status_tags = self.monitoring_config.get("status_tags", ["Status", "ErrorCode", "RejectionCount", "SystemState"])
                
                status = {"connected": True}
                for tag in status_tags:
                    response = self.connection.read(tag)
                    if response and response.value is not None:
                        status[tag] = response.value
            
            elif self.protocol == PLCProtocol.OPC_UA:
                # Read status nodes
                status_nodes = self.monitoring_config.get("status_nodes", ["Status", "ErrorCode", "RejectionCount", "SystemState"])
                
                status = {"connected": True}
                for node_name in status_nodes:
                    node_id = self.monitoring_config.get(f"{node_name}_node")
                    if node_id:
                        node = self.connection.get_node(node_id)
                        status[node_name] = node.get_value()
            
            elif self.protocol in [PLCProtocol.CUSTOM_TCP, PLCProtocol.CUSTOM_UDP]:
                # Create custom status request
                message_format = self.connection_params.get("message_format", "json")
                
                if message_format == "json":
                    message = json.dumps({
                        "command": "status",
                        "timestamp": time.time()
                    }).encode('utf-8')
                else:
                    # Binary format
                    format_string = self.connection_params.get("format_string", "!H")
                    values = [int(self.connection_params.get("status_code", 3))]  # Status request command
                    message = struct.pack(format_string, *values)
                
                # Send message
                self.connection.sendall(message)
                
                # Wait for response
                response_timeout = self.connection_params.get("response_timeout", 1.0)
                self.connection.settimeout(response_timeout)
                response_data = self.connection.recv(1024)
                
                if message_format == "json":
                    status = json.loads(response_data.decode('utf-8'))
                    status["connected"] = True
                else:
                    # Parse binary response
                    response_format = self.connection_params.get("status_format", "!HHHH")
                    unpacked = struct.unpack(response_format, response_data)
                    status = {
                        "connected": True,
                        "status_code": unpacked[0],
                        "error_code": unpacked[1],
                        "rejection_count": unpacked[2],
                        "system_state": unpacked[3]
                    }
            
            # Update command status
            command.status = "success"
            command.response = status
            
            # Add to response queue
            self.response_queue.put(command)
            
        except Exception as e:
            # Update command status
            command.status = "failed"
            command.error = str(e)
            
            # Add to response queue
            self.response_queue.put(command)
            
            self.logger.error(f"Error processing status request: {str(e)}")
    
    def _process_reset(self, command: PLCCommand):
        """
        Process a reset command.
        
        Args:
            command: Reset command to process
        """
        try:
            # Ensure connection is established
            if not self.connected and not self.connect():
                command.status = "failed"
                command.error = "Failed to connect to PLC"
                return
            
            # Execute reset based on protocol
            if self.protocol == PLCProtocol.SIMULATION:
                # Simulate reset
                self.logger.info("Simulating PLC reset")
                time.sleep(0.1)  # Simulate communication delay
                success = True
            
            elif self.protocol == PLCProtocol.MODBUS_TCP:
                # Write to reset register or coil
                reset_address = self.monitoring_config.get("reset_address")
                if reset_address is None:
                    raise ValueError("Reset address not configured")
                
                if isinstance(reset_address, int):
                    # Assume it's a coil address
                    response = self.connection.write_coil(reset_address, True)
                    success = not response.isError()
                else:
                    # Assume it's a register address
                    register_address, bit_position = self._parse_address(reset_address)
                    if bit_position is not None:
                        # Read current value
                        response = self.connection.read_holding_registers(register_address, 1)
                        if response.isError():
                            raise Exception(f"Error reading register {register_address}")
                        
                        current_value = response.registers[0]
                        # Set bit
                        new_value = current_value | (1 << bit_position)
                        response = self.connection.write_register(register_address, new_value)
                        success = not response.isError()
                    else:
                        # Write value directly
                        response = self.connection.write_register(register_address, 1)
                        success = not response.isError()
            
            elif self.protocol == PLCProtocol.ETHERNET_IP:
                # Write to reset tag
                reset_tag = self.monitoring_config.get("reset_tag")
                if reset_tag is None:
                    raise ValueError("Reset tag not configured")
                
                response = self.connection.write(reset_tag, 1)
                success = response is not None and response.error is None
            
            elif self.protocol == PLCProtocol.OPC_UA:
                # Write to reset node
                reset_node_id = self.monitoring_config.get("reset_node")
                if reset_node_id is None:
                    raise ValueError("Reset node not configured")
                
                node = self.connection.get_node(reset_node_id)
                node.set_value(1)
                success = True
            
            elif self.protocol in [PLCProtocol.CUSTOM_TCP, PLCProtocol.CUSTOM_UDP]:
                # Create custom reset message
                message_format = self.connection_params.get("message_format", "json")
                
                if message_format == "json":
                    message = json.dumps({
                        "command": "reset",
                        "timestamp": time.time()
                    }).encode('utf-8')
                else:
                    # Binary format
                    format_string = self.connection_params.get("format_string", "!H")
                    values = [int(self.connection_params.get("reset_code", 2))]  # Reset command
                    message = struct.pack(format_string, *values)
                
                # Send message
                self.connection.sendall(message)
                
                # Wait for response if configured
                if self.connection_params.get("wait_response", False):
                    response_timeout = self.connection_params.get("response_timeout", 1.0)
                    self.connection.settimeout(response_timeout)
                    response_data = self.connection.recv(1024)
                    
                    if message_format == "json":
                        response = json.loads(response_data.decode('utf-8'))
                        success = response.get("status") == "success"
                    else:
                        # Parse binary response
                        response_format = self.connection_params.get("response_format", "!H")
                        unpacked = struct.unpack(response_format, response_data)
                        success = unpacked[0] == 0  # Assume first value is status code
                else:
                    success = True  # Assume success if not waiting for response
            
            # Update command status
            command.status = "success" if success else "failed"
            if not success:
                command.error = "PLC reset command failed"
            
            # Log reset
            if success:
                self.logger.info("Successfully reset PLC")
            else:
                self.logger.error("Failed to reset PLC")
            
        except Exception as e:
            # Update command status
            command.status = "failed"
            command.error = str(e)
            
            self.logger.error(f"Error processing reset command: {str(e)}")
    
    def _monitoring_loop(self):
        """Worker thread to monitor PLC status."""
        while self.running:
            try:
                # Check if monitoring is enabled
                if not self.monitoring_config.get("enabled", True):
                    time.sleep(5.0)
                    continue
                
                # Get monitoring interval
                interval = self.monitoring_config.get("interval", 5.0)
                
                # Create status request command
                command = PLCCommand(
                    command_type="status",
                    timestamp=time.time(),
                    parameters={}
                )
                
                # Add to command queue
                self.command_queue.put(command)
                
                # Wait for response with timeout
                try:
                    start_time = time.time()
                    timeout = self.monitoring_config.get("timeout", 2.0)
                    
                    while time.time() - start_time < timeout:
                        try:
                            response = self.response_queue.get(timeout=0.1)
                            if response.timestamp == command.timestamp:
                                # Process monitoring response
                                if response.status == "success":
                                    self._process_monitoring_data(response.response)
                                else:
                                    self.logger.warning(f"Monitoring request failed: {response.error}")
                                break
                            else:
                                # Put back responses for other commands
                                self.response_queue.put(response)
                        except queue.Empty:
                            pass
                
                except Exception as e:
                    self.logger.error(f"Error waiting for monitoring response: {str(e)}")
                
                # Sleep until next monitoring interval
                time.sleep(interval)
            
            except Exception as e:
                self.logger.error(f"Error in monitoring loop: {str(e)}")
                time.sleep(5.0)  # Prevent tight loop on error
    
    def _process_monitoring_data(self, data: Dict[str, Any]):
        """
        Process monitoring data from PLC.
        
        Args:
            data: Monitoring data from PLC
        """
        # Log monitoring data
        if self.monitoring_config.get("log_data", False):
            self.logger.debug(f"PLC monitoring data: {data}")
        
        # Check for alarms
        if "error_code" in data and data["error_code"] != 0:
            self.logger.warning(f"PLC error detected: code {data['error_code']}")
        
        # Check for status changes
        if "status_code" in data:
            status_code = data["status_code"]
            status_messages = self.monitoring_config.get("status_messages", {})
            status_message = status_messages.get(str(status_code), f"Status code {status_code}")
            
            self.logger.info(f"PLC status: {status_message}")
        
        # Check rejection count
        if "rejection_count" in data:
            plc_rejection_count = data["rejection_count"]
            local_rejection_count = self.rejection_stats["successful_rejections"]
            
            if plc_rejection_count != local_rejection_count:
                self.logger.warning(f"Rejection count mismatch: PLC={plc_rejection_count}, Local={local_rejection_count}")
    
    def _add_to_history(self, event: RejectionEvent):
        """
        Add rejection event to history.
        
        Args:
            event: Rejection event to add
        """
        self.rejection_history.append(event)
        
        # Trim history if needed
        if len(self.rejection_history) > self.max_history_size:
            self.rejection_history = self.rejection_history[-self.max_history_size:]
    
    def _parse_address(self, address: str) -> Tuple[int, Optional[int]]:
        """
        Parse address string into register address and bit position.
        
        Args:
            address: Address string (e.g., "40001.2" for register 40001, bit 2)
            
        Returns:
            Tuple of (register_address, bit_position)
        """
        if '.' in address:
            parts = address.split('.')
            return int(parts[0]), int(parts[1])
        else:
            return int(address), None
    
    def get_status(self) -> Dict[str, Any]:
        """
        Get current PLC status.
        
        Returns:
            Dictionary with PLC status information
        """
        # Create status request command
        command = PLCCommand(
            command_type="status",
            timestamp=time.time(),
            parameters={}
        )
        
        # Add to command queue
        self.command_queue.put(command)
        
        # Wait for response with timeout
        try:
            start_time = time.time()
            timeout = 2.0
            
            while time.time() - start_time < timeout:
                try:
                    response = self.response_queue.get(timeout=0.1)
                    if response.timestamp == command.timestamp:
                        if response.status == "success":
                            return response.response
                        else:
                            return {
                                "connected": False,
                                "error": response.error
                            }
                    else:
                        # Put back responses for other commands
                        self.response_queue.put(response)
                except queue.Empty:
                    pass
            
            return {
                "connected": self.connected,
                "error": "Timeout waiting for status response"
            }
        
        except Exception as e:
            return {
                "connected": False,
                "error": str(e)
            }
    
    def reset_plc(self) -> bool:
        """
        Reset the PLC.
        
        Returns:
            True if reset command was queued successfully, False otherwise
        """
        try:
            # Create reset command
            command = PLCCommand(
                command_type="reset",
                timestamp=time.time(),
                parameters={}
            )
            
            # Add to command queue
            self.command_queue.put(command)
            
            return True
        
        except Exception as e:
            self.logger.error(f"Error queueing reset command: {str(e)}")
            return False
    
    def get_statistics(self) -> Dict[str, Any]:
        """
        Get current rejection statistics.
        
        Returns:
            Dictionary of rejection statistics
        """
        return self.rejection_stats
    
    def reset_statistics(self):
        """Reset rejection statistics."""
        defect_types = list(self.rejection_stats["rejection_by_defect"].keys())
        
        self.rejection_stats = {
            "total_rejections": 0,
            "successful_rejections": 0,
            "failed_rejections": 0,
            "rejection_by_defect": {defect_type: 0 for defect_type in defect_types},
            "average_response_time": 0.0,
            "last_rejection_time": None,
            "connection_errors": 0
        }
    
    def get_rejection_history(self, limit: int = None) -> List[RejectionEvent]:
        """
        Get rejection event history.
        
        Args:
            limit: Maximum number of events to return, or None for all
            
        Returns:
            List of rejection events
        """
        if limit is None or limit >= len(self.rejection_history):
            return self.rejection_history
        else:
            return self.rejection_history[-limit:]
    
    def clear_rejection_history(self):
        """Clear rejection event history."""
        self.rejection_history = []
    
    def register_rejection_callback(self, callback: Callable[[RejectionEvent], None]):
        """
        Register a callback function to be called when a rejection event occurs.
        
        Args:
            callback: Function to call with rejection event
        """
        self.rejection_callbacks.append(callback)
    
    def unregister_rejection_callback(self, callback: Callable[[RejectionEvent], None]):
        """
        Unregister a rejection callback function.
        
        Args:
            callback: Function to unregister
        """
        if callback in self.rejection_callbacks:
            self.rejection_callbacks.remove(callback)
    
    def shutdown(self):
        """Shutdown the PLC Integration Manager."""
        self.running = False
        
        if self.command_thread:
            self.command_thread.join(timeout=2.0)
        
        if self.monitoring_thread:
            self.monitoring_thread.join(timeout=2.0)
        
        self.disconnect()
        
        self.logger.info("PLC Integration Manager shutdown complete")
