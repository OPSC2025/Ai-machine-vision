"""
Production run management module for OPSC Sandwich Quality Inspection System.
Provides functionality for managing production runs, batches, and shifts.

Version: 1.0.0
Last Updated: 2025-04-21
"""

import os
import sys
import time
import json
import logging
import datetime
import uuid
import sqlite3
import numpy as np
import pandas as pd
import yaml
import threading
import queue
from typing import Dict, List, Optional, Tuple, Union, Any, BinaryIO
from dataclasses import dataclass, field
from pathlib import Path
from enum import Enum, auto

# Setup logging
logger = logging.getLogger(__name__)

class ProductionStatus(Enum):
    """Production status enum."""
    IDLE = auto()
    SETUP = auto()
    RUNNING = auto()
    PAUSED = auto()
    STOPPED = auto()
    COMPLETED = auto()
    ERROR = auto()
    MAINTENANCE = auto()
    CALIBRATION = auto()


@dataclass
class ProductConfig:
    """Product configuration data class."""
    product_id: str
    product_name: str
    product_code: str
    product_version: str
    description: str = ""
    created_at: str = field(default_factory=lambda: datetime.datetime.now().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.datetime.now().isoformat())
    active: bool = True
    parameters: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "product_id": self.product_id,
            "product_name": self.product_name,
            "product_code": self.product_code,
            "product_version": self.product_version,
            "description": self.description,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "active": self.active,
            "parameters": self.parameters
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ProductConfig':
        """Create from dictionary."""
        return cls(
            product_id=data.get("product_id"),
            product_name=data.get("product_name"),
            product_code=data.get("product_code"),
            product_version=data.get("product_version"),
            description=data.get("description", ""),
            created_at=data.get("created_at", datetime.datetime.now().isoformat()),
            updated_at=data.get("updated_at", datetime.datetime.now().isoformat()),
            active=data.get("active", True),
            parameters=data.get("parameters", {})
        )


@dataclass
class ProductionRunConfig:
    """Production run configuration data class."""
    run_id: str
    product_id: str
    batch_id: str
    operator_id: str
    line_id: str
    scheduled_start: str
    scheduled_end: str
    target_quantity: int
    description: str = ""
    created_at: str = field(default_factory=lambda: datetime.datetime.now().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.datetime.now().isoformat())
    parameters: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "run_id": self.run_id,
            "product_id": self.product_id,
            "batch_id": self.batch_id,
            "operator_id": self.operator_id,
            "line_id": self.line_id,
            "scheduled_start": self.scheduled_start,
            "scheduled_end": self.scheduled_end,
            "target_quantity": self.target_quantity,
            "description": self.description,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "parameters": self.parameters
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ProductionRunConfig':
        """Create from dictionary."""
        return cls(
            run_id=data.get("run_id"),
            product_id=data.get("product_id"),
            batch_id=data.get("batch_id"),
            operator_id=data.get("operator_id"),
            line_id=data.get("line_id"),
            scheduled_start=data.get("scheduled_start"),
            scheduled_end=data.get("scheduled_end"),
            target_quantity=data.get("target_quantity"),
            description=data.get("description", ""),
            created_at=data.get("created_at", datetime.datetime.now().isoformat()),
            updated_at=data.get("updated_at", datetime.datetime.now().isoformat()),
            parameters=data.get("parameters", {})
        )


@dataclass
class ProductionRunStatus:
    """Production run status data class."""
    run_id: str
    status: ProductionStatus
    actual_start: Optional[str] = None
    actual_end: Optional[str] = None
    current_quantity: int = 0
    good_quantity: int = 0
    reject_quantity: int = 0
    defect_counts: Dict[str, int] = field(default_factory=dict)
    downtime_minutes: float = 0.0
    efficiency: float = 0.0
    oee: float = 0.0
    notes: str = ""
    updated_at: str = field(default_factory=lambda: datetime.datetime.now().isoformat())
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "run_id": self.run_id,
            "status": self.status.name,
            "actual_start": self.actual_start,
            "actual_end": self.actual_end,
            "current_quantity": self.current_quantity,
            "good_quantity": self.good_quantity,
            "reject_quantity": self.reject_quantity,
            "defect_counts": self.defect_counts,
            "downtime_minutes": self.downtime_minutes,
            "efficiency": self.efficiency,
            "oee": self.oee,
            "notes": self.notes,
            "updated_at": self.updated_at
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ProductionRunStatus':
        """Create from dictionary."""
        status_str = data.get("status", "IDLE")
        try:
            status = ProductionStatus[status_str]
        except KeyError:
            status = ProductionStatus.IDLE
            logger.warning(f"Invalid production status: {status_str}, defaulting to IDLE")
        
        return cls(
            run_id=data.get("run_id"),
            status=status,
            actual_start=data.get("actual_start"),
            actual_end=data.get("actual_end"),
            current_quantity=data.get("current_quantity", 0),
            good_quantity=data.get("good_quantity", 0),
            reject_quantity=data.get("reject_quantity", 0),
            defect_counts=data.get("defect_counts", {}),
            downtime_minutes=data.get("downtime_minutes", 0.0),
            efficiency=data.get("efficiency", 0.0),
            oee=data.get("oee", 0.0),
            notes=data.get("notes", ""),
            updated_at=data.get("updated_at", datetime.datetime.now().isoformat())
        )


@dataclass
class ProductionEvent:
    """Production event data class."""
    event_id: str
    run_id: str
    event_type: str
    timestamp: str
    data: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "event_id": self.event_id,
            "run_id": self.run_id,
            "event_type": self.event_type,
            "timestamp": self.timestamp,
            "data": self.data
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ProductionEvent':
        """Create from dictionary."""
        return cls(
            event_id=data.get("event_id"),
            run_id=data.get("run_id"),
            event_type=data.get("event_type"),
            timestamp=data.get("timestamp"),
            data=data.get("data", {})
        )


@dataclass
class DowntimeRecord:
    """Downtime record data class."""
    downtime_id: str
    run_id: str
    start_time: str
    end_time: Optional[str] = None
    duration_minutes: float = 0.0
    reason: str = ""
    category: str = ""
    notes: str = ""
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "downtime_id": self.downtime_id,
            "run_id": self.run_id,
            "start_time": self.start_time,
            "end_time": self.end_time,
            "duration_minutes": self.duration_minutes,
            "reason": self.reason,
            "category": self.category,
            "notes": self.notes
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'DowntimeRecord':
        """Create from dictionary."""
        return cls(
            downtime_id=data.get("downtime_id"),
            run_id=data.get("run_id"),
            start_time=data.get("start_time"),
            end_time=data.get("end_time"),
            duration_minutes=data.get("duration_minutes", 0.0),
            reason=data.get("reason", ""),
            category=data.get("category", ""),
            notes=data.get("notes", "")
        )


@dataclass
class ShiftConfig:
    """Shift configuration data class."""
    shift_id: str
    shift_name: str
    start_time: str  # Format: "HH:MM"
    end_time: str    # Format: "HH:MM"
    active: bool = True
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "shift_id": self.shift_id,
            "shift_name": self.shift_name,
            "start_time": self.start_time,
            "end_time": self.end_time,
            "active": self.active
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ShiftConfig':
        """Create from dictionary."""
        return cls(
            shift_id=data.get("shift_id"),
            shift_name=data.get("shift_name"),
            start_time=data.get("start_time"),
            end_time=data.get("end_time"),
            active=data.get("active", True)
        )


class ProductionRunManager:
    """
    Production run manager for OPSC Sandwich Quality Inspection System.
    
    Provides functionality for managing production runs, batches, and shifts.
    """
    
    def __init__(self, db_path: str, config_dir: str):
        """
        Initialize production run manager.
        
        Args:
            db_path: Path to SQLite database file
            config_dir: Path to configuration directory
        """
        self.db_path = db_path
        self.config_dir = config_dir
        
        # Create configuration directory if it doesn't exist
        os.makedirs(self.config_dir, exist_ok=True)
        
        # Initialize database
        self._init_database()
        
        # Load configurations
        self.products = self._load_products()
        self.shifts = self._load_shifts()
        
        # Initialize active run
        self.active_run_id = None
        self.active_run_config = None
        self.active_run_status = None
        self.active_run_lock = threading.Lock()
        
        # Initialize downtime tracking
        self.active_downtime = None
        self.downtime_lock = threading.Lock()
        
        # Initialize event queue and worker thread
        self.event_queue = queue.Queue()
        self.event_thread = None
        self.event_thread_running = False
        
        # Initialize statistics
        self.stats_cache = {}
        self.stats_cache_lock = threading.Lock()
    
    def _init_database(self):
        """Initialize database tables."""
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Create products table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS products (
                    product_id TEXT PRIMARY KEY,
                    product_name TEXT NOT NULL,
                    product_code TEXT NOT NULL,
                    product_version TEXT NOT NULL,
                    description TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    active INTEGER NOT NULL,
                    parameters TEXT
                )
            """)
            
            # Create production_runs table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS production_runs (
                    run_id TEXT PRIMARY KEY,
                    product_id TEXT NOT NULL,
                    batch_id TEXT NOT NULL,
                    operator_id TEXT NOT NULL,
                    line_id TEXT NOT NULL,
                    scheduled_start TEXT NOT NULL,
                    scheduled_end TEXT NOT NULL,
                    target_quantity INTEGER NOT NULL,
                    description TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    parameters TEXT,
                    FOREIGN KEY (product_id) REFERENCES products (product_id)
                )
            """)
            
            # Create production_run_status table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS production_run_status (
                    run_id TEXT PRIMARY KEY,
                    status TEXT NOT NULL,
                    actual_start TEXT,
                    actual_end TEXT,
                    current_quantity INTEGER NOT NULL,
                    good_quantity INTEGER NOT NULL,
                    reject_quantity INTEGER NOT NULL,
                    defect_counts TEXT,
                    downtime_minutes REAL NOT NULL,
                    efficiency REAL NOT NULL,
                    oee REAL NOT NULL,
                    notes TEXT,
                    updated_at TEXT NOT NULL,
                    FOREIGN KEY (run_id) REFERENCES production_runs (run_id)
                )
            """)
            
            # Create production_events table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS production_events (
                    event_id TEXT PRIMARY KEY,
                    run_id TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    timestamp TEXT NOT NULL,
                    data TEXT,
                    FOREIGN KEY (run_id) REFERENCES production_runs (run_id)
                )
            """)
            
            # Create downtime_records table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS downtime_records (
                    downtime_id TEXT PRIMARY KEY,
                    run_id TEXT NOT NULL,
                    start_time TEXT NOT NULL,
                    end_time TEXT,
                    duration_minutes REAL NOT NULL,
                    reason TEXT,
                    category TEXT,
                    notes TEXT,
                    FOREIGN KEY (run_id) REFERENCES production_runs (run_id)
                )
            """)
            
            # Create shifts table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS shifts (
                    shift_id TEXT PRIMARY KEY,
                    shift_name TEXT NOT NULL,
                    start_time TEXT NOT NULL,
                    end_time TEXT NOT NULL,
                    active INTEGER NOT NULL
                )
            """)
            
            # Commit changes
            conn.commit()
            
            # Close connection
            conn.close()
            
            logger.info("Initialized production database tables")
        except Exception as e:
            logger.error(f"Error initializing database: {e}")
            raise
    
    def _load_products(self) -> Dict[str, ProductConfig]:
        """
        Load product configurations from database.
        
        Returns:
            Dictionary of product configurations
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Get products
            cursor.execute("SELECT * FROM products WHERE active = 1")
            rows = cursor.fetchall()
            
            # Close connection
            conn.close()
            
            # Convert rows to product configurations
            products = {}
            for row in rows:
                product_dict = dict(row)
                
                # Parse parameters
                if product_dict.get("parameters"):
                    product_dict["parameters"] = json.loads(product_dict["parameters"])
                else:
                    product_dict["parameters"] = {}
                
                # Convert active to boolean
                product_dict["active"] = bool(product_dict["active"])
                
                # Create product configuration
                product = ProductConfig.from_dict(product_dict)
                products[product.product_id] = product
            
            logger.info(f"Loaded {len(products)} product configurations")
            
            return products
        except Exception as e:
            logger.error(f"Error loading products: {e}")
            return {}
    
    def _load_shifts(self) -> Dict[str, ShiftConfig]:
        """
        Load shift configurations from database.
        
        Returns:
            Dictionary of shift configurations
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Get shifts
            cursor.execute("SELECT * FROM shifts WHERE active = 1")
            rows = cursor.fetchall()
            
            # Close connection
            conn.close()
            
            # Convert rows to shift configurations
            shifts = {}
            for row in rows:
                shift_dict = dict(row)
                
                # Convert active to boolean
                shift_dict["active"] = bool(shift_dict["active"])
                
                # Create shift configuration
                shift = ShiftConfig.from_dict(shift_dict)
                shifts[shift.shift_id] = shift
            
            logger.info(f"Loaded {len(shifts)} shift configurations")
            
            # If no shifts are defined, create default shifts
            if not shifts:
                logger.info("No shifts defined, creating default shifts")
                
                # Create default shifts
                morning_shift = ShiftConfig(
                    shift_id="shift_morning",
                    shift_name="Morning Shift",
                    start_time="06:00",
                    end_time="14:00",
                    active=True
                )
                
                afternoon_shift = ShiftConfig(
                    shift_id="shift_afternoon",
                    shift_name="Afternoon Shift",
                    start_time="14:00",
                    end_time="22:00",
                    active=True
                )
                
                night_shift = ShiftConfig(
                    shift_id="shift_night",
                    shift_name="Night Shift",
                    start_time="22:00",
                    end_time="06:00",
                    active=True
                )
                
                # Save shifts
                self.save_shift(morning_shift)
                self.save_shift(afternoon_shift)
                self.save_shift(night_shift)
                
                # Add shifts to dictionary
                shifts[morning_shift.shift_id] = morning_shift
                shifts[afternoon_shift.shift_id] = afternoon_shift
                shifts[night_shift.shift_id] = night_shift
            
            return shifts
        except Exception as e:
            logger.error(f"Error loading shifts: {e}")
            return {}
    
    def start_event_worker(self):
        """Start background event worker thread."""
        if self.event_thread is not None and self.event_thread.is_alive():
            logger.warning("Event worker thread is already running")
            return
        
        self.event_thread_running = True
        self.event_thread = threading.Thread(target=self._event_worker, daemon=True)
        self.event_thread.start()
        
        logger.info("Started event worker thread")
    
    def stop_event_worker(self):
        """Stop background event worker thread."""
        if self.event_thread is None or not self.event_thread.is_alive():
            logger.warning("Event worker thread is not running")
            return
        
        self.event_thread_running = False
        self.event_thread.join(timeout=5.0)
        
        logger.info("Stopped event worker thread")
    
    def _event_worker(self):
        """Background worker thread for processing event queue."""
        logger.info("Event worker thread started")
        
        while self.event_thread_running:
            try:
                # Get item from queue with timeout
                try:
                    event = self.event_queue.get(timeout=1.0)
                except queue.Empty:
                    continue
                
                # Process event
                try:
                    # Save event to database
                    self._save_event_to_db(event)
                    
                    # Update statistics cache
                    self._update_stats_cache(event)
                    
                    # Mark item as done
                    self.event_queue.task_done()
                except Exception as e:
                    logger.error(f"Error processing event: {e}")
                    
                    # Mark item as done
                    self.event_queue.task_done()
            except Exception as e:
                logger.error(f"Error in event worker thread: {e}")
        
        logger.info("Event worker thread stopped")
    
    def _save_event_to_db(self, event: ProductionEvent):
        """
        Save production event to database.
        
        Args:
            event: Production event
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Insert event
            cursor.execute(
                """
                INSERT INTO production_events (
                    event_id, run_id, event_type, timestamp, data
                )
                VALUES (?, ?, ?, ?, ?)
                """,
                (
                    event.event_id,
                    event.run_id,
                    event.event_type,
                    event.timestamp,
                    json.dumps(event.data) if event.data else None
                )
            )
            
            # Commit changes
            conn.commit()
            
            # Close connection
            conn.close()
        except Exception as e:
            logger.error(f"Error saving event to database: {e}")
    
    def _update_stats_cache(self, event: ProductionEvent):
        """
        Update statistics cache based on production event.
        
        Args:
            event: Production event
        """
        try:
            # Acquire lock
            with self.stats_cache_lock:
                # Get run statistics
                run_stats = self.stats_cache.get(event.run_id, {
                    "total_count": 0,
                    "good_count": 0,
                    "reject_count": 0,
                    "defect_counts": {},
                    "events": []
                })
                
                # Update statistics based on event type
                if event.event_type == "inspection_result":
                    # Increment total count
                    run_stats["total_count"] += 1
                    
                    # Update good/reject counts
                    result = event.data.get("result", "")
                    if result == "pass":
                        run_stats["good_count"] += 1
                    elif result == "fail":
                        run_stats["reject_count"] += 1
                        
                        # Update defect counts
                        defects = event.data.get("defects", [])
                        for defect in defects:
                            defect_type = defect.get("type", "unknown")
                            run_stats["defect_counts"][defect_type] = run_stats["defect_counts"].get(defect_type, 0) + 1
                
                # Add event to list (limit to last 100 events)
                run_stats["events"].append(event.to_dict())
                if len(run_stats["events"]) > 100:
                    run_stats["events"] = run_stats["events"][-100:]
                
                # Update cache
                self.stats_cache[event.run_id] = run_stats
        except Exception as e:
            logger.error(f"Error updating statistics cache: {e}")
    
    def create_product(self, product_name: str, product_code: str, product_version: str, description: str = "", parameters: Dict[str, Any] = None) -> str:
        """
        Create a new product.
        
        Args:
            product_name: Product name
            product_code: Product code
            product_version: Product version
            description: Product description
            parameters: Product parameters
        
        Returns:
            Product ID
        """
        try:
            # Generate product ID
            product_id = f"product_{uuid.uuid4().hex[:8]}"
            
            # Create product configuration
            product = ProductConfig(
                product_id=product_id,
                product_name=product_name,
                product_code=product_code,
                product_version=product_version,
                description=description,
                parameters=parameters or {}
            )
            
            # Save product
            self.save_product(product)
            
            # Add to products dictionary
            self.products[product_id] = product
            
            logger.info(f"Created product: {product_id}")
            
            return product_id
        except Exception as e:
            logger.error(f"Error creating product: {e}")
            raise
    
    def save_product(self, product: ProductConfig) -> bool:
        """
        Save product configuration to database.
        
        Args:
            product: Product configuration
        
        Returns:
            True if successful, False otherwise
        """
        try:
            # Update timestamp
            product.updated_at = datetime.datetime.now().isoformat()
            
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Check if product exists
            cursor.execute("SELECT 1 FROM products WHERE product_id = ?", (product.product_id,))
            exists = cursor.fetchone() is not None
            
            if exists:
                # Update product
                cursor.execute(
                    """
                    UPDATE products
                    SET product_name = ?, product_code = ?, product_version = ?,
                        description = ?, updated_at = ?, active = ?, parameters = ?
                    WHERE product_id = ?
                    """,
                    (
                        product.product_name,
                        product.product_code,
                        product.product_version,
                        product.description,
                        product.updated_at,
                        int(product.active),
                        json.dumps(product.parameters) if product.parameters else None,
                        product.product_id
                    )
                )
            else:
                # Insert product
                cursor.execute(
                    """
                    INSERT INTO products (
                        product_id, product_name, product_code, product_version,
                        description, created_at, updated_at, active, parameters
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        product.product_id,
                        product.product_name,
                        product.product_code,
                        product.product_version,
                        product.description,
                        product.created_at,
                        product.updated_at,
                        int(product.active),
                        json.dumps(product.parameters) if product.parameters else None
                    )
                )
            
            # Commit changes
            conn.commit()
            
            # Close connection
            conn.close()
            
            logger.info(f"Saved product: {product.product_id}")
            
            return True
        except Exception as e:
            logger.error(f"Error saving product: {e}")
            return False
    
    def get_product(self, product_id: str) -> Optional[ProductConfig]:
        """
        Get product configuration.
        
        Args:
            product_id: Product ID
        
        Returns:
            Product configuration or None if not found
        """
        # Check if product is in memory
        product = self.products.get(product_id)
        if product:
            return product
        
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Get product
            cursor.execute("SELECT * FROM products WHERE product_id = ?", (product_id,))
            row = cursor.fetchone()
            
            # Close connection
            conn.close()
            
            if not row:
                return None
            
            # Convert row to product configuration
            product_dict = dict(row)
            
            # Parse parameters
            if product_dict.get("parameters"):
                product_dict["parameters"] = json.loads(product_dict["parameters"])
            else:
                product_dict["parameters"] = {}
            
            # Convert active to boolean
            product_dict["active"] = bool(product_dict["active"])
            
            # Create product configuration
            product = ProductConfig.from_dict(product_dict)
            
            # Add to products dictionary if active
            if product.active:
                self.products[product_id] = product
            
            return product
        except Exception as e:
            logger.error(f"Error getting product: {e}")
            return None
    
    def list_products(self, active_only: bool = True) -> List[ProductConfig]:
        """
        List products.
        
        Args:
            active_only: Only include active products
        
        Returns:
            List of product configurations
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Get products
            if active_only:
                cursor.execute("SELECT * FROM products WHERE active = 1 ORDER BY product_name")
            else:
                cursor.execute("SELECT * FROM products ORDER BY product_name")
            
            rows = cursor.fetchall()
            
            # Close connection
            conn.close()
            
            # Convert rows to product configurations
            products = []
            for row in rows:
                product_dict = dict(row)
                
                # Parse parameters
                if product_dict.get("parameters"):
                    product_dict["parameters"] = json.loads(product_dict["parameters"])
                else:
                    product_dict["parameters"] = {}
                
                # Convert active to boolean
                product_dict["active"] = bool(product_dict["active"])
                
                # Create product configuration
                product = ProductConfig.from_dict(product_dict)
                products.append(product)
                
                # Update products dictionary if active
                if product.active:
                    self.products[product.product_id] = product
            
            return products
        except Exception as e:
            logger.error(f"Error listing products: {e}")
            return []
    
    def delete_product(self, product_id: str) -> bool:
        """
        Delete product.
        
        Args:
            product_id: Product ID
        
        Returns:
            True if successful, False otherwise
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Check if product is used in any production runs
            cursor.execute("SELECT 1 FROM production_runs WHERE product_id = ? LIMIT 1", (product_id,))
            if cursor.fetchone():
                logger.warning(f"Cannot delete product {product_id} because it is used in production runs")
                
                # Instead of deleting, mark as inactive
                cursor.execute("UPDATE products SET active = 0 WHERE product_id = ?", (product_id,))
                
                # Commit changes
                conn.commit()
                
                # Close connection
                conn.close()
                
                # Remove from products dictionary
                if product_id in self.products:
                    del self.products[product_id]
                
                logger.info(f"Marked product as inactive: {product_id}")
                
                return True
            
            # Delete product
            cursor.execute("DELETE FROM products WHERE product_id = ?", (product_id,))
            
            # Commit changes
            conn.commit()
            
            # Close connection
            conn.close()
            
            # Remove from products dictionary
            if product_id in self.products:
                del self.products[product_id]
            
            logger.info(f"Deleted product: {product_id}")
            
            return True
        except Exception as e:
            logger.error(f"Error deleting product: {e}")
            return False
    
    def create_shift(self, shift_name: str, start_time: str, end_time: str) -> str:
        """
        Create a new shift.
        
        Args:
            shift_name: Shift name
            start_time: Shift start time (format: "HH:MM")
            end_time: Shift end time (format: "HH:MM")
        
        Returns:
            Shift ID
        """
        try:
            # Validate time format
            datetime.datetime.strptime(start_time, "%H:%M")
            datetime.datetime.strptime(end_time, "%H:%M")
            
            # Generate shift ID
            shift_id = f"shift_{uuid.uuid4().hex[:8]}"
            
            # Create shift configuration
            shift = ShiftConfig(
                shift_id=shift_id,
                shift_name=shift_name,
                start_time=start_time,
                end_time=end_time,
                active=True
            )
            
            # Save shift
            self.save_shift(shift)
            
            # Add to shifts dictionary
            self.shifts[shift_id] = shift
            
            logger.info(f"Created shift: {shift_id}")
            
            return shift_id
        except Exception as e:
            logger.error(f"Error creating shift: {e}")
            raise
    
    def save_shift(self, shift: ShiftConfig) -> bool:
        """
        Save shift configuration to database.
        
        Args:
            shift: Shift configuration
        
        Returns:
            True if successful, False otherwise
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Check if shift exists
            cursor.execute("SELECT 1 FROM shifts WHERE shift_id = ?", (shift.shift_id,))
            exists = cursor.fetchone() is not None
            
            if exists:
                # Update shift
                cursor.execute(
                    """
                    UPDATE shifts
                    SET shift_name = ?, start_time = ?, end_time = ?, active = ?
                    WHERE shift_id = ?
                    """,
                    (
                        shift.shift_name,
                        shift.start_time,
                        shift.end_time,
                        int(shift.active),
                        shift.shift_id
                    )
                )
            else:
                # Insert shift
                cursor.execute(
                    """
                    INSERT INTO shifts (
                        shift_id, shift_name, start_time, end_time, active
                    )
                    VALUES (?, ?, ?, ?, ?)
                    """,
                    (
                        shift.shift_id,
                        shift.shift_name,
                        shift.start_time,
                        shift.end_time,
                        int(shift.active)
                    )
                )
            
            # Commit changes
            conn.commit()
            
            # Close connection
            conn.close()
            
            logger.info(f"Saved shift: {shift.shift_id}")
            
            return True
        except Exception as e:
            logger.error(f"Error saving shift: {e}")
            return False
    
    def get_shift(self, shift_id: str) -> Optional[ShiftConfig]:
        """
        Get shift configuration.
        
        Args:
            shift_id: Shift ID
        
        Returns:
            Shift configuration or None if not found
        """
        # Check if shift is in memory
        shift = self.shifts.get(shift_id)
        if shift:
            return shift
        
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Get shift
            cursor.execute("SELECT * FROM shifts WHERE shift_id = ?", (shift_id,))
            row = cursor.fetchone()
            
            # Close connection
            conn.close()
            
            if not row:
                return None
            
            # Convert row to shift configuration
            shift_dict = dict(row)
            
            # Convert active to boolean
            shift_dict["active"] = bool(shift_dict["active"])
            
            # Create shift configuration
            shift = ShiftConfig.from_dict(shift_dict)
            
            # Add to shifts dictionary if active
            if shift.active:
                self.shifts[shift_id] = shift
            
            return shift
        except Exception as e:
            logger.error(f"Error getting shift: {e}")
            return None
    
    def list_shifts(self, active_only: bool = True) -> List[ShiftConfig]:
        """
        List shifts.
        
        Args:
            active_only: Only include active shifts
        
        Returns:
            List of shift configurations
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Get shifts
            if active_only:
                cursor.execute("SELECT * FROM shifts WHERE active = 1 ORDER BY start_time")
            else:
                cursor.execute("SELECT * FROM shifts ORDER BY start_time")
            
            rows = cursor.fetchall()
            
            # Close connection
            conn.close()
            
            # Convert rows to shift configurations
            shifts = []
            for row in rows:
                shift_dict = dict(row)
                
                # Convert active to boolean
                shift_dict["active"] = bool(shift_dict["active"])
                
                # Create shift configuration
                shift = ShiftConfig.from_dict(shift_dict)
                shifts.append(shift)
                
                # Update shifts dictionary if active
                if shift.active:
                    self.shifts[shift.shift_id] = shift
            
            return shifts
        except Exception as e:
            logger.error(f"Error listing shifts: {e}")
            return []
    
    def delete_shift(self, shift_id: str) -> bool:
        """
        Delete shift.
        
        Args:
            shift_id: Shift ID
        
        Returns:
            True if successful, False otherwise
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Delete shift
            cursor.execute("DELETE FROM shifts WHERE shift_id = ?", (shift_id,))
            
            # Commit changes
            conn.commit()
            
            # Close connection
            conn.close()
            
            # Remove from shifts dictionary
            if shift_id in self.shifts:
                del self.shifts[shift_id]
            
            logger.info(f"Deleted shift: {shift_id}")
            
            return True
        except Exception as e:
            logger.error(f"Error deleting shift: {e}")
            return False
    
    def get_current_shift(self) -> Optional[ShiftConfig]:
        """
        Get current shift based on current time.
        
        Returns:
            Current shift configuration or None if not found
        """
        try:
            # Get current time
            now = datetime.datetime.now().time()
            
            # Convert to string for comparison
            now_str = now.strftime("%H:%M")
            
            # Check each shift
            for shift in self.shifts.values():
                start_time = shift.start_time
                end_time = shift.end_time
                
                # Handle shifts that span midnight
                if end_time < start_time:
                    # Shift spans midnight
                    if now_str >= start_time or now_str < end_time:
                        return shift
                else:
                    # Normal shift
                    if start_time <= now_str < end_time:
                        return shift
            
            return None
        except Exception as e:
            logger.error(f"Error getting current shift: {e}")
            return None
    
    def create_production_run(self, product_id: str, batch_id: str, operator_id: str, line_id: str, scheduled_start: str, scheduled_end: str, target_quantity: int, description: str = "", parameters: Dict[str, Any] = None) -> str:
        """
        Create a new production run.
        
        Args:
            product_id: Product ID
            batch_id: Batch ID
            operator_id: Operator ID
            line_id: Production line ID
            scheduled_start: Scheduled start time (ISO format)
            scheduled_end: Scheduled end time (ISO format)
            target_quantity: Target production quantity
            description: Run description
            parameters: Run parameters
        
        Returns:
            Run ID
        """
        try:
            # Validate product ID
            product = self.get_product(product_id)
            if not product:
                raise ValueError(f"Product not found: {product_id}")
            
            # Generate run ID
            run_id = f"run_{uuid.uuid4().hex[:8]}"
            
            # Create production run configuration
            run_config = ProductionRunConfig(
                run_id=run_id,
                product_id=product_id,
                batch_id=batch_id,
                operator_id=operator_id,
                line_id=line_id,
                scheduled_start=scheduled_start,
                scheduled_end=scheduled_end,
                target_quantity=target_quantity,
                description=description,
                parameters=parameters or {}
            )
            
            # Create production run status
            run_status = ProductionRunStatus(
                run_id=run_id,
                status=ProductionStatus.IDLE
            )
            
            # Save production run
            self.save_production_run(run_config, run_status)
            
            logger.info(f"Created production run: {run_id}")
            
            return run_id
        except Exception as e:
            logger.error(f"Error creating production run: {e}")
            raise
    
    def save_production_run(self, run_config: ProductionRunConfig, run_status: ProductionRunStatus) -> bool:
        """
        Save production run to database.
        
        Args:
            run_config: Production run configuration
            run_status: Production run status
        
        Returns:
            True if successful, False otherwise
        """
        try:
            # Update timestamps
            run_config.updated_at = datetime.datetime.now().isoformat()
            run_status.updated_at = datetime.datetime.now().isoformat()
            
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Check if run exists
            cursor.execute("SELECT 1 FROM production_runs WHERE run_id = ?", (run_config.run_id,))
            exists = cursor.fetchone() is not None
            
            if exists:
                # Update production run
                cursor.execute(
                    """
                    UPDATE production_runs
                    SET product_id = ?, batch_id = ?, operator_id = ?, line_id = ?,
                        scheduled_start = ?, scheduled_end = ?, target_quantity = ?,
                        description = ?, updated_at = ?, parameters = ?
                    WHERE run_id = ?
                    """,
                    (
                        run_config.product_id,
                        run_config.batch_id,
                        run_config.operator_id,
                        run_config.line_id,
                        run_config.scheduled_start,
                        run_config.scheduled_end,
                        run_config.target_quantity,
                        run_config.description,
                        run_config.updated_at,
                        json.dumps(run_config.parameters) if run_config.parameters else None,
                        run_config.run_id
                    )
                )
            else:
                # Insert production run
                cursor.execute(
                    """
                    INSERT INTO production_runs (
                        run_id, product_id, batch_id, operator_id, line_id,
                        scheduled_start, scheduled_end, target_quantity,
                        description, created_at, updated_at, parameters
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        run_config.run_id,
                        run_config.product_id,
                        run_config.batch_id,
                        run_config.operator_id,
                        run_config.line_id,
                        run_config.scheduled_start,
                        run_config.scheduled_end,
                        run_config.target_quantity,
                        run_config.description,
                        run_config.created_at,
                        run_config.updated_at,
                        json.dumps(run_config.parameters) if run_config.parameters else None
                    )
                )
            
            # Check if run status exists
            cursor.execute("SELECT 1 FROM production_run_status WHERE run_id = ?", (run_status.run_id,))
            status_exists = cursor.fetchone() is not None
            
            if status_exists:
                # Update production run status
                cursor.execute(
                    """
                    UPDATE production_run_status
                    SET status = ?, actual_start = ?, actual_end = ?,
                        current_quantity = ?, good_quantity = ?, reject_quantity = ?,
                        defect_counts = ?, downtime_minutes = ?, efficiency = ?,
                        oee = ?, notes = ?, updated_at = ?
                    WHERE run_id = ?
                    """,
                    (
                        run_status.status.name,
                        run_status.actual_start,
                        run_status.actual_end,
                        run_status.current_quantity,
                        run_status.good_quantity,
                        run_status.reject_quantity,
                        json.dumps(run_status.defect_counts) if run_status.defect_counts else None,
                        run_status.downtime_minutes,
                        run_status.efficiency,
                        run_status.oee,
                        run_status.notes,
                        run_status.updated_at,
                        run_status.run_id
                    )
                )
            else:
                # Insert production run status
                cursor.execute(
                    """
                    INSERT INTO production_run_status (
                        run_id, status, actual_start, actual_end,
                        current_quantity, good_quantity, reject_quantity,
                        defect_counts, downtime_minutes, efficiency,
                        oee, notes, updated_at
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        run_status.run_id,
                        run_status.status.name,
                        run_status.actual_start,
                        run_status.actual_end,
                        run_status.current_quantity,
                        run_status.good_quantity,
                        run_status.reject_quantity,
                        json.dumps(run_status.defect_counts) if run_status.defect_counts else None,
                        run_status.downtime_minutes,
                        run_status.efficiency,
                        run_status.oee,
                        run_status.notes,
                        run_status.updated_at
                    )
                )
            
            # Commit changes
            conn.commit()
            
            # Close connection
            conn.close()
            
            logger.info(f"Saved production run: {run_config.run_id}")
            
            return True
        except Exception as e:
            logger.error(f"Error saving production run: {e}")
            return False
    
    def get_production_run(self, run_id: str) -> Optional[Tuple[ProductionRunConfig, ProductionRunStatus]]:
        """
        Get production run.
        
        Args:
            run_id: Run ID
        
        Returns:
            Tuple of production run configuration and status, or None if not found
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Get production run
            cursor.execute("SELECT * FROM production_runs WHERE run_id = ?", (run_id,))
            run_row = cursor.fetchone()
            
            if not run_row:
                return None
            
            # Get production run status
            cursor.execute("SELECT * FROM production_run_status WHERE run_id = ?", (run_id,))
            status_row = cursor.fetchone()
            
            if not status_row:
                return None
            
            # Close connection
            conn.close()
            
            # Convert rows to objects
            run_dict = dict(run_row)
            status_dict = dict(status_row)
            
            # Parse parameters
            if run_dict.get("parameters"):
                run_dict["parameters"] = json.loads(run_dict["parameters"])
            else:
                run_dict["parameters"] = {}
            
            # Parse defect counts
            if status_dict.get("defect_counts"):
                status_dict["defect_counts"] = json.loads(status_dict["defect_counts"])
            else:
                status_dict["defect_counts"] = {}
            
            # Create objects
            run_config = ProductionRunConfig.from_dict(run_dict)
            run_status = ProductionRunStatus.from_dict(status_dict)
            
            return run_config, run_status
        except Exception as e:
            logger.error(f"Error getting production run: {e}")
            return None
    
    def list_production_runs(self, status: Optional[ProductionStatus] = None, product_id: Optional[str] = None, batch_id: Optional[str] = None, limit: int = 100, offset: int = 0) -> List[Tuple[ProductionRunConfig, ProductionRunStatus]]:
        """
        List production runs.
        
        Args:
            status: Filter by status (optional)
            product_id: Filter by product ID (optional)
            batch_id: Filter by batch ID (optional)
            limit: Maximum number of runs to return
            offset: Offset for pagination
        
        Returns:
            List of tuples of production run configuration and status
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Build query
            query = """
                SELECT r.*, s.*
                FROM production_runs r
                JOIN production_run_status s ON r.run_id = s.run_id
                WHERE 1=1
            """
            params = []
            
            if status:
                query += " AND s.status = ?"
                params.append(status.name)
            
            if product_id:
                query += " AND r.product_id = ?"
                params.append(product_id)
            
            if batch_id:
                query += " AND r.batch_id = ?"
                params.append(batch_id)
            
            query += " ORDER BY r.scheduled_start DESC LIMIT ? OFFSET ?"
            params.extend([limit, offset])
            
            # Execute query
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            # Close connection
            conn.close()
            
            # Convert rows to objects
            runs = []
            for row in rows:
                # Split row into run and status parts
                run_dict = {k: row[k] for k in row.keys() if k in [
                    "run_id", "product_id", "batch_id", "operator_id", "line_id",
                    "scheduled_start", "scheduled_end", "target_quantity",
                    "description", "created_at", "updated_at", "parameters"
                ]}
                
                status_dict = {k: row[k] for k in row.keys() if k in [
                    "run_id", "status", "actual_start", "actual_end",
                    "current_quantity", "good_quantity", "reject_quantity",
                    "defect_counts", "downtime_minutes", "efficiency",
                    "oee", "notes", "updated_at"
                ]}
                
                # Parse parameters
                if run_dict.get("parameters"):
                    run_dict["parameters"] = json.loads(run_dict["parameters"])
                else:
                    run_dict["parameters"] = {}
                
                # Parse defect counts
                if status_dict.get("defect_counts"):
                    status_dict["defect_counts"] = json.loads(status_dict["defect_counts"])
                else:
                    status_dict["defect_counts"] = {}
                
                # Create objects
                run_config = ProductionRunConfig.from_dict(run_dict)
                run_status = ProductionRunStatus.from_dict(status_dict)
                
                runs.append((run_config, run_status))
            
            return runs
        except Exception as e:
            logger.error(f"Error listing production runs: {e}")
            return []
    
    def delete_production_run(self, run_id: str) -> bool:
        """
        Delete production run.
        
        Args:
            run_id: Run ID
        
        Returns:
            True if successful, False otherwise
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Delete production run status
            cursor.execute("DELETE FROM production_run_status WHERE run_id = ?", (run_id,))
            
            # Delete production events
            cursor.execute("DELETE FROM production_events WHERE run_id = ?", (run_id,))
            
            # Delete downtime records
            cursor.execute("DELETE FROM downtime_records WHERE run_id = ?", (run_id,))
            
            # Delete production run
            cursor.execute("DELETE FROM production_runs WHERE run_id = ?", (run_id,))
            
            # Commit changes
            conn.commit()
            
            # Close connection
            conn.close()
            
            # Clear from cache
            with self.stats_cache_lock:
                if run_id in self.stats_cache:
                    del self.stats_cache[run_id]
            
            logger.info(f"Deleted production run: {run_id}")
            
            return True
        except Exception as e:
            logger.error(f"Error deleting production run: {e}")
            return False
    
    def start_production_run(self, run_id: str) -> bool:
        """
        Start a production run.
        
        Args:
            run_id: Run ID
        
        Returns:
            True if successful, False otherwise
        """
        try:
            # Acquire lock
            with self.active_run_lock:
                # Check if another run is active
                if self.active_run_id and self.active_run_id != run_id:
                    logger.warning(f"Cannot start run {run_id} because run {self.active_run_id} is already active")
                    return False
                
                # Get production run
                run = self.get_production_run(run_id)
                if not run:
                    logger.warning(f"Production run not found: {run_id}")
                    return False
                
                run_config, run_status = run
                
                # Check if run is already started
                if run_status.status == ProductionStatus.RUNNING:
                    logger.warning(f"Production run {run_id} is already running")
                    return True
                
                # Update run status
                run_status.status = ProductionStatus.RUNNING
                run_status.actual_start = datetime.datetime.now().isoformat()
                run_status.updated_at = datetime.datetime.now().isoformat()
                
                # Save run status
                self.save_production_run(run_config, run_status)
                
                # Set active run
                self.active_run_id = run_id
                self.active_run_config = run_config
                self.active_run_status = run_status
                
                # Create production event
                event = ProductionEvent(
                    event_id=f"event_{uuid.uuid4().hex[:8]}",
                    run_id=run_id,
                    event_type="run_started",
                    timestamp=datetime.datetime.now().isoformat(),
                    data={
                        "product_id": run_config.product_id,
                        "batch_id": run_config.batch_id,
                        "operator_id": run_config.operator_id,
                        "line_id": run_config.line_id
                    }
                )
                
                # Add event to queue
                self.event_queue.put(event)
                
                logger.info(f"Started production run: {run_id}")
                
                return True
        except Exception as e:
            logger.error(f"Error starting production run: {e}")
            return False
    
    def pause_production_run(self, run_id: str, reason: str = "") -> bool:
        """
        Pause a production run.
        
        Args:
            run_id: Run ID
            reason: Pause reason
        
        Returns:
            True if successful, False otherwise
        """
        try:
            # Acquire lock
            with self.active_run_lock:
                # Check if run is active
                if not self.active_run_id or self.active_run_id != run_id:
                    logger.warning(f"Cannot pause run {run_id} because it is not active")
                    return False
                
                # Get production run
                run = self.get_production_run(run_id)
                if not run:
                    logger.warning(f"Production run not found: {run_id}")
                    return False
                
                run_config, run_status = run
                
                # Check if run is running
                if run_status.status != ProductionStatus.RUNNING:
                    logger.warning(f"Production run {run_id} is not running")
                    return False
                
                # Update run status
                run_status.status = ProductionStatus.PAUSED
                run_status.updated_at = datetime.datetime.now().isoformat()
                
                # Save run status
                self.save_production_run(run_config, run_status)
                
                # Update active run status
                self.active_run_status = run_status
                
                # Start downtime tracking
                self.start_downtime(run_id, reason, "Pause")
                
                # Create production event
                event = ProductionEvent(
                    event_id=f"event_{uuid.uuid4().hex[:8]}",
                    run_id=run_id,
                    event_type="run_paused",
                    timestamp=datetime.datetime.now().isoformat(),
                    data={
                        "reason": reason
                    }
                )
                
                # Add event to queue
                self.event_queue.put(event)
                
                logger.info(f"Paused production run: {run_id}")
                
                return True
        except Exception as e:
            logger.error(f"Error pausing production run: {e}")
            return False
    
    def resume_production_run(self, run_id: str) -> bool:
        """
        Resume a paused production run.
        
        Args:
            run_id: Run ID
        
        Returns:
            True if successful, False otherwise
        """
        try:
            # Acquire lock
            with self.active_run_lock:
                # Check if run is active
                if not self.active_run_id or self.active_run_id != run_id:
                    logger.warning(f"Cannot resume run {run_id} because it is not active")
                    return False
                
                # Get production run
                run = self.get_production_run(run_id)
                if not run:
                    logger.warning(f"Production run not found: {run_id}")
                    return False
                
                run_config, run_status = run
                
                # Check if run is paused
                if run_status.status != ProductionStatus.PAUSED:
                    logger.warning(f"Production run {run_id} is not paused")
                    return False
                
                # Update run status
                run_status.status = ProductionStatus.RUNNING
                run_status.updated_at = datetime.datetime.now().isoformat()
                
                # Save run status
                self.save_production_run(run_config, run_status)
                
                # Update active run status
                self.active_run_status = run_status
                
                # End downtime tracking
                self.end_downtime(run_id)
                
                # Create production event
                event = ProductionEvent(
                    event_id=f"event_{uuid.uuid4().hex[:8]}",
                    run_id=run_id,
                    event_type="run_resumed",
                    timestamp=datetime.datetime.now().isoformat()
                )
                
                # Add event to queue
                self.event_queue.put(event)
                
                logger.info(f"Resumed production run: {run_id}")
                
                return True
        except Exception as e:
            logger.error(f"Error resuming production run: {e}")
            return False
    
    def stop_production_run(self, run_id: str, reason: str = "") -> bool:
        """
        Stop a production run.
        
        Args:
            run_id: Run ID
            reason: Stop reason
        
        Returns:
            True if successful, False otherwise
        """
        try:
            # Acquire lock
            with self.active_run_lock:
                # Check if run is active
                if not self.active_run_id or self.active_run_id != run_id:
                    logger.warning(f"Cannot stop run {run_id} because it is not active")
                    return False
                
                # Get production run
                run = self.get_production_run(run_id)
                if not run:
                    logger.warning(f"Production run not found: {run_id}")
                    return False
                
                run_config, run_status = run
                
                # Check if run is running or paused
                if run_status.status not in [ProductionStatus.RUNNING, ProductionStatus.PAUSED]:
                    logger.warning(f"Production run {run_id} is not running or paused")
                    return False
                
                # Update run status
                run_status.status = ProductionStatus.STOPPED
                run_status.actual_end = datetime.datetime.now().isoformat()
                run_status.updated_at = datetime.datetime.now().isoformat()
                
                # Calculate efficiency and OEE
                self._calculate_metrics(run_config, run_status)
                
                # Save run status
                self.save_production_run(run_config, run_status)
                
                # Clear active run
                self.active_run_id = None
                self.active_run_config = None
                self.active_run_status = None
                
                # End downtime tracking if paused
                if run_status.status == ProductionStatus.PAUSED:
                    self.end_downtime(run_id)
                
                # Create production event
                event = ProductionEvent(
                    event_id=f"event_{uuid.uuid4().hex[:8]}",
                    run_id=run_id,
                    event_type="run_stopped",
                    timestamp=datetime.datetime.now().isoformat(),
                    data={
                        "reason": reason,
                        "metrics": {
                            "current_quantity": run_status.current_quantity,
                            "good_quantity": run_status.good_quantity,
                            "reject_quantity": run_status.reject_quantity,
                            "defect_counts": run_status.defect_counts,
                            "downtime_minutes": run_status.downtime_minutes,
                            "efficiency": run_status.efficiency,
                            "oee": run_status.oee
                        }
                    }
                )
                
                # Add event to queue
                self.event_queue.put(event)
                
                logger.info(f"Stopped production run: {run_id}")
                
                return True
        except Exception as e:
            logger.error(f"Error stopping production run: {e}")
            return False
    
    def complete_production_run(self, run_id: str) -> bool:
        """
        Mark a production run as completed.
        
        Args:
            run_id: Run ID
        
        Returns:
            True if successful, False otherwise
        """
        try:
            # Acquire lock
            with self.active_run_lock:
                # Check if run is active
                if not self.active_run_id or self.active_run_id != run_id:
                    logger.warning(f"Cannot complete run {run_id} because it is not active")
                    return False
                
                # Get production run
                run = self.get_production_run(run_id)
                if not run:
                    logger.warning(f"Production run not found: {run_id}")
                    return False
                
                run_config, run_status = run
                
                # Check if run is running or paused
                if run_status.status not in [ProductionStatus.RUNNING, ProductionStatus.PAUSED]:
                    logger.warning(f"Production run {run_id} is not running or paused")
                    return False
                
                # Update run status
                run_status.status = ProductionStatus.COMPLETED
                run_status.actual_end = datetime.datetime.now().isoformat()
                run_status.updated_at = datetime.datetime.now().isoformat()
                
                # Calculate efficiency and OEE
                self._calculate_metrics(run_config, run_status)
                
                # Save run status
                self.save_production_run(run_config, run_status)
                
                # Clear active run
                self.active_run_id = None
                self.active_run_config = None
                self.active_run_status = None
                
                # End downtime tracking if paused
                if run_status.status == ProductionStatus.PAUSED:
                    self.end_downtime(run_id)
                
                # Create production event
                event = ProductionEvent(
                    event_id=f"event_{uuid.uuid4().hex[:8]}",
                    run_id=run_id,
                    event_type="run_completed",
                    timestamp=datetime.datetime.now().isoformat(),
                    data={
                        "metrics": {
                            "current_quantity": run_status.current_quantity,
                            "good_quantity": run_status.good_quantity,
                            "reject_quantity": run_status.reject_quantity,
                            "defect_counts": run_status.defect_counts,
                            "downtime_minutes": run_status.downtime_minutes,
                            "efficiency": run_status.efficiency,
                            "oee": run_status.oee
                        }
                    }
                )
                
                # Add event to queue
                self.event_queue.put(event)
                
                logger.info(f"Completed production run: {run_id}")
                
                return True
        except Exception as e:
            logger.error(f"Error completing production run: {e}")
            return False
    
    def _calculate_metrics(self, run_config: ProductionRunConfig, run_status: ProductionRunStatus):
        """
        Calculate efficiency and OEE metrics.
        
        Args:
            run_config: Production run configuration
            run_status: Production run status
        """
        try:
            # Calculate run duration
            if run_status.actual_start and run_status.actual_end:
                start_time = datetime.datetime.fromisoformat(run_status.actual_start)
                end_time = datetime.datetime.fromisoformat(run_status.actual_end)
                duration_minutes = (end_time - start_time).total_seconds() / 60.0
            else:
                duration_minutes = 0.0
            
            # Calculate net duration (excluding downtime)
            net_duration_minutes = max(0.0, duration_minutes - run_status.downtime_minutes)
            
            # Calculate efficiency (actual / target)
            if run_config.target_quantity > 0:
                run_status.efficiency = min(1.0, run_status.current_quantity / run_config.target_quantity)
            else:
                run_status.efficiency = 0.0
            
            # Calculate quality rate
            if run_status.current_quantity > 0:
                quality_rate = run_status.good_quantity / run_status.current_quantity
            else:
                quality_rate = 0.0
            
            # Calculate performance rate
            if net_duration_minutes > 0 and run_config.target_quantity > 0:
                # Calculate ideal cycle time (minutes per unit)
                scheduled_duration = (datetime.datetime.fromisoformat(run_config.scheduled_end) - 
                                     datetime.datetime.fromisoformat(run_config.scheduled_start)).total_seconds() / 60.0
                ideal_cycle_time = scheduled_duration / run_config.target_quantity
                
                # Calculate performance rate
                if run_status.current_quantity > 0:
                    actual_cycle_time = net_duration_minutes / run_status.current_quantity
                    performance_rate = min(1.0, ideal_cycle_time / actual_cycle_time)
                else:
                    performance_rate = 0.0
            else:
                performance_rate = 0.0
            
            # Calculate availability rate
            if duration_minutes > 0:
                availability_rate = net_duration_minutes / duration_minutes
            else:
                availability_rate = 0.0
            
            # Calculate OEE
            run_status.oee = availability_rate * performance_rate * quality_rate
        except Exception as e:
            logger.error(f"Error calculating metrics: {e}")
            run_status.efficiency = 0.0
            run_status.oee = 0.0
    
    def record_inspection_result(self, run_id: str, result: str, defects: List[Dict[str, Any]] = None) -> bool:
        """
        Record inspection result for a production run.
        
        Args:
            run_id: Run ID
            result: Inspection result ("pass" or "fail")
            defects: List of defects (if result is "fail")
        
        Returns:
            True if successful, False otherwise
        """
        try:
            # Validate run ID
            if not run_id:
                logger.warning("Run ID is required")
                return False
            
            # Validate result
            if result not in ["pass", "fail"]:
                logger.warning(f"Invalid inspection result: {result}")
                return False
            
            # Get production run
            run = self.get_production_run(run_id)
            if not run:
                logger.warning(f"Production run not found: {run_id}")
                return False
            
            run_config, run_status = run
            
            # Check if run is active
            if run_status.status != ProductionStatus.RUNNING:
                logger.warning(f"Cannot record inspection result for run {run_id} because it is not running")
                return False
            
            # Update run status
            run_status.current_quantity += 1
            
            if result == "pass":
                run_status.good_quantity += 1
            else:
                run_status.reject_quantity += 1
                
                # Update defect counts
                if defects:
                    for defect in defects:
                        defect_type = defect.get("type", "unknown")
                        run_status.defect_counts[defect_type] = run_status.defect_counts.get(defect_type, 0) + 1
            
            run_status.updated_at = datetime.datetime.now().isoformat()
            
            # Save run status
            self.save_production_run(run_config, run_status)
            
            # Update active run status
            if self.active_run_id == run_id:
                self.active_run_status = run_status
            
            # Create production event
            event = ProductionEvent(
                event_id=f"event_{uuid.uuid4().hex[:8]}",
                run_id=run_id,
                event_type="inspection_result",
                timestamp=datetime.datetime.now().isoformat(),
                data={
                    "result": result,
                    "defects": defects or [],
                    "current_count": run_status.current_quantity,
                    "good_count": run_status.good_quantity,
                    "reject_count": run_status.reject_quantity
                }
            )
            
            # Add event to queue
            self.event_queue.put(event)
            
            return True
        except Exception as e:
            logger.error(f"Error recording inspection result: {e}")
            return False
    
    def start_downtime(self, run_id: str, reason: str = "", category: str = "") -> str:
        """
        Start downtime tracking for a production run.
        
        Args:
            run_id: Run ID
            reason: Downtime reason
            category: Downtime category
        
        Returns:
            Downtime ID
        """
        try:
            # Acquire lock
            with self.downtime_lock:
                # Check if downtime is already being tracked
                if self.active_downtime:
                    logger.warning(f"Downtime is already being tracked for run {self.active_downtime.run_id}")
                    return self.active_downtime.downtime_id
                
                # Generate downtime ID
                downtime_id = f"downtime_{uuid.uuid4().hex[:8]}"
                
                # Create downtime record
                downtime = DowntimeRecord(
                    downtime_id=downtime_id,
                    run_id=run_id,
                    start_time=datetime.datetime.now().isoformat(),
                    reason=reason,
                    category=category
                )
                
                # Save downtime record
                self._save_downtime_record(downtime)
                
                # Set active downtime
                self.active_downtime = downtime
                
                # Create production event
                event = ProductionEvent(
                    event_id=f"event_{uuid.uuid4().hex[:8]}",
                    run_id=run_id,
                    event_type="downtime_started",
                    timestamp=datetime.datetime.now().isoformat(),
                    data={
                        "downtime_id": downtime_id,
                        "reason": reason,
                        "category": category
                    }
                )
                
                # Add event to queue
                self.event_queue.put(event)
                
                logger.info(f"Started downtime tracking: {downtime_id}")
                
                return downtime_id
        except Exception as e:
            logger.error(f"Error starting downtime tracking: {e}")
            return ""
    
    def end_downtime(self, run_id: str) -> bool:
        """
        End downtime tracking for a production run.
        
        Args:
            run_id: Run ID
        
        Returns:
            True if successful, False otherwise
        """
        try:
            # Acquire lock
            with self.downtime_lock:
                # Check if downtime is being tracked
                if not self.active_downtime:
                    logger.warning("No active downtime to end")
                    return False
                
                # Check if downtime is for the specified run
                if self.active_downtime.run_id != run_id:
                    logger.warning(f"Active downtime is for run {self.active_downtime.run_id}, not {run_id}")
                    return False
                
                # Update downtime record
                self.active_downtime.end_time = datetime.datetime.now().isoformat()
                
                # Calculate duration
                start_time = datetime.datetime.fromisoformat(self.active_downtime.start_time)
                end_time = datetime.datetime.fromisoformat(self.active_downtime.end_time)
                self.active_downtime.duration_minutes = (end_time - start_time).total_seconds() / 60.0
                
                # Save downtime record
                self._save_downtime_record(self.active_downtime)
                
                # Update run status with downtime
                run = self.get_production_run(run_id)
                if run:
                    run_config, run_status = run
                    run_status.downtime_minutes += self.active_downtime.duration_minutes
                    run_status.updated_at = datetime.datetime.now().isoformat()
                    self.save_production_run(run_config, run_status)
                    
                    # Update active run status
                    if self.active_run_id == run_id:
                        self.active_run_status = run_status
                
                # Create production event
                event = ProductionEvent(
                    event_id=f"event_{uuid.uuid4().hex[:8]}",
                    run_id=run_id,
                    event_type="downtime_ended",
                    timestamp=datetime.datetime.now().isoformat(),
                    data={
                        "downtime_id": self.active_downtime.downtime_id,
                        "duration_minutes": self.active_downtime.duration_minutes,
                        "reason": self.active_downtime.reason,
                        "category": self.active_downtime.category
                    }
                )
                
                # Add event to queue
                self.event_queue.put(event)
                
                # Get downtime ID before clearing
                downtime_id = self.active_downtime.downtime_id
                
                # Clear active downtime
                self.active_downtime = None
                
                logger.info(f"Ended downtime tracking: {downtime_id}")
                
                return True
        except Exception as e:
            logger.error(f"Error ending downtime tracking: {e}")
            return False
    
    def _save_downtime_record(self, downtime: DowntimeRecord):
        """
        Save downtime record to database.
        
        Args:
            downtime: Downtime record
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Check if downtime record exists
            cursor.execute("SELECT 1 FROM downtime_records WHERE downtime_id = ?", (downtime.downtime_id,))
            exists = cursor.fetchone() is not None
            
            if exists:
                # Update downtime record
                cursor.execute(
                    """
                    UPDATE downtime_records
                    SET end_time = ?, duration_minutes = ?, reason = ?, category = ?, notes = ?
                    WHERE downtime_id = ?
                    """,
                    (
                        downtime.end_time,
                        downtime.duration_minutes,
                        downtime.reason,
                        downtime.category,
                        downtime.notes,
                        downtime.downtime_id
                    )
                )
            else:
                # Insert downtime record
                cursor.execute(
                    """
                    INSERT INTO downtime_records (
                        downtime_id, run_id, start_time, end_time,
                        duration_minutes, reason, category, notes
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        downtime.downtime_id,
                        downtime.run_id,
                        downtime.start_time,
                        downtime.end_time,
                        downtime.duration_minutes,
                        downtime.reason,
                        downtime.category,
                        downtime.notes
                    )
                )
            
            # Commit changes
            conn.commit()
            
            # Close connection
            conn.close()
        except Exception as e:
            logger.error(f"Error saving downtime record: {e}")
    
    def get_downtime_record(self, downtime_id: str) -> Optional[DowntimeRecord]:
        """
        Get downtime record.
        
        Args:
            downtime_id: Downtime ID
        
        Returns:
            Downtime record or None if not found
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Get downtime record
            cursor.execute("SELECT * FROM downtime_records WHERE downtime_id = ?", (downtime_id,))
            row = cursor.fetchone()
            
            # Close connection
            conn.close()
            
            if not row:
                return None
            
            # Convert row to downtime record
            downtime_dict = dict(row)
            
            # Create downtime record
            downtime = DowntimeRecord(
                downtime_id=downtime_dict["downtime_id"],
                run_id=downtime_dict["run_id"],
                start_time=downtime_dict["start_time"],
                end_time=downtime_dict["end_time"],
                duration_minutes=downtime_dict["duration_minutes"],
                reason=downtime_dict["reason"],
                category=downtime_dict["category"],
                notes=downtime_dict["notes"]
            )
            
            return downtime
        except Exception as e:
            logger.error(f"Error getting downtime record: {e}")
            return None
    
    def list_downtime_records(self, run_id: Optional[str] = None, category: Optional[str] = None, limit: int = 100, offset: int = 0) -> List[DowntimeRecord]:
        """
        List downtime records.
        
        Args:
            run_id: Filter by run ID (optional)
            category: Filter by category (optional)
            limit: Maximum number of records to return
            offset: Offset for pagination
        
        Returns:
            List of downtime records
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Build query
            query = "SELECT * FROM downtime_records WHERE 1=1"
            params = []
            
            if run_id:
                query += " AND run_id = ?"
                params.append(run_id)
            
            if category:
                query += " AND category = ?"
                params.append(category)
            
            query += " ORDER BY start_time DESC LIMIT ? OFFSET ?"
            params.extend([limit, offset])
            
            # Execute query
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            # Close connection
            conn.close()
            
            # Convert rows to downtime records
            records = []
            for row in rows:
                downtime_dict = dict(row)
                
                # Create downtime record
                downtime = DowntimeRecord(
                    downtime_id=downtime_dict["downtime_id"],
                    run_id=downtime_dict["run_id"],
                    start_time=downtime_dict["start_time"],
                    end_time=downtime_dict["end_time"],
                    duration_minutes=downtime_dict["duration_minutes"],
                    reason=downtime_dict["reason"],
                    category=downtime_dict["category"],
                    notes=downtime_dict["notes"]
                )
                
                records.append(downtime)
            
            return records
        except Exception as e:
            logger.error(f"Error listing downtime records: {e}")
            return []
    
    def get_production_events(self, run_id: str, event_type: Optional[str] = None, limit: int = 100, offset: int = 0) -> List[ProductionEvent]:
        """
        Get production events for a run.
        
        Args:
            run_id: Run ID
            event_type: Filter by event type (optional)
            limit: Maximum number of events to return
            offset: Offset for pagination
        
        Returns:
            List of production events
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Build query
            query = "SELECT * FROM production_events WHERE run_id = ?"
            params = [run_id]
            
            if event_type:
                query += " AND event_type = ?"
                params.append(event_type)
            
            query += " ORDER BY timestamp DESC LIMIT ? OFFSET ?"
            params.extend([limit, offset])
            
            # Execute query
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            # Close connection
            conn.close()
            
            # Convert rows to production events
            events = []
            for row in rows:
                event_dict = dict(row)
                
                # Parse data
                if event_dict.get("data"):
                    event_dict["data"] = json.loads(event_dict["data"])
                else:
                    event_dict["data"] = {}
                
                # Create production event
                event = ProductionEvent.from_dict(event_dict)
                events.append(event)
            
            return events
        except Exception as e:
            logger.error(f"Error getting production events: {e}")
            return []
    
    def get_run_statistics(self, run_id: str) -> Dict[str, Any]:
        """
        Get statistics for a production run.
        
        Args:
            run_id: Run ID
        
        Returns:
            Dictionary of run statistics
        """
        try:
            # Check if statistics are in cache
            with self.stats_cache_lock:
                if run_id in self.stats_cache:
                    return self.stats_cache[run_id]
            
            # Get production run
            run = self.get_production_run(run_id)
            if not run:
                logger.warning(f"Production run not found: {run_id}")
                return {}
            
            run_config, run_status = run
            
            # Get product
            product = self.get_product(run_config.product_id)
            if not product:
                logger.warning(f"Product not found: {run_config.product_id}")
                product_name = "Unknown"
            else:
                product_name = product.product_name
            
            # Get downtime records
            downtime_records = self.list_downtime_records(run_id=run_id, limit=1000)
            
            # Calculate downtime by category
            downtime_by_category = {}
            for record in downtime_records:
                category = record.category or "Uncategorized"
                downtime_by_category[category] = downtime_by_category.get(category, 0.0) + record.duration_minutes
            
            # Get recent events
            events = self.get_production_events(run_id=run_id, limit=100)
            
            # Create statistics
            statistics = {
                "run_id": run_id,
                "product_id": run_config.product_id,
                "product_name": product_name,
                "batch_id": run_config.batch_id,
                "status": run_status.status.name,
                "scheduled_start": run_config.scheduled_start,
                "scheduled_end": run_config.scheduled_end,
                "actual_start": run_status.actual_start,
                "actual_end": run_status.actual_end,
                "target_quantity": run_config.target_quantity,
                "current_quantity": run_status.current_quantity,
                "good_quantity": run_status.good_quantity,
                "reject_quantity": run_status.reject_quantity,
                "defect_counts": run_status.defect_counts,
                "downtime_minutes": run_status.downtime_minutes,
                "downtime_by_category": downtime_by_category,
                "efficiency": run_status.efficiency,
                "oee": run_status.oee,
                "events": [event.to_dict() for event in events]
            }
            
            # Update cache
            with self.stats_cache_lock:
                self.stats_cache[run_id] = statistics
            
            return statistics
        except Exception as e:
            logger.error(f"Error getting run statistics: {e}")
            return {}
    
    def get_active_run(self) -> Optional[Tuple[ProductionRunConfig, ProductionRunStatus]]:
        """
        Get active production run.
        
        Returns:
            Tuple of production run configuration and status, or None if no active run
        """
        # Check if active run is set
        if not self.active_run_id:
            return None
        
        # Get production run
        return self.get_production_run(self.active_run_id)
    
    def get_production_summary(self, start_date: str, end_date: str) -> Dict[str, Any]:
        """
        Get production summary for a date range.
        
        Args:
            start_date: Start date (ISO format)
            end_date: End date (ISO format)
        
        Returns:
            Dictionary of production summary
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Get production runs in date range
            cursor.execute(
                """
                SELECT r.*, s.*
                FROM production_runs r
                JOIN production_run_status s ON r.run_id = s.run_id
                WHERE r.scheduled_start >= ? AND r.scheduled_start <= ?
                ORDER BY r.scheduled_start
                """,
                (start_date, end_date)
            )
            rows = cursor.fetchall()
            
            # Close connection
            conn.close()
            
            # Process runs
            runs = []
            total_target = 0
            total_produced = 0
            total_good = 0
            total_reject = 0
            total_downtime = 0.0
            defect_counts = {}
            
            for row in rows:
                # Split row into run and status parts
                run_dict = {k: row[k] for k in row.keys() if k in [
                    "run_id", "product_id", "batch_id", "operator_id", "line_id",
                    "scheduled_start", "scheduled_end", "target_quantity",
                    "description", "created_at", "updated_at", "parameters"
                ]}
                
                status_dict = {k: row[k] for k in row.keys() if k in [
                    "run_id", "status", "actual_start", "actual_end",
                    "current_quantity", "good_quantity", "reject_quantity",
                    "defect_counts", "downtime_minutes", "efficiency",
                    "oee", "notes", "updated_at"
                ]}
                
                # Parse parameters
                if run_dict.get("parameters"):
                    run_dict["parameters"] = json.loads(run_dict["parameters"])
                else:
                    run_dict["parameters"] = {}
                
                # Parse defect counts
                if status_dict.get("defect_counts"):
                    status_dict["defect_counts"] = json.loads(status_dict["defect_counts"])
                else:
                    status_dict["defect_counts"] = {}
                
                # Create objects
                run_config = ProductionRunConfig.from_dict(run_dict)
                run_status = ProductionRunStatus.from_dict(status_dict)
                
                # Get product name
                product = self.get_product(run_config.product_id)
                product_name = product.product_name if product else "Unknown"
                
                # Add to summary
                runs.append({
                    "run_id": run_config.run_id,
                    "product_id": run_config.product_id,
                    "product_name": product_name,
                    "batch_id": run_config.batch_id,
                    "scheduled_start": run_config.scheduled_start,
                    "scheduled_end": run_config.scheduled_end,
                    "status": run_status.status.name,
                    "target_quantity": run_config.target_quantity,
                    "current_quantity": run_status.current_quantity,
                    "good_quantity": run_status.good_quantity,
                    "reject_quantity": run_status.reject_quantity,
                    "efficiency": run_status.efficiency,
                    "oee": run_status.oee
                })
                
                # Update totals
                total_target += run_config.target_quantity
                total_produced += run_status.current_quantity
                total_good += run_status.good_quantity
                total_reject += run_status.reject_quantity
                total_downtime += run_status.downtime_minutes
                
                # Update defect counts
                for defect_type, count in run_status.defect_counts.items():
                    defect_counts[defect_type] = defect_counts.get(defect_type, 0) + count
            
            # Calculate overall metrics
            if total_target > 0:
                overall_efficiency = total_produced / total_target
            else:
                overall_efficiency = 0.0
            
            if total_produced > 0:
                quality_rate = total_good / total_produced
            else:
                quality_rate = 0.0
            
            # Create summary
            summary = {
                "start_date": start_date,
                "end_date": end_date,
                "runs": runs,
                "total_runs": len(runs),
                "total_target": total_target,
                "total_produced": total_produced,
                "total_good": total_good,
                "total_reject": total_reject,
                "total_downtime_minutes": total_downtime,
                "overall_efficiency": overall_efficiency,
                "quality_rate": quality_rate,
                "defect_counts": defect_counts
            }
            
            return summary
        except Exception as e:
            logger.error(f"Error getting production summary: {e}")
            return {}
    
    def export_production_data(self, run_id: str, format: str = "csv") -> Optional[str]:
        """
        Export production data for a run.
        
        Args:
            run_id: Run ID
            format: Export format ("csv" or "json")
        
        Returns:
            Path to exported file or None if export failed
        """
        try:
            # Get production run
            run = self.get_production_run(run_id)
            if not run:
                logger.warning(f"Production run not found: {run_id}")
                return None
            
            run_config, run_status = run
            
            # Get product
            product = self.get_product(run_config.product_id)
            if not product:
                logger.warning(f"Product not found: {run_config.product_id}")
                product_name = "Unknown"
            else:
                product_name = product.product_name
            
            # Get events
            events = self.get_production_events(run_id=run_id, limit=10000)
            
            # Get downtime records
            downtime_records = self.list_downtime_records(run_id=run_id, limit=1000)
            
            # Create export directory
            export_dir = os.path.join(self.config_dir, "exports")
            os.makedirs(export_dir, exist_ok=True)
            
            # Generate export filename
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"production_data_{run_id}_{timestamp}.{format}"
            export_path = os.path.join(export_dir, filename)
            
            # Export data
            if format == "csv":
                # Export run details
                run_details = {
                    "run_id": run_id,
                    "product_id": run_config.product_id,
                    "product_name": product_name,
                    "batch_id": run_config.batch_id,
                    "operator_id": run_config.operator_id,
                    "line_id": run_config.line_id,
                    "scheduled_start": run_config.scheduled_start,
                    "scheduled_end": run_config.scheduled_end,
                    "actual_start": run_status.actual_start,
                    "actual_end": run_status.actual_end,
                    "status": run_status.status.name,
                    "target_quantity": run_config.target_quantity,
                    "current_quantity": run_status.current_quantity,
                    "good_quantity": run_status.good_quantity,
                    "reject_quantity": run_status.reject_quantity,
                    "downtime_minutes": run_status.downtime_minutes,
                    "efficiency": run_status.efficiency,
                    "oee": run_status.oee
                }
                
                # Create DataFrames
                run_df = pd.DataFrame([run_details])
                
                events_df = pd.DataFrame([{
                    "event_id": event.event_id,
                    "run_id": event.run_id,
                    "event_type": event.event_type,
                    "timestamp": event.timestamp,
                    "data": json.dumps(event.data)
                } for event in events])
                
                downtime_df = pd.DataFrame([{
                    "downtime_id": record.downtime_id,
                    "run_id": record.run_id,
                    "start_time": record.start_time,
                    "end_time": record.end_time,
                    "duration_minutes": record.duration_minutes,
                    "reason": record.reason,
                    "category": record.category,
                    "notes": record.notes
                } for record in downtime_records])
                
                # Create defect counts DataFrame
                defect_counts = []
                for defect_type, count in run_status.defect_counts.items():
                    defect_counts.append({
                        "defect_type": defect_type,
                        "count": count
                    })
                
                defects_df = pd.DataFrame(defect_counts)
                
                # Write to CSV files
                run_df.to_csv(export_path, index=False)
                
                events_path = os.path.join(export_dir, f"events_{run_id}_{timestamp}.csv")
                events_df.to_csv(events_path, index=False)
                
                downtime_path = os.path.join(export_dir, f"downtime_{run_id}_{timestamp}.csv")
                downtime_df.to_csv(downtime_path, index=False)
                
                if not defects_df.empty:
                    defects_path = os.path.join(export_dir, f"defects_{run_id}_{timestamp}.csv")
                    defects_df.to_csv(defects_path, index=False)
            elif format == "json":
                # Create export data
                export_data = {
                    "run": {
                        "run_id": run_id,
                        "product_id": run_config.product_id,
                        "product_name": product_name,
                        "batch_id": run_config.batch_id,
                        "operator_id": run_config.operator_id,
                        "line_id": run_config.line_id,
                        "scheduled_start": run_config.scheduled_start,
                        "scheduled_end": run_config.scheduled_end,
                        "actual_start": run_status.actual_start,
                        "actual_end": run_status.actual_end,
                        "status": run_status.status.name,
                        "target_quantity": run_config.target_quantity,
                        "current_quantity": run_status.current_quantity,
                        "good_quantity": run_status.good_quantity,
                        "reject_quantity": run_status.reject_quantity,
                        "defect_counts": run_status.defect_counts,
                        "downtime_minutes": run_status.downtime_minutes,
                        "efficiency": run_status.efficiency,
                        "oee": run_status.oee,
                        "parameters": run_config.parameters
                    },
                    "events": [event.to_dict() for event in events],
                    "downtime_records": [record.to_dict() for record in downtime_records]
                }
                
                # Write to JSON file
                with open(export_path, "w") as f:
                    json.dump(export_data, f, indent=2)
            else:
                logger.warning(f"Unsupported export format: {format}")
                return None
            
            logger.info(f"Exported production data to {export_path}")
            
            return export_path
        except Exception as e:
            logger.error(f"Error exporting production data: {e}")
            return None


# Example usage
if __name__ == "__main__":
    # Setup logging
    logging.basicConfig(level=logging.INFO)
    
    # Create production run manager
    manager = ProductionRunManager(
        db_path="data/database/sandwich_inspection.db",
        config_dir="config"
    )
    
    # Start event worker
    manager.start_event_worker()
    
    # Create product
    product_id = manager.create_product(
        product_name="Classic Sandwich",
        product_code="SAND-001",
        product_version="1.0",
        description="Classic sandwich with ham and cheese",
        parameters={
            "length_mm": 150,
            "width_mm": 100,
            "height_mm": 50,
            "weight_g": 250
        }
    )
    
    # Create production run
    run_id = manager.create_production_run(
        product_id=product_id,
        batch_id="BATCH-001",
        operator_id="OP-001",
        line_id="LINE-001",
        scheduled_start=datetime.datetime.now().isoformat(),
        scheduled_end=(datetime.datetime.now() + datetime.timedelta(hours=8)).isoformat(),
        target_quantity=1000,
        description="Test production run"
    )
    
    # Start production run
    manager.start_production_run(run_id)
    
    # Record inspection results
    for i in range(10):
        if i % 3 == 0:
            # Fail with defects
            manager.record_inspection_result(
                run_id=run_id,
                result="fail",
                defects=[
                    {
                        "type": "missing_ingredient",
                        "severity": "high",
                        "location": "center"
                    }
                ]
            )
        else:
            # Pass
            manager.record_inspection_result(
                run_id=run_id,
                result="pass"
            )
    
    # Pause production run
    manager.pause_production_run(run_id, reason="Lunch break")
    
    # Resume production run
    manager.resume_production_run(run_id)
    
    # Record more inspection results
    for i in range(5):
        manager.record_inspection_result(
            run_id=run_id,
            result="pass"
        )
    
    # Complete production run
    manager.complete_production_run(run_id)
    
    # Get run statistics
    stats = manager.get_run_statistics(run_id)
    print(f"Run statistics: {stats}")
    
    # Export production data
    export_path = manager.export_production_data(run_id, format="json")
    print(f"Exported to: {export_path}")
    
    # Stop event worker
    manager.stop_event_worker()
