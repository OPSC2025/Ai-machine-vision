"""
Reporting system for OPSC Sandwich Quality Inspection System.
Provides functionality for generating reports on inspection results, production runs, and system performance.

Version: 1.0.0
Last Updated: 2025-04-21
"""

import os
import sys
import time
import json
import logging
import datetime
import uuid
import sqlite3
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from typing import Dict, List, Optional, Tuple, Union, Any, BinaryIO
from pathlib import Path
import threading
import queue
import jinja2
import pdfkit
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import plotly.io as pio
import io
import base64
import csv
import xlsxwriter
from dataclasses import dataclass, field

# Setup logging
logger = logging.getLogger(__name__)

@dataclass
class ReportConfig:
    """Report configuration data class."""
    report_type: str
    title: str
    description: Optional[str] = None
    parameters: Dict[str, Any] = field(default_factory=dict)
    created_by: Optional[str] = None
    output_format: str = "pdf"  # pdf, html, csv, xlsx
    template_name: Optional[str] = None
    include_charts: bool = True
    include_tables: bool = True
    include_summary: bool = True
    include_raw_data: bool = False
    logo_path: Optional[str] = None
    color_scheme: str = "default"  # default, light, dark, colorblind
    page_size: str = "A4"  # A4, letter, legal
    orientation: str = "portrait"  # portrait, landscape
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "report_type": self.report_type,
            "title": self.title,
            "description": self.description,
            "parameters": self.parameters,
            "created_by": self.created_by,
            "output_format": self.output_format,
            "template_name": self.template_name,
            "include_charts": self.include_charts,
            "include_tables": self.include_tables,
            "include_summary": self.include_summary,
            "include_raw_data": self.include_raw_data,
            "logo_path": self.logo_path,
            "color_scheme": self.color_scheme,
            "page_size": self.page_size,
            "orientation": self.orientation
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ReportConfig':
        """Create from dictionary."""
        return cls(
            report_type=data.get("report_type"),
            title=data.get("title"),
            description=data.get("description"),
            parameters=data.get("parameters", {}),
            created_by=data.get("created_by"),
            output_format=data.get("output_format", "pdf"),
            template_name=data.get("template_name"),
            include_charts=data.get("include_charts", True),
            include_tables=data.get("include_tables", True),
            include_summary=data.get("include_summary", True),
            include_raw_data=data.get("include_raw_data", False),
            logo_path=data.get("logo_path"),
            color_scheme=data.get("color_scheme", "default"),
            page_size=data.get("page_size", "A4"),
            orientation=data.get("orientation", "portrait")
        )

class ReportGenerator:
    """
    Report generator for OPSC Sandwich Quality Inspection System.
    
    Provides functionality for generating reports on inspection results, production runs, and system performance.
    """
    
    def __init__(self, db_path: str, templates_dir: str, output_dir: str, assets_dir: Optional[str] = None):
        """
        Initialize report generator.
        
        Args:
            db_path: Path to SQLite database file
            templates_dir: Path to directory containing report templates
            output_dir: Path to directory for report output
            assets_dir: Path to directory containing report assets (optional)
        """
        self.db_path = db_path
        self.templates_dir = templates_dir
        self.output_dir = output_dir
        self.assets_dir = assets_dir or os.path.join(templates_dir, "assets")
        
        # Create directories if they don't exist
        os.makedirs(self.templates_dir, exist_ok=True)
        os.makedirs(self.output_dir, exist_ok=True)
        os.makedirs(self.assets_dir, exist_ok=True)
        
        # Initialize Jinja2 environment
        self.jinja_env = jinja2.Environment(
            loader=jinja2.FileSystemLoader(self.templates_dir),
            autoescape=jinja2.select_autoescape(['html', 'xml']),
            trim_blocks=True,
            lstrip_blocks=True
        )
        
        # Add custom filters
        self.jinja_env.filters['format_date'] = self._format_date
        self.jinja_env.filters['format_number'] = self._format_number
        self.jinja_env.filters['format_percent'] = self._format_percent
        self.jinja_env.filters['to_json'] = json.dumps
        
        # Initialize report queue and worker thread
        self.report_queue = queue.Queue()
        self.report_thread = None
        self.report_thread_running = False
        
        # Initialize default templates
        self._init_default_templates()
    
    def _init_default_templates(self):
        """Initialize default report templates."""
        try:
            # Define default templates
            default_templates = {
                "daily_production_report.html": self._get_daily_production_template(),
                "defect_analysis_report.html": self._get_defect_analysis_template(),
                "system_performance_report.html": self._get_system_performance_template(),
                "camera_calibration_report.html": self._get_camera_calibration_template(),
                "model_performance_report.html": self._get_model_performance_template(),
                "custom_report.html": self._get_custom_report_template(),
                "report_styles.css": self._get_report_styles()
            }
            
            # Create default templates if they don't exist
            for filename, content in default_templates.items():
                filepath = os.path.join(self.templates_dir, filename)
                if not os.path.exists(filepath):
                    with open(filepath, "w") as f:
                        f.write(content)
                    logger.info(f"Created default template: {filepath}")
            
            # Create default logo if it doesn't exist
            logo_path = os.path.join(self.assets_dir, "logo.png")
            if not os.path.exists(logo_path):
                # Create a simple placeholder logo
                plt.figure(figsize=(4, 2))
                plt.text(0.5, 0.5, "OPSC", fontsize=40, ha='center', va='center', fontweight='bold')
                plt.axis('off')
                plt.savefig(logo_path, bbox_inches='tight', pad_inches=0.1)
                plt.close()
                logger.info(f"Created default logo: {logo_path}")
        except Exception as e:
            logger.error(f"Error initializing default templates: {e}")
    
    def start_report_worker(self):
        """Start background report worker thread."""
        if self.report_thread is not None and self.report_thread.is_alive():
            logger.warning("Report worker thread is already running")
            return
        
        self.report_thread_running = True
        self.report_thread = threading.Thread(target=self._report_worker, daemon=True)
        self.report_thread.start()
        
        logger.info("Started report worker thread")
    
    def stop_report_worker(self):
        """Stop background report worker thread."""
        if self.report_thread is None or not self.report_thread.is_alive():
            logger.warning("Report worker thread is not running")
            return
        
        self.report_thread_running = False
        self.report_thread.join(timeout=5.0)
        
        logger.info("Stopped report worker thread")
    
    def _report_worker(self):
        """Background worker thread for processing report queue."""
        logger.info("Report worker thread started")
        
        while self.report_thread_running:
            try:
                # Get item from queue with timeout
                try:
                    item = self.report_queue.get(timeout=1.0)
                except queue.Empty:
                    continue
                
                # Process item
                try:
                    report_id = item.get("report_id")
                    report_config = item.get("report_config")
                    
                    logger.info(f"Processing report: {report_id}")
                    
                    # Update report status to "generating"
                    self._update_report_status(report_id, "generating")
                    
                    # Generate report
                    try:
                        if report_config.report_type == "daily_production":
                            self._generate_daily_production_report(report_id, report_config)
                        elif report_config.report_type == "defect_analysis":
                            self._generate_defect_analysis_report(report_id, report_config)
                        elif report_config.report_type == "system_performance":
                            self._generate_system_performance_report(report_id, report_config)
                        elif report_config.report_type == "camera_calibration":
                            self._generate_camera_calibration_report(report_id, report_config)
                        elif report_config.report_type == "model_performance":
                            self._generate_model_performance_report(report_id, report_config)
                        elif report_config.report_type == "custom":
                            self._generate_custom_report(report_id, report_config)
                        else:
                            raise ValueError(f"Unknown report type: {report_config.report_type}")
                        
                        # Update report status to "completed"
                        self._update_report_status(report_id, "completed")
                    except Exception as e:
                        logger.error(f"Error generating report {report_id}: {e}")
                        
                        # Update report status to "error"
                        self._update_report_status(report_id, "error", str(e))
                    
                    # Mark item as done
                    self.report_queue.task_done()
                except Exception as e:
                    logger.error(f"Error processing report item: {e}")
                    
                    # Mark item as done
                    self.report_queue.task_done()
            except Exception as e:
                logger.error(f"Error in report worker thread: {e}")
        
        logger.info("Report worker thread stopped")
    
    def queue_report(self, report_config: ReportConfig) -> str:
        """
        Queue a report for generation.
        
        Args:
            report_config: Report configuration
        
        Returns:
            Report ID
        """
        try:
            # Generate report ID
            report_id = f"report_{uuid.uuid4().hex[:8]}"
            
            # Get current timestamp
            now = datetime.datetime.now().isoformat()
            
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Insert report record
            cursor.execute(
                """
                INSERT INTO reports (
                    report_id, report_type, title, description, parameters,
                    created_at, created_by, status
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    report_id,
                    report_config.report_type,
                    report_config.title,
                    report_config.description,
                    json.dumps(report_config.parameters),
                    now,
                    report_config.created_by,
                    "queued"
                )
            )
            
            # Commit changes
            conn.commit()
            
            # Get report ID
            cursor.execute("SELECT id FROM reports WHERE report_id = ?", (report_id,))
            entity_id = cursor.fetchone()[0]
            
            # Close connection
            conn.close()
            
            # Add item to report queue
            self.report_queue.put({
                "report_id": report_id,
                "report_config": report_config
            })
            
            logger.info(f"Queued report: {report_id}")
            
            return report_id
        except Exception as e:
            logger.error(f"Error queuing report: {e}")
            raise
    
    def get_report_status(self, report_id: str) -> Dict[str, Any]:
        """
        Get report status.
        
        Args:
            report_id: Report ID
        
        Returns:
            Report status dictionary
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Get report status
            cursor.execute(
                """
                SELECT * FROM reports WHERE report_id = ?
                """,
                (report_id,)
            )
            row = cursor.fetchone()
            
            # Close connection
            conn.close()
            
            if not row:
                return {"error": f"Report not found: {report_id}"}
            
            # Convert row to dictionary
            report = dict(row)
            
            # Parse parameters
            if report.get("parameters"):
                report["parameters"] = json.loads(report["parameters"])
            
            return report
        except Exception as e:
            logger.error(f"Error getting report status: {e}")
            return {"error": str(e)}
    
    def list_reports(self, limit: int = 100, offset: int = 0, report_type: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        List reports.
        
        Args:
            limit: Maximum number of reports to return
            offset: Offset for pagination
            report_type: Filter by report type (optional)
        
        Returns:
            List of report dictionaries
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Build query
            query = "SELECT * FROM reports"
            params = []
            
            if report_type:
                query += " WHERE report_type = ?"
                params.append(report_type)
            
            query += " ORDER BY created_at DESC LIMIT ? OFFSET ?"
            params.extend([limit, offset])
            
            # Get reports
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            # Close connection
            conn.close()
            
            # Convert rows to dictionaries
            reports = []
            for row in rows:
                report = dict(row)
                
                # Parse parameters
                if report.get("parameters"):
                    report["parameters"] = json.loads(report["parameters"])
                
                reports.append(report)
            
            return reports
        except Exception as e:
            logger.error(f"Error listing reports: {e}")
            return []
    
    def delete_report(self, report_id: str) -> bool:
        """
        Delete report.
        
        Args:
            report_id: Report ID
        
        Returns:
            True if successful, False otherwise
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Get report file path
            cursor.execute("SELECT file_path FROM reports WHERE report_id = ?", (report_id,))
            row = cursor.fetchone()
            
            if not row:
                logger.error(f"Report not found: {report_id}")
                return False
            
            file_path = row[0]
            
            # Delete report file if it exists
            if file_path and os.path.exists(file_path):
                os.remove(file_path)
            
            # Delete report record
            cursor.execute("DELETE FROM reports WHERE report_id = ?", (report_id,))
            
            # Commit changes
            conn.commit()
            
            # Close connection
            conn.close()
            
            logger.info(f"Deleted report: {report_id}")
            
            return True
        except Exception as e:
            logger.error(f"Error deleting report: {e}")
            return False
    
    def _update_report_status(self, report_id: str, status: str, error_message: Optional[str] = None, file_path: Optional[str] = None):
        """
        Update report status.
        
        Args:
            report_id: Report ID
            status: Report status (queued, generating, completed, error)
            error_message: Error message (if status is error)
            file_path: Path to report file (if status is completed)
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Update report status
            if status == "completed" and file_path:
                cursor.execute(
                    """
                    UPDATE reports
                    SET status = ?, file_path = ?
                    WHERE report_id = ?
                    """,
                    (status, file_path, report_id)
                )
            elif status == "error" and error_message:
                cursor.execute(
                    """
                    UPDATE reports
                    SET status = ?, error_message = ?
                    WHERE report_id = ?
                    """,
                    (status, error_message, report_id)
                )
            else:
                cursor.execute(
                    """
                    UPDATE reports
                    SET status = ?
                    WHERE report_id = ?
                    """,
                    (status, report_id)
                )
            
            # Commit changes
            conn.commit()
            
            # Close connection
            conn.close()
        except Exception as e:
            logger.error(f"Error updating report status: {e}")
    
    def _generate_daily_production_report(self, report_id: str, config: ReportConfig):
        """
        Generate daily production report.
        
        Args:
            report_id: Report ID
            config: Report configuration
        """
        try:
            # Get report parameters
            date = config.parameters.get("date", datetime.datetime.now().strftime("%Y-%m-%d"))
            product_type = config.parameters.get("product_type")
            
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            
            # Query production runs
            query = """
            SELECT * FROM production_runs
            WHERE date(start_time) = date(?)
            """
            params = [date]
            
            if product_type:
                query += " AND product_type = ?"
                params.append(product_type)
            
            df_runs = pd.read_sql_query(query, conn, params=params)
            
            if df_runs.empty:
                raise ValueError(f"No production runs found for date: {date}")
            
            # Query inspection results
            run_ids = df_runs["run_id"].tolist()
            placeholders = ", ".join(["?" for _ in run_ids])
            
            query = f"""
            SELECT * FROM inspection_results
            WHERE run_id IN ({placeholders})
            """
            
            df_results = pd.read_sql_query(query, conn, params=run_ids)
            
            # Query defect types
            df_defects = pd.read_sql_query("SELECT * FROM defect_types", conn)
            
            # Close connection
            conn.close()
            
            # Process data
            # Calculate production statistics
            total_inspected = df_results.shape[0]
            total_rejected = df_results[df_results["rejected"] == 1].shape[0]
            rejection_rate = total_rejected / total_inspected if total_inspected > 0 else 0
            
            # Calculate defect statistics
            defect_counts = df_results[df_results["defect_type"].notnull()].groupby("defect_type").size().reset_index(name="count")
            if not defect_counts.empty and not df_defects.empty:
                defect_counts = defect_counts.merge(df_defects[["defect_code", "name", "severity"]], left_on="defect_type", right_on="defect_code", how="left")
            
            # Calculate hourly production
            df_results["hour"] = pd.to_datetime(df_results["timestamp"]).dt.hour
            hourly_counts = df_results.groupby("hour").size().reset_index(name="count")
            hourly_rejected = df_results[df_results["rejected"] == 1].groupby("hour").size().reset_index(name="rejected")
            hourly_production = hourly_counts.merge(hourly_rejected, on="hour", how="left")
            hourly_production["rejected"] = hourly_production["rejected"].fillna(0)
            hourly_production["passed"] = hourly_production["count"] - hourly_production["rejected"]
            
            # Calculate run statistics
            run_stats = []
            for _, run in df_runs.iterrows():
                run_id = run["run_id"]
                run_results = df_results[df_results["run_id"] == run_id]
                run_inspected = run_results.shape[0]
                run_rejected = run_results[run_results["rejected"] == 1].shape[0]
                run_rejection_rate = run_rejected / run_inspected if run_inspected > 0 else 0
                
                run_stats.append({
                    "run_id": run_id,
                    "product_type": run["product_type"],
                    "batch_number": run["batch_number"],
                    "start_time": run["start_time"],
                    "end_time": run["end_time"],
                    "operator": run["operator"],
                    "status": run["status"],
                    "inspected": run_inspected,
                    "rejected": run_rejected,
                    "rejection_rate": run_rejection_rate
                })
            
            # Generate charts
            charts = {}
            
            if config.include_charts:
                # Hourly production chart
                fig = make_subplots(specs=[[{"secondary_y": True}]])
                
                fig.add_trace(
                    go.Bar(
                        x=hourly_production["hour"],
                        y=hourly_production["passed"],
                        name="Passed",
                        marker_color="green"
                    ),
                    secondary_y=False
                )
                
                fig.add_trace(
                    go.Bar(
                        x=hourly_production["hour"],
                        y=hourly_production["rejected"],
                        name="Rejected",
                        marker_color="red"
                    ),
                    secondary_y=False
                )
                
                fig.add_trace(
                    go.Scatter(
                        x=hourly_production["hour"],
                        y=hourly_production["rejected"] / hourly_production["count"] * 100,
                        name="Rejection Rate (%)",
                        marker_color="blue",
                        mode="lines+markers"
                    ),
                    secondary_y=True
                )
                
                fig.update_layout(
                    title="Hourly Production",
                    xaxis_title="Hour of Day",
                    yaxis_title="Count",
                    barmode="stack",
                    legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
                )
                
                fig.update_yaxes(title_text="Rejection Rate (%)", secondary_y=True)
                
                # Save chart
                hourly_chart_path = os.path.join(self.output_dir, f"{report_id}_hourly.png")
                fig.write_image(hourly_chart_path)
                charts["hourly_production"] = hourly_chart_path
                
                # Defect types chart
                if not defect_counts.empty:
                    fig = px.pie(
                        defect_counts,
                        values="count",
                        names="name" if "name" in defect_counts.columns else "defect_type",
                        title="Defect Types Distribution"
                    )
                    
                    fig.update_traces(textposition="inside", textinfo="percent+label")
                    
                    # Save chart
                    defects_chart_path = os.path.join(self.output_dir, f"{report_id}_defects.png")
                    fig.write_image(defects_chart_path)
                    charts["defect_types"] = defects_chart_path
                
                # Run comparison chart
                if len(run_stats) > 1:
                    fig = make_subplots(specs=[[{"secondary_y": True}]])
                    
                    fig.add_trace(
                        go.Bar(
                            x=[run["run_id"] for run in run_stats],
                            y=[run["inspected"] for run in run_stats],
                            name="Inspected",
                            marker_color="blue"
                        ),
                        secondary_y=False
                    )
                    
                    fig.add_trace(
                        go.Bar(
                            x=[run["run_id"] for run in run_stats],
                            y=[run["rejected"] for run in run_stats],
                            name="Rejected",
                            marker_color="red"
                        ),
                        secondary_y=False
                    )
                    
                    fig.add_trace(
                        go.Scatter(
                            x=[run["run_id"] for run in run_stats],
                            y=[run["rejection_rate"] * 100 for run in run_stats],
                            name="Rejection Rate (%)",
                            marker_color="green",
                            mode="lines+markers"
                        ),
                        secondary_y=True
                    )
                    
                    fig.update_layout(
                        title="Production Run Comparison",
                        xaxis_title="Run ID",
                        yaxis_title="Count",
                        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
                    )
                    
                    fig.update_yaxes(title_text="Rejection Rate (%)", secondary_y=True)
                    
                    # Save chart
                    runs_chart_path = os.path.join(self.output_dir, f"{report_id}_runs.png")
                    fig.write_image(runs_chart_path)
                    charts["run_comparison"] = runs_chart_path
            
            # Prepare template data
            template_data = {
                "report_id": report_id,
                "title": config.title,
                "description": config.description,
                "date": date,
                "product_type": product_type,
                "generated_at": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "generated_by": config.created_by or "System",
                "logo_path": config.logo_path or os.path.join(self.assets_dir, "logo.png"),
                "summary": {
                    "total_runs": len(run_stats),
                    "total_inspected": total_inspected,
                    "total_rejected": total_rejected,
                    "rejection_rate": rejection_rate,
                    "total_defects": defect_counts["count"].sum() if not defect_counts.empty else 0
                },
                "hourly_production": hourly_production.to_dict(orient="records"),
                "defect_counts": defect_counts.to_dict(orient="records") if not defect_counts.empty else [],
                "run_stats": run_stats,
                "charts": charts
            }
            
            # Generate report
            template_name = config.template_name or "daily_production_report.html"
            output_format = config.output_format.lower()
            
            if output_format == "html":
                # Generate HTML report
                html_content = self._render_template(template_name, template_data)
                output_path = os.path.join(self.output_dir, f"{report_id}.html")
                
                with open(output_path, "w") as f:
                    f.write(html_content)
            elif output_format == "pdf":
                # Generate PDF report
                html_content = self._render_template(template_name, template_data)
                output_path = os.path.join(self.output_dir, f"{report_id}.pdf")
                
                options = {
                    'page-size': config.page_size,
                    'orientation': config.orientation,
                    'title': config.title,
                    'encoding': 'UTF-8',
                    'enable-local-file-access': None
                }
                
                pdfkit.from_string(html_content, output_path, options=options)
            elif output_format == "csv":
                # Generate CSV report
                output_path = os.path.join(self.output_dir, f"{report_id}.csv")
                
                # Write run statistics to CSV
                with open(output_path, "w", newline="") as f:
                    writer = csv.writer(f)
                    writer.writerow(["Run ID", "Product Type", "Batch Number", "Start Time", "End Time", "Operator", "Status", "Inspected", "Rejected", "Rejection Rate"])
                    
                    for run in run_stats:
                        writer.writerow([
                            run["run_id"],
                            run["product_type"],
                            run["batch_number"],
                            run["start_time"],
                            run["end_time"],
                            run["operator"],
                            run["status"],
                            run["inspected"],
                            run["rejected"],
                            run["rejection_rate"]
                        ])
            elif output_format == "xlsx":
                # Generate Excel report
                output_path = os.path.join(self.output_dir, f"{report_id}.xlsx")
                
                with xlsxwriter.Workbook(output_path) as workbook:
                    # Create summary worksheet
                    summary_sheet = workbook.add_worksheet("Summary")
                    summary_sheet.write(0, 0, "Report ID")
                    summary_sheet.write(0, 1, report_id)
                    summary_sheet.write(1, 0, "Date")
                    summary_sheet.write(1, 1, date)
                    summary_sheet.write(2, 0, "Product Type")
                    summary_sheet.write(2, 1, product_type or "All")
                    summary_sheet.write(3, 0, "Total Runs")
                    summary_sheet.write(3, 1, len(run_stats))
                    summary_sheet.write(4, 0, "Total Inspected")
                    summary_sheet.write(4, 1, total_inspected)
                    summary_sheet.write(5, 0, "Total Rejected")
                    summary_sheet.write(5, 1, total_rejected)
                    summary_sheet.write(6, 0, "Rejection Rate")
                    summary_sheet.write(6, 1, rejection_rate)
                    
                    # Create runs worksheet
                    runs_sheet = workbook.add_worksheet("Production Runs")
                    runs_sheet.write_row(0, 0, ["Run ID", "Product Type", "Batch Number", "Start Time", "End Time", "Operator", "Status", "Inspected", "Rejected", "Rejection Rate"])
                    
                    for i, run in enumerate(run_stats):
                        runs_sheet.write(i + 1, 0, run["run_id"])
                        runs_sheet.write(i + 1, 1, run["product_type"])
                        runs_sheet.write(i + 1, 2, run["batch_number"])
                        runs_sheet.write(i + 1, 3, run["start_time"])
                        runs_sheet.write(i + 1, 4, run["end_time"])
                        runs_sheet.write(i + 1, 5, run["operator"])
                        runs_sheet.write(i + 1, 6, run["status"])
                        runs_sheet.write(i + 1, 7, run["inspected"])
                        runs_sheet.write(i + 1, 8, run["rejected"])
                        runs_sheet.write(i + 1, 9, run["rejection_rate"])
                    
                    # Create hourly production worksheet
                    hourly_sheet = workbook.add_worksheet("Hourly Production")
                    hourly_sheet.write_row(0, 0, ["Hour", "Total", "Passed", "Rejected", "Rejection Rate"])
                    
                    for i, row in hourly_production.iterrows():
                        hourly_sheet.write(i + 1, 0, row["hour"])
                        hourly_sheet.write(i + 1, 1, row["count"])
                        hourly_sheet.write(i + 1, 2, row["passed"])
                        hourly_sheet.write(i + 1, 3, row["rejected"])
                        hourly_sheet.write(i + 1, 4, row["rejected"] / row["count"] if row["count"] > 0 else 0)
                    
                    # Create defects worksheet if available
                    if not defect_counts.empty:
                        defects_sheet = workbook.add_worksheet("Defect Types")
                        columns = ["defect_type", "count"]
                        if "name" in defect_counts.columns:
                            columns.extend(["name", "severity"])
                        
                        defects_sheet.write_row(0, 0, columns)
                        
                        for i, row in defect_counts.iterrows():
                            for j, col in enumerate(columns):
                                defects_sheet.write(i + 1, j, row[col])
            else:
                raise ValueError(f"Unsupported output format: {output_format}")
            
            # Update report status
            self._update_report_status(report_id, "completed", file_path=output_path)
            
            logger.info(f"Generated daily production report: {report_id}")
        except Exception as e:
            logger.error(f"Error generating daily production report: {e}")
            
            # Update report status
            self._update_report_status(report_id, "error", str(e))
            
            raise
    
    def _generate_defect_analysis_report(self, report_id: str, config: ReportConfig):
        """
        Generate defect analysis report.
        
        Args:
            report_id: Report ID
            config: Report configuration
        """
        try:
            # Get report parameters
            start_date = config.parameters.get("start_date")
            end_date = config.parameters.get("end_date", datetime.datetime.now().strftime("%Y-%m-%d"))
            product_type = config.parameters.get("product_type")
            defect_type = config.parameters.get("defect_type")
            
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            
            # Query inspection results
            query = """
            SELECT ir.*, pr.product_type, pr.batch_number
            FROM inspection_results ir
            LEFT JOIN production_runs pr ON ir.run_id = pr.run_id
            WHERE ir.defect_type IS NOT NULL
            """
            params = []
            
            if start_date:
                query += " AND date(ir.timestamp) >= date(?)"
                params.append(start_date)
            
            if end_date:
                query += " AND date(ir.timestamp) <= date(?)"
                params.append(end_date)
            
            if product_type:
                query += " AND pr.product_type = ?"
                params.append(product_type)
            
            if defect_type:
                query += " AND ir.defect_type = ?"
                params.append(defect_type)
            
            df_results = pd.read_sql_query(query, conn, params=params)
            
            if df_results.empty:
                raise ValueError(f"No defects found for the specified parameters")
            
            # Query defect types
            df_defects = pd.read_sql_query("SELECT * FROM defect_types", conn)
            
            # Close connection
            conn.close()
            
            # Process data
            # Merge defect information
            if not df_defects.empty:
                df_results = df_results.merge(df_defects[["defect_code", "name", "severity", "color_code"]], left_on="defect_type", right_on="defect_code", how="left")
            
            # Calculate defect statistics
            defect_counts = df_results.groupby("defect_type").size().reset_index(name="count")
            if not defect_counts.empty and not df_defects.empty:
                defect_counts = defect_counts.merge(df_defects[["defect_code", "name", "severity", "color_code"]], left_on="defect_type", right_on="defect_code", how="left")
            
            # Calculate defect by product type
            if "product_type" in df_results.columns:
                defect_by_product = df_results.groupby(["product_type", "defect_type"]).size().reset_index(name="count")
                if not defect_by_product.empty and not df_defects.empty:
                    defect_by_product = defect_by_product.merge(df_defects[["defect_code", "name", "severity"]], left_on="defect_type", right_on="defect_code", how="left")
            else:
                defect_by_product = pd.DataFrame()
            
            # Calculate defect by camera
            defect_by_camera = df_results.groupby(["camera_id", "defect_type"]).size().reset_index(name="count")
            if not defect_by_camera.empty and not df_defects.empty:
                defect_by_camera = defect_by_camera.merge(df_defects[["defect_code", "name", "severity"]], left_on="defect_type", right_on="defect_code", how="left")
            
            # Calculate defect by day
            df_results["date"] = pd.to_datetime(df_results["timestamp"]).dt.date
            defect_by_day = df_results.groupby(["date", "defect_type"]).size().reset_index(name="count")
            if not defect_by_day.empty and not df_defects.empty:
                defect_by_day = defect_by_day.merge(df_defects[["defect_code", "name", "severity"]], left_on="defect_type", right_on="defect_code", how="left")
            
            # Calculate confidence distribution
            confidence_stats = df_results["confidence"].describe()
            
            # Generate charts
            charts = {}
            
            if config.include_charts:
                # Defect types chart
                if not defect_counts.empty:
                    fig = px.pie(
                        defect_counts,
                        values="count",
                        names="name" if "name" in defect_counts.columns else "defect_type",
                        title="Defect Types Distribution",
                        color="defect_type" if "color_code" not in defect_counts.columns else None,
                        color_discrete_map={row["defect_type"]: row["color_code"] for _, row in defect_counts.iterrows() if "color_code" in defect_counts.columns} if "color_code" in defect_counts.columns else None
                    )
                    
                    fig.update_traces(textposition="inside", textinfo="percent+label")
                    
                    # Save chart
                    defects_chart_path = os.path.join(self.output_dir, f"{report_id}_defects.png")
                    fig.write_image(defects_chart_path)
                    charts["defect_types"] = defects_chart_path
                
                # Defect by product type chart
                if not defect_by_product.empty:
                    fig = px.bar(
                        defect_by_product,
                        x="product_type",
                        y="count",
                        color="name" if "name" in defect_by_product.columns else "defect_type",
                        title="Defects by Product Type",
                        barmode="group"
                    )
                    
                    fig.update_layout(
                        xaxis_title="Product Type",
                        yaxis_title="Count",
                        legend_title="Defect Type"
                    )
                    
                    # Save chart
                    product_chart_path = os.path.join(self.output_dir, f"{report_id}_product.png")
                    fig.write_image(product_chart_path)
                    charts["defect_by_product"] = product_chart_path
                
                # Defect by camera chart
                if not defect_by_camera.empty:
                    fig = px.bar(
                        defect_by_camera,
                        x="camera_id",
                        y="count",
                        color="name" if "name" in defect_by_camera.columns else "defect_type",
                        title="Defects by Camera",
                        barmode="group"
                    )
                    
                    fig.update_layout(
                        xaxis_title="Camera ID",
                        yaxis_title="Count",
                        legend_title="Defect Type"
                    )
                    
                    # Save chart
                    camera_chart_path = os.path.join(self.output_dir, f"{report_id}_camera.png")
                    fig.write_image(camera_chart_path)
                    charts["defect_by_camera"] = camera_chart_path
                
                # Defect by day chart
                if not defect_by_day.empty:
                    # Convert date to string for plotting
                    defect_by_day["date_str"] = defect_by_day["date"].astype(str)
                    
                    fig = px.line(
                        defect_by_day,
                        x="date_str",
                        y="count",
                        color="name" if "name" in defect_by_day.columns else "defect_type",
                        title="Defects by Day",
                        markers=True
                    )
                    
                    fig.update_layout(
                        xaxis_title="Date",
                        yaxis_title="Count",
                        legend_title="Defect Type"
                    )
                    
                    # Save chart
                    day_chart_path = os.path.join(self.output_dir, f"{report_id}_day.png")
                    fig.write_image(day_chart_path)
                    charts["defect_by_day"] = day_chart_path
                
                # Confidence distribution chart
                if "confidence" in df_results.columns:
                    fig = px.histogram(
                        df_results,
                        x="confidence",
                        color="name" if "name" in df_results.columns else "defect_type",
                        title="Defect Confidence Distribution",
                        nbins=20
                    )
                    
                    fig.update_layout(
                        xaxis_title="Confidence",
                        yaxis_title="Count",
                        legend_title="Defect Type"
                    )
                    
                    # Save chart
                    confidence_chart_path = os.path.join(self.output_dir, f"{report_id}_confidence.png")
                    fig.write_image(confidence_chart_path)
                    charts["confidence_distribution"] = confidence_chart_path
            
            # Prepare template data
            template_data = {
                "report_id": report_id,
                "title": config.title,
                "description": config.description,
                "start_date": start_date,
                "end_date": end_date,
                "product_type": product_type,
                "defect_type": defect_type,
                "generated_at": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "generated_by": config.created_by or "System",
                "logo_path": config.logo_path or os.path.join(self.assets_dir, "logo.png"),
                "summary": {
                    "total_defects": df_results.shape[0],
                    "unique_defect_types": defect_counts.shape[0],
                    "avg_confidence": df_results["confidence"].mean() if "confidence" in df_results.columns else None,
                    "min_confidence": df_results["confidence"].min() if "confidence" in df_results.columns else None,
                    "max_confidence": df_results["confidence"].max() if "confidence" in df_results.columns else None
                },
                "defect_counts": defect_counts.to_dict(orient="records") if not defect_counts.empty else [],
                "defect_by_product": defect_by_product.to_dict(orient="records") if not defect_by_product.empty else [],
                "defect_by_camera": defect_by_camera.to_dict(orient="records") if not defect_by_camera.empty else [],
                "defect_by_day": defect_by_day.to_dict(orient="records") if not defect_by_day.empty else [],
                "confidence_stats": {
                    "count": confidence_stats["count"] if "confidence" in df_results.columns else 0,
                    "mean": confidence_stats["mean"] if "confidence" in df_results.columns else 0,
                    "std": confidence_stats["std"] if "confidence" in df_results.columns else 0,
                    "min": confidence_stats["min"] if "confidence" in df_results.columns else 0,
                    "25%": confidence_stats["25%"] if "confidence" in df_results.columns else 0,
                    "50%": confidence_stats["50%"] if "confidence" in df_results.columns else 0,
                    "75%": confidence_stats["75%"] if "confidence" in df_results.columns else 0,
                    "max": confidence_stats["max"] if "confidence" in df_results.columns else 0
                },
                "charts": charts
            }
            
            # Generate report
            template_name = config.template_name or "defect_analysis_report.html"
            output_format = config.output_format.lower()
            
            if output_format == "html":
                # Generate HTML report
                html_content = self._render_template(template_name, template_data)
                output_path = os.path.join(self.output_dir, f"{report_id}.html")
                
                with open(output_path, "w") as f:
                    f.write(html_content)
            elif output_format == "pdf":
                # Generate PDF report
                html_content = self._render_template(template_name, template_data)
                output_path = os.path.join(self.output_dir, f"{report_id}.pdf")
                
                options = {
                    'page-size': config.page_size,
                    'orientation': config.orientation,
                    'title': config.title,
                    'encoding': 'UTF-8',
                    'enable-local-file-access': None
                }
                
                pdfkit.from_string(html_content, output_path, options=options)
            elif output_format == "csv":
                # Generate CSV report
                output_path = os.path.join(self.output_dir, f"{report_id}.csv")
                
                # Write defect counts to CSV
                with open(output_path, "w", newline="") as f:
                    writer = csv.writer(f)
                    writer.writerow(["Defect Type", "Name", "Severity", "Count"])
                    
                    for _, row in defect_counts.iterrows():
                        writer.writerow([
                            row["defect_type"],
                            row["name"] if "name" in row else "",
                            row["severity"] if "severity" in row else "",
                            row["count"]
                        ])
            elif output_format == "xlsx":
                # Generate Excel report
                output_path = os.path.join(self.output_dir, f"{report_id}.xlsx")
                
                with xlsxwriter.Workbook(output_path) as workbook:
                    # Create summary worksheet
                    summary_sheet = workbook.add_worksheet("Summary")
                    summary_sheet.write(0, 0, "Report ID")
                    summary_sheet.write(0, 1, report_id)
                    summary_sheet.write(1, 0, "Start Date")
                    summary_sheet.write(1, 1, start_date or "All")
                    summary_sheet.write(2, 0, "End Date")
                    summary_sheet.write(2, 1, end_date)
                    summary_sheet.write(3, 0, "Product Type")
                    summary_sheet.write(3, 1, product_type or "All")
                    summary_sheet.write(4, 0, "Defect Type")
                    summary_sheet.write(4, 1, defect_type or "All")
                    summary_sheet.write(5, 0, "Total Defects")
                    summary_sheet.write(5, 1, df_results.shape[0])
                    summary_sheet.write(6, 0, "Unique Defect Types")
                    summary_sheet.write(6, 1, defect_counts.shape[0])
                    
                    # Create defect counts worksheet
                    counts_sheet = workbook.add_worksheet("Defect Counts")
                    columns = ["defect_type", "count"]
                    if "name" in defect_counts.columns:
                        columns.insert(1, "name")
                    if "severity" in defect_counts.columns:
                        columns.insert(2, "severity")
                    
                    counts_sheet.write_row(0, 0, columns)
                    
                    for i, row in defect_counts.iterrows():
                        for j, col in enumerate(columns):
                            counts_sheet.write(i + 1, j, row[col])
                    
                    # Create defect by product worksheet if available
                    if not defect_by_product.empty:
                        product_sheet = workbook.add_worksheet("Defects by Product")
                        columns = ["product_type", "defect_type", "count"]
                        if "name" in defect_by_product.columns:
                            columns.insert(2, "name")
                        if "severity" in defect_by_product.columns:
                            columns.insert(3, "severity")
                        
                        product_sheet.write_row(0, 0, columns)
                        
                        for i, row in defect_by_product.iterrows():
                            for j, col in enumerate(columns):
                                product_sheet.write(i + 1, j, row[col])
                    
                    # Create defect by camera worksheet
                    camera_sheet = workbook.add_worksheet("Defects by Camera")
                    columns = ["camera_id", "defect_type", "count"]
                    if "name" in defect_by_camera.columns:
                        columns.insert(2, "name")
                    if "severity" in defect_by_camera.columns:
                        columns.insert(3, "severity")
                    
                    camera_sheet.write_row(0, 0, columns)
                    
                    for i, row in defect_by_camera.iterrows():
                        for j, col in enumerate(columns):
                            camera_sheet.write(i + 1, j, row[col])
                    
                    # Create defect by day worksheet
                    day_sheet = workbook.add_worksheet("Defects by Day")
                    columns = ["date", "defect_type", "count"]
                    if "name" in defect_by_day.columns:
                        columns.insert(2, "name")
                    if "severity" in defect_by_day.columns:
                        columns.insert(3, "severity")
                    
                    day_sheet.write_row(0, 0, columns)
                    
                    for i, row in defect_by_day.iterrows():
                        for j, col in enumerate(columns):
                            day_sheet.write(i + 1, j, str(row[col]) if col == "date" else row[col])
                    
                    # Create raw data worksheet if requested
                    if config.include_raw_data:
                        raw_sheet = workbook.add_worksheet("Raw Data")
                        columns = df_results.columns.tolist()
                        
                        raw_sheet.write_row(0, 0, columns)
                        
                        for i, row in df_results.iterrows():
                            for j, col in enumerate(columns):
                                raw_sheet.write(i + 1, j, str(row[col]) if isinstance(row[col], (datetime.date, datetime.datetime)) else row[col])
            else:
                raise ValueError(f"Unsupported output format: {output_format}")
            
            # Update report status
            self._update_report_status(report_id, "completed", file_path=output_path)
            
            logger.info(f"Generated defect analysis report: {report_id}")
        except Exception as e:
            logger.error(f"Error generating defect analysis report: {e}")
            
            # Update report status
            self._update_report_status(report_id, "error", str(e))
            
            raise
    
    def _generate_system_performance_report(self, report_id: str, config: ReportConfig):
        """
        Generate system performance report.
        
        Args:
            report_id: Report ID
            config: Report configuration
        """
        # Implementation for system performance report
        pass
    
    def _generate_camera_calibration_report(self, report_id: str, config: ReportConfig):
        """
        Generate camera calibration report.
        
        Args:
            report_id: Report ID
            config: Report configuration
        """
        # Implementation for camera calibration report
        pass
    
    def _generate_model_performance_report(self, report_id: str, config: ReportConfig):
        """
        Generate model performance report.
        
        Args:
            report_id: Report ID
            config: Report configuration
        """
        # Implementation for model performance report
        pass
    
    def _generate_custom_report(self, report_id: str, config: ReportConfig):
        """
        Generate custom report.
        
        Args:
            report_id: Report ID
            config: Report configuration
        """
        # Implementation for custom report
        pass
    
    def _render_template(self, template_name: str, data: Dict[str, Any]) -> str:
        """
        Render Jinja2 template.
        
        Args:
            template_name: Template name
            data: Template data
        
        Returns:
            Rendered HTML content
        """
        try:
            # Get template
            template = self.jinja_env.get_template(template_name)
            
            # Render template
            html_content = template.render(**data)
            
            return html_content
        except Exception as e:
            logger.error(f"Error rendering template: {e}")
            raise
    
    def _format_date(self, value, format="%Y-%m-%d %H:%M:%S"):
        """Jinja2 filter to format date."""
        if isinstance(value, (datetime.date, datetime.datetime)):
            return value.strftime(format)
        return value
    
    def _format_number(self, value, precision=2):
        """Jinja2 filter to format number."""
        if isinstance(value, (int, float)):
            return f"{value:,.{precision}f}"
        return value
    
    def _format_percent(self, value, precision=2):
        """Jinja2 filter to format percentage."""
        if isinstance(value, (int, float)):
            return f"{value * 100:.{precision}f}%"
        return value
    
    def _get_daily_production_template(self) -> str:
        """Get default daily production report template."""
        return """<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ title }}</title>
    <style>
        {% include 'report_styles.css' %}
    </style>
</head>
<body>
    <div class="report">
        <div class="header">
            <img src="{{ logo_path }}" alt="Logo" class="logo">
            <div class="header-text">
                <h1>{{ title }}</h1>
                <p>{{ description }}</p>
                <p class="date">Date: {{ date }}</p>
                <p class="report-id">Report ID: {{ report_id }}</p>
            </div>
        </div>
        
        <div class="section">
            <h2>Summary</h2>
            <div class="summary-grid">
                <div class="summary-item">
                    <div class="summary-value">{{ summary.total_runs }}</div>
                    <div class="summary-label">Production Runs</div>
                </div>
                <div class="summary-item">
                    <div class="summary-value">{{ summary.total_inspected }}</div>
                    <div class="summary-label">Total Inspected</div>
                </div>
                <div class="summary-item">
                    <div class="summary-value">{{ summary.total_rejected }}</div>
                    <div class="summary-label">Total Rejected</div>
                </div>
                <div class="summary-item">
                    <div class="summary-value">{{ summary.rejection_rate|format_percent }}</div>
                    <div class="summary-label">Rejection Rate</div>
                </div>
            </div>
        </div>
        
        {% if charts.hourly_production %}
        <div class="section">
            <h2>Hourly Production</h2>
            <img src="{{ charts.hourly_production }}" alt="Hourly Production Chart" class="chart">
            
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Hour</th>
                        <th>Total</th>
                        <th>Passed</th>
                        <th>Rejected</th>
                        <th>Rejection Rate</th>
                    </tr>
                </thead>
                <tbody>
                    {% for hour in hourly_production %}
                    <tr>
                        <td>{{ hour.hour }}:00</td>
                        <td>{{ hour.count }}</td>
                        <td>{{ hour.passed }}</td>
                        <td>{{ hour.rejected }}</td>
                        <td>{{ (hour.rejected / hour.count if hour.count > 0 else 0)|format_percent }}</td>
                    </tr>
                    {% endfor %}
                </tbody>
            </table>
        </div>
        {% endif %}
        
        {% if charts.defect_types %}
        <div class="section">
            <h2>Defect Types</h2>
            <img src="{{ charts.defect_types }}" alt="Defect Types Chart" class="chart">
            
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Defect Type</th>
                        {% if defect_counts and defect_counts[0].name is defined %}
                        <th>Name</th>
                        {% endif %}
                        {% if defect_counts and defect_counts[0].severity is defined %}
                        <th>Severity</th>
                        {% endif %}
                        <th>Count</th>
                        <th>Percentage</th>
                    </tr>
                </thead>
                <tbody>
                    {% for defect in defect_counts %}
                    <tr>
                        <td>{{ defect.defect_type }}</td>
                        {% if defect.name is defined %}
                        <td>{{ defect.name }}</td>
                        {% endif %}
                        {% if defect.severity is defined %}
                        <td>{{ defect.severity }}</td>
                        {% endif %}
                        <td>{{ defect.count }}</td>
                        <td>{{ (defect.count / summary.total_defects if summary.total_defects > 0 else 0)|format_percent }}</td>
                    </tr>
                    {% endfor %}
                </tbody>
            </table>
        </div>
        {% endif %}
        
        {% if charts.run_comparison %}
        <div class="section">
            <h2>Production Run Comparison</h2>
            <img src="{{ charts.run_comparison }}" alt="Production Run Comparison Chart" class="chart">
        </div>
        {% endif %}
        
        <div class="section">
            <h2>Production Runs</h2>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Run ID</th>
                        <th>Product Type</th>
                        <th>Batch Number</th>
                        <th>Start Time</th>
                        <th>End Time</th>
                        <th>Operator</th>
                        <th>Status</th>
                        <th>Inspected</th>
                        <th>Rejected</th>
                        <th>Rejection Rate</th>
                    </tr>
                </thead>
                <tbody>
                    {% for run in run_stats %}
                    <tr>
                        <td>{{ run.run_id }}</td>
                        <td>{{ run.product_type }}</td>
                        <td>{{ run.batch_number }}</td>
                        <td>{{ run.start_time }}</td>
                        <td>{{ run.end_time }}</td>
                        <td>{{ run.operator }}</td>
                        <td>{{ run.status }}</td>
                        <td>{{ run.inspected }}</td>
                        <td>{{ run.rejected }}</td>
                        <td>{{ run.rejection_rate|format_percent }}</td>
                    </tr>
                    {% endfor %}
                </tbody>
            </table>
        </div>
        
        <div class="footer">
            <p>Generated on {{ generated_at }} by {{ generated_by }}</p>
            <p>OPSC Sandwich Quality Inspection System</p>
        </div>
    </div>
</body>
</html>"""
    
    def _get_defect_analysis_template(self) -> str:
        """Get default defect analysis report template."""
        return """<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ title }}</title>
    <style>
        {% include 'report_styles.css' %}
    </style>
</head>
<body>
    <div class="report">
        <div class="header">
            <img src="{{ logo_path }}" alt="Logo" class="logo">
            <div class="header-text">
                <h1>{{ title }}</h1>
                <p>{{ description }}</p>
                <p class="date">Period: {{ start_date or 'All' }} to {{ end_date }}</p>
                <p class="report-id">Report ID: {{ report_id }}</p>
            </div>
        </div>
        
        <div class="section">
            <h2>Summary</h2>
            <div class="summary-grid">
                <div class="summary-item">
                    <div class="summary-value">{{ summary.total_defects }}</div>
                    <div class="summary-label">Total Defects</div>
                </div>
                <div class="summary-item">
                    <div class="summary-value">{{ summary.unique_defect_types }}</div>
                    <div class="summary-label">Unique Defect Types</div>
                </div>
                {% if summary.avg_confidence %}
                <div class="summary-item">
                    <div class="summary-value">{{ summary.avg_confidence|format_percent }}</div>
                    <div class="summary-label">Average Confidence</div>
                </div>
                {% endif %}
            </div>
        </div>
        
        {% if charts.defect_types %}
        <div class="section">
            <h2>Defect Types Distribution</h2>
            <img src="{{ charts.defect_types }}" alt="Defect Types Chart" class="chart">
            
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Defect Type</th>
                        {% if defect_counts and defect_counts[0].name is defined %}
                        <th>Name</th>
                        {% endif %}
                        {% if defect_counts and defect_counts[0].severity is defined %}
                        <th>Severity</th>
                        {% endif %}
                        <th>Count</th>
                        <th>Percentage</th>
                    </tr>
                </thead>
                <tbody>
                    {% for defect in defect_counts %}
                    <tr>
                        <td>{{ defect.defect_type }}</td>
                        {% if defect.name is defined %}
                        <td>{{ defect.name }}</td>
                        {% endif %}
                        {% if defect.severity is defined %}
                        <td>{{ defect.severity }}</td>
                        {% endif %}
                        <td>{{ defect.count }}</td>
                        <td>{{ (defect.count / summary.total_defects if summary.total_defects > 0 else 0)|format_percent }}</td>
                    </tr>
                    {% endfor %}
                </tbody>
            </table>
        </div>
        {% endif %}
        
        {% if charts.defect_by_product %}
        <div class="section">
            <h2>Defects by Product Type</h2>
            <img src="{{ charts.defect_by_product }}" alt="Defects by Product Type Chart" class="chart">
            
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Product Type</th>
                        <th>Defect Type</th>
                        {% if defect_by_product and defect_by_product[0].name is defined %}
                        <th>Name</th>
                        {% endif %}
                        {% if defect_by_product and defect_by_product[0].severity is defined %}
                        <th>Severity</th>
                        {% endif %}
                        <th>Count</th>
                    </tr>
                </thead>
                <tbody>
                    {% for item in defect_by_product %}
                    <tr>
                        <td>{{ item.product_type }}</td>
                        <td>{{ item.defect_type }}</td>
                        {% if item.name is defined %}
                        <td>{{ item.name }}</td>
                        {% endif %}
                        {% if item.severity is defined %}
                        <td>{{ item.severity }}</td>
                        {% endif %}
                        <td>{{ item.count }}</td>
                    </tr>
                    {% endfor %}
                </tbody>
            </table>
        </div>
        {% endif %}
        
        {% if charts.defect_by_camera %}
        <div class="section">
            <h2>Defects by Camera</h2>
            <img src="{{ charts.defect_by_camera }}" alt="Defects by Camera Chart" class="chart">
            
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Camera ID</th>
                        <th>Defect Type</th>
                        {% if defect_by_camera and defect_by_camera[0].name is defined %}
                        <th>Name</th>
                        {% endif %}
                        {% if defect_by_camera and defect_by_camera[0].severity is defined %}
                        <th>Severity</th>
                        {% endif %}
                        <th>Count</th>
                    </tr>
                </thead>
                <tbody>
                    {% for item in defect_by_camera %}
                    <tr>
                        <td>{{ item.camera_id }}</td>
                        <td>{{ item.defect_type }}</td>
                        {% if item.name is defined %}
                        <td>{{ item.name }}</td>
                        {% endif %}
                        {% if item.severity is defined %}
                        <td>{{ item.severity }}</td>
                        {% endif %}
                        <td>{{ item.count }}</td>
                    </tr>
                    {% endfor %}
                </tbody>
            </table>
        </div>
        {% endif %}
        
        {% if charts.defect_by_day %}
        <div class="section">
            <h2>Defects by Day</h2>
            <img src="{{ charts.defect_by_day }}" alt="Defects by Day Chart" class="chart">
            
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Defect Type</th>
                        {% if defect_by_day and defect_by_day[0].name is defined %}
                        <th>Name</th>
                        {% endif %}
                        {% if defect_by_day and defect_by_day[0].severity is defined %}
                        <th>Severity</th>
                        {% endif %}
                        <th>Count</th>
                    </tr>
                </thead>
                <tbody>
                    {% for item in defect_by_day %}
                    <tr>
                        <td>{{ item.date }}</td>
                        <td>{{ item.defect_type }}</td>
                        {% if item.name is defined %}
                        <td>{{ item.name }}</td>
                        {% endif %}
                        {% if item.severity is defined %}
                        <td>{{ item.severity }}</td>
                        {% endif %}
                        <td>{{ item.count }}</td>
                    </tr>
                    {% endfor %}
                </tbody>
            </table>
        </div>
        {% endif %}
        
        {% if charts.confidence_distribution %}
        <div class="section">
            <h2>Confidence Distribution</h2>
            <img src="{{ charts.confidence_distribution }}" alt="Confidence Distribution Chart" class="chart">
            
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Statistic</th>
                        <th>Value</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Count</td>
                        <td>{{ confidence_stats.count }}</td>
                    </tr>
                    <tr>
                        <td>Mean</td>
                        <td>{{ confidence_stats.mean|format_percent }}</td>
                    </tr>
                    <tr>
                        <td>Standard Deviation</td>
                        <td>{{ confidence_stats.std|format_percent }}</td>
                    </tr>
                    <tr>
                        <td>Minimum</td>
                        <td>{{ confidence_stats.min|format_percent }}</td>
                    </tr>
                    <tr>
                        <td>25th Percentile</td>
                        <td>{{ confidence_stats["25%"]|format_percent }}</td>
                    </tr>
                    <tr>
                        <td>Median</td>
                        <td>{{ confidence_stats["50%"]|format_percent }}</td>
                    </tr>
                    <tr>
                        <td>75th Percentile</td>
                        <td>{{ confidence_stats["75%"]|format_percent }}</td>
                    </tr>
                    <tr>
                        <td>Maximum</td>
                        <td>{{ confidence_stats.max|format_percent }}</td>
                    </tr>
                </tbody>
            </table>
        </div>
        {% endif %}
        
        <div class="footer">
            <p>Generated on {{ generated_at }} by {{ generated_by }}</p>
            <p>OPSC Sandwich Quality Inspection System</p>
        </div>
    </div>
</body>
</html>"""
    
    def _get_system_performance_template(self) -> str:
        """Get default system performance report template."""
        return """<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ title }}</title>
    <style>
        {% include 'report_styles.css' %}
    </style>
</head>
<body>
    <div class="report">
        <div class="header">
            <img src="{{ logo_path }}" alt="Logo" class="logo">
            <div class="header-text">
                <h1>{{ title }}</h1>
                <p>{{ description }}</p>
                <p class="date">Period: {{ start_date or 'All' }} to {{ end_date }}</p>
                <p class="report-id">Report ID: {{ report_id }}</p>
            </div>
        </div>
        
        <!-- System Performance Report Content -->
        
        <div class="footer">
            <p>Generated on {{ generated_at }} by {{ generated_by }}</p>
            <p>OPSC Sandwich Quality Inspection System</p>
        </div>
    </div>
</body>
</html>"""
    
    def _get_camera_calibration_template(self) -> str:
        """Get default camera calibration report template."""
        return """<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ title }}</title>
    <style>
        {% include 'report_styles.css' %}
    </style>
</head>
<body>
    <div class="report">
        <div class="header">
            <img src="{{ logo_path }}" alt="Logo" class="logo">
            <div class="header-text">
                <h1>{{ title }}</h1>
                <p>{{ description }}</p>
                <p class="date">Camera ID: {{ camera_id }}</p>
                <p class="report-id">Report ID: {{ report_id }}</p>
            </div>
        </div>
        
        <!-- Camera Calibration Report Content -->
        
        <div class="footer">
            <p>Generated on {{ generated_at }} by {{ generated_by }}</p>
            <p>OPSC Sandwich Quality Inspection System</p>
        </div>
    </div>
</body>
</html>"""
    
    def _get_model_performance_template(self) -> str:
        """Get default model performance report template."""
        return """<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ title }}</title>
    <style>
        {% include 'report_styles.css' %}
    </style>
</head>
<body>
    <div class="report">
        <div class="header">
            <img src="{{ logo_path }}" alt="Logo" class="logo">
            <div class="header-text">
                <h1>{{ title }}</h1>
                <p>{{ description }}</p>
                <p class="date">Model ID: {{ model_id }}</p>
                <p class="report-id">Report ID: {{ report_id }}</p>
            </div>
        </div>
        
        <!-- Model Performance Report Content -->
        
        <div class="footer">
            <p>Generated on {{ generated_at }} by {{ generated_by }}</p>
            <p>OPSC Sandwich Quality Inspection System</p>
        </div>
    </div>
</body>
</html>"""
    
    def _get_custom_report_template(self) -> str:
        """Get default custom report template."""
        return """<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ title }}</title>
    <style>
        {% include 'report_styles.css' %}
    </style>
</head>
<body>
    <div class="report">
        <div class="header">
            <img src="{{ logo_path }}" alt="Logo" class="logo">
            <div class="header-text">
                <h1>{{ title }}</h1>
                <p>{{ description }}</p>
                <p class="report-id">Report ID: {{ report_id }}</p>
            </div>
        </div>
        
        <!-- Custom Report Content -->
        
        <div class="footer">
            <p>Generated on {{ generated_at }} by {{ generated_by }}</p>
            <p>OPSC Sandwich Quality Inspection System</p>
        </div>
    </div>
</body>
</html>"""
    
    def _get_report_styles(self) -> str:
        """Get default report styles."""
        return """/* Report Styles */
* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

body {
    font-family: Arial, sans-serif;
    line-height: 1.6;
    color: #333;
    background-color: #f5f5f5;
}

.report {
    max-width: 1200px;
    margin: 20px auto;
    background-color: #fff;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    padding: 20px;
}

.header {
    display: flex;
    align-items: center;
    margin-bottom: 30px;
    border-bottom: 2px solid #eee;
    padding-bottom: 20px;
}

.logo {
    max-width: 150px;
    max-height: 80px;
    margin-right: 20px;
}

.header-text {
    flex: 1;
}

h1 {
    color: #2c3e50;
    margin-bottom: 10px;
}

h2 {
    color: #3498db;
    margin: 20px 0 15px;
    border-bottom: 1px solid #eee;
    padding-bottom: 5px;
}

.date, .report-id {
    color: #7f8c8d;
    font-size: 0.9em;
    margin-top: 5px;
}

.section {
    margin-bottom: 30px;
}

.summary-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 20px;
    margin: 20px 0;
}

.summary-item {
    background-color: #f8f9fa;
    border-radius: 5px;
    padding: 15px;
    text-align: center;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
}

.summary-value {
    font-size: 2em;
    font-weight: bold;
    color: #2980b9;
    margin-bottom: 5px;
}

.summary-label {
    color: #7f8c8d;
    font-size: 0.9em;
}

.chart {
    width: 100%;
    max-width: 800px;
    margin: 20px auto;
    display: block;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

.data-table {
    width: 100%;
    border-collapse: collapse;
    margin: 20px 0;
}

.data-table th, .data-table td {
    padding: 10px;
    text-align: left;
    border-bottom: 1px solid #ddd;
}

.data-table th {
    background-color: #f2f2f2;
    font-weight: bold;
}

.data-table tr:nth-child(even) {
    background-color: #f9f9f9;
}

.data-table tr:hover {
    background-color: #f1f1f1;
}

.footer {
    margin-top: 50px;
    padding-top: 20px;
    border-top: 2px solid #eee;
    text-align: center;
    color: #7f8c8d;
    font-size: 0.9em;
}

@media print {
    body {
        background-color: #fff;
    }
    
    .report {
        box-shadow: none;
        margin: 0;
        max-width: none;
    }
    
    .chart {
        max-width: 100%;
        box-shadow: none;
    }
    
    @page {
        margin: 1cm;
    }
}

@media (max-width: 768px) {
    .header {
        flex-direction: column;
        text-align: center;
    }
    
    .logo {
        margin-right: 0;
        margin-bottom: 15px;
    }
    
    .summary-grid {
        grid-template-columns: 1fr;
    }
    
    .data-table {
        font-size: 0.9em;
    }
}"""


# Example usage
if __name__ == "__main__":
    # Setup logging
    logging.basicConfig(level=logging.INFO)
    
    # Create report generator
    report_generator = ReportGenerator(
        db_path="data/database/sandwich_inspection.db",
        templates_dir="data/reports/templates",
        output_dir="data/reports/output",
        assets_dir="data/reports/assets"
    )
    
    # Start report worker
    report_generator.start_report_worker()
    
    # Create report configuration
    report_config = ReportConfig(
        report_type="daily_production",
        title="Daily Production Report",
        description="Summary of production runs and inspection results",
        parameters={
            "date": datetime.datetime.now().strftime("%Y-%m-%d")
        },
        created_by="System"
    )
    
    # Queue report
    report_id = report_generator.queue_report(report_config)
    print(f"Queued report: {report_id}")
    
    # Wait for report to complete
    time.sleep(5)
    
    # Get report status
    status = report_generator.get_report_status(report_id)
    print(f"Report status: {status}")
    
    # Stop report worker
    report_generator.stop_report_worker()
