"""
Azure cloud integration for OPSC Sandwich Quality Inspection System.
Provides functionality for syncing data, images, and reports to Azure cloud services.

Version: 1.0.0
Last Updated: 2025-04-21
"""

import os
import sys
import time
import json
import logging
import datetime
import uuid
from typing import Dict, List, Optional, Tuple, Union, Any, BinaryIO
from pathlib import Path
import sqlite3
import threading
import queue

# Azure SDK imports
from azure.storage.blob import BlobServiceClient, BlobClient, ContainerClient
from azure.storage.blob import ContentSettings
from azure.core.exceptions import ResourceExistsError, ResourceNotFoundError
from azure.identity import DefaultAzureCredential
from azure.data.tables import TableServiceClient, TableClient, UpdateMode
from azure.core.credentials import AzureNamedKeyCredential

# Setup logging
logger = logging.getLogger(__name__)

class AzureCloudSync:
    """
    Azure cloud integration for OPSC Sandwich Quality Inspection System.
    
    Provides functionality for syncing data, images, and reports to Azure cloud services.
    """
    
    def __init__(self, connection_string: Optional[str] = None, 
                 account_name: Optional[str] = None, 
                 account_key: Optional[str] = None,
                 db_path: str = "data/database/sandwich_inspection.db"):
        """
        Initialize Azure cloud integration.
        
        Args:
            connection_string: Azure Storage connection string (optional)
            account_name: Azure Storage account name (optional, used with account_key)
            account_key: Azure Storage account key (optional, used with account_name)
            db_path: Path to SQLite database file
        
        Note:
            Either connection_string or both account_name and account_key must be provided.
            If both are provided, connection_string takes precedence.
        """
        self.db_path = db_path
        
        # Get connection string from environment if not provided
        if not connection_string:
            connection_string = os.environ.get("AZURE_STORAGE_CONNECTION_STRING")
        
        # Get account name and key from environment if not provided
        if not account_name:
            account_name = os.environ.get("AZURE_STORAGE_ACCOUNT")
        if not account_key:
            account_key = os.environ.get("AZURE_STORAGE_KEY")
        
        # Initialize Azure clients
        if connection_string:
            self.blob_service_client = BlobServiceClient.from_connection_string(connection_string)
            self.table_service_client = TableServiceClient.from_connection_string(connection_string)
            logger.info("Initialized Azure clients using connection string")
        elif account_name and account_key:
            # Initialize blob service client
            self.blob_service_client = BlobServiceClient(
                account_url=f"https://{account_name}.blob.core.windows.net",
                credential={"account_name": account_name, "account_key": account_key}
            )
            
            # Initialize table service client
            self.table_service_client = TableServiceClient(
                endpoint=f"https://{account_name}.table.core.windows.net",
                credential=AzureNamedKeyCredential(account_name, account_key)
            )
            
            logger.info("Initialized Azure clients using account name and key")
        else:
            raise ValueError("Either connection_string or both account_name and account_key must be provided")
        
        # Initialize containers and tables
        self._init_containers()
        self._init_tables()
        
        # Initialize sync queue and worker thread
        self.sync_queue = queue.Queue()
        self.sync_thread = None
        self.sync_thread_running = False
    
    def _init_containers(self):
        """Initialize Azure Blob Storage containers."""
        try:
            # Create containers if they don't exist
            containers = [
                "inspection-images",
                "calibration-images",
                "reports",
                "models",
                "logs"
            ]
            
            for container_name in containers:
                try:
                    container_client = self.blob_service_client.create_container(container_name)
                    logger.info(f"Created container: {container_name}")
                except ResourceExistsError:
                    container_client = self.blob_service_client.get_container_client(container_name)
                    logger.info(f"Container already exists: {container_name}")
        except Exception as e:
            logger.error(f"Error initializing Azure Blob Storage containers: {e}")
            raise
    
    def _init_tables(self):
        """Initialize Azure Table Storage tables."""
        try:
            # Create tables if they don't exist
            tables = [
                "inspectionresults",
                "productionruns",
                "defecttypes",
                "cameracalibrations",
                "modelperformance",
                "hardwaretelemetry",
                "systemlogs",
                "alerts"
            ]
            
            for table_name in tables:
                try:
                    table_client = self.table_service_client.create_table(table_name)
                    logger.info(f"Created table: {table_name}")
                except ResourceExistsError:
                    table_client = self.table_service_client.get_table_client(table_name)
                    logger.info(f"Table already exists: {table_name}")
        except Exception as e:
            logger.error(f"Error initializing Azure Table Storage tables: {e}")
            raise
    
    def start_sync_worker(self):
        """Start background sync worker thread."""
        if self.sync_thread is not None and self.sync_thread.is_alive():
            logger.warning("Sync worker thread is already running")
            return
        
        self.sync_thread_running = True
        self.sync_thread = threading.Thread(target=self._sync_worker, daemon=True)
        self.sync_thread.start()
        
        logger.info("Started sync worker thread")
    
    def stop_sync_worker(self):
        """Stop background sync worker thread."""
        if self.sync_thread is None or not self.sync_thread.is_alive():
            logger.warning("Sync worker thread is not running")
            return
        
        self.sync_thread_running = False
        self.sync_thread.join(timeout=5.0)
        
        logger.info("Stopped sync worker thread")
    
    def _sync_worker(self):
        """Background worker thread for processing sync queue."""
        logger.info("Sync worker thread started")
        
        while self.sync_thread_running:
            try:
                # Get item from queue with timeout
                try:
                    item = self.sync_queue.get(timeout=1.0)
                except queue.Empty:
                    continue
                
                # Process item
                try:
                    entity_type = item.get("entity_type")
                    entity_id = item.get("entity_id")
                    
                    logger.info(f"Processing sync item: {entity_type} {entity_id}")
                    
                    if entity_type == "inspection_result":
                        self._sync_inspection_result(entity_id)
                    elif entity_type == "production_run":
                        self._sync_production_run(entity_id)
                    elif entity_type == "defect_type":
                        self._sync_defect_type(entity_id)
                    elif entity_type == "camera_calibration":
                        self._sync_camera_calibration(entity_id)
                    elif entity_type == "model_performance":
                        self._sync_model_performance(entity_id)
                    elif entity_type == "hardware_telemetry":
                        self._sync_hardware_telemetry(entity_id)
                    elif entity_type == "system_log":
                        self._sync_system_log(entity_id)
                    elif entity_type == "alert":
                        self._sync_alert(entity_id)
                    elif entity_type == "report":
                        self._sync_report(entity_id)
                    elif entity_type == "image":
                        self._sync_image(item.get("file_path"), item.get("container"), item.get("blob_name"))
                    else:
                        logger.warning(f"Unknown entity type: {entity_type}")
                    
                    # Mark item as done
                    self.sync_queue.task_done()
                except Exception as e:
                    logger.error(f"Error processing sync item: {e}")
                    
                    # Update sync status in database
                    self._update_sync_status(
                        entity_type=item.get("entity_type"),
                        entity_id=item.get("entity_id"),
                        sync_status="error",
                        error_message=str(e)
                    )
                    
                    # Mark item as done
                    self.sync_queue.task_done()
            except Exception as e:
                logger.error(f"Error in sync worker thread: {e}")
        
        logger.info("Sync worker thread stopped")
    
    def queue_sync_item(self, entity_type: str, entity_id: int):
        """
        Queue an item for background synchronization.
        
        Args:
            entity_type: Entity type (e.g., "inspection_result", "production_run")
            entity_id: Entity ID
        """
        try:
            # Add item to sync queue
            self.sync_queue.put({
                "entity_type": entity_type,
                "entity_id": entity_id
            })
            
            # Update sync status in database
            self._update_sync_status(
                entity_type=entity_type,
                entity_id=entity_id,
                sync_status="queued"
            )
            
            logger.info(f"Queued sync item: {entity_type} {entity_id}")
        except Exception as e:
            logger.error(f"Error queuing sync item: {e}")
    
    def queue_image_sync(self, file_path: str, container: str, blob_name: Optional[str] = None):
        """
        Queue an image for background synchronization.
        
        Args:
            file_path: Path to image file
            container: Blob container name
            blob_name: Blob name (if None, use filename)
        """
        try:
            # Get blob name if not provided
            if blob_name is None:
                blob_name = os.path.basename(file_path)
            
            # Add item to sync queue
            self.sync_queue.put({
                "entity_type": "image",
                "file_path": file_path,
                "container": container,
                "blob_name": blob_name
            })
            
            logger.info(f"Queued image sync: {file_path} to {container}/{blob_name}")
        except Exception as e:
            logger.error(f"Error queuing image sync: {e}")
    
    def _update_sync_status(self, entity_type: str, entity_id: int, sync_status: str, error_message: Optional[str] = None, azure_blob_url: Optional[str] = None, azure_table_entity: Optional[str] = None):
        """
        Update sync status in database.
        
        Args:
            entity_type: Entity type
            entity_id: Entity ID
            sync_status: Sync status (queued, syncing, success, error)
            error_message: Error message (if status is error)
            azure_blob_url: Azure Blob URL (if applicable)
            azure_table_entity: Azure Table entity ID (if applicable)
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Get current timestamp
            now = datetime.datetime.now().isoformat()
            
            # Check if record exists
            cursor.execute(
                "SELECT id FROM cloud_sync WHERE entity_type = ? AND entity_id = ?",
                (entity_type, entity_id)
            )
            row = cursor.fetchone()
            
            if row:
                # Update existing record
                if sync_status == "success":
                    # Update with successful sync
                    cursor.execute(
                        """
                        UPDATE cloud_sync
                        SET sync_status = ?, last_sync_attempt = ?, last_successful_sync = ?,
                            error_message = ?, retry_count = 0, azure_blob_url = ?, azure_table_entity = ?,
                            updated_at = ?
                        WHERE entity_type = ? AND entity_id = ?
                        """,
                        (sync_status, now, now, None, azure_blob_url, azure_table_entity, now, entity_type, entity_id)
                    )
                elif sync_status == "error":
                    # Update with error and increment retry count
                    cursor.execute(
                        """
                        UPDATE cloud_sync
                        SET sync_status = ?, last_sync_attempt = ?, error_message = ?,
                            retry_count = retry_count + 1, updated_at = ?
                        WHERE entity_type = ? AND entity_id = ?
                        """,
                        (sync_status, now, error_message, now, entity_type, entity_id)
                    )
                else:
                    # Update status only
                    cursor.execute(
                        """
                        UPDATE cloud_sync
                        SET sync_status = ?, last_sync_attempt = ?, updated_at = ?
                        WHERE entity_type = ? AND entity_id = ?
                        """,
                        (sync_status, now, now, entity_type, entity_id)
                    )
            else:
                # Insert new record
                cursor.execute(
                    """
                    INSERT INTO cloud_sync (
                        entity_type, entity_id, sync_status, last_sync_attempt, last_successful_sync,
                        error_message, retry_count, azure_blob_url, azure_table_entity, created_at, updated_at
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (entity_type, entity_id, sync_status, now, None if sync_status != "success" else now,
                     error_message, 0, azure_blob_url, azure_table_entity, now, now)
                )
            
            # Commit changes
            conn.commit()
            
            # Close connection
            conn.close()
        except Exception as e:
            logger.error(f"Error updating sync status: {e}")
    
    def _sync_inspection_result(self, entity_id: int):
        """
        Synchronize inspection result to Azure.
        
        Args:
            entity_id: Inspection result ID
        """
        try:
            # Update sync status
            self._update_sync_status(
                entity_type="inspection_result",
                entity_id=entity_id,
                sync_status="syncing"
            )
            
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Get inspection result
            cursor.execute(
                """
                SELECT * FROM inspection_results WHERE id = ?
                """,
                (entity_id,)
            )
            row = cursor.fetchone()
            
            if not row:
                raise ValueError(f"Inspection result not found: {entity_id}")
            
            # Convert row to dictionary
            result = dict(row)
            
            # Sync image if available
            image_path = result.get("image_path")
            blob_url = None
            
            if image_path and os.path.exists(image_path):
                # Generate blob name
                blob_name = f"{result.get('run_id', 'unknown')}/{os.path.basename(image_path)}"
                
                # Upload image
                blob_url = self._upload_blob(image_path, "inspection-images", blob_name)
            
            # Create table entity
            partition_key = result.get("run_id", "unknown")
            row_key = str(result.get("id"))
            
            entity = {
                "PartitionKey": partition_key,
                "RowKey": row_key,
                "Timestamp": result.get("timestamp"),
                "CameraId": result.get("camera_id"),
                "ImagePath": result.get("image_path"),
                "BlobUrl": blob_url,
                "DefectType": result.get("defect_type"),
                "Confidence": result.get("confidence"),
                "BboxX": result.get("bbox_x"),
                "BboxY": result.get("bbox_y"),
                "BboxWidth": result.get("bbox_width"),
                "BboxHeight": result.get("bbox_height"),
                "Processed": result.get("processed"),
                "Rejected": result.get("rejected")
            }
            
            # Upload to Azure Table
            table_client = self.table_service_client.get_table_client("inspectionresults")
            table_client.upsert_entity(entity)
            
            # Update sync status
            self._update_sync_status(
                entity_type="inspection_result",
                entity_id=entity_id,
                sync_status="success",
                azure_blob_url=blob_url,
                azure_table_entity=f"{partition_key}/{row_key}"
            )
            
            # Close connection
            conn.close()
            
            logger.info(f"Synchronized inspection result: {entity_id}")
        except Exception as e:
            logger.error(f"Error synchronizing inspection result: {e}")
            
            # Update sync status
            self._update_sync_status(
                entity_type="inspection_result",
                entity_id=entity_id,
                sync_status="error",
                error_message=str(e)
            )
            
            raise
    
    def _sync_production_run(self, entity_id: int):
        """
        Synchronize production run to Azure.
        
        Args:
            entity_id: Production run ID
        """
        try:
            # Update sync status
            self._update_sync_status(
                entity_type="production_run",
                entity_id=entity_id,
                sync_status="syncing"
            )
            
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Get production run
            cursor.execute(
                """
                SELECT * FROM production_runs WHERE id = ?
                """,
                (entity_id,)
            )
            row = cursor.fetchone()
            
            if not row:
                raise ValueError(f"Production run not found: {entity_id}")
            
            # Convert row to dictionary
            run = dict(row)
            
            # Create table entity
            partition_key = run.get("product_type", "unknown")
            row_key = run.get("run_id")
            
            entity = {
                "PartitionKey": partition_key,
                "RowKey": row_key,
                "StartTime": run.get("start_time"),
                "EndTime": run.get("end_time"),
                "BatchNumber": run.get("batch_number"),
                "Operator": run.get("operator"),
                "Status": run.get("status"),
                "TotalInspected": run.get("total_inspected"),
                "TotalRejected": run.get("total_rejected"),
                "Notes": run.get("notes")
            }
            
            # Upload to Azure Table
            table_client = self.table_service_client.get_table_client("productionruns")
            table_client.upsert_entity(entity)
            
            # Update sync status
            self._update_sync_status(
                entity_type="production_run",
                entity_id=entity_id,
                sync_status="success",
                azure_table_entity=f"{partition_key}/{row_key}"
            )
            
            # Close connection
            conn.close()
            
            logger.info(f"Synchronized production run: {entity_id}")
        except Exception as e:
            logger.error(f"Error synchronizing production run: {e}")
            
            # Update sync status
            self._update_sync_status(
                entity_type="production_run",
                entity_id=entity_id,
                sync_status="error",
                error_message=str(e)
            )
            
            raise
    
    def _sync_defect_type(self, entity_id: int):
        """
        Synchronize defect type to Azure.
        
        Args:
            entity_id: Defect type ID
        """
        try:
            # Update sync status
            self._update_sync_status(
                entity_type="defect_type",
                entity_id=entity_id,
                sync_status="syncing"
            )
            
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Get defect type
            cursor.execute(
                """
                SELECT * FROM defect_types WHERE id = ?
                """,
                (entity_id,)
            )
            row = cursor.fetchone()
            
            if not row:
                raise ValueError(f"Defect type not found: {entity_id}")
            
            # Convert row to dictionary
            defect_type = dict(row)
            
            # Create table entity
            partition_key = defect_type.get("severity", "unknown")
            row_key = defect_type.get("defect_code")
            
            entity = {
                "PartitionKey": partition_key,
                "RowKey": row_key,
                "Name": defect_type.get("name"),
                "Description": defect_type.get("description"),
                "AutoReject": defect_type.get("auto_reject"),
                "ColorCode": defect_type.get("color_code"),
                "CreatedAt": defect_type.get("created_at"),
                "UpdatedAt": defect_type.get("updated_at")
            }
            
            # Upload to Azure Table
            table_client = self.table_service_client.get_table_client("defecttypes")
            table_client.upsert_entity(entity)
            
            # Update sync status
            self._update_sync_status(
                entity_type="defect_type",
                entity_id=entity_id,
                sync_status="success",
                azure_table_entity=f"{partition_key}/{row_key}"
            )
            
            # Close connection
            conn.close()
            
            logger.info(f"Synchronized defect type: {entity_id}")
        except Exception as e:
            logger.error(f"Error synchronizing defect type: {e}")
            
            # Update sync status
            self._update_sync_status(
                entity_type="defect_type",
                entity_id=entity_id,
                sync_status="error",
                error_message=str(e)
            )
            
            raise
    
    def _sync_camera_calibration(self, entity_id: int):
        """
        Synchronize camera calibration to Azure.
        
        Args:
            entity_id: Camera calibration ID
        """
        try:
            # Update sync status
            self._update_sync_status(
                entity_type="camera_calibration",
                entity_id=entity_id,
                sync_status="syncing"
            )
            
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Get camera calibration
            cursor.execute(
                """
                SELECT * FROM camera_calibrations WHERE id = ?
                """,
                (entity_id,)
            )
            row = cursor.fetchone()
            
            if not row:
                raise ValueError(f"Camera calibration not found: {entity_id}")
            
            # Convert row to dictionary
            calibration = dict(row)
            
            # Create table entity
            partition_key = calibration.get("camera_id", "unknown")
            row_key = f"{calibration.get('id')}_{calibration.get('calibration_date').replace(':', '-')}"
            
            entity = {
                "PartitionKey": partition_key,
                "RowKey": row_key,
                "CalibrationDate": calibration.get("calibration_date"),
                "IntrinsicMatrix": calibration.get("intrinsic_matrix"),
                "DistortionCoefficients": calibration.get("distortion_coefficients"),
                "ResolutionWidth": calibration.get("resolution_width"),
                "ResolutionHeight": calibration.get("resolution_height"),
                "PixelSizeMm": calibration.get("pixel_size_mm"),
                "FocalLengthMm": calibration.get("focal_length_mm"),
                "WorkingDistanceMm": calibration.get("working_distance_mm"),
                "Notes": calibration.get("notes"),
                "Active": calibration.get("active")
            }
            
            # Upload to Azure Table
            table_client = self.table_service_client.get_table_client("cameracalibrations")
            table_client.upsert_entity(entity)
            
            # Update sync status
            self._update_sync_status(
                entity_type="camera_calibration",
                entity_id=entity_id,
                sync_status="success",
                azure_table_entity=f"{partition_key}/{row_key}"
            )
            
            # Close connection
            conn.close()
            
            logger.info(f"Synchronized camera calibration: {entity_id}")
        except Exception as e:
            logger.error(f"Error synchronizing camera calibration: {e}")
            
            # Update sync status
            self._update_sync_status(
                entity_type="camera_calibration",
                entity_id=entity_id,
                sync_status="error",
                error_message=str(e)
            )
            
            raise
    
    def _sync_model_performance(self, entity_id: int):
        """
        Synchronize model performance to Azure.
        
        Args:
            entity_id: Model performance ID
        """
        try:
            # Update sync status
            self._update_sync_status(
                entity_type="model_performance",
                entity_id=entity_id,
                sync_status="syncing"
            )
            
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Get model performance
            cursor.execute(
                """
                SELECT * FROM model_performance WHERE id = ?
                """,
                (entity_id,)
            )
            row = cursor.fetchone()
            
            if not row:
                raise ValueError(f"Model performance not found: {entity_id}")
            
            # Convert row to dictionary
            performance = dict(row)
            
            # Create table entity
            partition_key = performance.get("model_id", "unknown")
            row_key = f"{performance.get('id')}_{performance.get('timestamp').replace(':', '-')}"
            
            entity = {
                "PartitionKey": partition_key,
                "RowKey": row_key,
                "Timestamp": performance.get("timestamp"),
                "ModelVersion": performance.get("model_version"),
                "RunId": performance.get("run_id"),
                "InferenceTimeMs": performance.get("inference_time_ms"),
                "MemoryUsageMb": performance.get("memory_usage_mb"),
                "CpuUsagePercent": performance.get("cpu_usage_percent"),
                "GpuUsagePercent": performance.get("gpu_usage_percent"),
                "TemperatureCelsius": performance.get("temperature_celsius"),
                "BatchSize": performance.get("batch_size"),
                "Precision": performance.get("precision"),
                "Device": performance.get("device")
            }
            
            # Upload to Azure Table
            table_client = self.table_service_client.get_table_client("modelperformance")
            table_client.upsert_entity(entity)
            
            # Update sync status
            self._update_sync_status(
                entity_type="model_performance",
                entity_id=entity_id,
                sync_status="success",
                azure_table_entity=f"{partition_key}/{row_key}"
            )
            
            # Close connection
            conn.close()
            
            logger.info(f"Synchronized model performance: {entity_id}")
        except Exception as e:
            logger.error(f"Error synchronizing model performance: {e}")
            
            # Update sync status
            self._update_sync_status(
                entity_type="model_performance",
                entity_id=entity_id,
                sync_status="error",
                error_message=str(e)
            )
            
            raise
    
    def _sync_hardware_telemetry(self, entity_id: int):
        """
        Synchronize hardware telemetry to Azure.
        
        Args:
            entity_id: Hardware telemetry ID
        """
        try:
            # Update sync status
            self._update_sync_status(
                entity_type="hardware_telemetry",
                entity_id=entity_id,
                sync_status="syncing"
            )
            
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Get hardware telemetry
            cursor.execute(
                """
                SELECT * FROM hardware_telemetry WHERE id = ?
                """,
                (entity_id,)
            )
            row = cursor.fetchone()
            
            if not row:
                raise ValueError(f"Hardware telemetry not found: {entity_id}")
            
            # Convert row to dictionary
            telemetry = dict(row)
            
            # Create table entity
            partition_key = telemetry.get("device_id", "unknown")
            row_key = f"{telemetry.get('id')}_{telemetry.get('timestamp').replace(':', '-')}"
            
            entity = {
                "PartitionKey": partition_key,
                "RowKey": row_key,
                "Timestamp": telemetry.get("timestamp"),
                "DeviceType": telemetry.get("device_type"),
                "CpuUsagePercent": telemetry.get("cpu_usage_percent"),
                "MemoryUsagePercent": telemetry.get("memory_usage_percent"),
                "DiskUsagePercent": telemetry.get("disk_usage_percent"),
                "TemperatureCelsius": telemetry.get("temperature_celsius"),
                "NetworkRxBytes": telemetry.get("network_rx_bytes"),
                "NetworkTxBytes": telemetry.get("network_tx_bytes"),
                "PowerUsageWatts": telemetry.get("power_usage_watts"),
                "UptimeSeconds": telemetry.get("uptime_seconds")
            }
            
            # Upload to Azure Table
            table_client = self.table_service_client.get_table_client("hardwaretelemetry")
            table_client.upsert_entity(entity)
            
            # Update sync status
            self._update_sync_status(
                entity_type="hardware_telemetry",
                entity_id=entity_id,
                sync_status="success",
                azure_table_entity=f"{partition_key}/{row_key}"
            )
            
            # Close connection
            conn.close()
            
            logger.info(f"Synchronized hardware telemetry: {entity_id}")
        except Exception as e:
            logger.error(f"Error synchronizing hardware telemetry: {e}")
            
            # Update sync status
            self._update_sync_status(
                entity_type="hardware_telemetry",
                entity_id=entity_id,
                sync_status="error",
                error_message=str(e)
            )
            
            raise
    
    def _sync_system_log(self, entity_id: int):
        """
        Synchronize system log to Azure.
        
        Args:
            entity_id: System log ID
        """
        try:
            # Update sync status
            self._update_sync_status(
                entity_type="system_log",
                entity_id=entity_id,
                sync_status="syncing"
            )
            
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Get system log
            cursor.execute(
                """
                SELECT * FROM system_logs WHERE id = ?
                """,
                (entity_id,)
            )
            row = cursor.fetchone()
            
            if not row:
                raise ValueError(f"System log not found: {entity_id}")
            
            # Convert row to dictionary
            log = dict(row)
            
            # Create table entity
            partition_key = log.get("component", "unknown")
            row_key = f"{log.get('id')}_{log.get('timestamp').replace(':', '-')}"
            
            entity = {
                "PartitionKey": partition_key,
                "RowKey": row_key,
                "Timestamp": log.get("timestamp"),
                "Level": log.get("level"),
                "Message": log.get("message"),
                "Details": log.get("details")
            }
            
            # Upload to Azure Table
            table_client = self.table_service_client.get_table_client("systemlogs")
            table_client.upsert_entity(entity)
            
            # Update sync status
            self._update_sync_status(
                entity_type="system_log",
                entity_id=entity_id,
                sync_status="success",
                azure_table_entity=f"{partition_key}/{row_key}"
            )
            
            # Close connection
            conn.close()
            
            logger.info(f"Synchronized system log: {entity_id}")
        except Exception as e:
            logger.error(f"Error synchronizing system log: {e}")
            
            # Update sync status
            self._update_sync_status(
                entity_type="system_log",
                entity_id=entity_id,
                sync_status="error",
                error_message=str(e)
            )
            
            raise
    
    def _sync_alert(self, entity_id: int):
        """
        Synchronize alert to Azure.
        
        Args:
            entity_id: Alert ID
        """
        try:
            # Update sync status
            self._update_sync_status(
                entity_type="alert",
                entity_id=entity_id,
                sync_status="syncing"
            )
            
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Get alert
            cursor.execute(
                """
                SELECT * FROM alerts WHERE id = ?
                """,
                (entity_id,)
            )
            row = cursor.fetchone()
            
            if not row:
                raise ValueError(f"Alert not found: {entity_id}")
            
            # Convert row to dictionary
            alert = dict(row)
            
            # Create table entity
            partition_key = alert.get("severity", "unknown")
            row_key = alert.get("alert_id")
            
            entity = {
                "PartitionKey": partition_key,
                "RowKey": row_key,
                "Timestamp": alert.get("timestamp"),
                "AlertType": alert.get("alert_type"),
                "Source": alert.get("source"),
                "Message": alert.get("message"),
                "Details": alert.get("details"),
                "Acknowledged": alert.get("acknowledged"),
                "AcknowledgedBy": alert.get("acknowledged_by"),
                "AcknowledgedAt": alert.get("acknowledged_at"),
                "Resolved": alert.get("resolved"),
                "ResolvedBy": alert.get("resolved_by"),
                "ResolvedAt": alert.get("resolved_at"),
                "ActionsTaken": alert.get("actions_taken")
            }
            
            # Upload to Azure Table
            table_client = self.table_service_client.get_table_client("alerts")
            table_client.upsert_entity(entity)
            
            # Update sync status
            self._update_sync_status(
                entity_type="alert",
                entity_id=entity_id,
                sync_status="success",
                azure_table_entity=f"{partition_key}/{row_key}"
            )
            
            # Close connection
            conn.close()
            
            logger.info(f"Synchronized alert: {entity_id}")
        except Exception as e:
            logger.error(f"Error synchronizing alert: {e}")
            
            # Update sync status
            self._update_sync_status(
                entity_type="alert",
                entity_id=entity_id,
                sync_status="error",
                error_message=str(e)
            )
            
            raise
    
    def _sync_report(self, entity_id: int):
        """
        Synchronize report to Azure.
        
        Args:
            entity_id: Report ID
        """
        try:
            # Update sync status
            self._update_sync_status(
                entity_type="report",
                entity_id=entity_id,
                sync_status="syncing"
            )
            
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Get report
            cursor.execute(
                """
                SELECT * FROM reports WHERE id = ?
                """,
                (entity_id,)
            )
            row = cursor.fetchone()
            
            if not row:
                raise ValueError(f"Report not found: {entity_id}")
            
            # Convert row to dictionary
            report = dict(row)
            
            # Sync report file if available
            file_path = report.get("file_path")
            blob_url = None
            
            if file_path and os.path.exists(file_path):
                # Generate blob name
                blob_name = f"{report.get('report_type', 'unknown')}/{os.path.basename(file_path)}"
                
                # Upload file
                blob_url = self._upload_blob(file_path, "reports", blob_name)
            
            # Create table entity
            partition_key = report.get("report_type", "unknown")
            row_key = report.get("report_id")
            
            entity = {
                "PartitionKey": partition_key,
                "RowKey": row_key,
                "Title": report.get("title"),
                "Description": report.get("description"),
                "Parameters": report.get("parameters"),
                "CreatedAt": report.get("created_at"),
                "CreatedBy": report.get("created_by"),
                "FilePath": report.get("file_path"),
                "BlobUrl": blob_url,
                "Status": report.get("status"),
                "ErrorMessage": report.get("error_message")
            }
            
            # Upload to Azure Table
            table_client = self.table_service_client.get_table_client("reports")
            table_client.upsert_entity(entity)
            
            # Update sync status
            self._update_sync_status(
                entity_type="report",
                entity_id=entity_id,
                sync_status="success",
                azure_blob_url=blob_url,
                azure_table_entity=f"{partition_key}/{row_key}"
            )
            
            # Close connection
            conn.close()
            
            logger.info(f"Synchronized report: {entity_id}")
        except Exception as e:
            logger.error(f"Error synchronizing report: {e}")
            
            # Update sync status
            self._update_sync_status(
                entity_type="report",
                entity_id=entity_id,
                sync_status="error",
                error_message=str(e)
            )
            
            raise
    
    def _sync_image(self, file_path: str, container: str, blob_name: str):
        """
        Synchronize image to Azure.
        
        Args:
            file_path: Path to image file
            container: Blob container name
            blob_name: Blob name
        """
        try:
            # Upload image
            blob_url = self._upload_blob(file_path, container, blob_name)
            
            logger.info(f"Synchronized image: {file_path} to {container}/{blob_name}")
            
            return blob_url
        except Exception as e:
            logger.error(f"Error synchronizing image: {e}")
            raise
    
    def _upload_blob(self, file_path: str, container_name: str, blob_name: str) -> str:
        """
        Upload file to Azure Blob Storage.
        
        Args:
            file_path: Path to file
            container_name: Blob container name
            blob_name: Blob name
        
        Returns:
            Blob URL
        """
        try:
            # Check if file exists
            if not os.path.exists(file_path):
                raise FileNotFoundError(f"File not found: {file_path}")
            
            # Get container client
            container_client = self.blob_service_client.get_container_client(container_name)
            
            # Get blob client
            blob_client = container_client.get_blob_client(blob_name)
            
            # Determine content type
            content_type = self._get_content_type(file_path)
            
            # Upload file
            with open(file_path, "rb") as data:
                blob_client.upload_blob(
                    data,
                    overwrite=True,
                    content_settings=ContentSettings(content_type=content_type)
                )
            
            # Get blob URL
            blob_url = blob_client.url
            
            logger.info(f"Uploaded blob: {file_path} to {container_name}/{blob_name}")
            
            return blob_url
        except Exception as e:
            logger.error(f"Error uploading blob: {e}")
            raise
    
    def _get_content_type(self, file_path: str) -> str:
        """
        Get content type for file.
        
        Args:
            file_path: Path to file
        
        Returns:
            Content type
        """
        # Get file extension
        _, ext = os.path.splitext(file_path)
        ext = ext.lower()
        
        # Map extension to content type
        content_types = {
            ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg",
            ".png": "image/png",
            ".gif": "image/gif",
            ".bmp": "image/bmp",
            ".tiff": "image/tiff",
            ".tif": "image/tiff",
            ".pdf": "application/pdf",
            ".csv": "text/csv",
            ".txt": "text/plain",
            ".json": "application/json",
            ".xml": "application/xml",
            ".html": "text/html",
            ".htm": "text/html",
            ".zip": "application/zip",
            ".tar": "application/x-tar",
            ".gz": "application/gzip",
            ".mp4": "video/mp4",
            ".avi": "video/x-msvideo",
            ".mov": "video/quicktime",
            ".wmv": "video/x-ms-wmv"
        }
        
        return content_types.get(ext, "application/octet-stream")
    
    def download_blob(self, container_name: str, blob_name: str, destination_path: str) -> str:
        """
        Download file from Azure Blob Storage.
        
        Args:
            container_name: Blob container name
            blob_name: Blob name
            destination_path: Path to save downloaded file
        
        Returns:
            Path to downloaded file
        """
        try:
            # Get container client
            container_client = self.blob_service_client.get_container_client(container_name)
            
            # Get blob client
            blob_client = container_client.get_blob_client(blob_name)
            
            # Create directory if it doesn't exist
            os.makedirs(os.path.dirname(destination_path), exist_ok=True)
            
            # Download file
            with open(destination_path, "wb") as file:
                blob_data = blob_client.download_blob()
                file.write(blob_data.readall())
            
            logger.info(f"Downloaded blob: {container_name}/{blob_name} to {destination_path}")
            
            return destination_path
        except Exception as e:
            logger.error(f"Error downloading blob: {e}")
            raise
    
    def list_blobs(self, container_name: str, prefix: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        List blobs in container.
        
        Args:
            container_name: Blob container name
            prefix: Blob name prefix (optional)
        
        Returns:
            List of blob information dictionaries
        """
        try:
            # Get container client
            container_client = self.blob_service_client.get_container_client(container_name)
            
            # List blobs
            blobs = []
            for blob in container_client.list_blobs(name_starts_with=prefix):
                blobs.append({
                    "name": blob.name,
                    "size": blob.size,
                    "content_type": blob.content_settings.content_type,
                    "created_on": blob.creation_time,
                    "last_modified": blob.last_modified,
                    "url": f"{container_client.url}/{blob.name}"
                })
            
            return blobs
        except Exception as e:
            logger.error(f"Error listing blobs: {e}")
            return []
    
    def delete_blob(self, container_name: str, blob_name: str) -> bool:
        """
        Delete blob from Azure Blob Storage.
        
        Args:
            container_name: Blob container name
            blob_name: Blob name
        
        Returns:
            True if successful, False otherwise
        """
        try:
            # Get container client
            container_client = self.blob_service_client.get_container_client(container_name)
            
            # Delete blob
            container_client.delete_blob(blob_name)
            
            logger.info(f"Deleted blob: {container_name}/{blob_name}")
            
            return True
        except Exception as e:
            logger.error(f"Error deleting blob: {e}")
            return False
    
    def get_pending_sync_items(self, limit: int = 100) -> List[Dict[str, Any]]:
        """
        Get pending sync items.
        
        Args:
            limit: Maximum number of items to return
        
        Returns:
            List of pending sync items
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Get pending sync items
            cursor.execute(
                """
                SELECT * FROM cloud_sync
                WHERE sync_status IN ('queued', 'error')
                ORDER BY 
                    CASE sync_status
                        WHEN 'queued' THEN 1
                        WHEN 'error' THEN 2
                    END,
                    last_sync_attempt ASC
                LIMIT ?
                """,
                (limit,)
            )
            rows = cursor.fetchall()
            
            # Convert rows to dictionaries
            items = [dict(row) for row in rows]
            
            # Close connection
            conn.close()
            
            return items
        except Exception as e:
            logger.error(f"Error getting pending sync items: {e}")
            return []
    
    def retry_failed_syncs(self, max_retries: int = 5) -> int:
        """
        Retry failed sync items.
        
        Args:
            max_retries: Maximum number of retry attempts
        
        Returns:
            Number of items queued for retry
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Get failed sync items
            cursor.execute(
                """
                SELECT * FROM cloud_sync
                WHERE sync_status = 'error' AND retry_count < ?
                """,
                (max_retries,)
            )
            rows = cursor.fetchall()
            
            # Queue items for retry
            count = 0
            for row in rows:
                self.queue_sync_item(row["entity_type"], row["entity_id"])
                count += 1
            
            # Close connection
            conn.close()
            
            logger.info(f"Queued {count} items for retry")
            
            return count
        except Exception as e:
            logger.error(f"Error retrying failed syncs: {e}")
            return 0
    
    def get_sync_statistics(self) -> Dict[str, Any]:
        """
        Get sync statistics.
        
        Returns:
            Dictionary with sync statistics
        """
        try:
            # Connect to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Get total count
            cursor.execute("SELECT COUNT(*) FROM cloud_sync")
            total_count = cursor.fetchone()[0]
            
            # Get counts by status
            cursor.execute(
                """
                SELECT sync_status, COUNT(*) FROM cloud_sync
                GROUP BY sync_status
                """
            )
            status_counts = {row[0]: row[1] for row in cursor.fetchall()}
            
            # Get counts by entity type
            cursor.execute(
                """
                SELECT entity_type, COUNT(*) FROM cloud_sync
                GROUP BY entity_type
                """
            )
            entity_counts = {row[0]: row[1] for row in cursor.fetchall()}
            
            # Get recent errors
            cursor.execute(
                """
                SELECT entity_type, entity_id, error_message, last_sync_attempt
                FROM cloud_sync
                WHERE sync_status = 'error'
                ORDER BY last_sync_attempt DESC
                LIMIT 10
                """
            )
            recent_errors = [
                {
                    "entity_type": row[0],
                    "entity_id": row[1],
                    "error_message": row[2],
                    "last_sync_attempt": row[3]
                }
                for row in cursor.fetchall()
            ]
            
            # Close connection
            conn.close()
            
            # Create statistics dictionary
            statistics = {
                "total_count": total_count,
                "status_counts": status_counts,
                "entity_counts": entity_counts,
                "recent_errors": recent_errors,
                "queue_size": self.sync_queue.qsize(),
                "worker_running": self.sync_thread is not None and self.sync_thread.is_alive()
            }
            
            return statistics
        except Exception as e:
            logger.error(f"Error getting sync statistics: {e}")
            return {}


# Example usage
if __name__ == "__main__":
    # Setup logging
    logging.basicConfig(level=logging.INFO)
    
    # Create Azure cloud sync
    cloud_sync = AzureCloudSync(
        connection_string=os.environ.get("AZURE_STORAGE_CONNECTION_STRING"),
        db_path="data/database/sandwich_inspection.db"
    )
    
    # Start sync worker
    cloud_sync.start_sync_worker()
    
    # Queue some items for sync
    cloud_sync.queue_sync_item("inspection_result", 1)
    cloud_sync.queue_sync_item("production_run", 1)
    
    # Queue an image for sync
    cloud_sync.queue_image_sync(
        file_path="data/images/defect_001.jpg",
        container="inspection-images",
        blob_name="test/defect_001.jpg"
    )
    
    # Wait for sync to complete
    time.sleep(5)
    
    # Get sync statistics
    statistics = cloud_sync.get_sync_statistics()
    print(json.dumps(statistics, indent=2))
    
    # Stop sync worker
    cloud_sync.stop_sync_worker()
