"""
Network utility module for OPSC Sandwich Quality Inspection System.
Provides network-related utilities for device discovery, connectivity testing, and monitoring.

Version: 1.0.0
Last Updated: 2025-04-20
"""

import os
import sys
import socket
import subprocess
import time
import ipaddress
import threading
import queue
from typing import Dict, List, Optional, Tuple, Union, Any, Callable
import logging
import json
from dataclasses import dataclass
import re

import requests
import netifaces
import psutil

from .config import get_config
from .logging import setup_logging, log_exception

# Setup logging
logger = setup_logging(__name__)


@dataclass
class NetworkDevice:
    """Class representing a network device."""
    ip: str
    mac: Optional[str] = None
    hostname: Optional[str] = None
    device_type: Optional[str] = None
    is_online: bool = False
    last_seen: Optional[float] = None
    rtt: Optional[float] = None  # Round-trip time in milliseconds
    packet_loss: Optional[float] = None  # Packet loss percentage
    ports: Optional[List[int]] = None  # Open ports


class NetworkManager:
    """
    Network manager for the OPSC Vision System.
    Provides utilities for network device discovery, connectivity testing, and monitoring.
    """

    def __init__(self):
        """Initialize the network manager."""
        self.devices: Dict[str, NetworkDevice] = {}
        self._discovery_thread: Optional[threading.Thread] = None
        self._monitoring_thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self._lock = threading.Lock()
    
    def get_network_interfaces(self) -> Dict[str, Dict[str, Any]]:
        """
        Get information about network interfaces.

        Returns:
            Dictionary mapping interface names to interface information.
        """
        interfaces = {}
        
        for interface in netifaces.interfaces():
            try:
                # Skip loopback interfaces
                if interface.startswith("lo"):
                    continue
                
                addrs = netifaces.ifaddresses(interface)
                
                # Get IPv4 address
                ipv4 = None
                if netifaces.AF_INET in addrs:
                    ipv4 = addrs[netifaces.AF_INET][0].get("addr")
                
                # Get MAC address
                mac = None
                if netifaces.AF_LINK in addrs:
                    mac = addrs[netifaces.AF_LINK][0].get("addr")
                
                # Get interface statistics
                stats = {}
                try:
                    with open(f"/sys/class/net/{interface}/statistics/rx_bytes") as f:
                        stats["rx_bytes"] = int(f.read().strip())
                    with open(f"/sys/class/net/{interface}/statistics/tx_bytes") as f:
                        stats["tx_bytes"] = int(f.read().strip())
                    with open(f"/sys/class/net/{interface}/statistics/rx_packets") as f:
                        stats["rx_packets"] = int(f.read().strip())
                    with open(f"/sys/class/net/{interface}/statistics/tx_packets") as f:
                        stats["tx_packets"] = int(f.read().strip())
                    with open(f"/sys/class/net/{interface}/statistics/rx_errors") as f:
                        stats["rx_errors"] = int(f.read().strip())
                    with open(f"/sys/class/net/{interface}/statistics/tx_errors") as f:
                        stats["tx_errors"] = int(f.read().strip())
                    with open(f"/sys/class/net/{interface}/statistics/rx_dropped") as f:
                        stats["rx_dropped"] = int(f.read().strip())
                    with open(f"/sys/class/net/{interface}/statistics/tx_dropped") as f:
                        stats["tx_dropped"] = int(f.read().strip())
                except (IOError, OSError) as e:
                    logger.warning(f"Failed to read statistics for interface {interface}: {e}")
                
                # Get MTU
                mtu = None
                try:
                    with open(f"/sys/class/net/{interface}/mtu") as f:
                        mtu = int(f.read().strip())
                except (IOError, OSError) as e:
                    logger.warning(f"Failed to read MTU for interface {interface}: {e}")
                
                # Get interface state
                state = None
                try:
                    with open(f"/sys/class/net/{interface}/operstate") as f:
                        state = f.read().strip()
                except (IOError, OSError) as e:
                    logger.warning(f"Failed to read state for interface {interface}: {e}")
                
                interfaces[interface] = {
                    "ipv4": ipv4,
                    "mac": mac,
                    "mtu": mtu,
                    "state": state,
                    "statistics": stats
                }
            except Exception as e:
                logger.error(f"Error getting information for interface {interface}: {e}")
        
        return interfaces
    
    def get_default_interface(self) -> Optional[str]:
        """
        Get the name of the default network interface.

        Returns:
            Name of the default interface, or None if not found.
        """
        try:
            # Get the default gateway
            gateways = netifaces.gateways()
            if "default" in gateways and netifaces.AF_INET in gateways["default"]:
                return gateways["default"][netifaces.AF_INET][1]
        except Exception as e:
            logger.error(f"Error getting default interface: {e}")
        
        return None
    
    def get_subnet(self, interface: Optional[str] = None) -> Optional[str]:
        """
        Get the subnet for the specified interface.

        Args:
            interface: Name of the interface. If None, uses the default interface.

        Returns:
            Subnet in CIDR notation (e.g., "192.168.1.0/24"), or None if not found.
        """
        if interface is None:
            interface = self.get_default_interface()
            if interface is None:
                logger.error("No default interface found")
                return None
        
        try:
            addrs = netifaces.ifaddresses(interface)
            if netifaces.AF_INET in addrs:
                addr = addrs[netifaces.AF_INET][0]
                ip = addr.get("addr")
                netmask = addr.get("netmask")
                
                if ip and netmask:
                    # Convert netmask to CIDR prefix length
                    netmask_bits = sum(bin(int(x)).count('1') for x in netmask.split('.'))
                    
                    # Calculate network address
                    ip_int = int.from_bytes(socket.inet_aton(ip), byteorder="big")
                    netmask_int = int.from_bytes(socket.inet_aton(netmask), byteorder="big")
                    network_int = ip_int & netmask_int
                    network = socket.inet_ntoa(network_int.to_bytes(4, byteorder="big"))
                    
                    return f"{network}/{netmask_bits}"
        except Exception as e:
            logger.error(f"Error getting subnet for interface {interface}: {e}")
        
        return None
    
    def discover_devices(
        self,
        subnet: Optional[str] = None,
        timeout: float = 1.0,
        max_workers: int = 100,
        callback: Optional[Callable[[NetworkDevice], None]] = None
    ) -> List[NetworkDevice]:
        """
        Discover devices on the network.

        Args:
            subnet: Subnet to scan in CIDR notation (e.g., "192.168.1.0/24").
                   If None, uses the subnet from the configuration or the default interface.
            timeout: Timeout for each ping in seconds.
            max_workers: Maximum number of worker threads.
            callback: Optional callback function to call for each discovered device.

        Returns:
            List of discovered devices.
        """
        # Get subnet from configuration or default interface if not specified
        if subnet is None:
            subnet = get_config("network.global.subnet")
            if subnet is None:
                subnet = self.get_subnet()
                if subnet is None:
                    logger.error("Failed to determine subnet")
                    return []
        
        logger.info(f"Discovering devices on subnet {subnet}")
        
        # Parse subnet
        try:
            network = ipaddress.ip_network(subnet, strict=False)
        except ValueError as e:
            logger.error(f"Invalid subnet: {subnet}: {e}")
            return []
        
        # Create worker threads
        worker_queue: queue.Queue = queue.Queue()
        result_queue: queue.Queue = queue.Queue()
        stop_event = threading.Event()
        
        def worker():
            while not stop_event.is_set():
                try:
                    ip = worker_queue.get(block=False)
                except queue.Empty:
                    break
                
                try:
                    # Ping the IP address
                    is_online, rtt = self._ping(str(ip), timeout)
                    
                    if is_online:
                        # Get MAC address
                        mac = self._get_mac_address(str(ip))
                        
                        # Get hostname
                        hostname = self._get_hostname(str(ip))
                        
                        # Create device
                        device = NetworkDevice(
                            ip=str(ip),
                            mac=mac,
                            hostname=hostname,
                            is_online=True,
                            last_seen=time.time(),
                            rtt=rtt
                        )
                        
                        # Add to result queue
                        result_queue.put(device)
                        
                        # Call callback if provided
                        if callback:
                            callback(device)
                except Exception as e:
                    logger.error(f"Error discovering device {ip}: {e}")
                finally:
                    worker_queue.task_done()
        
        # Add IP addresses to queue
        for ip in network.hosts():
            worker_queue.put(ip)
        
        # Start worker threads
        threads = []
        for _ in range(min(max_workers, worker_queue.qsize())):
            thread = threading.Thread(target=worker)
            thread.daemon = True
            thread.start()
            threads.append(thread)
        
        # Wait for all tasks to complete
        try:
            worker_queue.join()
        except KeyboardInterrupt:
            logger.info("Discovery interrupted")
            stop_event.set()
        
        # Get results
        devices = []
        while not result_queue.empty():
            device = result_queue.get()
            devices.append(device)
            
            # Update devices dictionary
            with self._lock:
                self.devices[device.ip] = device
        
        logger.info(f"Discovered {len(devices)} devices")
        return devices
    
    def start_discovery(
        self,
        subnet: Optional[str] = None,
        interval: float = 300.0,
        timeout: float = 1.0,
        max_workers: int = 100,
        callback: Optional[Callable[[NetworkDevice], None]] = None
    ) -> None:
        """
        Start periodic device discovery.

        Args:
            subnet: Subnet to scan in CIDR notation (e.g., "192.168.1.0/24").
                   If None, uses the subnet from the configuration or the default interface.
            interval: Interval between discovery runs in seconds.
            timeout: Timeout for each ping in seconds.
            max_workers: Maximum number of worker threads.
            callback: Optional callback function to call for each discovered device.
        """
        if self._discovery_thread is not None and self._discovery_thread.is_alive():
            logger.warning("Discovery already running")
            return
        
        self._stop_event.clear()
        
        def discovery_loop():
            while not self._stop_event.is_set():
                try:
                    self.discover_devices(subnet, timeout, max_workers, callback)
                except Exception as e:
                    logger.error(f"Error in discovery loop: {e}")
                
                # Sleep until next run or stop event
                for _ in range(int(interval)):
                    if self._stop_event.is_set():
                        break
                    time.sleep(1)
        
        self._discovery_thread = threading.Thread(target=discovery_loop)
        self._discovery_thread.daemon = True
        self._discovery_thread.start()
        
        logger.info(f"Started periodic discovery with interval {interval} seconds")
    
    def stop_discovery(self) -> None:
        """Stop periodic device discovery."""
        if self._discovery_thread is None or not self._discovery_thread.is_alive():
            logger.warning("Discovery not running")
            return
        
        self._stop_event.set()
        self._discovery_thread.join(timeout=5.0)
        self._discovery_thread = None
        
        logger.info("Stopped periodic discovery")
    
    def start_monitoring(
        self,
        devices: Optional[List[str]] = None,
        interval: float = 60.0,
        timeout: float = 1.0,
        callback: Optional[Callable[[NetworkDevice], None]] = None
    ) -> None:
        """
        Start monitoring devices.

        Args:
            devices: List of IP addresses to monitor. If None, monitors all discovered devices.
            interval: Interval between monitoring runs in seconds.
            timeout: Timeout for each ping in seconds.
            callback: Optional callback function to call for each monitored device.
        """
        if self._monitoring_thread is not None and self._monitoring_thread.is_alive():
            logger.warning("Monitoring already running")
            return
        
        self._stop_event.clear()
        
        def monitoring_loop():
            while not self._stop_event.is_set():
                try:
                    # Get devices to monitor
                    monitor_devices = devices
                    if monitor_devices is None:
                        with self._lock:
                            monitor_devices = list(self.devices.keys())
                    
                    # Monitor each device
                    for ip in monitor_devices:
                        if self._stop_event.is_set():
                            break
                        
                        try:
                            # Ping the device
                            is_online, rtt = self._ping(ip, timeout)
                            
                            # Update device information
                            with self._lock:
                                if ip in self.devices:
                                    device = self.devices[ip]
                                    device.is_online = is_online
                                    device.rtt = rtt
                                    device.last_seen = time.time() if is_online else device.last_seen
                                else:
                                    device = NetworkDevice(
                                        ip=ip,
                                        is_online=is_online,
                                        last_seen=time.time() if is_online else None,
                                        rtt=rtt
                                    )
                                    self.devices[ip] = device
                                
                                # Call callback if provided
                                if callback:
                                    callback(device)
                        except Exception as e:
                            logger.error(f"Error monitoring device {ip}: {e}")
                except Exception as e:
                    logger.error(f"Error in monitoring loop: {e}")
                
                # Sleep until next run or stop event
                for _ in range(int(interval)):
                    if self._stop_event.is_set():
                        break
                    time.sleep(1)
        
        self._monitoring_thread = threading.Thread(target=monitoring_loop)
        self._monitoring_thread.daemon = True
        self._monitoring_thread.start()
        
        logger.info(f"Started monitoring with interval {interval} seconds")
    
    def stop_monitoring(self) -> None:
        """Stop monitoring devices."""
        if self._monitoring_thread is None or not self._monitoring_thread.is_alive():
            logger.warning("Monitoring not running")
            return
        
        self._stop_event.set()
        self._monitoring_thread.join(timeout=5.0)
        self._monitoring_thread = None
        
        logger.info("Stopped monitoring")
    
    def get_device(self, ip: str) -> Optional[NetworkDevice]:
        """
        Get information about a device.

        Args:
            ip: IP address of the device.

        Returns:
            Device information, or None if not found.
        """
        with self._lock:
            return self.devices.get(ip)
    
    def get_devices(self) -> Dict[str, NetworkDevice]:
        """
        Get information about all devices.

        Returns:
            Dictionary mapping IP addresses to device information.
        """
        with self._lock:
            return self.devices.copy()
    
    def check_connectivity(self, ip: str, port: int, timeout: float = 1.0) -> bool:
        """
        Check if a device is reachable on a specific port.

        Args:
            ip: IP address of the device.
            port: Port to check.
            timeout: Timeout in seconds.

        Returns:
            True if the device is reachable on the specified port, False otherwise.
        """
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(timeout)
                s.connect((ip, port))
                return True
        except (socket.timeout, ConnectionRefusedError, OSError):
            return False
        except Exception as e:
            logger.error(f"Error checking connectivity to {ip}:{port}: {e}")
            return False
    
    def scan_ports(
        self,
        ip: str,
        ports: List[int],
        timeout: float = 1.0,
        max_workers: int = 10
    ) -> List[int]:
        """
        Scan ports on a device.

        Args:
            ip: IP address of the device.
            ports: List of ports to scan.
            timeout: Timeout for each connection attempt in seconds.
            max_workers: Maximum number of worker threads.

        Returns:
            List of open ports.
        """
        logger.info(f"Scanning ports on {ip}")
        
        # Create worker threads
        worker_queue: queue.Queue = queue.Queue()
        result_queue: queue.Queue = queue.Queue()
        stop_event = threading.Event()
        
        def worker():
            while not stop_event.is_set():
                try:
                    port = worker_queue.get(block=False)
                except queue.Empty:
                    break
                
                try:
                    # Check if port is open
                    if self.check_connectivity(ip, port, timeout):
                        result_queue.put(port)
                except Exception as e:
                    logger.error(f"Error scanning port {port} on {ip}: {e}")
                finally:
                    worker_queue.task_done()
        
        # Add ports to queue
        for port in ports:
            worker_queue.put(port)
        
        # Start worker threads
        threads = []
        for _ in range(min(max_workers, worker_queue.qsize())):
            thread = threading.Thread(target=worker)
            thread.daemon = True
            thread.start()
            threads.append(thread)
        
        # Wait for all tasks to complete
        try:
            worker_queue.join()
        except KeyboardInterrupt:
            logger.info("Port scan interrupted")
            stop_event.set()
        
        # Get results
        open_ports = []
        while not result_queue.empty():
            port = result_queue.get()
            open_ports.append(port)
        
        # Update device information
        with self._lock:
            if ip in self.devices:
                self.devices[ip].ports = open_ports
        
        logger.info(f"Found {len(open_ports)} open ports on {ip}")
        return open_ports
    
    def get_network_stats(self, interface: Optional[str] = None) -> Dict[str, Any]:
        """
        Get network statistics for an interface.

        Args:
            interface: Name of the interface. If None, uses the default interface.

        Returns:
            Dictionary of network statistics.
        """
        if interface is None:
            interface = self.get_default_interface()
            if interface is None:
                logger.error("No default interface found")
                return {}
        
        try:
            # Get interface statistics
            stats = {}
            
            # Get current statistics
            with open(f"/sys/class/net/{interface}/statistics/rx_bytes") as f:
                stats["rx_bytes"] = int(f.read().strip())
            with open(f"/sys/class/net/{interface}/statistics/tx_bytes") as f:
                stats["tx_bytes"] = int(f.read().strip())
            with open(f"/sys/class/net/{interface}/statistics/rx_packets") as f:
                stats["rx_packets"] = int(f.read().strip())
            with open(f"/sys/class/net/{interface}/statistics/tx_packets") as f:
                stats["tx_packets"] = int(f.read().strip())
            with open(f"/sys/class/net/{interface}/statistics/rx_errors") as f:
                stats["rx_errors"] = int(f.read().strip())
            with open(f"/sys/class/net/{interface}/statistics/tx_errors") as f:
                stats["tx_errors"] = int(f.read().strip())
            with open(f"/sys/class/net/{interface}/statistics/rx_dropped") as f:
                stats["rx_dropped"] = int(f.read().strip())
            with open(f"/sys/class/net/{interface}/statistics/tx_dropped") as f:
                stats["tx_dropped"] = int(f.read().strip())
            
            # Get interface speed
            speed = None
            try:
                with open(f"/sys/class/net/{interface}/speed") as f:
                    speed = int(f.read().strip())
            except (IOError, OSError):
                # Speed might not be available for all interfaces
                pass
            
            stats["speed"] = speed
            
            # Get MTU
            with open(f"/sys/class/net/{interface}/mtu") as f:
                stats["mtu"] = int(f.read().strip())
            
            # Get interface state
            with open(f"/sys/class/net/{interface}/operstate") as f:
                stats["state"] = f.read().strip()
            
            # Get IP address
            addrs = netifaces.ifaddresses(interface)
            if netifaces.AF_INET in addrs:
                stats["ipv4"] = addrs[netifaces.AF_INET][0].get("addr")
            
            # Get MAC address
            if netifaces.AF_LINK in addrs:
                stats["mac"] = addrs[netifaces.AF_LINK][0].get("addr")
            
            return stats
        except Exception as e:
            logger.error(f"Error getting network statistics for interface {interface}: {e}")
            return {}
    
    def _ping(self, ip: str, timeout: float = 1.0) -> Tuple[bool, Optional[float]]:
        """
        Ping an IP address.

        Args:
            ip: IP address to ping.
            timeout: Timeout in seconds.

        Returns:
            Tuple of (is_reachable, round_trip_time).
            round_trip_time is in milliseconds, or None if not reachable.
        """
        try:
            # Use ping command
            timeout_ms = int(timeout * 1000)
            cmd = ["ping", "-c", "1", "-W", str(int(timeout)), "-w", str(int(timeout)), ip]
            
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                universal_newlines=True
            )
            stdout, stderr = process.communicate()
            
            # Check if ping was successful
            if process.returncode == 0:
                # Extract round-trip time
                match = re.search(r"time=(\d+\.\d+) ms", stdout)
                if match:
                    rtt = float(match.group(1))
                    return True, rtt
                return True, None
            
            return False, None
        except Exception as e:
            logger.error(f"Error pinging {ip}: {e}")
            return False, None
    
    def _get_mac_address(self, ip: str) -> Optional[str]:
        """
        Get the MAC address for an IP address.

        Args:
            ip: IP address.

        Returns:
            MAC address, or None if not found.
        """
        try:
            # Check ARP cache
            cmd = ["arp", "-n", ip]
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                universal_newlines=True
            )
            stdout, stderr = process.communicate()
            
            # Extract MAC address
            match = re.search(r"([0-9a-fA-F]{2}(?::[0-9a-fA-F]{2}){5})", stdout)
            if match:
                return match.group(1)
            
            return None
        except Exception as e:
            logger.error(f"Error getting MAC address for {ip}: {e}")
            return None
    
    def _get_hostname(self, ip: str) -> Optional[str]:
        """
        Get the hostname for an IP address.

        Args:
            ip: IP address.

        Returns:
            Hostname, or None if not found.
        """
        try:
            hostname, _, _ = socket.gethostbyaddr(ip)
            return hostname
        except (socket.herror, socket.gaierror):
            return None
        except Exception as e:
            logger.error(f"Error getting hostname for {ip}: {e}")
            return None


# Singleton instance
_network_manager: Optional[NetworkManager] = None


def get_network_manager() -> NetworkManager:
    """
    Get the singleton NetworkManager instance.

    Returns:
        NetworkManager instance.
    """
    global _network_manager
    if _network_manager is None:
        _network_manager = NetworkManager()
    return _network_manager


def get_network_interfaces() -> Dict[str, Dict[str, Any]]:
    """
    Get information about network interfaces.

    Returns:
        Dictionary mapping interface names to interface information.
    """
    return get_network_manager().get_network_interfaces()


def get_default_interface() -> Optional[str]:
    """
    Get the name of the default network interface.

    Returns:
        Name of the default interface, or None if not found.
    """
    return get_network_manager().get_default_interface()


def get_subnet(interface: Optional[str] = None) -> Optional[str]:
    """
    Get the subnet for the specified interface.

    Args:
        interface: Name of the interface. If None, uses the default interface.

    Returns:
        Subnet in CIDR notation (e.g., "192.168.1.0/24"), or None if not found.
    """
    return get_network_manager().get_subnet(interface)


def discover_devices(
    subnet: Optional[str] = None,
    timeout: float = 1.0,
    max_workers: int = 100,
    callback: Optional[Callable[[NetworkDevice], None]] = None
) -> List[NetworkDevice]:
    """
    Discover devices on the network.

    Args:
        subnet: Subnet to scan in CIDR notation (e.g., "192.168.1.0/24").
               If None, uses the subnet from the configuration or the default interface.
        timeout: Timeout for each ping in seconds.
        max_workers: Maximum number of worker threads.
        callback: Optional callback function to call for each discovered device.

    Returns:
        List of discovered devices.
    """
    return get_network_manager().discover_devices(subnet, timeout, max_workers, callback)


def check_connectivity(ip: str, port: int, timeout: float = 1.0) -> bool:
    """
    Check if a device is reachable on a specific port.

    Args:
        ip: IP address of the device.
        port: Port to check.
        timeout: Timeout in seconds.

    Returns:
        True if the device is reachable on the specified port, False otherwise.
    """
    return get_network_manager().check_connectivity(ip, port, timeout)


def scan_ports(
    ip: str,
    ports: List[int],
    timeout: float = 1.0,
    max_workers: int = 10
) -> List[int]:
    """
    Scan ports on a device.

    Args:
        ip: IP address of the device.
        ports: List of ports to scan.
        timeout: Timeout for each connection attempt in seconds.
        max_workers: Maximum number of worker threads.

    Returns:
        List of open ports.
    """
    return get_network_manager().scan_ports(ip, ports, timeout, max_workers)


def get_network_stats(interface: Optional[str] = None) -> Dict[str, Any]:
    """
    Get network statistics for an interface.

    Args:
        interface: Name of the interface. If None, uses the default interface.

    Returns:
        Dictionary of network statistics.
    """
    return get_network_manager().get_network_stats(interface)


if __name__ == "__main__":
    # Setup logging for standalone execution
    logging.basicConfig(level=logging.INFO)
    
    # Example usage
    network_manager = get_network_manager()
    
    # Get network interfaces
    interfaces = network_manager.get_network_interfaces()
    logger.info(f"Network interfaces: {json.dumps(interfaces, indent=2)}")
    
    # Get default interface
    default_interface = network_manager.get_default_interface()
    logger.info(f"Default interface: {default_interface}")
    
    # Get subnet
    subnet = network_manager.get_subnet()
    logger.info(f"Subnet: {subnet}")
    
    # Discover devices
    devices = network_manager.discover_devices()
    logger.info(f"Discovered devices: {len(devices)}")
    for device in devices:
        logger.info(f"  {device.ip} ({device.hostname or 'Unknown'}) - MAC: {device.mac or 'Unknown'}")
    
    # Scan ports on a device
    if devices:
        device = devices[0]
        ports = network_manager.scan_ports(device.ip, [22, 80, 443, 3956])
        logger.info(f"Open ports on {device.ip}: {ports}")
    
    # Get network statistics
    stats = network_manager.get_network_stats()
    logger.info(f"Network statistics: {json.dumps(stats, indent=2)}")
