"""
Logging utilities for the OPSC Sandwich Quality Inspection System.

This module provides utilities for setting up and managing logging.

Version: 1.0.0
Last Updated: 2025-04-21
"""

import os
import sys
import logging
import logging.handlers
from datetime import datetime
from pathlib import Path
from typing import Optional, Union, Dict, Any

def setup_logging(
    level: int = logging.INFO,
    log_file: Optional[str] = None,
    log_dir: str = "data/logs",
    app_name: str = "opsc-vision",
    max_bytes: int = 10485760,  # 10 MB
    backup_count: int = 10,
    console: bool = True,
    format_string: Optional[str] = None
) -> logging.Logger:
    """
    Set up logging for the application.
    
    Args:
        level: Logging level
        log_file: Path to log file (if None, will use app_name)
        log_dir: Directory for log files
        app_name: Application name for logger
        max_bytes: Maximum log file size before rotation
        backup_count: Number of backup log files to keep
        console: Whether to log to console
        format_string: Custom format string for log messages
    
    Returns:
        Configured logger
    """
    # Create logger
    logger = logging.getLogger(app_name)
    logger.setLevel(level)
    
    # Clear existing handlers
    logger.handlers = []
    
    # Create log directory if it doesn't exist
    if log_file is not None or log_dir is not None:
        os.makedirs(log_dir, exist_ok=True)
    
    # Set default format string if not provided
    if format_string is None:
        format_string = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    
    # Create formatter
    formatter = logging.Formatter(format_string)
    
    # Add file handler if log_file or log_dir is provided
    if log_file is not None or log_dir is not None:
        # If log_file is not provided, use app_name with timestamp
        if log_file is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            log_file = f"{app_name}_{timestamp}.log"
        
        # Create full path to log file
        log_path = os.path.join(log_dir, log_file)
        
        # Create rotating file handler
        file_handler = logging.handlers.RotatingFileHandler(
            log_path,
            maxBytes=max_bytes,
            backupCount=backup_count
        )
        file_handler.setLevel(level)
        file_handler.setFormatter(formatter)
        
        # Add handler to logger
        logger.addHandler(file_handler)
    
    # Add console handler if requested
    if console:
        console_handler = logging.StreamHandler()
        console_handler.setLevel(level)
        console_handler.setFormatter(formatter)
        
        # Add handler to logger
        logger.addHandler(console_handler)
    
    return logger


class LoggerAdapter(logging.LoggerAdapter):
    """
    Logger adapter for adding context to log messages.
    
    This adapter allows adding context information to log messages,
    such as camera ID, process ID, or other metadata.
    """
    
    def __init__(self, logger: logging.Logger, extra: Dict[str, Any] = None):
        """
        Initialize the logger adapter.
        
        Args:
            logger: Base logger
            extra: Extra context information
        """
        super().__init__(logger, extra or {})
    
    def process(self, msg, kwargs):
        """
        Process the log message to add context.
        
        Args:
            msg: Log message
            kwargs: Keyword arguments
        
        Returns:
            Processed message and kwargs
        """
        # Add context information to message
        context_str = " ".join(f"[{k}={v}]" for k, v in self.extra.items())
        if context_str:
            msg = f"{context_str} {msg}"
        
        return msg, kwargs


# Example usage
if __name__ == "__main__":
    # Setup logging
    logger = setup_logging(
        level=logging.DEBUG,
        app_name="opsc-vision-test",
        console=True
    )
    
    # Log some messages
    logger.debug("Debug message")
    logger.info("Info message")
    logger.warning("Warning message")
    logger.error("Error message")
    
    # Create logger adapter with context
    adapter = LoggerAdapter(logger, {"camera": "cam1", "process": "inference"})
    
    # Log with context
    adapter.info("Processing image")
    adapter.error("Failed to process image")
