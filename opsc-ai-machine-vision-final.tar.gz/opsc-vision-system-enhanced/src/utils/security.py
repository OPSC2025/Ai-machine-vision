"""
Security utility module for OPSC Sandwich Quality Inspection System.
Provides authentication, authorization, and encryption utilities.

Version: 1.0.0
Last Updated: 2025-04-20
"""

import os
import sys
import base64
import hashlib
import hmac
import secrets
import string
import time
import uuid
from typing import Dict, List, Optional, Tuple, Union, Any, Callable
import logging
import json
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
import re

import jwt
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.backends import default_backend
import bcrypt

from .config import get_config
from .logging import setup_logging, log_exception

# Setup logging
logger = setup_logging(__name__)


class PasswordPolicy:
    """Password policy enforcement."""
    
    def __init__(
        self,
        min_length: int = 12,
        require_uppercase: bool = True,
        require_lowercase: bool = True,
        require_digits: bool = True,
        require_special: bool = True,
        max_repeated_chars: int = 3,
        disallow_common_words: bool = True,
        disallow_username: bool = True
    ):
        """
        Initialize password policy.
        
        Args:
            min_length: Minimum password length.
            require_uppercase: Whether to require uppercase letters.
            require_lowercase: Whether to require lowercase letters.
            require_digits: Whether to require digits.
            require_special: Whether to require special characters.
            max_repeated_chars: Maximum number of repeated characters.
            disallow_common_words: Whether to disallow common words.
            disallow_username: Whether to disallow the username in the password.
        """
        self.min_length = min_length
        self.require_uppercase = require_uppercase
        self.require_lowercase = require_lowercase
        self.require_digits = require_digits
        self.require_special = require_special
        self.max_repeated_chars = max_repeated_chars
        self.disallow_common_words = disallow_common_words
        self.disallow_username = disallow_username
        
        # Common words to disallow
        self.common_words = [
            "password", "admin", "user", "login", "welcome", "123456", "qwerty",
            "letmein", "monkey", "abc123", "football", "iloveyou", "1234567",
            "123123", "12345678", "123456789", "1234567890", "superman", "batman",
            "trustno1", "sunshine", "master", "access", "shadow", "michael", "jennifer",
            "111111", "000000", "654321", "charlie", "joshua", "maggie", "jordan",
            "hunter", "ranger", "thomas", "harley", "robert", "matthew", "pepper",
            "jessica", "james", "martin", "dallas", "hockey", "mickey", "francis",
            "summer", "internet", "service", "canada", "hello", "ranger", "shadow",
            "baseball", "donald", "harley", "hockey", "letmein", "maggie", "mike",
            "mustang", "snoopy", "buster", "dragon", "jordan", "michael", "michelle",
            "mindy", "patrick", "123abc", "andrew", "bear", "calvin", "changeme",
            "diamond", "fuckme", "fuckyou", "matthew", "miller", "tiger", "trustno1",
            "alex", "apple", "avalon", "brandy", "chelsea", "coffee", "falcon",
            "freedom", "gandalf", "green", "helpme", "linda", "magic", "merlin",
            "newyork", "soccer", "thomas", "wizard", "asdfgh", "bandit", "batman",
            "boris", "butthead", "dorothy", "eeyore", "fishing", "football", "george",
            "happy", "iloveyou", "jennifer", "jonathan", "love", "marina", "master",
            "missy", "monday", "monkey", "natasha", "ncc1701", "newpass", "pamela",
            "pepper", "piglet", "poohbear", "pookie", "rabbit", "rachel", "rocket",
            "rose", "smile", "sparky", "spring", "steven", "success", "summer",
            "sunshine", "superman", "tequila", "thunder", "tigers", "tuesday", "victory",
            "wilson", "winner", "winter", "wolves", "xyz123", "zxcvbn"
        ]
    
    def validate(self, password: str, username: Optional[str] = None) -> Tuple[bool, List[str]]:
        """
        Validate a password against the policy.
        
        Args:
            password: Password to validate.
            username: Optional username to check against.
            
        Returns:
            Tuple of (is_valid, error_messages).
        """
        errors = []
        
        # Check length
        if len(password) < self.min_length:
            errors.append(f"Password must be at least {self.min_length} characters long")
        
        # Check character requirements
        if self.require_uppercase and not any(c.isupper() for c in password):
            errors.append("Password must contain at least one uppercase letter")
        
        if self.require_lowercase and not any(c.islower() for c in password):
            errors.append("Password must contain at least one lowercase letter")
        
        if self.require_digits and not any(c.isdigit() for c in password):
            errors.append("Password must contain at least one digit")
        
        if self.require_special and not any(c in string.punctuation for c in password):
            errors.append("Password must contain at least one special character")
        
        # Check for repeated characters
        for i in range(len(password) - self.max_repeated_chars + 1):
            if len(set(password[i:i+self.max_repeated_chars])) == 1:
                errors.append(f"Password must not contain more than {self.max_repeated_chars} repeated characters")
                break
        
        # Check for common words
        if self.disallow_common_words:
            password_lower = password.lower()
            for word in self.common_words:
                if word in password_lower:
                    errors.append(f"Password must not contain common words (found '{word}')")
                    break
        
        # Check for username
        if self.disallow_username and username and username.lower() in password.lower():
            errors.append("Password must not contain the username")
        
        return len(errors) == 0, errors
    
    @classmethod
    def from_config(cls) -> 'PasswordPolicy':
        """
        Create a password policy from configuration.
        
        Returns:
            PasswordPolicy instance.
        """
        return cls(
            min_length=get_config("app.security.password_policy.min_length", 12),
            require_uppercase=get_config("app.security.password_policy.require_uppercase", True),
            require_lowercase=get_config("app.security.password_policy.require_lowercase", True),
            require_digits=get_config("app.security.password_policy.require_digits", True),
            require_special=get_config("app.security.password_policy.require_special", True),
            max_repeated_chars=get_config("app.security.password_policy.max_repeated_chars", 3),
            disallow_common_words=get_config("app.security.password_policy.disallow_common_words", True),
            disallow_username=get_config("app.security.password_policy.disallow_username", True)
        )


class PasswordHasher:
    """Password hashing and verification."""
    
    def __init__(self, rounds: int = 12):
        """
        Initialize password hasher.
        
        Args:
            rounds: Number of rounds for bcrypt.
        """
        self.rounds = rounds
    
    def hash_password(self, password: str) -> str:
        """
        Hash a password.
        
        Args:
            password: Password to hash.
            
        Returns:
            Hashed password.
        """
        password_bytes = password.encode('utf-8')
        salt = bcrypt.gensalt(rounds=self.rounds)
        hashed = bcrypt.hashpw(password_bytes, salt)
        return hashed.decode('utf-8')
    
    def verify_password(self, password: str, hashed_password: str) -> bool:
        """
        Verify a password against a hash.
        
        Args:
            password: Password to verify.
            hashed_password: Hashed password to verify against.
            
        Returns:
            True if the password matches the hash, False otherwise.
        """
        password_bytes = password.encode('utf-8')
        hashed_bytes = hashed_password.encode('utf-8')
        try:
            return bcrypt.checkpw(password_bytes, hashed_bytes)
        except Exception as e:
            logger.error(f"Error verifying password: {e}")
            return False
    
    @classmethod
    def from_config(cls) -> 'PasswordHasher':
        """
        Create a password hasher from configuration.
        
        Returns:
            PasswordHasher instance.
        """
        return cls(
            rounds=get_config("app.security.password_hasher.rounds", 12)
        )


@dataclass
class User:
    """User information."""
    
    username: str
    hashed_password: str
    email: Optional[str] = None
    full_name: Optional[str] = None
    roles: List[str] = field(default_factory=list)
    is_active: bool = True
    last_login: Optional[datetime] = None
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    
    def to_dict(self) -> Dict[str, Any]:
        """
        Convert user to dictionary.
        
        Returns:
            Dictionary representation of the user.
        """
        return {
            "username": self.username,
            "hashed_password": self.hashed_password,
            "email": self.email,
            "full_name": self.full_name,
            "roles": self.roles,
            "is_active": self.is_active,
            "last_login": self.last_login.isoformat() if self.last_login else None,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat()
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'User':
        """
        Create a user from a dictionary.
        
        Args:
            data: Dictionary representation of the user.
            
        Returns:
            User instance.
        """
        return cls(
            username=data["username"],
            hashed_password=data["hashed_password"],
            email=data.get("email"),
            full_name=data.get("full_name"),
            roles=data.get("roles", []),
            is_active=data.get("is_active", True),
            last_login=datetime.fromisoformat(data["last_login"]) if data.get("last_login") else None,
            created_at=datetime.fromisoformat(data["created_at"]),
            updated_at=datetime.fromisoformat(data["updated_at"])
        )


class UserManager:
    """User management."""
    
    def __init__(
        self,
        users_file: Optional[str] = None,
        password_hasher: Optional[PasswordHasher] = None,
        password_policy: Optional[PasswordPolicy] = None
    ):
        """
        Initialize user manager.
        
        Args:
            users_file: Path to users file. If None, uses the path from configuration.
            password_hasher: Password hasher to use. If None, creates a new one.
            password_policy: Password policy to use. If None, creates a new one.
        """
        if users_file is None:
            data_dir = get_config("app.paths.database", "/home/ubuntu/opsc-vision-system/data/database")
            users_file = os.path.join(data_dir, "users.json")
        
        self.users_file = users_file
        self.password_hasher = password_hasher or PasswordHasher.from_config()
        self.password_policy = password_policy or PasswordPolicy.from_config()
        self.users: Dict[str, User] = {}
        
        # Create users file directory if it doesn't exist
        os.makedirs(os.path.dirname(self.users_file), exist_ok=True)
        
        # Load users
        self._load_users()
    
    def _load_users(self) -> None:
        """Load users from file."""
        if not os.path.exists(self.users_file):
            logger.info(f"Users file does not exist: {self.users_file}")
            return
        
        try:
            with open(self.users_file, "r") as f:
                users_data = json.load(f)
            
            self.users = {
                username: User.from_dict(user_data)
                for username, user_data in users_data.items()
            }
            
            logger.info(f"Loaded {len(self.users)} users from {self.users_file}")
        except Exception as e:
            logger.error(f"Error loading users from {self.users_file}: {e}")
    
    def _save_users(self) -> None:
        """Save users to file."""
        try:
            users_data = {
                username: user.to_dict()
                for username, user in self.users.items()
            }
            
            with open(self.users_file, "w") as f:
                json.dump(users_data, f, indent=2)
            
            logger.info(f"Saved {len(self.users)} users to {self.users_file}")
        except Exception as e:
            logger.error(f"Error saving users to {self.users_file}: {e}")
    
    def create_user(
        self,
        username: str,
        password: str,
        email: Optional[str] = None,
        full_name: Optional[str] = None,
        roles: Optional[List[str]] = None,
        validate_password: bool = True
    ) -> Tuple[bool, Optional[User], List[str]]:
        """
        Create a new user.
        
        Args:
            username: Username.
            password: Password.
            email: Email address.
            full_name: Full name.
            roles: List of roles.
            validate_password: Whether to validate the password against the policy.
            
        Returns:
            Tuple of (success, user, error_messages).
        """
        # Check if username already exists
        if username in self.users:
            return False, None, ["Username already exists"]
        
        # Validate username
        if not re.match(r"^[a-zA-Z0-9_-]{3,32}$", username):
            return False, None, ["Username must be 3-32 characters and contain only letters, numbers, underscores, and hyphens"]
        
        # Validate password
        if validate_password:
            is_valid, errors = self.password_policy.validate(password, username)
            if not is_valid:
                return False, None, errors
        
        # Hash password
        hashed_password = self.password_hasher.hash_password(password)
        
        # Create user
        user = User(
            username=username,
            hashed_password=hashed_password,
            email=email,
            full_name=full_name,
            roles=roles or []
        )
        
        # Add user
        self.users[username] = user
        
        # Save users
        self._save_users()
        
        return True, user, []
    
    def update_user(
        self,
        username: str,
        email: Optional[str] = None,
        full_name: Optional[str] = None,
        roles: Optional[List[str]] = None,
        is_active: Optional[bool] = None
    ) -> Tuple[bool, Optional[User], List[str]]:
        """
        Update a user.
        
        Args:
            username: Username.
            email: Email address.
            full_name: Full name.
            roles: List of roles.
            is_active: Whether the user is active.
            
        Returns:
            Tuple of (success, user, error_messages).
        """
        # Check if username exists
        if username not in self.users:
            return False, None, ["User not found"]
        
        # Get user
        user = self.users[username]
        
        # Update user
        if email is not None:
            user.email = email
        
        if full_name is not None:
            user.full_name = full_name
        
        if roles is not None:
            user.roles = roles
        
        if is_active is not None:
            user.is_active = is_active
        
        # Update timestamp
        user.updated_at = datetime.now()
        
        # Save users
        self._save_users()
        
        return True, user, []
    
    def change_password(
        self,
        username: str,
        new_password: str,
        validate_password: bool = True
    ) -> Tuple[bool, List[str]]:
        """
        Change a user's password.
        
        Args:
            username: Username.
            new_password: New password.
            validate_password: Whether to validate the password against the policy.
            
        Returns:
            Tuple of (success, error_messages).
        """
        # Check if username exists
        if username not in self.users:
            return False, ["User not found"]
        
        # Validate password
        if validate_password:
            is_valid, errors = self.password_policy.validate(new_password, username)
            if not is_valid:
                return False, errors
        
        # Hash password
        hashed_password = self.password_hasher.hash_password(new_password)
        
        # Update user
        user = self.users[username]
        user.hashed_password = hashed_password
        user.updated_at = datetime.now()
        
        # Save users
        self._save_users()
        
        return True, []
    
    def delete_user(self, username: str) -> bool:
        """
        Delete a user.
        
        Args:
            username: Username.
            
        Returns:
            True if the user was deleted, False otherwise.
        """
        # Check if username exists
        if username not in self.users:
            return False
        
        # Delete user
        del self.users[username]
        
        # Save users
        self._save_users()
        
        return True
    
    def get_user(self, username: str) -> Optional[User]:
        """
        Get a user.
        
        Args:
            username: Username.
            
        Returns:
            User if found, None otherwise.
        """
        return self.users.get(username)
    
    def get_users(self) -> List[User]:
        """
        Get all users.
        
        Returns:
            List of users.
        """
        return list(self.users.values())
    
    def authenticate(self, username: str, password: str) -> Tuple[bool, Optional[User], List[str]]:
        """
        Authenticate a user.
        
        Args:
            username: Username.
            password: Password.
            
        Returns:
            Tuple of (success, user, error_messages).
        """
        # Check if username exists
        if username not in self.users:
            return False, None, ["Invalid username or password"]
        
        # Get user
        user = self.users[username]
        
        # Check if user is active
        if not user.is_active:
            return False, None, ["User is not active"]
        
        # Verify password
        if not self.password_hasher.verify_password(password, user.hashed_password):
            return False, None, ["Invalid username or password"]
        
        # Update last login
        user.last_login = datetime.now()
        self._save_users()
        
        return True, user, []
    
    def has_role(self, username: str, role: str) -> bool:
        """
        Check if a user has a role.
        
        Args:
            username: Username.
            role: Role to check.
            
        Returns:
            True if the user has the role, False otherwise.
        """
        user = self.get_user(username)
        if user is None:
            return False
        
        return role in user.roles
    
    @classmethod
    def from_config(cls) -> 'UserManager':
        """
        Create a user manager from configuration.
        
        Returns:
            UserManager instance.
        """
        return cls()


class TokenManager:
    """JWT token management."""
    
    def __init__(
        self,
        secret_key: Optional[str] = None,
        algorithm: str = "HS256",
        access_token_expires: int = 3600,  # 1 hour
        refresh_token_expires: int = 86400 * 7  # 7 days
    ):
        """
        Initialize token manager.
        
        Args:
            secret_key: Secret key for signing tokens. If None, uses the key from configuration.
            algorithm: Algorithm to use for signing tokens.
            access_token_expires: Access token expiration time in seconds.
            refresh_token_expires: Refresh token expiration time in seconds.
        """
        if secret_key is None:
            secret_key = get_config("app.security.jwt.secret_key")
            if secret_key is None:
                # Generate a random secret key
                secret_key = secrets.token_hex(32)
                logger.warning("No JWT secret key found in configuration, generated a random one")
        
        self.secret_key = secret_key
        self.algorithm = algorithm
        self.access_token_expires = access_token_expires
        self.refresh_token_expires = refresh_token_expires
    
    def create_access_token(self, data: Dict[str, Any]) -> str:
        """
        Create an access token.
        
        Args:
            data: Data to include in the token.
            
        Returns:
            Access token.
        """
        to_encode = data.copy()
        expire = datetime.utcnow() + timedelta(seconds=self.access_token_expires)
        to_encode.update({"exp": expire, "type": "access"})
        
        return jwt.encode(to_encode, self.secret_key, algorithm=self.algorithm)
    
    def create_refresh_token(self, data: Dict[str, Any]) -> str:
        """
        Create a refresh token.
        
        Args:
            data: Data to include in the token.
            
        Returns:
            Refresh token.
        """
        to_encode = data.copy()
        expire = datetime.utcnow() + timedelta(seconds=self.refresh_token_expires)
        to_encode.update({"exp": expire, "type": "refresh"})
        
        return jwt.encode(to_encode, self.secret_key, algorithm=self.algorithm)
    
    def decode_token(self, token: str) -> Dict[str, Any]:
        """
        Decode a token.
        
        Args:
            token: Token to decode.
            
        Returns:
            Decoded token data.
            
        Raises:
            jwt.PyJWTError: If the token is invalid.
        """
        return jwt.decode(token, self.secret_key, algorithms=[self.algorithm])
    
    def refresh_access_token(self, refresh_token: str) -> Tuple[bool, Optional[str], List[str]]:
        """
        Refresh an access token using a refresh token.
        
        Args:
            refresh_token: Refresh token.
            
        Returns:
            Tuple of (success, access_token, error_messages).
        """
        try:
            # Decode refresh token
            payload = self.decode_token(refresh_token)
            
            # Check token type
            if payload.get("type") != "refresh":
                return False, None, ["Invalid token type"]
            
            # Create new access token
            data = {k: v for k, v in payload.items() if k not in ["exp", "type"]}
            access_token = self.create_access_token(data)
            
            return True, access_token, []
        except jwt.PyJWTError as e:
            logger.error(f"Error refreshing access token: {e}")
            return False, None, ["Invalid refresh token"]
    
    @classmethod
    def from_config(cls) -> 'TokenManager':
        """
        Create a token manager from configuration.
        
        Returns:
            TokenManager instance.
        """
        return cls(
            secret_key=get_config("app.security.jwt.secret_key"),
            algorithm=get_config("app.security.jwt.algorithm", "HS256"),
            access_token_expires=get_config("app.security.jwt.access_token_expires", 3600),
            refresh_token_expires=get_config("app.security.jwt.refresh_token_expires", 86400 * 7)
        )


class Encryptor:
    """Data encryption and decryption."""
    
    def __init__(self, key: Optional[bytes] = None):
        """
        Initialize encryptor.
        
        Args:
            key: Encryption key. If None, generates a new key.
        """
        if key is None:
            # Generate a new key
            key = Fernet.generate_key()
        
        self.fernet = Fernet(key)
        self.key = key
    
    def encrypt(self, data: str) -> str:
        """
        Encrypt data.
        
        Args:
            data: Data to encrypt.
            
        Returns:
            Encrypted data as a base64-encoded string.
        """
        return self.fernet.encrypt(data.encode()).decode()
    
    def decrypt(self, encrypted_data: str) -> str:
        """
        Decrypt data.
        
        Args:
            encrypted_data: Encrypted data as a base64-encoded string.
            
        Returns:
            Decrypted data.
            
        Raises:
            cryptography.fernet.InvalidToken: If the token is invalid.
        """
        return self.fernet.decrypt(encrypted_data.encode()).decode()
    
    @classmethod
    def from_password(cls, password: str, salt: Optional[bytes] = None) -> 'Encryptor':
        """
        Create an encryptor from a password.
        
        Args:
            password: Password to derive key from.
            salt: Salt for key derivation. If None, generates a new salt.
            
        Returns:
            Encryptor instance.
        """
        if salt is None:
            # Generate a new salt
            salt = os.urandom(16)
        
        # Derive key from password
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=100000,
            backend=default_backend()
        )
        key = base64.urlsafe_b64encode(kdf.derive(password.encode()))
        
        return cls(key)
    
    @classmethod
    def from_config(cls) -> 'Encryptor':
        """
        Create an encryptor from configuration.
        
        Returns:
            Encryptor instance.
        """
        key_base64 = get_config("app.security.encryption.key")
        if key_base64:
            try:
                key = base64.urlsafe_b64decode(key_base64)
                return cls(key)
            except Exception as e:
                logger.error(f"Error decoding encryption key: {e}")
        
        # Generate a new key
        encryptor = cls()
        logger.warning("No encryption key found in configuration, generated a new one")
        
        return encryptor


def generate_api_key() -> str:
    """
    Generate a random API key.
    
    Returns:
        API key.
    """
    return f"opsc_{secrets.token_hex(16)}"


def generate_secure_password(length: int = 16) -> str:
    """
    Generate a secure random password.
    
    Args:
        length: Password length.
        
    Returns:
        Secure password.
    """
    # Ensure at least one of each character type
    chars = []
    chars.append(secrets.choice(string.ascii_uppercase))
    chars.append(secrets.choice(string.ascii_lowercase))
    chars.append(secrets.choice(string.digits))
    chars.append(secrets.choice(string.punctuation))
    
    # Fill the rest with random characters
    for _ in range(length - 4):
        chars.append(secrets.choice(
            string.ascii_uppercase +
            string.ascii_lowercase +
            string.digits +
            string.punctuation
        ))
    
    # Shuffle the characters
    secrets.SystemRandom().shuffle(chars)
    
    return ''.join(chars)


def generate_hmac(data: str, key: str, algorithm: str = 'sha256') -> str:
    """
    Generate an HMAC for data.
    
    Args:
        data: Data to sign.
        key: Key for signing.
        algorithm: Hash algorithm to use.
        
    Returns:
        HMAC as a hexadecimal string.
    """
    h = hmac.new(
        key.encode(),
        data.encode(),
        getattr(hashlib, algorithm)
    )
    return h.hexdigest()


def verify_hmac(data: str, signature: str, key: str, algorithm: str = 'sha256') -> bool:
    """
    Verify an HMAC for data.
    
    Args:
        data: Data to verify.
        signature: HMAC signature as a hexadecimal string.
        key: Key for verification.
        algorithm: Hash algorithm to use.
        
    Returns:
        True if the HMAC is valid, False otherwise.
    """
    expected = generate_hmac(data, key, algorithm)
    return hmac.compare_digest(signature, expected)


# Singleton instances
_user_manager: Optional[UserManager] = None
_token_manager: Optional[TokenManager] = None
_encryptor: Optional[Encryptor] = None


def get_user_manager() -> UserManager:
    """
    Get the singleton UserManager instance.
    
    Returns:
        UserManager instance.
    """
    global _user_manager
    if _user_manager is None:
        _user_manager = UserManager.from_config()
    return _user_manager


def get_token_manager() -> TokenManager:
    """
    Get the singleton TokenManager instance.
    
    Returns:
        TokenManager instance.
    """
    global _token_manager
    if _token_manager is None:
        _token_manager = TokenManager.from_config()
    return _token_manager


def get_encryptor() -> Encryptor:
    """
    Get the singleton Encryptor instance.
    
    Returns:
        Encryptor instance.
    """
    global _encryptor
    if _encryptor is None:
        _encryptor = Encryptor.from_config()
    return _encryptor


if __name__ == "__main__":
    # Setup logging for standalone execution
    logging.basicConfig(level=logging.INFO)
    
    # Example usage
    user_manager = get_user_manager()
    
    # Create a user
    success, user, errors = user_manager.create_user(
        username="admin",
        password=generate_secure_password(),
        email="admin@example.com",
        full_name="Admin User",
        roles=["admin"]
    )
    
    if success:
        logger.info(f"Created user: {user.username}")
    else:
        logger.error(f"Failed to create user: {errors}")
    
    # Create a token
    token_manager = get_token_manager()
    access_token = token_manager.create_access_token({"sub": "admin"})
    refresh_token = token_manager.create_refresh_token({"sub": "admin"})
    
    logger.info(f"Access token: {access_token}")
    logger.info(f"Refresh token: {refresh_token}")
    
    # Encrypt data
    encryptor = get_encryptor()
    encrypted = encryptor.encrypt("sensitive data")
    decrypted = encryptor.decrypt(encrypted)
    
    logger.info(f"Encrypted: {encrypted}")
    logger.info(f"Decrypted: {decrypted}")
