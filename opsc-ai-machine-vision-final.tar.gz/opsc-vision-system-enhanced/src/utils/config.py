"""
Configuration manager for the OPSC Sandwich Quality Inspection System.

This module provides utilities for loading and managing configuration files.

Version: 1.0.0
Last Updated: 2025-04-21
"""

import os
import sys
import yaml
import logging
from typing import Dict, Any, Optional

# Setup logging
logger = logging.getLogger(__name__)

class ConfigManager:
    """
    Configuration manager for the OPSC Sandwich Quality Inspection System.
    
    This class provides methods for loading and accessing configuration files.
    """
    
    def __init__(self, config_path: str):
        """
        Initialize the configuration manager.
        
        Args:
            config_path: Path to the main configuration file
        """
        self.config_path = config_path
        self.config = self._load_config(config_path)
    
    def _load_config(self, config_path: str) -> Dict[str, Any]:
        """
        Load configuration from YAML file.
        
        Args:
            config_path: Path to configuration file
        
        Returns:
            Configuration dictionary
        """
        try:
            # Check if file exists
            if not os.path.exists(config_path):
                logger.error(f"Configuration file not found: {config_path}")
                return {}
            
            # Load YAML file
            with open(config_path, 'r') as f:
                config = yaml.safe_load(f)
            
            logger.info(f"Loaded configuration from {config_path}")
            return config or {}
        except Exception as e:
            logger.error(f"Error loading configuration from {config_path}: {e}")
            return {}
    
    def get_config(self) -> Dict[str, Any]:
        """
        Get the loaded configuration.
        
        Returns:
            Configuration dictionary
        """
        return self.config
    
    def get_value(self, key: str, default: Any = None) -> Any:
        """
        Get a value from the configuration.
        
        Args:
            key: Configuration key (can use dot notation for nested keys)
            default: Default value if key is not found
        
        Returns:
            Configuration value or default
        """
        # Split key by dots
        keys = key.split('.')
        
        # Start with the full config
        value = self.config
        
        # Traverse the keys
        for k in keys:
            if isinstance(value, dict) and k in value:
                value = value[k]
            else:
                return default
        
        return value
    
    def load_sub_config(self, sub_config_path: str) -> Dict[str, Any]:
        """
        Load a sub-configuration file.
        
        Args:
            sub_config_path: Path to sub-configuration file (relative to main config directory)
        
        Returns:
            Sub-configuration dictionary
        """
        # Get directory of main config
        config_dir = os.path.dirname(os.path.abspath(self.config_path))
        
        # Build full path to sub-config
        full_path = os.path.join(config_dir, sub_config_path)
        
        # Load sub-config
        return self._load_config(full_path)


# Example usage
if __name__ == "__main__":
    # Setup logging
    logging.basicConfig(level=logging.INFO)
    
    # Create config manager
    config_manager = ConfigManager("config/app.yaml")
    
    # Get configuration
    config = config_manager.get_config()
    
    # Print configuration
    print(config)
    
    # Get specific value
    print(config_manager.get_value("database.path", "default/path.db"))
    
    # Load sub-config
    cameras_config = config_manager.load_sub_config("cameras.yaml")
    print(cameras_config)
