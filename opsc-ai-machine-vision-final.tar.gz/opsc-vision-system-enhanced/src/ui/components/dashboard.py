"""
Dashboard layout components for the Crustless Creations AI machine vision application.

This module provides layout components for creating responsive dashboards,
including cards, grids, and other layout elements.
"""

import streamlit as st
from typing import List, Dict, Any, Optional, Callable, Union, Tuple
import time

def card(
    title: Optional[str] = None,
    content: Optional[Callable] = None,
    footer: Optional[str] = None,
    key: Optional[str] = None,
    padding: int = 20,
    border_radius: int = 10,
    border_color: str = "#e6e6e6",
    background_color: str = "#ffffff",
    title_color: str = "#333333",
    footer_color: str = "#666666",
    elevation: int = 1,
    height: Optional[str] = None
) -> None:
    """
    Create a card component with title, content, and footer.
    
    Args:
        title: Optional title for the card
        content: Function that renders the card content
        footer: Optional footer text
        key: Unique key for the component
        padding: Padding inside the card in pixels
        border_radius: Border radius in pixels
        border_color: Border color in hex format
        background_color: Background color in hex format
        title_color: Title text color in hex format
        footer_color: Footer text color in hex format
        elevation: Shadow elevation (1-5)
        height: Optional fixed height for the card
    """
    # Generate a unique key if not provided
    if key is None:
        key = f"card_{int(time.time() * 1000)}"
    
    # Calculate shadow based on elevation
    shadow = f"0 {elevation}px {elevation * 2}px rgba(0,0,0,{0.1 + elevation * 0.05})"
    
    # Create the card container
    card_style = f"""
        padding: {padding}px;
        border-radius: {border_radius}px;
        border: 1px solid {border_color};
        background-color: {background_color};
        box-shadow: {shadow};
        margin-bottom: 20px;
    """
    
    if height:
        card_style += f"height: {height};"
    
    with st.container():
        # Apply card styling
        st.markdown(f'<div style="{card_style}" id="{key}">', unsafe_allow_html=True)
        
        # Render title if provided
        if title:
            st.markdown(
                f'<h3 style="margin-top: 0; color: {title_color};">{title}</h3>',
                unsafe_allow_html=True
            )
        
        # Render content if provided
        if content:
            content()
        
        # Render footer if provided
        if footer:
            st.markdown(
                f'<div style="margin-top: 15px; font-size: 0.8em; color: {footer_color};">{footer}</div>',
                unsafe_allow_html=True
            )
        
        # Close the card div
        st.markdown('</div>', unsafe_allow_html=True)

def metric_card(
    title: str,
    value: Union[str, int, float],
    delta: Optional[Union[str, int, float]] = None,
    delta_color: str = "normal",
    prefix: str = "",
    suffix: str = "",
    key: Optional[str] = None,
    help_text: Optional[str] = None
) -> None:
    """
    Create a card displaying a metric with optional delta.
    
    Args:
        title: Title for the metric
        value: Current value of the metric
        delta: Optional delta (change) value
        delta_color: Color for delta ('normal', 'inverse', 'off')
        prefix: Prefix for the value (e.g., "$")
        suffix: Suffix for the value (e.g., "%")
        key: Unique key for the component
        help_text: Optional help text to display on hover
    """
    def content():
        st.metric(
            label="",  # We already show the title in the card
            value=f"{prefix}{value}{suffix}",
            delta=f"{prefix}{delta}{suffix}" if delta is not None else None,
            delta_color=delta_color,
            help=help_text
        )
    
    card(title=title, content=content, key=key, padding=15)

def info_card(
    title: str,
    text: str,
    icon: Optional[str] = None,
    key: Optional[str] = None
) -> None:
    """
    Create a card displaying informational text with an optional icon.
    
    Args:
        title: Title for the card
        text: Text content to display
        icon: Optional icon name from streamlit's icon set
        key: Unique key for the component
    """
    def content():
        if icon:
            st.markdown(f":{icon}: {text}")
        else:
            st.markdown(text)
    
    card(title=title, content=content, key=key)

def chart_card(
    title: str,
    chart_function: Callable,
    footer: Optional[str] = None,
    key: Optional[str] = None,
    height: Optional[str] = None
) -> None:
    """
    Create a card containing a chart.
    
    Args:
        title: Title for the card
        chart_function: Function that renders the chart
        footer: Optional footer text (e.g., data source)
        key: Unique key for the component
        height: Optional fixed height for the card
    """
    card(
        title=title,
        content=chart_function,
        footer=footer,
        key=key,
        height=height
    )

def image_card(
    title: str,
    image_path: str,
    caption: Optional[str] = None,
    key: Optional[str] = None,
    use_column_width: bool = True
) -> None:
    """
    Create a card displaying an image.
    
    Args:
        title: Title for the card
        image_path: Path or URL to the image
        caption: Optional caption for the image
        key: Unique key for the component
        use_column_width: Whether to expand image to column width
    """
    def content():
        st.image(
            image_path,
            caption=caption,
            use_column_width=use_column_width
        )
    
    card(title=title, content=content, key=key)

def action_card(
    title: str,
    description: str,
    button_text: str,
    on_click: Callable,
    icon: Optional[str] = None,
    key: Optional[str] = None
) -> None:
    """
    Create a card with a description and action button.
    
    Args:
        title: Title for the card
        description: Description text
        button_text: Text for the action button
        on_click: Function to call when button is clicked
        icon: Optional icon name from streamlit's icon set
        key: Unique key for the component
    """
    def content():
        st.markdown(description)
        if icon:
            button_label = f":{icon}: {button_text}"
        else:
            button_label = button_text
        
        st.button(button_label, on_click=on_click, key=f"{key}_button" if key else None)
    
    card(title=title, content=content, key=key)

def status_card(
    title: str,
    status: str,
    description: str,
    key: Optional[str] = None
) -> None:
    """
    Create a card displaying a status with color coding.
    
    Args:
        title: Title for the card
        status: Status text ("success", "warning", "error", "info")
        description: Description text
        key: Unique key for the component
    """
    # Map status to colors
    status_colors = {
        "success": "#28a745",
        "warning": "#ffc107",
        "error": "#dc3545",
        "info": "#17a2b8"
    }
    
    color = status_colors.get(status.lower(), "#6c757d")
    
    def content():
        st.markdown(
            f'<div style="color: {color}; font-weight: bold; margin-bottom: 10px;">{status.upper()}</div>',
            unsafe_allow_html=True
        )
        st.markdown(description)
    
    card(title=title, content=content, key=key)

def grid_dashboard(
    num_columns: int = 2,
    column_widths: Optional[List[int]] = None
) -> List[st.container]:
    """
    Create a grid layout for a dashboard.
    
    Args:
        num_columns: Number of columns in the grid
        column_widths: Optional list of relative column widths
        
    Returns:
        List of column containers
    """
    if column_widths is None:
        # Equal width columns
        column_widths = [1] * num_columns
    
    # Ensure we have the right number of widths
    if len(column_widths) != num_columns:
        column_widths = [1] * num_columns
    
    # Create columns
    return st.columns(column_widths)

def tabbed_interface(tabs: Dict[str, Callable]) -> None:
    """
    Create a tabbed interface.
    
    Args:
        tabs: Dictionary mapping tab names to content functions
    """
    tab_list = st.tabs(list(tabs.keys()))
    
    for i, (tab_name, content_func) in enumerate(tabs.items()):
        with tab_list[i]:
            content_func()

def collapsible_section(
    title: str,
    content: Callable,
    default_open: bool = False,
    icon: Optional[str] = None
) -> None:
    """
    Create a collapsible section.
    
    Args:
        title: Title for the section
        content: Function that renders the section content
        default_open: Whether the section is open by default
        icon: Optional icon name from streamlit's icon set
    """
    if icon:
        expander = st.expander(f":{icon}: {title}", expanded=default_open)
    else:
        expander = st.expander(title, expanded=default_open)
    
    with expander:
        content()

def responsive_grid(
    items: List[Callable],
    num_columns: Dict[str, int] = {"large": 3, "medium": 2, "small": 1},
    gap: str = "20px"
) -> None:
    """
    Create a responsive grid layout that adjusts based on screen size.
    
    Args:
        items: List of functions that render grid items
        num_columns: Dictionary with number of columns for different screen sizes
        gap: Gap between grid items
    """
    # Create CSS for responsive grid
    css = f"""
    <style>
        .responsive-grid {{
            display: grid;
            grid-template-columns: repeat({num_columns["large"]}, 1fr);
            gap: {gap};
            margin-bottom: 20px;
        }}
        
        /* Medium screens */
        @media (max-width: 1200px) {{
            .responsive-grid {{
                grid-template-columns: repeat({num_columns["medium"]}, 1fr);
            }}
        }}
        
        /* Small screens */
        @media (max-width: 768px) {{
            .responsive-grid {{
                grid-template-columns: repeat({num_columns["small"]}, 1fr);
            }}
        }}
    </style>
    """
    
    st.markdown(css, unsafe_allow_html=True)
    
    # Start grid container
    st.markdown('<div class="responsive-grid">', unsafe_allow_html=True)
    
    # Add each item in a separate container
    for i, item_func in enumerate(items):
        st.markdown(f'<div class="grid-item" id="grid-item-{i}">', unsafe_allow_html=True)
        item_func()
        st.markdown('</div>', unsafe_allow_html=True)
    
    # Close grid container
    st.markdown('</div>', unsafe_allow_html=True)

def dashboard_header(
    title: str,
    subtitle: Optional[str] = None,
    date_range: Optional[Tuple[str, str]] = None,
    actions: Optional[List[Tuple[str, Callable]]] = None
) -> None:
    """
    Create a dashboard header with title, subtitle, date range, and actions.
    
    Args:
        title: Dashboard title
        subtitle: Optional subtitle
        date_range: Optional tuple of (start_date, end_date) strings
        actions: Optional list of (button_text, on_click_function) tuples
    """
    col1, col2 = st.columns([7, 3])
    
    with col1:
        st.title(title)
        if subtitle:
            st.markdown(f"<p style='font-size: 1.2em; margin-top: -15px;'>{subtitle}</p>", unsafe_allow_html=True)
        
        if date_range:
            start_date, end_date = date_range
            st.markdown(f"<p style='color: #666;'>Period: {start_date} to {end_date}</p>", unsafe_allow_html=True)
    
    with col2:
        if actions:
            for button_text, on_click in actions:
                st.button(button_text, on_click=on_click, use_container_width=True)

def demo_dashboard_components() -> None:
    """
    Demonstrate all dashboard components with sample data.
    """
    st.title("Dashboard Components Demo")
    
    # Demo dashboard header
    dashboard_header(
        "Production Dashboard",
        "Crustless Creations Quality Control",
        ("April 1, 2025", "April 20, 2025"),
        [("Refresh", lambda: None), ("Export", lambda: None)]
    )
    
    st.markdown("## Card Components")
    
    # Basic card
    col1, col2 = grid_dashboard(2)
    
    with col1:
        def basic_card_content():
            st.write("This is a basic card with title and content.")
            st.write("Cards can contain any Streamlit elements.")
        
        card(
            title="Basic Card",
            content=basic_card_content,
            footer="Last updated: April 20, 2025"
        )
    
    with col2:
        # Metric card
        metric_card(
            title="Daily Production",
            value=1234,
            delta=56,
            suffix=" units"
        )
    
    # Info cards
    cols = grid_dashboard(3)
    
    with cols[0]:
        info_card(
            title="System Status",
            text="All systems operational",
            icon="check_circle"
        )
    
    with cols[1]:
        info_card(
            title="Maintenance",
            text="Next scheduled: April 25, 2025",
            icon="wrench"
        )
    
    with cols[2]:
        info_card(
            title="Alerts",
            text="No active alerts",
            icon="bell"
        )
    
    # Chart card
    def sample_chart():
        import numpy as np
        import pandas as pd
        
        # Generate sample data
        dates = pd.date_range(start='2025-04-01', end='2025-04-20')
        values = np.cumsum(np.random.randn(len(dates)))
        
        df = pd.DataFrame({
            'Date': dates,
            'Value': values
        })
        
        st.line_chart(df.set_index('Date'))
    
    chart_card(
        title="Production Trend",
        chart_function=sample_chart,
        footer="Source: Production Database",
        height="300px"
    )
    
    # Status cards
    cols = grid_dashboard(2)
    
    with cols[0]:
        status_card(
            title="Host System",
            status="success",
            description="All components running normally. CPU usage at 45%, memory at 60%."
        )
    
    with cols[1]:
        status_card(
            title="ADLINK Jetson",
            status="warning",
            description="High temperature detected (85°C). Consider checking cooling system."
        )
    
    # Action card
    def action_function():
        st.session_state.action_clicked = True
    
    action_card(
        title="System Maintenance",
        description="Run system diagnostics to check for potential issues.",
        button_text="Run Diagnostics",
        on_click=action_function,
        icon="gear"
    )
    
    if "action_clicked" in st.session_state and st.session_state.action_clicked:
        st.success("Diagnostics started!")
        st.session_state.action_clicked = False
    
    # Tabbed interface
    st.markdown("## Tabbed Interface")
    
    def tab1_content():
        st.write("This is the content of Tab 1")
        st.slider("Sample slider", 0, 100, 50)
    
    def tab2_content():
        st.write("This is the content of Tab 2")
        st.button("Sample button")
    
    def tab3_content():
        st.write("This is the content of Tab 3")
        st.checkbox("Sample checkbox")
    
    tabbed_interface({
        "Tab 1": tab1_content,
        "Tab 2": tab2_content,
        "Tab 3": tab3_content
    })
    
    # Collapsible section
    st.markdown("## Collapsible Sections")
    
    def section_content():
        st.write("This is collapsible content that can be expanded or collapsed.")
        st.write("Useful for detailed information that doesn't need to be visible all the time.")
    
    collapsible_section(
        title="Detailed Information",
        content=section_content,
        default_open=True,
        icon="info"
    )
    
    # Responsive grid
    st.markdown("## Responsive Grid")
    
    def grid_item(index):
        def content():
            st.write(f"Grid Item {index}")
            st.slider(f"Value {index}", 0, 100, 50, key=f"slider_{index}")
        
        card(
            title=f"Item {index}",
            content=content
        )
    
    # Create 6 grid items
    grid_items = [lambda i=i: grid_item(i) for i in range(1, 7)]
    
    responsive_grid(
        items=grid_items,
        num_columns={"large": 3, "medium": 2, "small": 1}
    )

if __name__ == "__main__":
    # This will run when the script is executed directly
    st.set_page_config(
        page_title="Dashboard Components Demo",
        page_icon="📊",
        layout="wide"
    )
    demo_dashboard_components()
