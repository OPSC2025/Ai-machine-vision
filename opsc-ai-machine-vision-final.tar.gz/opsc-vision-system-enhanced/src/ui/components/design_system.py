"""
Modern design framework for the OPSC Sandwich Quality Inspection System.

This module provides a comprehensive design system with consistent styling,
color schemes, typography, and component styling to create a modern and
professional user interface.
"""

import streamlit as st
from typing import Dict, List, Optional, Callable, Union, Tuple, Any
import time
import base64
import os

# Define the design system constants
# Color palette
COLORS = {
    # Primary colors
    "primary": {
        "main": "#1565C0",  # Deep blue
        "light": "#1E88E5",
        "dark": "#0D47A1",
        "contrast": "#FFFFFF"
    },
    # Secondary colors
    "secondary": {
        "main": "#00796B",  # Teal
        "light": "#009688",
        "dark": "#00695C",
        "contrast": "#FFFFFF"
    },
    # Accent colors
    "accent": {
        "main": "#FF6D00",  # Orange
        "light": "#FF9E40",
        "dark": "#E65100",
        "contrast": "#FFFFFF"
    },
    # Semantic colors
    "success": {
        "main": "#2E7D32",  # Green
        "light": "#4CAF50",
        "dark": "#1B5E20",
        "contrast": "#FFFFFF"
    },
    "warning": {
        "main": "#F57F17",  # Amber
        "light": "#FFC107",
        "dark": "#FF8F00",
        "contrast": "#000000"
    },
    "error": {
        "main": "#C62828",  # Red
        "light": "#EF5350",
        "dark": "#B71C1C",
        "contrast": "#FFFFFF"
    },
    "info": {
        "main": "#0277BD",  # Light Blue
        "light": "#03A9F4",
        "dark": "#01579B",
        "contrast": "#FFFFFF"
    },
    # Neutral colors
    "neutral": {
        "main": "#616161",  # Gray
        "light": "#9E9E9E",
        "dark": "#424242",
        "contrast": "#FFFFFF",
        "background": "#F5F5F5",
        "paper": "#FFFFFF",
        "border": "#E0E0E0"
    }
}

# Typography
TYPOGRAPHY = {
    "h1": {
        "font-family": "'Roboto', sans-serif",
        "font-weight": "300",
        "font-size": "2.5rem",
        "line-height": "1.2",
        "letter-spacing": "-0.01562em",
        "margin-top": "0.5rem",
        "margin-bottom": "0.5rem"
    },
    "h2": {
        "font-family": "'Roboto', sans-serif",
        "font-weight": "400",
        "font-size": "2rem",
        "line-height": "1.2",
        "letter-spacing": "-0.00833em",
        "margin-top": "0.5rem",
        "margin-bottom": "0.5rem"
    },
    "h3": {
        "font-family": "'Roboto', sans-serif",
        "font-weight": "500",
        "font-size": "1.5rem",
        "line-height": "1.2",
        "letter-spacing": "0em",
        "margin-top": "0.5rem",
        "margin-bottom": "0.5rem"
    },
    "h4": {
        "font-family": "'Roboto', sans-serif",
        "font-weight": "500",
        "font-size": "1.25rem",
        "line-height": "1.2",
        "letter-spacing": "0.00735em",
        "margin-top": "0.5rem",
        "margin-bottom": "0.5rem"
    },
    "h5": {
        "font-family": "'Roboto', sans-serif",
        "font-weight": "500",
        "font-size": "1.1rem",
        "line-height": "1.2",
        "letter-spacing": "0em",
        "margin-top": "0.5rem",
        "margin-bottom": "0.5rem"
    },
    "h6": {
        "font-family": "'Roboto', sans-serif",
        "font-weight": "500",
        "font-size": "1rem",
        "line-height": "1.2",
        "letter-spacing": "0.0075em",
        "margin-top": "0.5rem",
        "margin-bottom": "0.5rem"
    },
    "body1": {
        "font-family": "'Roboto', sans-serif",
        "font-weight": "400",
        "font-size": "1rem",
        "line-height": "1.5",
        "letter-spacing": "0.00938em"
    },
    "body2": {
        "font-family": "'Roboto', sans-serif",
        "font-weight": "400",
        "font-size": "0.875rem",
        "line-height": "1.43",
        "letter-spacing": "0.01071em"
    },
    "caption": {
        "font-family": "'Roboto', sans-serif",
        "font-weight": "400",
        "font-size": "0.75rem",
        "line-height": "1.66",
        "letter-spacing": "0.03333em"
    },
    "button": {
        "font-family": "'Roboto', sans-serif",
        "font-weight": "500",
        "font-size": "0.875rem",
        "line-height": "1.75",
        "letter-spacing": "0.02857em",
        "text-transform": "uppercase"
    }
}

# Spacing system (in pixels)
SPACING = {
    "xs": "4px",
    "sm": "8px",
    "md": "16px",
    "lg": "24px",
    "xl": "32px",
    "xxl": "48px"
}

# Shadows
SHADOWS = {
    "none": "none",
    "sm": "0 1px 2px 0 rgba(0, 0, 0, 0.05)",
    "md": "0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)",
    "lg": "0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)",
    "xl": "0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)"
}

# Border radius
BORDER_RADIUS = {
    "none": "0",
    "sm": "0.125rem",
    "md": "0.25rem",
    "lg": "0.5rem",
    "xl": "1rem",
    "full": "9999px"
}

# Transitions
TRANSITIONS = {
    "fast": "all 0.1s ease",
    "normal": "all 0.2s ease",
    "slow": "all 0.3s ease"
}

# Breakpoints for responsive design
BREAKPOINTS = {
    "xs": "0px",
    "sm": "600px",
    "md": "960px",
    "lg": "1280px",
    "xl": "1920px"
}

def load_design_system():
    """
    Load the design system CSS and JavaScript into the Streamlit app.
    This should be called at the beginning of the app.
    """
    # Load Google Fonts
    st.markdown(
        """
        <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        """,
        unsafe_allow_html=True
    )
    
    # Generate CSS variables from the design system
    css_variables = ":root {\n"
    
    # Add colors
    for color_type, color_values in COLORS.items():
        if isinstance(color_values, dict):
            for shade, value in color_values.items():
                css_variables += f"  --color-{color_type}-{shade}: {value};\n"
        else:
            css_variables += f"  --color-{color_type}: {color_values};\n"
    
    # Add spacing
    for size, value in SPACING.items():
        css_variables += f"  --spacing-{size}: {value};\n"
    
    # Add shadows
    for size, value in SHADOWS.items():
        css_variables += f"  --shadow-{size}: {value};\n"
    
    # Add border radius
    for size, value in BORDER_RADIUS.items():
        css_variables += f"  --radius-{size}: {value};\n"
    
    # Add transitions
    for speed, value in TRANSITIONS.items():
        css_variables += f"  --transition-{speed}: {value};\n"
    
    # Add breakpoints
    for size, value in BREAKPOINTS.items():
        css_variables += f"  --breakpoint-{size}: {value};\n"
    
    css_variables += "}\n"
    
    # Base styles
    base_styles = """
    body {
        font-family: 'Roboto', sans-serif;
        color: var(--color-neutral-dark);
        background-color: var(--color-neutral-background);
        margin: 0;
        padding: 0;
    }
    
    /* Override Streamlit's default styles */
    .stApp {
        background-color: var(--color-neutral-background);
    }
    
    /* Streamlit sidebar */
    .css-1d391kg, .css-12oz5g7 {
        background-color: var(--color-neutral-paper);
    }
    
    /* Streamlit buttons */
    .stButton > button {
        background-color: var(--color-primary-main);
        color: var(--color-primary-contrast);
        border: none;
        border-radius: var(--radius-md);
        padding: 0.5rem 1rem;
        font-weight: 500;
        transition: var(--transition-normal);
    }
    
    .stButton > button:hover {
        background-color: var(--color-primary-dark);
        box-shadow: var(--shadow-md);
    }
    
    /* Streamlit metrics */
    .stMetric {
        background-color: var(--color-neutral-paper);
        border-radius: var(--radius-md);
        padding: var(--spacing-md);
        box-shadow: var(--shadow-sm);
    }
    
    /* Streamlit dataframes */
    .stDataFrame {
        border-radius: var(--radius-md);
        overflow: hidden;
    }
    
    /* Streamlit tabs */
    .stTabs [data-baseweb="tab-list"] {
        gap: 1px;
    }
    
    .stTabs [data-baseweb="tab"] {
        height: 50px;
        white-space: pre-wrap;
        background-color: var(--color-neutral-paper);
        border-radius: var(--radius-md) var(--radius-md) 0 0;
        gap: 1px;
    }
    
    .stTabs [aria-selected="true"] {
        background-color: var(--color-primary-main);
        color: var(--color-primary-contrast);
    }
    
    /* Custom card class */
    .modern-card {
        background-color: var(--color-neutral-paper);
        border-radius: var(--radius-md);
        padding: var(--spacing-md);
        box-shadow: var(--shadow-md);
        margin-bottom: var(--spacing-md);
        transition: var(--transition-normal);
    }
    
    .modern-card:hover {
        box-shadow: var(--shadow-lg);
        transform: translateY(-2px);
    }
    
    /* Custom status indicators */
    .status-indicator {
        display: inline-block;
        width: 12px;
        height: 12px;
        border-radius: 50%;
        margin-right: 8px;
    }
    
    .status-success {
        background-color: var(--color-success-main);
    }
    
    .status-warning {
        background-color: var(--color-warning-main);
    }
    
    .status-error {
        background-color: var(--color-error-main);
    }
    
    .status-info {
        background-color: var(--color-info-main);
    }
    
    /* Typography classes */
    .typography-h1, .typography-h2, .typography-h3, 
    .typography-h4, .typography-h5, .typography-h6,
    .typography-body1, .typography-body2, 
    .typography-caption, .typography-button {
        margin: 0;
    }
    """
    
    # Generate typography classes
    typography_styles = ""
    for tag, styles in TYPOGRAPHY.items():
        typography_styles += f".typography-{tag} {{\n"
        for prop, value in styles.items():
            typography_styles += f"  {prop}: {value};\n"
        typography_styles += "}\n"
    
    # Combine all styles
    all_styles = css_variables + base_styles + typography_styles
    
    # Apply styles
    st.markdown(f"<style>{all_styles}</style>", unsafe_allow_html=True)

def apply_theme(theme="light"):
    """
    Apply a specific theme to the application.
    
    Args:
        theme: The theme to apply ("light" or "dark")
    """
    if theme == "dark":
        # Override colors for dark theme
        dark_theme_css = """
        <style>
        :root {
            --color-neutral-background: #121212;
            --color-neutral-paper: #1E1E1E;
            --color-neutral-dark: #E0E0E0;
            --color-neutral-light: #757575;
            --color-neutral-border: #333333;
        }
        
        body {
            color: var(--color-neutral-dark);
            background-color: var(--color-neutral-background);
        }
        
        .stApp {
            background-color: var(--color-neutral-background);
        }
        
        /* Streamlit sidebar */
        .css-1d391kg, .css-12oz5g7 {
            background-color: var(--color-neutral-paper);
        }
        
        /* Streamlit widgets */
        .stTextInput > div > div {
            background-color: var(--color-neutral-paper);
            color: var(--color-neutral-dark);
        }
        
        .stSelectbox > div > div {
            background-color: var(--color-neutral-paper);
            color: var(--color-neutral-dark);
        }
        </style>
        """
        st.markdown(dark_theme_css, unsafe_allow_html=True)

def styled_container(
    content_func: Callable,
    background_color: Optional[str] = None,
    border_radius: Optional[str] = None,
    padding: Optional[str] = None,
    margin: Optional[str] = None,
    shadow: Optional[str] = None,
    border: Optional[str] = None,
    width: Optional[str] = None,
    height: Optional[str] = None,
    hover_effect: bool = False,
    key: Optional[str] = None
):
    """
    Create a styled container with custom CSS properties.
    
    Args:
        content_func: Function that renders the container content
        background_color: Background color of the container
        border_radius: Border radius of the container
        padding: Padding inside the container
        margin: Margin around the container
        shadow: Box shadow for the container
        border: Border style for the container
        width: Width of the container
        height: Height of the container
        hover_effect: Whether to apply a hover effect
        key: Unique key for the component
    """
    # Generate a unique key if not provided
    if key is None:
        key = f"container_{int(time.time() * 1000)}"
    
    # Build the style string
    style = ""
    if background_color:
        style += f"background-color: {background_color};"
    if border_radius:
        style += f"border-radius: {border_radius};"
    if padding:
        style += f"padding: {padding};"
    if margin:
        style += f"margin: {margin};"
    if shadow:
        style += f"box-shadow: {shadow};"
    if border:
        style += f"border: {border};"
    if width:
        style += f"width: {width};"
    if height:
        style += f"height: {height};"
    
    # Add hover effect if requested
    hover_style = ""
    if hover_effect:
        hover_style = f"""
        <style>
        .container-{key}:hover {{
            box-shadow: var(--shadow-lg);
            transform: translateY(-2px);
        }}
        </style>
        """
    
    # Create the container
    st.markdown(
        f"""
        <div class="container-{key}" style="{style}">
        {hover_style}
        """,
        unsafe_allow_html=True
    )
    
    # Render the content
    content_func()
    
    # Close the container
    st.markdown("</div>", unsafe_allow_html=True)

def modern_card(
    title: Optional[str] = None,
    content: Optional[Callable] = None,
    footer: Optional[str] = None,
    icon: Optional[str] = None,
    color: str = "primary",
    elevation: int = 1,
    border: bool = False,
    hover_effect: bool = True,
    key: Optional[str] = None
):
    """
    Create a modern card component with title, content, and footer.
    
    Args:
        title: Optional title for the card
        content: Function that renders the card content
        footer: Optional footer text
        icon: Optional Material icon name
        color: Color theme for the card ("primary", "secondary", "accent", etc.)
        elevation: Shadow elevation (1-5)
        border: Whether to show a border
        hover_effect: Whether to apply a hover effect
        key: Unique key for the component
    """
    # Generate a unique key if not provided
    if key is None:
        key = f"card_{int(time.time() * 1000)}"
    
    # Calculate shadow based on elevation
    shadow = SHADOWS.get(f"{'none' if elevation == 0 else 'sm' if elevation == 1 else 'md' if elevation == 2 else 'lg' if elevation == 3 else 'xl'}")
    
    # Get color from theme
    color_value = COLORS.get(color, COLORS["primary"])
    if isinstance(color_value, dict):
        color_value = color_value["main"]
    
    # Create the card container
    card_style = f"""
        background-color: var(--color-neutral-paper);
        border-radius: var(--radius-md);
        padding: var(--spacing-md);
        box-shadow: {shadow};
        margin-bottom: var(--spacing-md);
        transition: var(--transition-normal);
        overflow: hidden;
    """
    
    if border:
        card_style += f"border: 1px solid var(--color-neutral-border);"
    
    # Add hover effect
    hover_style = ""
    if hover_effect:
        hover_style = f"""
        <style>
        .card-{key}:hover {{
            box-shadow: var(--shadow-lg);
            transform: translateY(-2px);
        }}
        </style>
        """
    
    # Start the card
    st.markdown(
        f"""
        <div class="card-{key}" style="{card_style}">
        {hover_style}
        """,
        unsafe_allow_html=True
    )
    
    # Render title if provided
    if title:
        title_style = f"""
            margin-top: 0;
            margin-bottom: var(--spacing-md);
            color: var(--color-{color}-main);
            font-size: 1.25rem;
            font-weight: 500;
            display: flex;
            align-items: center;
        """
        
        icon_html = f'<i class="material-icons" style="margin-right: 8px;">{icon}</i>' if icon else ""
        
        st.markdown(
            f'<h3 style="{title_style}">{icon_html}{title}</h3>',
            unsafe_allow_html=True
        )
    
    # Render content if provided
    if content:
        content()
    
    # Render footer if provided
    if footer:
        footer_style = f"""
            margin-top: var(--spacing-md);
            padding-top: var(--spacing-sm);
            border-top: 1px solid var(--color-neutral-border);
            font-size: 0.875rem;
            color: var(--color-neutral-light);
        """
        
        st.markdown(
            f'<div style="{footer_style}">{footer}</div>',
            unsafe_allow_html=True
        )
    
    # Close the card
    st.markdown("</div>", unsafe_allow_html=True)

def styled_metric(
    label: str,
    value: Union[str, int, float],
    delta: Optional[Union[str, int, float]] = None,
    delta_color: str = "normal",
    prefix: str = "",
    suffix: str = "",
    color: str = "primary",
    icon: Optional[str] = None,
    help_text: Optional[str] = None,
    key: Optional[str] = None
):
    """
    Create a styled metric component with modern design.
    
    Args:
        label: Label for the metric
        value: Current value of the metric
        delta: Optional delta (change) value
        delta_color: Color for delta ('normal', 'inverse', 'off')
        prefix: Prefix for the value (e.g., "$")
        suffix: Suffix for the value (e.g., "%")
        color: Color theme for the metric
        icon: Optional Material icon name
        help_text: Optional help text to display on hover
        key: Unique key for the component
    """
    # Generate a unique key if not provided
    if key is None:
        key = f"metric_{int(time.time() * 1000)}"
    
    # Get color from theme
    color_value = COLORS.get(color, COLORS["primary"])
    if isinstance(color_value, dict):
        color_value = color_value["main"]
    
    # Determine delta color
    delta_style = ""
    if delta is not None:
        if delta_color == "normal":
            delta_style = "color: var(--color-success-main);" if float(str(delta).replace('%', '')) >= 0 else "color: var(--color-error-main);"
        elif delta_color == "inverse":
            delta_style = "color: var(--color-error-main);" if float(str(delta).replace('%', '')) >= 0 else "color: var(--color-success-main);"
        else:
            delta_style = f"color: var(--color-{color}-main);"
    
    # Create the metric container
    metric_style = f"""
        background-color: var(--color-neutral-paper);
        border-radius: var(--radius-md);
        padding: var(--spacing-md);
        box-shadow: var(--shadow-sm);
        margin-bottom: var(--spacing-md);
        transition: var(--transition-normal);
    """
    
    # Add hover effect
    hover_style = f"""
    <style>
    .metric-{key}:hover {{
        box-shadow: var(--shadow-md);
    }}
    </style>
    """
    
    # Format the value and delta
    formatted_value = f"{prefix}{value}{suffix}"
    
    delta_html = ""
    if delta is not None:
        delta_prefix = "+" if float(str(delta).replace('%', '')) > 0 else ""
        formatted_delta = f"{delta_prefix}{delta}{suffix}"
        delta_html = f'<div style="{delta_style} font-size: 0.875rem;">{formatted_delta}</div>'
    
    # Create icon HTML if provided
    icon_html = f'<i class="material-icons" style="margin-right: 8px; color: var(--color-{color}-main);">{icon}</i>' if icon else ""
    
    # Create help text HTML if provided
    help_html = f'title="{help_text}"' if help_text else ""
    
    # Render the metric
    st.markdown(
        f"""
        {hover_style}
        <div class="metric-{key}" style="{metric_style}" {help_html}>
            <div style="display: flex; align-items: center; margin-bottom: 4px;">
                {icon_html}
                <div style="color: var(--color-neutral-light); font-size: 0.875rem;">{label}</div>
            </div>
            <div style="font-size: 1.5rem; font-weight: 500; color: var(--color-{color}-main);">{formatted_value}</div>
            {delta_html}
        </div>
        """,
        unsafe_allow_html=True
    )

def styled_button(
    label: str,
    on_click: Optional[Callable] = None,
    args: Optional[Tuple] = None,
    kwargs: Optional[Dict] = None,
    color: str = "primary",
    variant: str = "filled",
    size: str = "medium",
    icon: Optional[str] = None,
    full_width: bool = False,
    disabled: bool = False,
    key: Optional[str] = None
):
    """
    Create a styled button with modern design.
    
    Args:
        label: Button text
        on_click: Function to call when button is clicked
        args: Arguments to pass to on_click
        kwargs: Keyword arguments to pass to on_click
        color: Color theme for the button
        variant: Button variant ("filled", "outlined", "text")
        size: Button size ("small", "medium", "large")
        icon: Optional Material icon name
        full_width: Whether the button should take full width
        disabled: Whether the button is disabled
        key: Unique key for the component
    """
    # Add icon if provided
    if icon:
        label = f":{icon}: {label}"
    
    # Set button style based on variant and size
    if variant == "filled":
        button_type = "primary"
    elif variant == "outlined":
        button_type = "secondary"
    else:  # text
        button_type = ""
    
    # Set button size
    if size == "small":
        use_small = True
    elif size == "large":
        use_small = False
    else:  # medium
        use_small = False
    
    # Create the button
    return st.button(
        label,
        on_click=on_click,
        args=args or (),
        kwargs=kwargs or {},
        type=button_type,
        disabled=disabled,
        use_container_width=full_width,
        key=key
    )

def styled_tabs(
    tabs: Dict[str, Callable],
    color: str = "primary",
    key: Optional[str] = None
):
    """
    Create styled tabs with modern design.
    
    Args:
        tabs: Dictionary mapping tab names to content functions
        color: Color theme for the tabs
        key: Unique key for the component
    """
    # Generate a unique key if not provided
    if key is None:
        key = f"tabs_{int(time.time() * 1000)}"
    
    # Create custom CSS for tabs
    tabs_css = f"""
    <style>
    [data-testid="stHorizontalBlock"] > div:has([role="tab"]) {{
        background-color: var(--color-neutral-paper);
        border-radius: var(--radius-md) var(--radius-md) 0 0;
        padding-top: var(--spacing-xs);
    }}
    
    [data-testid="stHorizontalBlock"] [role="tab"] {{
        background-color: transparent;
        color: var(--color-neutral-dark);
        border-radius: var(--radius-md) var(--radius-md) 0 0;
        padding: var(--spacing-sm) var(--spacing-md);
        font-weight: 500;
    }}
    
    [data-testid="stHorizontalBlock"] [role="tab"][aria-selected="true"] {{
        background-color: var(--color-{color}-main);
        color: var(--color-{color}-contrast);
    }}
    
    [data-testid="stHorizontalBlock"] [role="tabpanel"] {{
        background-color: var(--color-neutral-paper);
        border-radius: 0 0 var(--radius-md) var(--radius-md);
        padding: var(--spacing-md);
        box-shadow: var(--shadow-sm);
    }}
    </style>
    """
    
    st.markdown(tabs_css, unsafe_allow_html=True)
    
    # Create the tabs
    tab_list = st.tabs(list(tabs.keys()))
    
    # Render content for each tab
    for i, (tab_name, content_func) in enumerate(tabs.items()):
        with tab_list[i]:
            content_func()

def styled_status_indicator(
    status: str,
    label: str,
    tooltip: Optional[str] = None,
    size: int = 12,
    key: Optional[str] = None
):
    """
    Display a styled status indicator with a label.
    
    Args:
        status: The status type ("success", "warning", "error", "info", "offline")
        label: The label text to display next to the indicator
        tooltip: Optional tooltip text to display on hover
        size: Size of the indicator in pixels
        key: Unique key for the component
    """
    # Map status to colors
    status_colors = {
        "success": "var(--color-success-main)",
        "warning": "var(--color-warning-main)",
        "error": "var(--color-error-main)",
        "info": "var(--color-info-main)",
        "offline": "var(--color-neutral-light)"
    }
    
    color = status_colors.get(status.lower(), status_colors["offline"])
    
    # Create tooltip attribute if provided
    tooltip_attr = f'title="{tooltip}"' if tooltip else ''
    
    # Render the indicator
    st.markdown(
        f"""
        <div style="display: flex; align-items: center; margin-bottom: 8px;">
            <div style="
                width: {size}px;
                height: {size}px;
                border-radius: 50%;
                background-color: {color};
                margin-right: 8px;
                display: inline-block;
                flex-shrink: 0;
                " {tooltip_attr}>
            </div>
            <div>{label}</div>
        </div>
        """,
        unsafe_allow_html=True
    )

def styled_progress(
    value: float,
    label: Optional[str] = None,
    color: str = "primary",
    height: int = 8,
    show_percentage: bool = True,
    key: Optional[str] = None
):
    """
    Display a styled progress bar.
    
    Args:
        value: Progress value between 0.0 and 1.0
        label: Optional label to display above the progress bar
        color: Color theme for the progress bar
        height: Height of the progress bar in pixels
        show_percentage: Whether to show percentage text
        key: Unique key for the component
    """
    # Ensure value is between 0 and 1
    value = max(0.0, min(1.0, value))
    
    # Get color from theme
    color_value = COLORS.get(color, COLORS["primary"])
    if isinstance(color_value, dict):
        color_value = color_value["main"]
    
    # Create label HTML if provided
    label_html = f'<div style="margin-bottom: 4px;">{label}</div>' if label else ''
    
    # Create percentage HTML if requested
    percentage_html = f'<div style="margin-top: 4px; font-size: 0.875rem; text-align: right;">{int(value * 100)}%</div>' if show_percentage else ''
    
    # Render the progress bar
    st.markdown(
        f"""
        <div>
            {label_html}
            <div style="
                width: 100%;
                height: {height}px;
                background-color: var(--color-neutral-border);
                border-radius: {height // 2}px;
                overflow: hidden;
            ">
                <div style="
                    width: {value * 100}%;
                    height: 100%;
                    background-color: var(--color-{color}-main);
                    border-radius: {height // 2}px;
                    transition: width 0.3s ease;
                "></div>
            </div>
            {percentage_html}
        </div>
        """,
        unsafe_allow_html=True
    )

def styled_divider(
    label: Optional[str] = None,
    color: str = "neutral",
    thickness: int = 1,
    margin: str = "md",
    key: Optional[str] = None
):
    """
    Display a styled divider with optional label.
    
    Args:
        label: Optional label to display in the middle of the divider
        color: Color theme for the divider
        thickness: Thickness of the divider in pixels
        margin: Margin size around the divider
        key: Unique key for the component
    """
    # Get color from theme
    color_value = COLORS.get(color, COLORS["neutral"])
    if isinstance(color_value, dict):
        color_value = color_value["light"]
    
    # Get margin from spacing
    margin_value = SPACING.get(margin, SPACING["md"])
    
    # Create divider with or without label
    if label:
        st.markdown(
            f"""
            <div style="
                display: flex;
                align-items: center;
                margin: {margin_value} 0;
            ">
                <div style="
                    flex-grow: 1;
                    height: {thickness}px;
                    background-color: {color_value};
                "></div>
                <div style="
                    padding: 0 var(--spacing-sm);
                    color: {color_value};
                    font-size: 0.875rem;
                ">{label}</div>
                <div style="
                    flex-grow: 1;
                    height: {thickness}px;
                    background-color: {color_value};
                "></div>
            </div>
            """,
            unsafe_allow_html=True
        )
    else:
        st.markdown(
            f"""
            <div style="
                height: {thickness}px;
                background-color: {color_value};
                margin: {margin_value} 0;
            "></div>
            """,
            unsafe_allow_html=True
        )

def styled_badge(
    label: str,
    color: str = "primary",
    variant: str = "filled",
    size: str = "medium",
    icon: Optional[str] = None,
    key: Optional[str] = None
):
    """
    Display a styled badge.
    
    Args:
        label: Text to display in the badge
        color: Color theme for the badge
        variant: Badge variant ("filled", "outlined", "text")
        size: Badge size ("small", "medium", "large")
        icon: Optional Material icon name
        key: Unique key for the component
    """
    # Get color from theme
    color_dict = COLORS.get(color, COLORS["primary"])
    
    # Determine background and text colors based on variant
    if variant == "filled":
        bg_color = f"var(--color-{color}-main)"
        text_color = f"var(--color-{color}-contrast)"
        border = "none"
    elif variant == "outlined":
        bg_color = "transparent"
        text_color = f"var(--color-{color}-main)"
        border = f"1px solid var(--color-{color}-main)"
    else:  # text
        bg_color = "transparent"
        text_color = f"var(--color-{color}-main)"
        border = "none"
    
    # Determine size
    if size == "small":
        padding = "2px 6px"
        font_size = "0.75rem"
    elif size == "large":
        padding = "6px 12px"
        font_size = "1rem"
    else:  # medium
        padding = "4px 8px"
        font_size = "0.875rem"
    
    # Create icon HTML if provided
    icon_html = f'<i class="material-icons" style="font-size: {font_size}; margin-right: 4px;">{icon}</i>' if icon else ""
    
    # Render the badge
    st.markdown(
        f"""
        <span style="
            display: inline-flex;
            align-items: center;
            background-color: {bg_color};
            color: {text_color};
            border: {border};
            border-radius: var(--radius-full);
            padding: {padding};
            font-size: {font_size};
            font-weight: 500;
            line-height: 1;
            white-space: nowrap;
        ">
            {icon_html}{label}
        </span>
        """,
        unsafe_allow_html=True
    )

def styled_alert(
    message: str,
    type: str = "info",
    icon: Optional[str] = None,
    dismissible: bool = False,
    key: Optional[str] = None
):
    """
    Display a styled alert message.
    
    Args:
        message: Alert message text
        type: Alert type ("info", "success", "warning", "error")
        icon: Optional Material icon name (overrides default icon)
        dismissible: Whether the alert can be dismissed
        key: Unique key for the component
    """
    # Generate a unique key if not provided
    if key is None:
        key = f"alert_{int(time.time() * 1000)}"
    
    # Map alert types to colors and default icons
    alert_types = {
        "info": {"color": "info", "icon": "info"},
        "success": {"color": "success", "icon": "check_circle"},
        "warning": {"color": "warning", "icon": "warning"},
        "error": {"color": "error", "icon": "error"}
    }
    
    alert_info = alert_types.get(type, alert_types["info"])
    color = alert_info["color"]
    default_icon = alert_info["icon"]
    
    # Use provided icon or default
    icon_name = icon or default_icon
    
    # Create dismiss button if dismissible
    dismiss_button = ""
    dismiss_script = ""
    if dismissible:
        dismiss_button = f"""
        <button onclick="document.getElementById('alert-{key}').style.display='none';" 
                style="background: none; border: none; cursor: pointer; margin-left: auto; color: inherit;">
            <i class="material-icons" style="font-size: 18px;">close</i>
        </button>
        """
        
        dismiss_script = f"""
        <script>
            function dismissAlert{key}() {{
                document.getElementById('alert-{key}').style.display = 'none';
            }}
        </script>
        """
    
    # Render the alert
    st.markdown(
        f"""
        {dismiss_script}
        <div id="alert-{key}" style="
            display: flex;
            align-items: flex-start;
            background-color: var(--color-{color}-light);
            color: var(--color-{color}-dark);
            border-left: 4px solid var(--color-{color}-main);
            border-radius: var(--radius-md);
            padding: var(--spacing-md);
            margin-bottom: var(--spacing-md);
        ">
            <i class="material-icons" style="margin-right: 12px; flex-shrink: 0;">{icon_name}</i>
            <div style="flex-grow: 1;">{message}</div>
            {dismiss_button}
        </div>
        """,
        unsafe_allow_html=True
    )

def styled_tooltip(
    content: str,
    tooltip_text: str,
    position: str = "top",
    key: Optional[str] = None
):
    """
    Display content with a tooltip that appears on hover.
    
    Args:
        content: HTML content to display
        tooltip_text: Text to display in the tooltip
        position: Tooltip position ("top", "bottom", "left", "right")
        key: Unique key for the component
    """
    # Generate a unique key if not provided
    if key is None:
        key = f"tooltip_{int(time.time() * 1000)}"
    
    # Create CSS for tooltip
    tooltip_css = f"""
    <style>
    .tooltip-container-{key} {{
        position: relative;
        display: inline-block;
    }}
    
    .tooltip-container-{key} .tooltip-{key} {{
        visibility: hidden;
        background-color: rgba(0, 0, 0, 0.8);
        color: white;
        text-align: center;
        border-radius: var(--radius-sm);
        padding: 8px;
        position: absolute;
        z-index: 1000;
        width: max-content;
        max-width: 200px;
        opacity: 0;
        transition: opacity 0.3s;
        font-size: 0.75rem;
    }}
    
    .tooltip-container-{key}:hover .tooltip-{key} {{
        visibility: visible;
        opacity: 1;
    }}
    """
    
    # Add position-specific CSS
    if position == "top":
        tooltip_css += f"""
        .tooltip-container-{key} .tooltip-{key} {{
            bottom: 100%;
            left: 50%;
            transform: translateX(-50%);
            margin-bottom: 5px;
        }}
        
        .tooltip-container-{key} .tooltip-{key}::after {{
            content: "";
            position: absolute;
            top: 100%;
            left: 50%;
            margin-left: -5px;
            border-width: 5px;
            border-style: solid;
            border-color: rgba(0, 0, 0, 0.8) transparent transparent transparent;
        }}
        """
    elif position == "bottom":
        tooltip_css += f"""
        .tooltip-container-{key} .tooltip-{key} {{
            top: 100%;
            left: 50%;
            transform: translateX(-50%);
            margin-top: 5px;
        }}
        
        .tooltip-container-{key} .tooltip-{key}::after {{
            content: "";
            position: absolute;
            bottom: 100%;
            left: 50%;
            margin-left: -5px;
            border-width: 5px;
            border-style: solid;
            border-color: transparent transparent rgba(0, 0, 0, 0.8) transparent;
        }}
        """
    elif position == "left":
        tooltip_css += f"""
        .tooltip-container-{key} .tooltip-{key} {{
            right: 100%;
            top: 50%;
            transform: translateY(-50%);
            margin-right: 5px;
        }}
        
        .tooltip-container-{key} .tooltip-{key}::after {{
            content: "";
            position: absolute;
            left: 100%;
            top: 50%;
            margin-top: -5px;
            border-width: 5px;
            border-style: solid;
            border-color: transparent transparent transparent rgba(0, 0, 0, 0.8);
        }}
        """
    else:  # right
        tooltip_css += f"""
        .tooltip-container-{key} .tooltip-{key} {{
            left: 100%;
            top: 50%;
            transform: translateY(-50%);
            margin-left: 5px;
        }}
        
        .tooltip-container-{key} .tooltip-{key}::after {{
            content: "";
            position: absolute;
            right: 100%;
            top: 50%;
            margin-top: -5px;
            border-width: 5px;
            border-style: solid;
            border-color: transparent rgba(0, 0, 0, 0.8) transparent transparent;
        }}
        """
    
    tooltip_css += "</style>"
    
    # Render the tooltip
    st.markdown(
        f"""
        {tooltip_css}
        <div class="tooltip-container-{key}">
            {content}
            <span class="tooltip-{key}">{tooltip_text}</span>
        </div>
        """,
        unsafe_allow_html=True
    )

def responsive_grid_layout(
    columns: Dict[str, List[Callable]],
    gap: str = "md",
    key: Optional[str] = None
):
    """
    Create a responsive grid layout that adjusts based on screen size.
    
    Args:
        columns: Dictionary with column configuration for different screen sizes
                 e.g., {"lg": [func1, func2], "md": [func3, func4, func5]}
        gap: Gap size between grid items
        key: Unique key for the component
    """
    # Generate a unique key if not provided
    if key is None:
        key = f"grid_{int(time.time() * 1000)}"
    
    # Get gap value from spacing
    gap_value = SPACING.get(gap, SPACING["md"])
    
    # Create CSS for responsive grid
    grid_css = f"""
    <style>
    .responsive-grid-{key} {{
        display: grid;
        gap: {gap_value};
        margin-bottom: {gap_value};
    }}
    
    /* Default (large screens) */
    .responsive-grid-{key} {{
        grid-template-columns: repeat({len(columns.get("lg", []))}, 1fr);
    }}
    
    /* Medium screens */
    @media (max-width: 960px) {{
        .responsive-grid-{key} {{
            grid-template-columns: repeat({len(columns.get("md", columns.get("lg", [])))}, 1fr);
        }}
    }}
    
    /* Small screens */
    @media (max-width: 600px) {{
        .responsive-grid-{key} {{
            grid-template-columns: repeat({len(columns.get("sm", [1]))}, 1fr);
        }}
    }}
    </style>
    """
    
    st.markdown(grid_css, unsafe_allow_html=True)
    
    # Start grid container
    st.markdown(f'<div class="responsive-grid-{key}">', unsafe_allow_html=True)
    
    # Add each item in a separate container
    for i, item_func in enumerate(columns.get("lg", [])):
        st.markdown(f'<div class="grid-item-{key}" id="grid-item-{key}-{i}">', unsafe_allow_html=True)
        item_func()
        st.markdown('</div>', unsafe_allow_html=True)
    
    # Close grid container
    st.markdown('</div>', unsafe_allow_html=True)

def demo_design_system():
    """
    Demonstrate all design system components with examples.
    """
    # Load the design system
    load_design_system()
    
    st.title("Design System Demo")
    
    # Theme switcher
    theme = st.radio("Theme", ["Light", "Dark"], horizontal=True)
    if theme == "Dark":
        apply_theme("dark")
    
    # Typography
    st.markdown("## Typography")
    
    st.markdown('<p class="typography-h1">Heading 1</p>', unsafe_allow_html=True)
    st.markdown('<p class="typography-h2">Heading 2</p>', unsafe_allow_html=True)
    st.markdown('<p class="typography-h3">Heading 3</p>', unsafe_allow_html=True)
    st.markdown('<p class="typography-h4">Heading 4</p>', unsafe_allow_html=True)
    st.markdown('<p class="typography-h5">Heading 5</p>', unsafe_allow_html=True)
    st.markdown('<p class="typography-h6">Heading 6</p>', unsafe_allow_html=True)
    st.markdown('<p class="typography-body1">Body 1: This is a paragraph of text that demonstrates the body1 typography style.</p>', unsafe_allow_html=True)
    st.markdown('<p class="typography-body2">Body 2: This is a paragraph of text that demonstrates the body2 typography style.</p>', unsafe_allow_html=True)
    st.markdown('<p class="typography-caption">Caption: This is a caption text.</p>', unsafe_allow_html=True)
    st.markdown('<p class="typography-button">BUTTON TEXT</p>', unsafe_allow_html=True)
    
    # Colors
    st.markdown("## Colors")
    
    # Primary colors
    st.markdown("### Primary Colors")
    cols = st.columns(4)
    for i, shade in enumerate(["main", "light", "dark", "contrast"]):
        with cols[i]:
            st.markdown(
                f"""
                <div style="
                    background-color: var(--color-primary-{shade});
                    color: {COLORS['primary']['contrast'] if shade != 'contrast' else COLORS['primary']['main']};
                    padding: 16px;
                    border-radius: 4px;
                    text-align: center;
                ">
                    primary-{shade}
                </div>
                """,
                unsafe_allow_html=True
            )
    
    # Secondary colors
    st.markdown("### Secondary Colors")
    cols = st.columns(4)
    for i, shade in enumerate(["main", "light", "dark", "contrast"]):
        with cols[i]:
            st.markdown(
                f"""
                <div style="
                    background-color: var(--color-secondary-{shade});
                    color: {COLORS['secondary']['contrast'] if shade != 'contrast' else COLORS['secondary']['main']};
                    padding: 16px;
                    border-radius: 4px;
                    text-align: center;
                ">
                    secondary-{shade}
                </div>
                """,
                unsafe_allow_html=True
            )
    
    # Semantic colors
    st.markdown("### Semantic Colors")
    cols = st.columns(4)
    for i, color in enumerate(["success", "warning", "error", "info"]):
        with cols[i]:
            st.markdown(
                f"""
                <div style="
                    background-color: var(--color-{color}-main);
                    color: var(--color-{color}-contrast);
                    padding: 16px;
                    border-radius: 4px;
                    text-align: center;
                ">
                    {color}
                </div>
                """,
                unsafe_allow_html=True
            )
    
    # Components
    st.markdown("## Components")
    
    # Cards
    st.markdown("### Cards")
    
    cols = st.columns(2)
    
    with cols[0]:
        def card_content():
            st.write("This is a basic card with title and content.")
            st.write("Cards can contain any Streamlit elements.")
        
        modern_card(
            title="Basic Card",
            content=card_content,
            footer="Last updated: April 21, 2025",
            icon="info",
            key="demo_basic_card"
        )
    
    with cols[1]:
        def card_content2():
            st.metric(
                label="",
                value="1,234",
                delta="56"
            )
        
        modern_card(
            title="Metric Card",
            content=card_content2,
            color="secondary",
            icon="trending_up",
            key="demo_metric_card"
        )
    
    # Styled metrics
    st.markdown("### Styled Metrics")
    
    cols = st.columns(4)
    
    with cols[0]:
        styled_metric(
            label="Sandwiches Inspected",
            value="1,234",
            delta="+56",
            color="primary",
            icon="inventory_2",
            key="demo_metric1"
        )
    
    with cols[1]:
        styled_metric(
            label="Defect Rate",
            value="0.8",
            delta="-0.2",
            suffix="%",
            delta_color="inverse",
            color="secondary",
            icon="trending_down",
            key="demo_metric2"
        )
    
    with cols[2]:
        styled_metric(
            label="Production Speed",
            value="250",
            suffix=" units/min",
            color="accent",
            icon="speed",
            key="demo_metric3"
        )
    
    with cols[3]:
        styled_metric(
            label="Uptime",
            value="99.8",
            suffix="%",
            color="success",
            icon="check_circle",
            key="demo_metric4"
        )
    
    # Buttons
    st.markdown("### Buttons")
    
    cols = st.columns(3)
    
    with cols[0]:
        styled_button(
            "Primary Button",
            color="primary",
            variant="filled",
            icon="check",
            key="demo_button1"
        )
    
    with cols[1]:
        styled_button(
            "Secondary Button",
            color="secondary",
            variant="outlined",
            icon="settings",
            key="demo_button2"
        )
    
    with cols[2]:
        styled_button(
            "Accent Button",
            color="accent",
            variant="filled",
            icon="star",
            key="demo_button3"
        )
    
    # Status indicators
    st.markdown("### Status Indicators")
    
    cols = st.columns(4)
    
    with cols[0]:
        styled_status_indicator(
            "success",
            "System Online",
            tooltip="System is running normally",
            key="demo_status1"
        )
    
    with cols[1]:
        styled_status_indicator(
            "warning",
            "Low Disk Space",
            tooltip="Disk space below 20%",
            key="demo_status2"
        )
    
    with cols[2]:
        styled_status_indicator(
            "error",
            "Camera Offline",
            tooltip="Camera connection lost",
            key="demo_status3"
        )
    
    with cols[3]:
        styled_status_indicator(
            "info",
            "Processing",
            tooltip="Processing images",
            key="demo_status4"
        )
    
    # Progress bars
    st.markdown("### Progress Bars")
    
    styled_progress(
        0.75,
        label="Processing Images",
        color="primary",
        key="demo_progress1"
    )
    
    styled_progress(
        0.45,
        label="Disk Usage",
        color="warning",
        key="demo_progress2"
    )
    
    styled_progress(
        0.95,
        label="Memory Usage",
        color="error",
        key="demo_progress3"
    )
    
    # Dividers
    st.markdown("### Dividers")
    
    styled_divider()
    
    styled_divider(label="With Label")
    
    styled_divider(label="Custom Color", color="primary")
    
    # Badges
    st.markdown("### Badges")
    
    cols = st.columns(4)
    
    with cols[0]:
        styled_badge(
            "Primary",
            color="primary",
            variant="filled",
            key="demo_badge1"
        )
    
    with cols[1]:
        styled_badge(
            "Secondary",
            color="secondary",
            variant="outlined",
            key="demo_badge2"
        )
    
    with cols[2]:
        styled_badge(
            "Success",
            color="success",
            variant="filled",
            icon="check",
            key="demo_badge3"
        )
    
    with cols[3]:
        styled_badge(
            "Error",
            color="error",
            variant="filled",
            icon="error",
            key="demo_badge4"
        )
    
    # Alerts
    st.markdown("### Alerts")
    
    styled_alert(
        "This is an information alert.",
        type="info",
        key="demo_alert1"
    )
    
    styled_alert(
        "This is a success alert.",
        type="success",
        key="demo_alert2"
    )
    
    styled_alert(
        "This is a warning alert.",
        type="warning",
        key="demo_alert3"
    )
    
    styled_alert(
        "This is an error alert.",
        type="error",
        dismissible=True,
        key="demo_alert4"
    )
    
    # Tooltips
    st.markdown("### Tooltips")
    
    cols = st.columns(4)
    
    with cols[0]:
        styled_tooltip(
            "<span style='color: var(--color-primary-main);'>Hover me (top)</span>",
            "This tooltip appears on top",
            position="top",
            key="demo_tooltip1"
        )
    
    with cols[1]:
        styled_tooltip(
            "<span style='color: var(--color-secondary-main);'>Hover me (bottom)</span>",
            "This tooltip appears on bottom",
            position="bottom",
            key="demo_tooltip2"
        )
    
    with cols[2]:
        styled_tooltip(
            "<span style='color: var(--color-accent-main);'>Hover me (left)</span>",
            "This tooltip appears on left",
            position="left",
            key="demo_tooltip3"
        )
    
    with cols[3]:
        styled_tooltip(
            "<span style='color: var(--color-error-main);'>Hover me (right)</span>",
            "This tooltip appears on right",
            position="right",
            key="demo_tooltip4"
        )
    
    # Tabs
    st.markdown("### Tabs")
    
    def tab1_content():
        st.write("This is the content of Tab 1")
        st.slider("Sample slider", 0, 100, 50)
    
    def tab2_content():
        st.write("This is the content of Tab 2")
        st.button("Sample button")
    
    def tab3_content():
        st.write("This is the content of Tab 3")
        st.checkbox("Sample checkbox")
    
    styled_tabs(
        {
            "Tab 1": tab1_content,
            "Tab 2": tab2_content,
            "Tab 3": tab3_content
        },
        key="demo_tabs"
    )
    
    # Responsive grid
    st.markdown("### Responsive Grid")
    
    def grid_item1():
        modern_card(
            title="Grid Item 1",
            content=lambda: st.write("This is grid item 1"),
            icon="grid_view",
            key="grid_item1"
        )
    
    def grid_item2():
        modern_card(
            title="Grid Item 2",
            content=lambda: st.write("This is grid item 2"),
            icon="grid_view",
            key="grid_item2"
        )
    
    def grid_item3():
        modern_card(
            title="Grid Item 3",
            content=lambda: st.write("This is grid item 3"),
            icon="grid_view",
            key="grid_item3"
        )
    
    def grid_item4():
        modern_card(
            title="Grid Item 4",
            content=lambda: st.write("This is grid item 4"),
            icon="grid_view",
            key="grid_item4"
        )
    
    responsive_grid_layout(
        {
            "lg": [grid_item1, grid_item2, grid_item3, grid_item4],
            "md": [grid_item1, grid_item2],
            "sm": [grid_item1]
        },
        key="demo_grid"
    )

if __name__ == "__main__":
    # This will run when the script is executed directly
    demo_design_system()
