"""
Material UI integration for the OPSC Sandwich Quality Inspection System.

This module provides Material Design components and styling for Streamlit,
creating a bridge between Material Design principles and Streamlit's component system.
"""

import streamlit as st
from typing import Dict, List, Optional, Callable, Union, Tuple, Any
import time
import base64
from src.ui.components.design_system import COLORS, TYPOGRAPHY, SPACING, SHADOWS, BORDER_RADIUS

def load_material_icons():
    """
    Load Material Icons font and CSS into the Streamlit app.
    """
    st.markdown(
        """
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <style>
        .material-icons {
            font-family: 'Material Icons';
            font-weight: normal;
            font-style: normal;
            font-size: 24px;
            line-height: 1;
            letter-spacing: normal;
            text-transform: none;
            display: inline-block;
            white-space: nowrap;
            word-wrap: normal;
            direction: ltr;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
            text-rendering: optimizeLegibility;
            vertical-align: middle;
        }
        </style>
        """,
        unsafe_allow_html=True
    )

def material_button(
    label: str,
    on_click: Optional[Callable] = None,
    args: Optional[Tuple] = None,
    kwargs: Optional[Dict] = None,
    type: str = "contained",  # "contained", "outlined", "text"
    color: str = "primary",   # "primary", "secondary", "accent", "success", "warning", "error"
    icon: Optional[str] = None,
    icon_position: str = "left",  # "left", "right"
    disabled: bool = False,
    full_width: bool = False,
    key: Optional[str] = None,
    help: Optional[str] = None,
    size: str = "medium"  # "small", "medium", "large"
) -> bool:
    """
    Create a Material Design styled button.
    
    Args:
        label: Text to display on the button
        on_click: Callback function to execute when button is clicked
        args: Args to pass to the callback
        kwargs: Kwargs to pass to the callback
        type: Button type (contained, outlined, text)
        color: Button color theme
        icon: Optional Material Icons name
        icon_position: Position of the icon (left or right)
        disabled: Whether the button is disabled
        full_width: Whether the button should take full width
        key: Unique key for the component
        help: Tooltip text
        size: Button size (small, medium, large)
        
    Returns:
        True if the button was clicked, False otherwise
    """
    # Generate a unique key if not provided
    if key is None:
        key = f"material_button_{int(time.time() * 1000)}"
    
    # Get color from theme
    color_value = COLORS.get(color, COLORS["primary"])
    if isinstance(color_value, dict):
        main_color = color_value["main"]
        hover_color = color_value["dark"]
        text_color = color_value["contrast"]
    else:
        main_color = color_value
        hover_color = color_value
        text_color = "#FFFFFF"
    
    # Set button style based on type
    if type == "contained":
        background_color = main_color
        border = f"none"
        text_color = text_color
    elif type == "outlined":
        background_color = "transparent"
        border = f"1px solid {main_color}"
        text_color = main_color
    else:  # text
        background_color = "transparent"
        border = "none"
        text_color = main_color
    
    # Set padding based on size
    if size == "small":
        padding = "4px 8px"
        font_size = "0.8rem"
    elif size == "large":
        padding = "12px 24px"
        font_size = "1.1rem"
    else:  # medium
        padding = "8px 16px"
        font_size = "1rem"
    
    # Create icon HTML if provided
    icon_html = ""
    if icon:
        icon_html = f'<span class="material-icons" style="font-size: {font_size}; margin: {"-4px 8px -4px -4px" if icon_position == "left" else "-4px -4px -4px 8px"}">{icon}</span>'
    
    # Create button label with icon
    if icon and icon_position == "left":
        button_content = f"{icon_html}{label}"
    elif icon and icon_position == "right":
        button_content = f"{label}{icon_html}"
    else:
        button_content = label
    
    # Create custom button CSS
    custom_css = f"""
    <style>
    div[data-testid="stButton"] > button:first-child {{
        background-color: {background_color};
        color: {text_color};
        border: {border};
        border-radius: {BORDER_RADIUS["md"]};
        padding: {padding};
        font-family: {TYPOGRAPHY["button"]["font-family"]};
        font-weight: {TYPOGRAPHY["button"]["font-weight"]};
        font-size: {font_size};
        letter-spacing: {TYPOGRAPHY["button"]["letter-spacing"]};
        text-transform: {TYPOGRAPHY["button"]["text-transform"]};
        transition: all 0.2s ease;
        box-shadow: {SHADOWS["sm"] if type == "contained" else "none"};
        width: {("100%" if full_width else "auto")};
        opacity: {("0.6" if disabled else "1")};
        cursor: {("not-allowed" if disabled else "pointer")};
        display: flex;
        align-items: center;
        justify-content: center;
    }}
    div[data-testid="stButton"] > button:first-child:hover {{
        background-color: {hover_color if type == "contained" else (f"rgba({int(main_color[1:3], 16)}, {int(main_color[3:5], 16)}, {int(main_color[5:7], 16)}, 0.08)")};
        border-color: {hover_color if type == "outlined" else "transparent"};
        box-shadow: {SHADOWS["md"] if type == "contained" else "none"};
    }}
    div[data-testid="stButton"] > button:first-child:active {{
        transform: translateY(1px);
    }}
    </style>
    """
    
    # Apply custom CSS
    st.markdown(custom_css, unsafe_allow_html=True)
    
    # Create the button with Streamlit
    return st.button(
        button_content,
        key=key,
        help=help,
        on_click=on_click,
        args=args,
        kwargs=kwargs,
        disabled=disabled,
        use_container_width=full_width
    )

def material_card(
    content_func: Callable,
    title: Optional[str] = None,
    subtitle: Optional[str] = None,
    elevation: int = 1,
    outlined: bool = False,
    radius: str = "md",
    padding: str = "md",
    margin: str = "md",
    header_color: str = "primary",
    header_divider: bool = True,
    footer: Optional[Union[str, Callable]] = None,
    footer_divider: bool = True,
    key: Optional[str] = None
):
    """
    Create a Material Design styled card.
    
    Args:
        content_func: Function that renders the card content
        title: Optional card title
        subtitle: Optional card subtitle
        elevation: Shadow elevation (0-5)
        outlined: Whether to show a border instead of shadow
        radius: Border radius size (none, sm, md, lg, xl, full)
        padding: Padding size (xs, sm, md, lg, xl, xxl)
        margin: Margin size (xs, sm, md, lg, xl, xxl)
        header_color: Color for the header
        header_divider: Whether to show a divider after the header
        footer: Optional footer content (string or function)
        footer_divider: Whether to show a divider before the footer
        key: Unique key for the component
    """
    # Generate a unique key if not provided
    if key is None:
        key = f"material_card_{int(time.time() * 1000)}"
    
    # Get shadow based on elevation
    shadow = SHADOWS.get(f"{'none' if elevation == 0 or outlined else 'sm' if elevation == 1 else 'md' if elevation == 2 else 'lg' if elevation == 3 else 'xl'}")
    
    # Get border radius
    border_radius_value = BORDER_RADIUS.get(radius, BORDER_RADIUS["md"])
    
    # Get padding and margin
    padding_value = SPACING.get(padding, SPACING["md"])
    margin_value = SPACING.get(margin, SPACING["md"])
    
    # Get header color
    header_color_value = COLORS.get(header_color, COLORS["primary"])
    if isinstance(header_color_value, dict):
        header_color_value = header_color_value["main"]
    
    # Create card container style
    card_style = f"""
        background-color: var(--color-neutral-paper);
        border-radius: {border_radius_value};
        margin-bottom: {margin_value};
        overflow: hidden;
        {f"box-shadow: {shadow};" if not outlined else ""}
        {f"border: 1px solid var(--color-neutral-border);" if outlined else ""}
    """
    
    # Create card header style
    header_style = f"""
        padding: {padding_value};
        {f"border-bottom: 1px solid var(--color-neutral-border);" if header_divider and (title or subtitle) else ""}
    """
    
    # Create card content style
    content_style = f"""
        padding: {padding_value};
    """
    
    # Create card footer style
    footer_style = f"""
        padding: {padding_value};
        {f"border-top: 1px solid var(--color-neutral-border);" if footer_divider and footer else ""}
        background-color: var(--color-neutral-background);
    """
    
    # Start the card
    st.markdown(f'<div style="{card_style}" id="{key}">', unsafe_allow_html=True)
    
    # Render header if title or subtitle is provided
    if title or subtitle:
        st.markdown(f'<div style="{header_style}">', unsafe_allow_html=True)
        
        if title:
            st.markdown(
                f'<h3 style="margin: 0; color: {header_color_value}; {"; ".join([f"{k}: {v}" for k, v in TYPOGRAPHY["h4"].items() if k != "margin-top" and k != "margin-bottom"])}">{title}</h3>',
                unsafe_allow_html=True
            )
        
        if subtitle:
            st.markdown(
                f'<p style="margin: {("8px 0 0 0" if title else "0")}; color: var(--color-neutral-main); {"; ".join([f"{k}: {v}" for k, v in TYPOGRAPHY["body2"].items() if k != "margin-top" and k != "margin-bottom"])}">{subtitle}</p>',
                unsafe_allow_html=True
            )
        
        st.markdown('</div>', unsafe_allow_html=True)
    
    # Render content
    st.markdown(f'<div style="{content_style}">', unsafe_allow_html=True)
    content_func()
    st.markdown('</div>', unsafe_allow_html=True)
    
    # Render footer if provided
    if footer:
        st.markdown(f'<div style="{footer_style}">', unsafe_allow_html=True)
        
        if callable(footer):
            footer()
        else:
            st.markdown(
                f'<p style="margin: 0; color: var(--color-neutral-main); {"; ".join([f"{k}: {v}" for k, v in TYPOGRAPHY["caption"].items() if k != "margin-top" and k != "margin-bottom"])}">{footer}</p>',
                unsafe_allow_html=True
            )
        
        st.markdown('</div>', unsafe_allow_html=True)
    
    # Close the card
    st.markdown('</div>', unsafe_allow_html=True)

def material_text_field(
    label: str,
    value: str = "",
    placeholder: str = "",
    type: str = "text",  # "text", "password", "number", "email"
    disabled: bool = False,
    required: bool = False,
    helper_text: Optional[str] = None,
    error_text: Optional[str] = None,
    max_chars: Optional[int] = None,
    key: Optional[str] = None,
    on_change: Optional[Callable] = None,
    args: Optional[Tuple] = None,
    kwargs: Optional[Dict] = None
) -> str:
    """
    Create a Material Design styled text field.
    
    Args:
        label: Label for the text field
        value: Initial value
        placeholder: Placeholder text
        type: Input type
        disabled: Whether the field is disabled
        required: Whether the field is required
        helper_text: Helper text to display below the field
        error_text: Error text to display (overrides helper_text)
        max_chars: Maximum number of characters
        key: Unique key for the component
        on_change: Callback function to execute when value changes
        args: Args to pass to the callback
        kwargs: Kwargs to pass to the callback
        
    Returns:
        The current value of the text field
    """
    # Generate a unique key if not provided
    if key is None:
        key = f"material_text_field_{int(time.time() * 1000)}"
    
    # Create custom CSS for the text field
    custom_css = f"""
    <style>
    div[data-testid="stTextInput"] > div:first-child > div:first-child > div:first-child > input:first-child {{
        border-radius: {BORDER_RADIUS["md"]};
        border: 1px solid {("var(--color-error-main)" if error_text else "var(--color-neutral-border)")};
        padding: 12px 16px;
        font-family: {TYPOGRAPHY["body1"]["font-family"]};
        font-size: {TYPOGRAPHY["body1"]["font-size"]};
        transition: all 0.2s ease;
        background-color: {"var(--color-neutral-paper)"};
    }}
    div[data-testid="stTextInput"] > div:first-child > div:first-child > div:first-child > input:first-child:focus {{
        border-color: {("var(--color-error-main)" if error_text else "var(--color-primary-main)")};
        box-shadow: 0 0 0 1px {("var(--color-error-main)" if error_text else "var(--color-primary-main)")};
    }}
    div[data-testid="stTextInput"] label {{
        color: {("var(--color-error-main)" if error_text else "var(--color-neutral-main)")};
        font-family: {TYPOGRAPHY["body2"]["font-family"]};
        font-size: {TYPOGRAPHY["body2"]["font-size"]};
        font-weight: 500;
    }}
    .helper-text {{
        font-family: {TYPOGRAPHY["caption"]["font-family"]};
        font-size: {TYPOGRAPHY["caption"]["font-size"]};
        color: {("var(--color-error-main)" if error_text else "var(--color-neutral-main)")};
        margin-top: 4px;
        margin-left: 4px;
    }}
    </style>
    """
    
    # Apply custom CSS
    st.markdown(custom_css, unsafe_allow_html=True)
    
    # Create the text field with Streamlit
    if type == "password":
        result = st.text_input(
            label,
            value=value,
            placeholder=placeholder,
            disabled=disabled,
            type="password",
            key=key,
            max_chars=max_chars,
            on_change=on_change,
            args=args,
            kwargs=kwargs
        )
    elif type == "number":
        result = st.number_input(
            label,
            value=float(value) if value else 0.0,
            disabled=disabled,
            key=key,
            on_change=on_change,
            args=args,
            kwargs=kwargs
        )
        result = str(result)
    else:
        result = st.text_input(
            label,
            value=value,
            placeholder=placeholder,
            disabled=disabled,
            key=key,
            max_chars=max_chars,
            on_change=on_change,
            args=args,
            kwargs=kwargs
        )
    
    # Display helper text or error text
    if error_text:
        st.markdown(f'<div class="helper-text">{error_text}</div>', unsafe_allow_html=True)
    elif helper_text:
        st.markdown(f'<div class="helper-text">{helper_text}</div>', unsafe_allow_html=True)
    
    return result

def material_select(
    label: str,
    options: List[Union[str, Tuple[str, str]]],
    default_index: int = 0,
    disabled: bool = False,
    helper_text: Optional[str] = None,
    error_text: Optional[str] = None,
    key: Optional[str] = None,
    on_change: Optional[Callable] = None,
    args: Optional[Tuple] = None,
    kwargs: Optional[Dict] = None
) -> str:
    """
    Create a Material Design styled select dropdown.
    
    Args:
        label: Label for the select
        options: List of options (strings or tuples of (value, label))
        default_index: Index of the default selected option
        disabled: Whether the select is disabled
        helper_text: Helper text to display below the select
        error_text: Error text to display (overrides helper_text)
        key: Unique key for the component
        on_change: Callback function to execute when value changes
        args: Args to pass to the callback
        kwargs: Kwargs to pass to the callback
        
    Returns:
        The current value of the select
    """
    # Generate a unique key if not provided
    if key is None:
        key = f"material_select_{int(time.time() * 1000)}"
    
    # Process options
    if options and isinstance(options[0], tuple):
        values = [opt[0] for opt in options]
        labels = {opt[0]: opt[1] for opt in options}
        format_func = lambda x: labels[x]
    else:
        values = options
        format_func = lambda x: x
    
    # Create custom CSS for the select
    custom_css = f"""
    <style>
    div[data-testid="stSelectbox"] > div:first-child > div:first-child > div:first-child > div:nth-child(2) {{
        border-radius: {BORDER_RADIUS["md"]};
        border: 1px solid {("var(--color-error-main)" if error_text else "var(--color-neutral-border)")};
        background-color: {"var(--color-neutral-paper)"};
    }}
    div[data-testid="stSelectbox"] > div:first-child > div:first-child > div:first-child > div:nth-child(2):focus-within {{
        border-color: {("var(--color-error-main)" if error_text else "var(--color-primary-main)")};
        box-shadow: 0 0 0 1px {("var(--color-error-main)" if error_text else "var(--color-primary-main)")};
    }}
    div[data-testid="stSelectbox"] label {{
        color: {("var(--color-error-main)" if error_text else "var(--color-neutral-main)")};
        font-family: {TYPOGRAPHY["body2"]["font-family"]};
        font-size: {TYPOGRAPHY["body2"]["font-size"]};
        font-weight: 500;
    }}
    .helper-text {{
        font-family: {TYPOGRAPHY["caption"]["font-family"]};
        font-size: {TYPOGRAPHY["caption"]["font-size"]};
        color: {("var(--color-error-main)" if error_text else "var(--color-neutral-main)")};
        margin-top: 4px;
        margin-left: 4px;
    }}
    </style>
    """
    
    # Apply custom CSS
    st.markdown(custom_css, unsafe_allow_html=True)
    
    # Create the select with Streamlit
    result = st.selectbox(
        label,
        options=values,
        index=default_index,
        format_func=format_func,
        disabled=disabled,
        key=key,
        on_change=on_change,
        args=args,
        kwargs=kwargs
    )
    
    # Display helper text or error text
    if error_text:
        st.markdown(f'<div class="helper-text">{error_text}</div>', unsafe_allow_html=True)
    elif helper_text:
        st.markdown(f'<div class="helper-text">{helper_text}</div>', unsafe_allow_html=True)
    
    return result

def material_checkbox(
    label: str,
    value: bool = False,
    disabled: bool = False,
    helper_text: Optional[str] = None,
    error_text: Optional[str] = None,
    key: Optional[str] = None,
    on_change: Optional[Callable] = None,
    args: Optional[Tuple] = None,
    kwargs: Optional[Dict] = None
) -> bool:
    """
    Create a Material Design styled checkbox.
    
    Args:
        label: Label for the checkbox
        value: Initial value
        disabled: Whether the checkbox is disabled
        helper_text: Helper text to display next to the checkbox
        error_text: Error text to display (overrides helper_text)
        key: Unique key for the component
        on_change: Callback function to execute when value changes
        args: Args to pass to the callback
        kwargs: Kwargs to pass to the callback
        
    Returns:
        The current value of the checkbox
    """
    # Generate a unique key if not provided
    if key is None:
        key = f"material_checkbox_{int(time.time() * 1000)}"
    
    # Create custom CSS for the checkbox
    custom_css = f"""
    <style>
    div[data-testid="stCheckbox"] > label > div[role="checkbox"] {{
        border-radius: {BORDER_RADIUS["sm"]};
        border: 2px solid {("var(--color-error-main)" if error_text else "var(--color-neutral-main)")};
        background-color: {"var(--color-neutral-paper)"};
        transition: all 0.2s ease;
    }}
    div[data-testid="stCheckbox"] > label > div[role="checkbox"][aria-checked="true"] {{
        border-color: var(--color-primary-main);
        background-color: var(--color-primary-main);
    }}
    div[data-testid="stCheckbox"] > label > div[data-testid="stMarkdownContainer"] {{
        color: {("var(--color-error-main)" if error_text else "var(--color-neutral-dark)")};
        font-family: {TYPOGRAPHY["body2"]["font-family"]};
        font-size: {TYPOGRAPHY["body2"]["font-size"]};
    }}
    .helper-text-inline {{
        font-family: {TYPOGRAPHY["caption"]["font-family"]};
        font-size: {TYPOGRAPHY["caption"]["font-size"]};
        color: {("var(--color-error-main)" if error_text else "var(--color-neutral-main)")};
        margin-left: 32px;
        margin-top: 2px;
    }}
    </style>
    """
    
    # Apply custom CSS
    st.markdown(custom_css, unsafe_allow_html=True)
    
    # Create the checkbox with Streamlit
    result = st.checkbox(
        label,
        value=value,
        disabled=disabled,
        key=key,
        on_change=on_change,
        args=args,
        kwargs=kwargs
    )
    
    # Display helper text or error text
    if error_text:
        st.markdown(f'<div class="helper-text-inline">{error_text}</div>', unsafe_allow_html=True)
    elif helper_text:
        st.markdown(f'<div class="helper-text-inline">{helper_text}</div>', unsafe_allow_html=True)
    
    return result

def material_radio(
    label: str,
    options: List[Union[str, Tuple[str, str]]],
    default_index: int = 0,
    horizontal: bool = False,
    disabled: bool = False,
    helper_text: Optional[str] = None,
    error_text: Optional[str] = None,
    key: Optional[str] = None,
    on_change: Optional[Callable] = None,
    args: Optional[Tuple] = None,
    kwargs: Optional[Dict] = None
) -> str:
    """
    Create a Material Design styled radio button group.
    
    Args:
        label: Label for the radio group
        options: List of options (strings or tuples of (value, label))
        default_index: Index of the default selected option
        horizontal: Whether to display options horizontally
        disabled: Whether the radio group is disabled
        helper_text: Helper text to display below the radio group
        error_text: Error text to display (overrides helper_text)
        key: Unique key for the component
        on_change: Callback function to execute when value changes
        args: Args to pass to the callback
        kwargs: Kwargs to pass to the callback
        
    Returns:
        The current value of the radio group
    """
    # Generate a unique key if not provided
    if key is None:
        key = f"material_radio_{int(time.time() * 1000)}"
    
    # Process options
    if options and isinstance(options[0], tuple):
        values = [opt[0] for opt in options]
        labels = {opt[0]: opt[1] for opt in options}
        format_func = lambda x: labels[x]
    else:
        values = options
        format_func = lambda x: x
    
    # Create custom CSS for the radio group
    custom_css = f"""
    <style>
    div[data-testid="stRadio"] > div:first-child > div:first-child > label > div:first-child {{
        border-color: {("var(--color-error-main)" if error_text else "var(--color-neutral-main)")};
        transition: all 0.2s ease;
    }}
    div[data-testid="stRadio"] > div:first-child > div:first-child > label > div:first-child[data-baseweb="radio"] {{
        background-color: var(--color-primary-main);
        border-color: var(--color-primary-main);
    }}
    div[data-testid="stRadio"] > div:first-child > div:first-child > label > div:nth-child(2) {{
        color: var(--color-neutral-dark);
        font-family: {TYPOGRAPHY["body2"]["font-family"]};
        font-size: {TYPOGRAPHY["body2"]["font-size"]};
    }}
    div[data-testid="stRadio"] > div:first-child > label {{
        color: {("var(--color-error-main)" if error_text else "var(--color-neutral-main)")};
        font-family: {TYPOGRAPHY["body2"]["font-family"]};
        font-size: {TYPOGRAPHY["body2"]["font-size"]};
        font-weight: 500;
    }}
    .helper-text {{
        font-family: {TYPOGRAPHY["caption"]["font-family"]};
        font-size: {TYPOGRAPHY["caption"]["font-size"]};
        color: {("var(--color-error-main)" if error_text else "var(--color-neutral-main)")};
        margin-top: 4px;
        margin-left: 4px;
    }}
    </style>
    """
    
    # Apply custom CSS
    st.markdown(custom_css, unsafe_allow_html=True)
    
    # Create the radio group with Streamlit
    result = st.radio(
        label,
        options=values,
        index=default_index,
        format_func=format_func,
        horizontal=horizontal,
        disabled=disabled,
        key=key,
        on_change=on_change,
        args=args,
        kwargs=kwargs
    )
    
    # Display helper text or error text
    if error_text:
        st.markdown(f'<div class="helper-text">{error_text}</div>', unsafe_allow_html=True)
    elif helper_text:
        st.markdown(f'<div class="helper-text">{helper_text}</div>', unsafe_allow_html=True)
    
    return result

def material_slider(
    label: str,
    min_value: Union[int, float],
    max_value: Union[int, float],
    value: Optional[Union[int, float]] = None,
    step: Optional[Union[int, float]] = None,
    disabled: bool = False,
    helper_text: Optional[str] = None,
    error_text: Optional[str] = None,
    format: Optional[str] = None,
    key: Optional[str] = None,
    on_change: Optional[Callable] = None,
    args: Optional[Tuple] = None,
    kwargs: Optional[Dict] = None
) -> Union[int, float]:
    """
    Create a Material Design styled slider.
    
    Args:
        label: Label for the slider
        min_value: Minimum value
        max_value: Maximum value
        value: Initial value or (min, max) for a range slider
        step: Step size
        disabled: Whether the slider is disabled
        helper_text: Helper text to display below the slider
        error_text: Error text to display (overrides helper_text)
        format: Format string for the value
        key: Unique key for the component
        on_change: Callback function to execute when value changes
        args: Args to pass to the callback
        kwargs: Kwargs to pass to the callback
        
    Returns:
        The current value of the slider
    """
    # Generate a unique key if not provided
    if key is None:
        key = f"material_slider_{int(time.time() * 1000)}"
    
    # Create custom CSS for the slider
    custom_css = f"""
    <style>
    div[data-testid="stSlider"] > div:first-child > div:nth-child(2) > div[role="slider"] {{
        background-color: var(--color-primary-main);
    }}
    div[data-testid="stSlider"] > div:first-child > div:first-child > div:first-child {{
        background-color: var(--color-primary-light);
    }}
    div[data-testid="stSlider"] > div:first-child > div:first-child > div:nth-child(2) {{
        background-color: var(--color-neutral-light);
    }}
    div[data-testid="stSlider"] > div:first-child > label {{
        color: {("var(--color-error-main)" if error_text else "var(--color-neutral-main)")};
        font-family: {TYPOGRAPHY["body2"]["font-family"]};
        font-size: {TYPOGRAPHY["body2"]["font-size"]};
        font-weight: 500;
    }}
    .helper-text {{
        font-family: {TYPOGRAPHY["caption"]["font-family"]};
        font-size: {TYPOGRAPHY["caption"]["font-size"]};
        color: {("var(--color-error-main)" if error_text else "var(--color-neutral-main)")};
        margin-top: 4px;
        margin-left: 4px;
    }}
    </style>
    """
    
    # Apply custom CSS
    st.markdown(custom_css, unsafe_allow_html=True)
    
    # Create the slider with Streamlit
    result = st.slider(
        label,
        min_value=min_value,
        max_value=max_value,
        value=value,
        step=step,
        format=format,
        disabled=disabled,
        key=key,
        on_change=on_change,
        args=args,
        kwargs=kwargs
    )
    
    # Display helper text or error text
    if error_text:
        st.markdown(f'<div class="helper-text">{error_text}</div>', unsafe_allow_html=True)
    elif helper_text:
        st.markdown(f'<div class="helper-text">{helper_text}</div>', unsafe_allow_html=True)
    
    return result

def material_tabs(
    tabs: Dict[str, Callable],
    key: Optional[str] = None,
    align: str = "left"  # "left", "center", "right"
) -> None:
    """
    Create Material Design styled tabs.
    
    Args:
        tabs: Dictionary mapping tab labels to content functions
        key: Unique key for the component
        align: Alignment of the tabs
    """
    # Generate a unique key if not provided
    if key is None:
        key = f"material_tabs_{int(time.time() * 1000)}"
    
    # Create custom CSS for the tabs
    custom_css = f"""
    <style>
    div[data-testid="stTabs"] > div:first-child {{
        background-color: transparent;
        justify-content: {("flex-start" if align == "left" else "center" if align == "center" else "flex-end")};
    }}
    div[data-testid="stTabs"] > div:first-child > div[role="tab"] {{
        background-color: transparent;
        color: var(--color-neutral-main);
        border-radius: 0;
        border-bottom: 2px solid transparent;
        padding: 1rem 1.5rem;
        font-family: {TYPOGRAPHY["button"]["font-family"]};
        font-weight: {TYPOGRAPHY["button"]["font-weight"]};
        font-size: {TYPOGRAPHY["button"]["font-size"]};
        letter-spacing: {TYPOGRAPHY["button"]["letter-spacing"]};
        text-transform: {TYPOGRAPHY["button"]["text-transform"]};
        transition: all 0.2s ease;
    }}
    div[data-testid="stTabs"] > div:first-child > div[role="tab"][aria-selected="true"] {{
        background-color: transparent;
        color: var(--color-primary-main);
        border-bottom-color: var(--color-primary-main);
        font-weight: 600;
    }}
    div[data-testid="stTabs"] > div:first-child > div[role="tab"]:hover {{
        background-color: rgba(0, 0, 0, 0.05);
        color: var(--color-primary-main);
    }}
    </style>
    """
    
    # Apply custom CSS
    st.markdown(custom_css, unsafe_allow_html=True)
    
    # Create the tabs with Streamlit
    tab_list = st.tabs(list(tabs.keys()))
    
    for i, (tab_name, content_func) in enumerate(tabs.items()):
        with tab_list[i]:
            content_func()

def material_data_table(
    data: Union[pd.DataFrame, Dict[str, List]],
    use_container_width: bool = True,
    hide_index: bool = False,
    column_config: Optional[Dict[str, Dict]] = None,
    key: Optional[str] = None
) -> None:
    """
    Create a Material Design styled data table.
    
    Args:
        data: DataFrame or dictionary of lists
        use_container_width: Whether to use the full container width
        hide_index: Whether to hide the index column
        column_config: Configuration for columns
        key: Unique key for the component
    """
    # Generate a unique key if not provided
    if key is None:
        key = f"material_data_table_{int(time.time() * 1000)}"
    
    # Create custom CSS for the data table
    custom_css = f"""
    <style>
    div[data-testid="stDataFrame"] > div:first-child {{
        border-radius: {BORDER_RADIUS["md"]};
        overflow: hidden;
        border: 1px solid var(--color-neutral-border);
    }}
    div[data-testid="stDataFrame"] > div:first-child > div:first-child {{
        background-color: var(--color-neutral-background);
    }}
    div[data-testid="stDataFrame"] > div:first-child > div:first-child > div:first-child > div:first-child > div:first-child {{
        background-color: var(--color-primary-main);
        color: var(--color-primary-contrast);
        font-family: {TYPOGRAPHY["button"]["font-family"]};
        font-weight: {TYPOGRAPHY["button"]["font-weight"]};
        font-size: {TYPOGRAPHY["button"]["font-size"]};
        letter-spacing: {TYPOGRAPHY["button"]["letter-spacing"]};
    }}
    div[data-testid="stDataFrame"] > div:first-child > div:first-child > div:first-child > div:first-child > div:nth-child(2) {{
        background-color: var(--color-neutral-paper);
        font-family: {TYPOGRAPHY["body2"]["font-family"]};
        font-size: {TYPOGRAPHY["body2"]["font-size"]};
    }}
    div[data-testid="stDataFrame"] > div:first-child > div:first-child > div:first-child > div:first-child > div:nth-child(2) > div:nth-child(odd) {{
        background-color: rgba(0, 0, 0, 0.02);
    }}
    </style>
    """
    
    # Apply custom CSS
    st.markdown(custom_css, unsafe_allow_html=True)
    
    # Create the data table with Streamlit
    st.dataframe(
        data,
        use_container_width=use_container_width,
        hide_index=hide_index,
        column_config=column_config,
        key=key
    )

def material_metric(
    label: str,
    value: Union[int, float, str],
    delta: Optional[Union[int, float, str]] = None,
    delta_color: str = "normal",  # "normal", "inverse", "off"
    help: Optional[str] = None,
    key: Optional[str] = None
) -> None:
    """
    Create a Material Design styled metric.
    
    Args:
        label: Label for the metric
        value: Value to display
        delta: Optional delta value
        delta_color: Color mode for the delta
        help: Optional help text
        key: Unique key for the component
    """
    # Generate a unique key if not provided
    if key is None:
        key = f"material_metric_{int(time.time() * 1000)}"
    
    # Create custom CSS for the metric
    custom_css = f"""
    <style>
    div[data-testid="stMetric"] {{
        background-color: var(--color-neutral-paper);
        border-radius: {BORDER_RADIUS["md"]};
        padding: 1rem;
        box-shadow: {SHADOWS["sm"]};
        transition: all 0.2s ease;
    }}
    div[data-testid="stMetric"]:hover {{
        box-shadow: {SHADOWS["md"]};
        transform: translateY(-2px);
    }}
    div[data-testid="stMetric"] > div:first-child > div:first-child > div:first-child {{
        font-family: {TYPOGRAPHY["h4"]["font-family"]};
        font-weight: {TYPOGRAPHY["h4"]["font-weight"]};
        font-size: {TYPOGRAPHY["h4"]["font-size"]};
        color: var(--color-neutral-dark);
    }}
    div[data-testid="stMetric"] > div:first-child > div:first-child > div:nth-child(2) {{
        font-family: {TYPOGRAPHY["caption"]["font-family"]};
        font-size: {TYPOGRAPHY["caption"]["font-size"]};
        color: var(--color-neutral-main);
    }}
    </style>
    """
    
    # Apply custom CSS
    st.markdown(custom_css, unsafe_allow_html=True)
    
    # Create the metric with Streamlit
    st.metric(
        label=label,
        value=value,
        delta=delta,
        delta_color=delta_color,
        help=help,
        key=key
    )

def material_icon_button(
    icon: str,
    on_click: Optional[Callable] = None,
    args: Optional[Tuple] = None,
    kwargs: Optional[Dict] = None,
    color: str = "primary",
    size: str = "medium",  # "small", "medium", "large"
    tooltip: Optional[str] = None,
    disabled: bool = False,
    key: Optional[str] = None
) -> bool:
    """
    Create a Material Design styled icon button.
    
    Args:
        icon: Material Icons name
        on_click: Callback function to execute when button is clicked
        args: Args to pass to the callback
        kwargs: Kwargs to pass to the callback
        color: Button color theme
        size: Button size
        tooltip: Tooltip text
        disabled: Whether the button is disabled
        key: Unique key for the component
        
    Returns:
        True if the button was clicked, False otherwise
    """
    # Generate a unique key if not provided
    if key is None:
        key = f"material_icon_button_{int(time.time() * 1000)}"
    
    # Get color from theme
    color_value = COLORS.get(color, COLORS["primary"])
    if isinstance(color_value, dict):
        main_color = color_value["main"]
    else:
        main_color = color_value
    
    # Set size based on parameter
    if size == "small":
        icon_size = "18px"
        button_size = "32px"
    elif size == "large":
        icon_size = "32px"
        button_size = "48px"
    else:  # medium
        icon_size = "24px"
        button_size = "40px"
    
    # Create the icon button HTML
    icon_button_html = f"""
    <button
        id="{key}"
        style="
            width: {button_size};
            height: {button_size};
            border-radius: 50%;
            border: none;
            background-color: transparent;
            color: {main_color};
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: {"not-allowed" if disabled else "pointer"};
            opacity: {0.5 if disabled else 1.0};
            transition: background-color 0.2s ease;
        "
        title="{tooltip or ''}"
        {"disabled" if disabled else ""}
    >
        <span class="material-icons" style="font-size: {icon_size};">{icon}</span>
    </button>
    
    <script>
        document.getElementById("{key}").addEventListener("mouseover", function() {{
            if (!this.disabled) {{
                this.style.backgroundColor = "rgba(0, 0, 0, 0.04)";
            }}
        }});
        
        document.getElementById("{key}").addEventListener("mouseout", function() {{
            this.style.backgroundColor = "transparent";
        }});
        
        document.getElementById("{key}").addEventListener("click", function() {{
            if (!this.disabled) {{
                // This will be handled by the Streamlit button
            }}
        }});
    </script>
    """
    
    # Create a hidden button for the click handler
    clicked = st.button(
        "Hidden Button",
        key=f"{key}_hidden",
        on_click=on_click,
        args=args,
        kwargs=kwargs,
        disabled=disabled
    )
    
    # Hide the actual button and show our custom button
    st.markdown(
        f"""
        <style>
        div[data-testid="stButton"] > button[kind="secondary"][data-testid="baseButton-secondary"] {{
            display: none;
        }}
        </style>
        
        {icon_button_html}
        """,
        unsafe_allow_html=True
    )
    
    return clicked

def material_chip(
    label: str,
    color: str = "primary",
    variant: str = "filled",  # "filled", "outlined"
    icon: Optional[str] = None,
    deletable: bool = False,
    on_delete: Optional[Callable] = None,
    key: Optional[str] = None
) -> None:
    """
    Create a Material Design styled chip.
    
    Args:
        label: Text to display on the chip
        color: Chip color theme
        variant: Chip variant
        icon: Optional Material Icons name
        deletable: Whether the chip can be deleted
        on_delete: Callback function to execute when delete is clicked
        key: Unique key for the component
    """
    # Generate a unique key if not provided
    if key is None:
        key = f"material_chip_{int(time.time() * 1000)}"
    
    # Get color from theme
    color_value = COLORS.get(color, COLORS["primary"])
    if isinstance(color_value, dict):
        main_color = color_value["main"]
        light_color = color_value["light"]
        text_color = color_value["contrast"] if variant == "filled" else main_color
    else:
        main_color = color_value
        light_color = color_value
        text_color = "#FFFFFF" if variant == "filled" else main_color
    
    # Set background color based on variant
    background_color = main_color if variant == "filled" else "transparent"
    border = f"1px solid {main_color}" if variant == "outlined" else "none"
    
    # Create the chip HTML
    chip_html = f"""
    <div
        id="{key}"
        style="
            display: inline-flex;
            align-items: center;
            height: 32px;
            border-radius: 16px;
            padding: 0 12px;
            background-color: {background_color};
            color: {text_color};
            font-family: {TYPOGRAPHY["body2"]["font-family"]};
            font-size: {TYPOGRAPHY["body2"]["font-size"]};
            font-weight: 500;
            border: {border};
            margin-right: 8px;
            margin-bottom: 8px;
        "
    >
    """
    
    # Add icon if provided
    if icon:
        chip_html += f"""
        <span class="material-icons" style="font-size: 18px; margin-right: 8px;">{icon}</span>
        """
    
    # Add label
    chip_html += f"""
    <span>{label}</span>
    """
    
    # Add delete button if deletable
    if deletable:
        delete_key = f"{key}_delete"
        chip_html += f"""
        <span
            id="{delete_key}"
            class="material-icons"
            style="
                font-size: 18px;
                margin-left: 8px;
                cursor: pointer;
                opacity: 0.7;
            "
        >
            cancel
        </span>
        
        <script>
            document.getElementById("{delete_key}").addEventListener("mouseover", function() {{
                this.style.opacity = "1.0";
            }});
            
            document.getElementById("{delete_key}").addEventListener("mouseout", function() {{
                this.style.opacity = "0.7";
            }});
            
            document.getElementById("{delete_key}").addEventListener("click", function() {{
                // This will be handled by the Streamlit button
                document.getElementById("{key}").style.display = "none";
            }});
        </script>
        """
    
    # Close the chip div
    chip_html += "</div>"
    
    # Create a hidden button for the delete handler if needed
    if deletable and on_delete:
        delete_clicked = st.button(
            "Hidden Delete Button",
            key=f"{key}_hidden_delete",
            on_click=on_delete
        )
        
        # Hide the actual button
        st.markdown(
            f"""
            <style>
            div[data-testid="stButton"] > button[kind="secondary"][data-testid="baseButton-secondary"] {{
                display: none;
            }}
            </style>
            """,
            unsafe_allow_html=True
        )
    
    # Display the chip
    st.markdown(chip_html, unsafe_allow_html=True)

def material_divider(
    thickness: int = 1,
    color: str = "neutral-border",
    margin: str = "md",
    key: Optional[str] = None
) -> None:
    """
    Create a Material Design styled divider.
    
    Args:
        thickness: Thickness of the divider in pixels
        color: Color of the divider
        margin: Margin size (xs, sm, md, lg, xl, xxl)
        key: Unique key for the component
    """
    # Generate a unique key if not provided
    if key is None:
        key = f"material_divider_{int(time.time() * 1000)}"
    
    # Get color from theme
    if "-" in color:
        color_type, color_shade = color.split("-")
        color_value = COLORS.get(color_type, {}).get(color_shade, COLORS["neutral"]["border"])
    else:
        color_value = COLORS.get(color, {}).get("main", COLORS["neutral"]["border"])
    
    # Get margin value
    margin_value = SPACING.get(margin, SPACING["md"])
    
    # Create the divider HTML
    divider_html = f"""
    <div
        id="{key}"
        style="
            height: {thickness}px;
            background-color: {color_value};
            margin: {margin_value} 0;
            width: 100%;
        "
    ></div>
    """
    
    # Display the divider
    st.markdown(divider_html, unsafe_allow_html=True)

def material_alert(
    message: str,
    severity: str = "info",  # "info", "success", "warning", "error"
    icon: Optional[str] = None,
    dismissible: bool = False,
    on_dismiss: Optional[Callable] = None,
    key: Optional[str] = None
) -> None:
    """
    Create a Material Design styled alert.
    
    Args:
        message: Alert message
        severity: Alert severity
        icon: Optional Material Icons name (overrides default icon)
        dismissible: Whether the alert can be dismissed
        on_dismiss: Callback function to execute when alert is dismissed
        key: Unique key for the component
    """
    # Generate a unique key if not provided
    if key is None:
        key = f"material_alert_{int(time.time() * 1000)}"
    
    # Map severity to color and default icon
    severity_map = {
        "info": {"color": COLORS["info"]["main"], "bg_color": f"rgba({int(COLORS['info']['main'][1:3], 16)}, {int(COLORS['info']['main'][3:5], 16)}, {int(COLORS['info']['main'][5:7], 16)}, 0.1)", "icon": "info"},
        "success": {"color": COLORS["success"]["main"], "bg_color": f"rgba({int(COLORS['success']['main'][1:3], 16)}, {int(COLORS['success']['main'][3:5], 16)}, {int(COLORS['success']['main'][5:7], 16)}, 0.1)", "icon": "check_circle"},
        "warning": {"color": COLORS["warning"]["main"], "bg_color": f"rgba({int(COLORS['warning']['main'][1:3], 16)}, {int(COLORS['warning']['main'][3:5], 16)}, {int(COLORS['warning']['main'][5:7], 16)}, 0.1)", "icon": "warning"},
        "error": {"color": COLORS["error"]["main"], "bg_color": f"rgba({int(COLORS['error']['main'][1:3], 16)}, {int(COLORS['error']['main'][3:5], 16)}, {int(COLORS['error']['main'][5:7], 16)}, 0.1)", "icon": "error"}
    }
    
    color = severity_map.get(severity, severity_map["info"])["color"]
    bg_color = severity_map.get(severity, severity_map["info"])["bg_color"]
    default_icon = severity_map.get(severity, severity_map["info"])["icon"]
    
    # Use provided icon or default
    icon = icon or default_icon
    
    # Create the alert HTML
    alert_html = f"""
    <div
        id="{key}"
        style="
            display: flex;
            align-items: flex-start;
            padding: 16px;
            border-radius: {BORDER_RADIUS["md"]};
            background-color: {bg_color};
            color: {color};
            margin-bottom: 16px;
        "
    >
        <span class="material-icons" style="margin-right: 12px;">{icon}</span>
        <div style="flex: 1; font-family: {TYPOGRAPHY["body1"]["font-family"]}; font-size: {TYPOGRAPHY["body1"]["font-size"]};">
            {message}
        </div>
    """
    
    # Add dismiss button if dismissible
    if dismissible:
        dismiss_key = f"{key}_dismiss"
        alert_html += f"""
        <span
            id="{dismiss_key}"
            class="material-icons"
            style="
                cursor: pointer;
                opacity: 0.7;
            "
        >
            close
        </span>
        
        <script>
            document.getElementById("{dismiss_key}").addEventListener("mouseover", function() {{
                this.style.opacity = "1.0";
            }});
            
            document.getElementById("{dismiss_key}").addEventListener("mouseout", function() {{
                this.style.opacity = "0.7";
            }});
            
            document.getElementById("{dismiss_key}").addEventListener("click", function() {{
                // This will be handled by the Streamlit button
                document.getElementById("{key}").style.display = "none";
            }});
        </script>
        """
    
    # Close the alert div
    alert_html += "</div>"
    
    # Create a hidden button for the dismiss handler if needed
    if dismissible and on_dismiss:
        dismiss_clicked = st.button(
            "Hidden Dismiss Button",
            key=f"{key}_hidden_dismiss",
            on_click=on_dismiss
        )
        
        # Hide the actual button
        st.markdown(
            f"""
            <style>
            div[data-testid="stButton"] > button[kind="secondary"][data-testid="baseButton-secondary"] {{
                display: none;
            }}
            </style>
            """,
            unsafe_allow_html=True
        )
    
    # Display the alert
    st.markdown(alert_html, unsafe_allow_html=True)

def material_progress(
    value: float,
    label: Optional[str] = None,
    color: str = "primary",
    height: int = 4,
    show_percentage: bool = False,
    key: Optional[str] = None
) -> None:
    """
    Create a Material Design styled progress bar.
    
    Args:
        value: Progress value between 0.0 and 1.0
        label: Optional label to display above the progress bar
        color: Progress bar color theme
        height: Height of the progress bar in pixels
        show_percentage: Whether to show percentage text
        key: Unique key for the component
    """
    # Generate a unique key if not provided
    if key is None:
        key = f"material_progress_{int(time.time() * 1000)}"
    
    # Ensure value is between 0 and 1
    value = max(0.0, min(1.0, value))
    
    # Get color from theme
    color_value = COLORS.get(color, COLORS["primary"])
    if isinstance(color_value, dict):
        main_color = color_value["main"]
    else:
        main_color = color_value
    
    # Create the progress bar HTML
    progress_html = ""
    
    # Add label if provided
    if label:
        progress_html += f"""
        <div style="
            font-family: {TYPOGRAPHY["body2"]["font-family"]};
            font-size: {TYPOGRAPHY["body2"]["font-size"]};
            color: var(--color-neutral-main);
            margin-bottom: 4px;
            display: flex;
            justify-content: space-between;
        ">
            <span>{label}</span>
            {f"<span>{int(value * 100)}%</span>" if show_percentage else ""}
        </div>
        """
    
    # Add progress bar
    progress_html += f"""
    <div
        id="{key}"
        style="
            width: 100%;
            height: {height}px;
            background-color: var(--color-neutral-border);
            border-radius: {height // 2}px;
            overflow: hidden;
            margin-bottom: {16 if show_percentage and not label else 0}px;
        "
    >
        <div style="
            width: {value * 100}%;
            height: 100%;
            background-color: {main_color};
            transition: width 0.3s ease;
        "></div>
    </div>
    """
    
    # Add percentage text if requested and no label
    if show_percentage and not label:
        progress_html += f"""
        <div style="
            font-family: {TYPOGRAPHY["caption"]["font-family"]};
            font-size: {TYPOGRAPHY["caption"]["font-size"]};
            color: var(--color-neutral-main);
            text-align: right;
            margin-top: 4px;
        ">
            {int(value * 100)}%
        </div>
        """
    
    # Display the progress bar
    st.markdown(progress_html, unsafe_allow_html=True)

def material_badge(
    content_func: Callable,
    count: int,
    max_count: int = 99,
    color: str = "error",
    position: str = "top-right",  # "top-right", "top-left", "bottom-right", "bottom-left"
    dot: bool = False,
    key: Optional[str] = None
) -> None:
    """
    Create a Material Design styled badge.
    
    Args:
        content_func: Function that renders the content to badge
        count: Badge count
        max_count: Maximum count to display before showing "+"
        color: Badge color theme
        position: Position of the badge
        dot: Whether to show a dot instead of count
        key: Unique key for the component
    """
    # Generate a unique key if not provided
    if key is None:
        key = f"material_badge_{int(time.time() * 1000)}"
    
    # Get color from theme
    color_value = COLORS.get(color, COLORS["error"])
    if isinstance(color_value, dict):
        main_color = color_value["main"]
        text_color = color_value["contrast"]
    else:
        main_color = color_value
        text_color = "#FFFFFF"
    
    # Determine badge position
    position_style = ""
    if position == "top-right":
        position_style = "top: -8px; right: -8px;"
    elif position == "top-left":
        position_style = "top: -8px; left: -8px;"
    elif position == "bottom-right":
        position_style = "bottom: -8px; right: -8px;"
    elif position == "bottom-left":
        position_style = "bottom: -8px; left: -8px;"
    
    # Determine badge content
    if dot:
        badge_content = ""
        badge_size = "width: 8px; height: 8px; min-width: 8px;"
    else:
        display_count = f"{count}+" if count > max_count else str(count)
        badge_content = display_count
        badge_size = "min-width: 20px; height: 20px; padding: 0 6px;"
    
    # Create the badge HTML
    badge_html = f"""
    <style>
    .badge-container-{key} {{
        position: relative;
        display: inline-flex;
    }}
    
    .badge-{key} {{
        position: absolute;
        {position_style}
        {badge_size}
        border-radius: 10px;
        background-color: {main_color};
        color: {text_color};
        font-family: {TYPOGRAPHY["caption"]["font-family"]};
        font-size: 0.75rem;
        font-weight: 500;
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 1;
    }}
    </style>
    
    <div class="badge-container-{key}">
        <div class="badge-{key}">{badge_content}</div>
    """
    
    # Apply the badge HTML
    st.markdown(badge_html, unsafe_allow_html=True)
    
    # Render the content
    content_func()
    
    # Close the badge container
    st.markdown("</div>", unsafe_allow_html=True)

def material_tooltip(
    content_func: Callable,
    tooltip_text: str,
    position: str = "top",  # "top", "bottom", "left", "right"
    key: Optional[str] = None
) -> None:
    """
    Create a Material Design styled tooltip.
    
    Args:
        content_func: Function that renders the content to add tooltip to
        tooltip_text: Text to display in the tooltip
        position: Position of the tooltip
        key: Unique key for the component
    """
    # Generate a unique key if not provided
    if key is None:
        key = f"material_tooltip_{int(time.time() * 1000)}"
    
    # Create the tooltip HTML
    tooltip_html = f"""
    <style>
    .tooltip-container-{key} {{
        position: relative;
        display: inline-block;
    }}
    
    .tooltip-container-{key} .tooltip-{key} {{
        visibility: hidden;
        background-color: rgba(97, 97, 97, 0.9);
        color: #fff;
        text-align: center;
        border-radius: 4px;
        padding: 8px 16px;
        position: absolute;
        z-index: 1;
        font-family: {TYPOGRAPHY["caption"]["font-family"]};
        font-size: {TYPOGRAPHY["caption"]["font-size"]};
        line-height: 1.4;
        white-space: nowrap;
        
        /* Position the tooltip */
        {
            "bottom: 125%; left: 50%; transform: translateX(-50%);" if position == "top" else
            "top: 125%; left: 50%; transform: translateX(-50%);" if position == "bottom" else
            "top: 50%; right: 125%; transform: translateY(-50%);" if position == "left" else
            "top: 50%; left: 125%; transform: translateY(-50%);" if position == "right" else
            "bottom: 125%; left: 50%; transform: translateX(-50%);"
        }
        
        /* Fade in transition */
        opacity: 0;
        transition: opacity 0.3s;
    }}
    
    .tooltip-container-{key}:hover .tooltip-{key} {{
        visibility: visible;
        opacity: 1;
    }}
    
    /* Arrow */
    .tooltip-container-{key} .tooltip-{key}::after {{
        content: "";
        position: absolute;
        border-width: 5px;
        border-style: solid;
        
        /* Position the arrow */
        {
            "top: 100%; left: 50%; margin-left: -5px; border-color: rgba(97, 97, 97, 0.9) transparent transparent transparent;" if position == "top" else
            "bottom: 100%; left: 50%; margin-left: -5px; border-color: transparent transparent rgba(97, 97, 97, 0.9) transparent;" if position == "bottom" else
            "top: 50%; left: 100%; margin-top: -5px; border-color: transparent transparent transparent rgba(97, 97, 97, 0.9);" if position == "left" else
            "top: 50%; right: 100%; margin-top: -5px; border-color: transparent rgba(97, 97, 97, 0.9) transparent transparent;" if position == "right" else
            "top: 100%; left: 50%; margin-left: -5px; border-color: rgba(97, 97, 97, 0.9) transparent transparent transparent;"
        }
    }}
    </style>
    
    <div class="tooltip-container-{key}">
        <div class="tooltip-{key}">{tooltip_text}</div>
    """
    
    # Apply the tooltip HTML
    st.markdown(tooltip_html, unsafe_allow_html=True)
    
    # Render the content
    content_func()
    
    # Close the tooltip container
    st.markdown("</div>", unsafe_allow_html=True)

def material_avatar(
    text: Optional[str] = None,
    image: Optional[str] = None,
    icon: Optional[str] = None,
    size: str = "medium",  # "small", "medium", "large"
    color: str = "primary",
    variant: str = "circular",  # "circular", "rounded", "square"
    key: Optional[str] = None
) -> None:
    """
    Create a Material Design styled avatar.
    
    Args:
        text: Text to display in the avatar
        image: URL or path to image
        icon: Material Icons name
        size: Avatar size
        color: Avatar color theme
        variant: Avatar shape
        key: Unique key for the component
    """
    # Generate a unique key if not provided
    if key is None:
        key = f"material_avatar_{int(time.time() * 1000)}"
    
    # Get color from theme
    color_value = COLORS.get(color, COLORS["primary"])
    if isinstance(color_value, dict):
        main_color = color_value["main"]
        text_color = color_value["contrast"]
    else:
        main_color = color_value
        text_color = "#FFFFFF"
    
    # Set size based on parameter
    if size == "small":
        avatar_size = "32px"
        font_size = "0.875rem"
        icon_size = "16px"
    elif size == "large":
        avatar_size = "56px"
        font_size = "1.5rem"
        icon_size = "32px"
    else:  # medium
        avatar_size = "40px"
        font_size = "1.25rem"
        icon_size = "24px"
    
    # Set border radius based on variant
    if variant == "circular":
        border_radius = "50%"
    elif variant == "rounded":
        border_radius = "4px"
    else:  # square
        border_radius = "0"
    
    # Create the avatar HTML
    avatar_html = f"""
    <div
        id="{key}"
        style="
            width: {avatar_size};
            height: {avatar_size};
            border-radius: {border_radius};
            display: inline-flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            background-color: {main_color if not image else "transparent"};
            color: {text_color};
            font-family: {TYPOGRAPHY["body1"]["font-family"]};
            font-size: {font_size};
            font-weight: 500;
        "
    >
    """
    
    # Add content based on what's provided
    if image:
        avatar_html += f"""
        <img
            src="{image}"
            style="
                width: 100%;
                height: 100%;
                object-fit: cover;
            "
            alt="Avatar"
        />
        """
    elif icon:
        avatar_html += f"""
        <span class="material-icons" style="font-size: {icon_size};">{icon}</span>
        """
    elif text:
        # Use first letter if text is provided
        display_text = text[0].upper() if text else ""
        avatar_html += display_text
    
    # Close the avatar div
    avatar_html += "</div>"
    
    # Display the avatar
    st.markdown(avatar_html, unsafe_allow_html=True)

def material_list(
    items: List[Dict[str, Any]],
    dense: bool = False,
    dividers: bool = True,
    key: Optional[str] = None
) -> None:
    """
    Create a Material Design styled list.
    
    Args:
        items: List of item dictionaries with keys:
            - text: Primary text
            - secondary_text: Optional secondary text
            - icon: Optional Material Icons name
            - avatar: Optional avatar configuration
            - action: Optional action button or switch
        dense: Whether to use dense spacing
        dividers: Whether to show dividers between items
        key: Unique key for the component
    """
    # Generate a unique key if not provided
    if key is None:
        key = f"material_list_{int(time.time() * 1000)}"
    
    # Create the list HTML
    list_html = f"""
    <div
        id="{key}"
        style="
            border: 1px solid var(--color-neutral-border);
            border-radius: {BORDER_RADIUS["md"]};
            overflow: hidden;
            background-color: var(--color-neutral-paper);
        "
    >
    """
    
    # Add list items
    for i, item in enumerate(items):
        # Get item properties
        text = item.get("text", "")
        secondary_text = item.get("secondary_text", "")
        icon = item.get("icon", "")
        avatar_config = item.get("avatar", {})
        
        # Set padding based on density
        padding = "8px 16px" if dense else "16px"
        
        # Create list item
        list_html += f"""
        <div
            style="
                display: flex;
                align-items: {("flex-start" if secondary_text else "center")};
                padding: {padding};
                {f"border-bottom: 1px solid var(--color-neutral-border);" if dividers and i < len(items) - 1 else ""}
            "
        >
        """
        
        # Add avatar or icon
        if avatar_config:
            avatar_text = avatar_config.get("text", "")
            avatar_image = avatar_config.get("image", "")
            avatar_icon = avatar_config.get("icon", "")
            avatar_color = avatar_config.get("color", "primary")
            avatar_size = avatar_config.get("size", "small")
            
            list_html += f"""
            <div style="margin-right: 16px;">
                <div
                    style="
                        width: {("24px" if avatar_size == "small" else "40px" if avatar_size == "medium" else "56px")};
                        height: {("24px" if avatar_size == "small" else "40px" if avatar_size == "medium" else "56px")};
                        border-radius: 50%;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        overflow: hidden;
                        background-color: {COLORS.get(avatar_color, COLORS["primary"]).get("main", COLORS["primary"]["main"]) if not avatar_image else "transparent"};
                        color: {COLORS.get(avatar_color, COLORS["primary"]).get("contrast", COLORS["primary"]["contrast"])};
                        font-family: {TYPOGRAPHY["body1"]["font-family"]};
                        font-size: {("0.75rem" if avatar_size == "small" else "1rem" if avatar_size == "medium" else "1.25rem")};
                        font-weight: 500;
                    "
                >
                """
                
            if avatar_image:
                list_html += f"""
                <img
                    src="{avatar_image}"
                    style="
                        width: 100%;
                        height: 100%;
                        object-fit: cover;
                    "
                    alt="Avatar"
                />
                """
            elif avatar_icon:
                list_html += f"""
                <span class="material-icons" style="font-size: {("16px" if avatar_size == "small" else "24px" if avatar_size == "medium" else "32px")};">{avatar_icon}</span>
                """
            elif avatar_text:
                # Use first letter if text is provided
                display_text = avatar_text[0].upper() if avatar_text else ""
                list_html += display_text
                
            list_html += """
                </div>
            </div>
            """
        elif icon:
            list_html += f"""
            <div style="margin-right: 16px;">
                <span class="material-icons" style="color: var(--color-neutral-main);">{icon}</span>
            </div>
            """
        
        # Add text content
        list_html += f"""
        <div style="flex: 1; min-width: 0;">
            <div style="
                font-family: {TYPOGRAPHY["body1"]["font-family"]};
                font-size: {TYPOGRAPHY["body1"]["font-size"]};
                color: var(--color-neutral-dark);
                {("margin-bottom: 4px;" if secondary_text else "")}
            ">
                {text}
            </div>
        """
        
        if secondary_text:
            list_html += f"""
            <div style="
                font-family: {TYPOGRAPHY["body2"]["font-family"]};
                font-size: {TYPOGRAPHY["body2"]["font-size"]};
                color: var(--color-neutral-main);
            ">
                {secondary_text}
            </div>
            """
        
        list_html += "</div>"
        
        # Add action if provided
        action = item.get("action", {})
        if action:
            action_type = action.get("type", "")
            action_icon = action.get("icon", "")
            
            if action_type == "icon" and action_icon:
                list_html += f"""
                <div style="margin-left: 16px;">
                    <span class="material-icons" style="color: var(--color-neutral-main); cursor: pointer;">{action_icon}</span>
                </div>
                """
            elif action_type == "switch":
                checked = action.get("checked", False)
                list_html += f"""
                <div style="margin-left: 16px;">
                    <div style="
                        width: 36px;
                        height: 20px;
                        border-radius: 10px;
                        background-color: {("var(--color-primary-main)" if checked else "var(--color-neutral-light)")};
                        position: relative;
                        transition: background-color 0.3s;
                        cursor: pointer;
                    ">
                        <div style="
                            width: 16px;
                            height: 16px;
                            border-radius: 50%;
                            background-color: white;
                            position: absolute;
                            top: 2px;
                            {("right: 2px" if checked else "left: 2px")};
                            transition: left 0.3s, right 0.3s;
                        "></div>
                    </div>
                </div>
                """
        
        # Close list item
        list_html += "</div>"
    
    # Close the list
    list_html += "</div>"
    
    # Display the list
    st.markdown(list_html, unsafe_allow_html=True)

def demo_material_components():
    """
    Demonstrate all Material UI components.
    """
    st.title("Material UI Components Demo")
    
    # Load Material Icons
    load_material_icons()
    
    # Buttons
    st.header("Buttons")
    col1, col2, col3 = st.columns(3)
    
    with col1:
        material_button("Contained Button", type="contained", icon="send")
    
    with col2:
        material_button("Outlined Button", type="outlined", icon="edit", color="secondary")
    
    with col3:
        material_button("Text Button", type="text", icon="delete", color="error", icon_position="right")
    
    # Cards
    st.header("Cards")
    col1, col2 = st.columns(2)
    
    with col1:
        def card_content():
            st.write("This is a basic card with title and content.")
            material_button("Card Action", type="contained", size="small")
        
        material_card(
            title="Basic Card",
            subtitle="Card subtitle",
            content_func=card_content,
            footer="Last updated: April 21, 2025"
        )
    
    with col2:
        def card_content2():
            st.write("This is an outlined card with elevation.")
            st.write("Cards can contain any Streamlit elements.")
        
        material_card(
            title="Outlined Card",
            content_func=card_content2,
            outlined=True,
            elevation=0
        )
    
    # Text Fields
    st.header("Text Fields")
    col1, col2 = st.columns(2)
    
    with col1:
        material_text_field(
            "Standard Input",
            placeholder="Enter text here",
            helper_text="Helper text provides additional information"
        )
        
        material_text_field(
            "Password Input",
            type="password",
            placeholder="Enter password"
        )
    
    with col2:
        material_text_field(
            "Error Input",
            value="Invalid value",
            error_text="This field has an error"
        )
        
        material_text_field(
            "Disabled Input",
            value="Cannot edit this",
            disabled=True
        )
    
    # Select and Checkboxes
    st.header("Select and Checkboxes")
    col1, col2 = st.columns(2)
    
    with col1:
        material_select(
            "Select Option",
            options=[
                ("option1", "Option 1"),
                ("option2", "Option 2"),
                ("option3", "Option 3")
            ],
            helper_text="Select one option"
        )
    
    with col2:
        material_checkbox("Enable feature", value=True)
        material_checkbox("Disabled option", disabled=True)
        material_checkbox("With helper text", helper_text="This is additional information")
    
    # Radio Buttons and Sliders
    st.header("Radio Buttons and Sliders")
    col1, col2 = st.columns(2)
    
    with col1:
        material_radio(
            "Select Option",
            options=["Option 1", "Option 2", "Option 3"],
            helper_text="Select one option"
        )
    
    with col2:
        material_slider(
            "Adjust Value",
            min_value=0,
            max_value=100,
            value=50,
            helper_text="Drag to adjust"
        )
    
    # Tabs
    st.header("Tabs")
    
    def tab1_content():
        st.write("This is the content of Tab 1")
        material_button("Tab 1 Action", type="contained", size="small")
    
    def tab2_content():
        st.write("This is the content of Tab 2")
        material_checkbox("Tab 2 Option")
    
    def tab3_content():
        st.write("This is the content of Tab 3")
        material_text_field("Tab 3 Input")
    
    material_tabs({
        "Tab 1": tab1_content,
        "Tab 2": tab2_content,
        "Tab 3": tab3_content
    })
    
    # Data Table
    st.header("Data Table")
    
    import pandas as pd
    import numpy as np
    
    # Create sample data
    data = pd.DataFrame({
        "Name": ["John Doe", "Jane Smith", "Bob Johnson"],
        "Age": [32, 28, 45],
        "Status": ["Active", "Pending", "Inactive"]
    })
    
    material_data_table(data, hide_index=True)
    
    # Metrics
    st.header("Metrics")
    col1, col2, col3 = st.columns(3)
    
    with col1:
        material_metric("Revenue", "$12,345", delta="$1,234")
    
    with col2:
        material_metric("Conversion Rate", "4.5%", delta="-0.5%", delta_color="inverse")
    
    with col3:
        material_metric("Active Users", "1,234", delta="12%")
    
    # Icon Buttons
    st.header("Icon Buttons")
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        material_icon_button("add", tooltip="Add item")
    
    with col2:
        material_icon_button("edit", color="secondary", tooltip="Edit")
    
    with col3:
        material_icon_button("delete", color="error", tooltip="Delete")
    
    with col4:
        material_icon_button("settings", disabled=True, tooltip="Settings (disabled)")
    
    # Chips
    st.header("Chips")
    col1, col2 = st.columns(2)
    
    with col1:
        material_chip("Basic Chip")
        material_chip("Primary Chip", color="primary")
        material_chip("Success Chip", color="success", icon="check")
    
    with col2:
        material_chip("Outlined Chip", variant="outlined")
        material_chip("Warning Chip", color="warning", variant="outlined")
        material_chip("Deletable Chip", deletable=True)
    
    # Divider
    st.header("Divider")
    material_divider()
    
    # Alerts
    st.header("Alerts")
    material_alert("This is an info alert", severity="info")
    material_alert("This is a success alert", severity="success")
    material_alert("This is a warning alert", severity="warning")
    material_alert("This is an error alert", severity="error", dismissible=True)
    
    # Progress
    st.header("Progress")
    col1, col2 = st.columns(2)
    
    with col1:
        material_progress(0.3, label="Basic Progress", show_percentage=True)
    
    with col2:
        material_progress(0.7, label="Custom Color", color="success", show_percentage=True)
    
    # Badge
    st.header("Badge")
    col1, col2, col3 = st.columns(3)
    
    with col1:
        def badge_content1():
            material_icon_button("mail", size="large")
        
        material_badge(badge_content1, count=5)
    
    with col2:
        def badge_content2():
            material_icon_button("notifications", size="large")
        
        material_badge(badge_content2, count=99, max_count=99)
    
    with col3:
        def badge_content3():
            material_icon_button("shopping_cart", size="large")
        
        material_badge(badge_content3, count=0, dot=True)
    
    # Tooltip
    st.header("Tooltip")
    col1, col2, col3 = st.columns(3)
    
    with col1:
        def tooltip_content1():
            material_button("Hover Me", type="contained")
        
        material_tooltip(tooltip_content1, "This is a tooltip")
    
    with col2:
        def tooltip_content2():
            material_icon_button("info")
        
        material_tooltip(tooltip_content2, "Important information", position="right")
    
    with col3:
        def tooltip_content3():
            st.write("Hover over this text")
        
        material_tooltip(tooltip_content3, "Text tooltip", position="bottom")
    
    # Avatar
    st.header("Avatar")
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        material_avatar(text="JD")
    
    with col2:
        material_avatar(icon="person", color="secondary")
    
    with col3:
        material_avatar(text="AB", size="large", color="success")
    
    with col4:
        material_avatar(icon="star", variant="rounded", color="warning")
    
    # List
    st.header("List")
    
    material_list([
        {
            "text": "Inbox",
            "icon": "inbox",
            "action": {"type": "icon", "icon": "chevron_right"}
        },
        {
            "text": "John Doe",
            "secondary_text": "Meeting scheduled for tomorrow",
            "avatar": {"text": "JD", "color": "primary"},
            "action": {"type": "icon", "icon": "star_border"}
        },
        {
            "text": "Dark Mode",
            "icon": "dark_mode",
            "action": {"type": "switch", "checked": True}
        },
        {
            "text": "Jane Smith",
            "secondary_text": "Sent you a file",
            "avatar": {"icon": "person", "color": "secondary"},
            "action": {"type": "icon", "icon": "download"}
        }
    ])

if __name__ == "__main__":
    # This will run when the script is executed directly
    st.set_page_config(page_title="Material UI Demo", layout="wide")
    demo_material_components()
