"""
Responsive layout system for the OPSC Sandwich Quality Inspection System.

This module provides responsive layout components and utilities that adapt
to different screen sizes and device types, ensuring a consistent user experience
across desktop, tablet, and mobile devices.
"""

import streamlit as st
from typing import Dict, List, Optional, Callable, Union, Tuple, Any
import time
from src.ui.components.design_system import BREAKPOINTS

def responsive_container(
    content_func: Callable,
    desktop_styles: Dict[str, str] = {},
    tablet_styles: Dict[str, str] = {},
    mobile_styles: Dict[str, str] = {},
    key: Optional[str] = None
):
    """
    Create a responsive container that adapts to different screen sizes.
    
    Args:
        content_func: Function that renders the container content
        desktop_styles: CSS styles for desktop screens (>= 1280px)
        tablet_styles: CSS styles for tablet screens (>= 600px and < 1280px)
        mobile_styles: CSS styles for mobile screens (< 600px)
        key: Unique key for the component
    """
    # Generate a unique key if not provided
    if key is None:
        key = f"responsive_container_{int(time.time() * 1000)}"
    
    # Convert style dictionaries to CSS strings
    desktop_css = "; ".join([f"{k}: {v}" for k, v in desktop_styles.items()])
    tablet_css = "; ".join([f"{k}: {v}" for k, v in tablet_styles.items()])
    mobile_css = "; ".join([f"{k}: {v}" for k, v in mobile_styles.items()])
    
    # Create responsive CSS
    css = f"""
    <style>
    .responsive-container-{key} {{
        {desktop_css}
    }}
    
    /* Tablet styles */
    @media (max-width: 1279px) and (min-width: 600px) {{
        .responsive-container-{key} {{
            {tablet_css}
        }}
    }}
    
    /* Mobile styles */
    @media (max-width: 599px) {{
        .responsive-container-{key} {{
            {mobile_css}
        }}
    }}
    </style>
    """
    
    # Apply CSS
    st.markdown(css, unsafe_allow_html=True)
    
    # Create container
    st.markdown(f'<div class="responsive-container-{key}">', unsafe_allow_html=True)
    
    # Render content
    content_func()
    
    # Close container
    st.markdown('</div>', unsafe_allow_html=True)

def responsive_grid(
    items: List[Callable],
    desktop_columns: int = 4,
    tablet_columns: int = 2,
    mobile_columns: int = 1,
    gap: str = "16px",
    key: Optional[str] = None
):
    """
    Create a responsive grid layout that adapts to different screen sizes.
    
    Args:
        items: List of functions that render grid items
        desktop_columns: Number of columns on desktop screens
        tablet_columns: Number of columns on tablet screens
        mobile_columns: Number of columns on mobile screens
        gap: Gap between grid items
        key: Unique key for the component
    """
    # Generate a unique key if not provided
    if key is None:
        key = f"responsive_grid_{int(time.time() * 1000)}"
    
    # Create CSS for responsive grid
    css = f"""
    <style>
    .responsive-grid-{key} {{
        display: grid;
        grid-template-columns: repeat({desktop_columns}, 1fr);
        gap: {gap};
        width: 100%;
    }}
    
    /* Tablet styles */
    @media (max-width: 1279px) and (min-width: 600px) {{
        .responsive-grid-{key} {{
            grid-template-columns: repeat({tablet_columns}, 1fr);
        }}
    }}
    
    /* Mobile styles */
    @media (max-width: 599px) {{
        .responsive-grid-{key} {{
            grid-template-columns: repeat({mobile_columns}, 1fr);
        }}
    }}
    </style>
    """
    
    # Apply CSS
    st.markdown(css, unsafe_allow_html=True)
    
    # Create grid container
    st.markdown(f'<div class="responsive-grid-{key}">', unsafe_allow_html=True)
    
    # Render grid items
    for i, item_func in enumerate(items):
        st.markdown(f'<div class="grid-item-{key}-{i}">', unsafe_allow_html=True)
        item_func()
        st.markdown('</div>', unsafe_allow_html=True)
    
    # Close grid container
    st.markdown('</div>', unsafe_allow_html=True)

def responsive_columns(
    content_funcs: List[Callable],
    desktop_widths: List[int],
    tablet_widths: Optional[List[int]] = None,
    mobile_widths: Optional[List[int]] = None,
    gap: str = "16px",
    key: Optional[str] = None
):
    """
    Create responsive columns that adapt to different screen sizes.
    
    Args:
        content_funcs: List of functions that render column content
        desktop_widths: List of column widths for desktop screens (in percentage or fr units)
        tablet_widths: Optional list of column widths for tablet screens
        mobile_widths: Optional list of column widths for mobile screens
        gap: Gap between columns
        key: Unique key for the component
    """
    # Generate a unique key if not provided
    if key is None:
        key = f"responsive_columns_{int(time.time() * 1000)}"
    
    # Set default tablet and mobile widths if not provided
    if tablet_widths is None:
        # Default to 2 columns on tablet
        tablet_widths = []
        for i, _ in enumerate(content_funcs):
            if i % 2 == 0 and i < len(content_funcs) - 1:
                tablet_widths.append(50)
            elif i % 2 == 1:
                tablet_widths.append(50)
            else:
                tablet_widths.append(100)
    
    if mobile_widths is None:
        # Default to 1 column on mobile
        mobile_widths = [100] * len(content_funcs)
    
    # Ensure all width lists have the same length
    if len(desktop_widths) != len(content_funcs) or len(tablet_widths) != len(content_funcs) or len(mobile_widths) != len(content_funcs):
        raise ValueError("Width lists must have the same length as content_funcs")
    
    # Convert percentage widths to CSS grid template
    desktop_template = " ".join([f"{w}fr" for w in desktop_widths])
    tablet_template = " ".join([f"{w}fr" for w in tablet_widths])
    mobile_template = " ".join([f"{w}fr" for w in mobile_widths])
    
    # Create CSS for responsive columns
    css = f"""
    <style>
    .responsive-columns-{key} {{
        display: grid;
        grid-template-columns: {desktop_template};
        gap: {gap};
        width: 100%;
    }}
    
    /* Tablet styles */
    @media (max-width: 1279px) and (min-width: 600px) {{
        .responsive-columns-{key} {{
            grid-template-columns: {tablet_template};
        }}
    }}
    
    /* Mobile styles */
    @media (max-width: 599px) {{
        .responsive-columns-{key} {{
            grid-template-columns: {mobile_template};
        }}
    }}
    </style>
    """
    
    # Apply CSS
    st.markdown(css, unsafe_allow_html=True)
    
    # Create columns container
    st.markdown(f'<div class="responsive-columns-{key}">', unsafe_allow_html=True)
    
    # Render column content
    for i, content_func in enumerate(content_funcs):
        st.markdown(f'<div class="column-{key}-{i}">', unsafe_allow_html=True)
        content_func()
        st.markdown('</div>', unsafe_allow_html=True)
    
    # Close columns container
    st.markdown('</div>', unsafe_allow_html=True)

def responsive_card(
    content_func: Callable,
    title: Optional[str] = None,
    subtitle: Optional[str] = None,
    footer: Optional[Union[str, Callable]] = None,
    desktop_styles: Dict[str, str] = {},
    tablet_styles: Dict[str, str] = {},
    mobile_styles: Dict[str, str] = {},
    key: Optional[str] = None
):
    """
    Create a responsive card that adapts to different screen sizes.
    
    Args:
        content_func: Function that renders the card content
        title: Optional title for the card
        subtitle: Optional subtitle for the card
        footer: Optional footer for the card (string or function)
        desktop_styles: CSS styles for desktop screens
        tablet_styles: CSS styles for tablet screens
        mobile_styles: CSS styles for mobile screens
        key: Unique key for the component
    """
    # Generate a unique key if not provided
    if key is None:
        key = f"responsive_card_{int(time.time() * 1000)}"
    
    # Default styles
    default_desktop_styles = {
        "background-color": "var(--color-neutral-paper)",
        "border-radius": "var(--radius-md)",
        "box-shadow": "var(--shadow-md)",
        "overflow": "hidden",
        "margin-bottom": "var(--spacing-md)"
    }
    
    default_tablet_styles = {}
    
    default_mobile_styles = {
        "margin-bottom": "var(--spacing-sm)"
    }
    
    # Merge default styles with provided styles
    desktop_styles = {**default_desktop_styles, **desktop_styles}
    tablet_styles = {**default_tablet_styles, **tablet_styles}
    mobile_styles = {**default_mobile_styles, **mobile_styles}
    
    # Convert style dictionaries to CSS strings
    desktop_css = "; ".join([f"{k}: {v}" for k, v in desktop_styles.items()])
    tablet_css = "; ".join([f"{k}: {v}" for k, v in tablet_styles.items()])
    mobile_css = "; ".join([f"{k}: {v}" for k, v in mobile_styles.items()])
    
    # Create responsive CSS
    css = f"""
    <style>
    .responsive-card-{key} {{
        {desktop_css}
    }}
    
    /* Tablet styles */
    @media (max-width: 1279px) and (min-width: 600px) {{
        .responsive-card-{key} {{
            {tablet_css}
        }}
    }}
    
    /* Mobile styles */
    @media (max-width: 599px) {{
        .responsive-card-{key} {{
            {mobile_css}
        }}
    }}
    
    .card-header-{key} {{
        padding: var(--spacing-md);
        border-bottom: 1px solid var(--color-neutral-border);
    }}
    
    .card-content-{key} {{
        padding: var(--spacing-md);
    }}
    
    .card-footer-{key} {{
        padding: var(--spacing-md);
        border-top: 1px solid var(--color-neutral-border);
        background-color: var(--color-neutral-background);
    }}
    </style>
    """
    
    # Apply CSS
    st.markdown(css, unsafe_allow_html=True)
    
    # Create card container
    st.markdown(f'<div class="responsive-card-{key}">', unsafe_allow_html=True)
    
    # Render header if title or subtitle is provided
    if title or subtitle:
        st.markdown(f'<div class="card-header-{key}">', unsafe_allow_html=True)
        
        if title:
            st.markdown(f'<h3 style="margin: 0; color: var(--color-primary-main);">{title}</h3>', unsafe_allow_html=True)
        
        if subtitle:
            st.markdown(f'<p style="margin: {("8px 0 0 0" if title else "0")}; color: var(--color-neutral-main);">{subtitle}</p>', unsafe_allow_html=True)
        
        st.markdown('</div>', unsafe_allow_html=True)
    
    # Render content
    st.markdown(f'<div class="card-content-{key}">', unsafe_allow_html=True)
    content_func()
    st.markdown('</div>', unsafe_allow_html=True)
    
    # Render footer if provided
    if footer:
        st.markdown(f'<div class="card-footer-{key}">', unsafe_allow_html=True)
        
        if callable(footer):
            footer()
        else:
            st.markdown(f'<p style="margin: 0; color: var(--color-neutral-main);">{footer}</p>', unsafe_allow_html=True)
        
        st.markdown('</div>', unsafe_allow_html=True)
    
    # Close card container
    st.markdown('</div>', unsafe_allow_html=True)

def responsive_sidebar(
    content_func: Callable,
    desktop_width: str = "300px",
    tablet_width: str = "250px",
    mobile_width: str = "100%",
    position: str = "left",  # "left" or "right"
    collapsible: bool = True,
    default_collapsed_mobile: bool = True,
    key: Optional[str] = None
):
    """
    Create a responsive sidebar that adapts to different screen sizes.
    
    Args:
        content_func: Function that renders the sidebar content
        desktop_width: Width of the sidebar on desktop screens
        tablet_width: Width of the sidebar on tablet screens
        mobile_width: Width of the sidebar on mobile screens
        position: Position of the sidebar ("left" or "right")
        collapsible: Whether the sidebar can be collapsed
        default_collapsed_mobile: Whether the sidebar is collapsed by default on mobile
        key: Unique key for the component
    """
    # Generate a unique key if not provided
    if key is None:
        key = f"responsive_sidebar_{int(time.time() * 1000)}"
    
    # Create session state for sidebar collapsed state if it doesn't exist
    if f"sidebar_collapsed_{key}" not in st.session_state:
        st.session_state[f"sidebar_collapsed_{key}"] = default_collapsed_mobile
    
    # Create CSS for responsive sidebar
    css = f"""
    <style>
    .sidebar-container-{key} {{
        display: flex;
        width: 100%;
    }}
    
    .sidebar-{key} {{
        width: {desktop_width};
        background-color: var(--color-neutral-paper);
        border-{'right' if position == 'left' else 'left'}: 1px solid var(--color-neutral-border);
        height: calc(100vh - 80px);
        position: sticky;
        top: 80px;
        overflow-y: auto;
        transition: transform 0.3s ease;
    }}
    
    .sidebar-content-{key} {{
        padding: var(--spacing-md);
    }}
    
    .main-content-{key} {{
        flex: 1;
        padding: var(--spacing-md);
        min-width: 0;
    }}
    
    .sidebar-toggle-{key} {{
        display: none;
        position: fixed;
        {'left' if position == 'left' else 'right'}: 10px;
        top: 10px;
        z-index: 1000;
        background-color: var(--color-primary-main);
        color: var(--color-primary-contrast);
        border: none;
        border-radius: 50%;
        width: 40px;
        height: 40px;
        font-size: 20px;
        cursor: pointer;
        box-shadow: var(--shadow-md);
    }}
    
    /* Tablet styles */
    @media (max-width: 1279px) and (min-width: 600px) {{
        .sidebar-{key} {{
            width: {tablet_width};
        }}
    }}
    
    /* Mobile styles */
    @media (max-width: 599px) {{
        .sidebar-container-{key} {{
            display: block;
            position: relative;
        }}
        
        .sidebar-{key} {{
            width: {mobile_width};
            position: fixed;
            {'left' if position == 'left' else 'right'}: 0;
            top: 0;
            height: 100vh;
            z-index: 999;
            transform: translateX({'-100%' if position == 'left' else '100%'});
        }}
        
        .sidebar-{key}.expanded {{
            transform: translateX(0);
        }}
        
        .sidebar-toggle-{key} {{
            display: flex;
            align-items: center;
            justify-content: center;
        }}
        
        .main-content-{key} {{
            padding: var(--spacing-sm);
        }}
    }}
    </style>
    """
    
    # Apply CSS
    st.markdown(css, unsafe_allow_html=True)
    
    # Create sidebar toggle button for mobile
    if collapsible:
        toggle_html = f"""
        <button
            id="sidebar-toggle-{key}"
            class="sidebar-toggle-{key}"
            onclick="toggleSidebar('{key}')"
        >
            <span id="sidebar-toggle-icon-{key}">
                {
                    '&#9776;' if st.session_state[f"sidebar_collapsed_{key}"] else '&times;'
                }
            </span>
        </button>
        
        <script>
            function toggleSidebar(key) {{
                const sidebar = document.querySelector(`.sidebar-${{key}}`);
                const icon = document.getElementById(`sidebar-toggle-icon-${{key}}`);
                
                if (sidebar.classList.contains('expanded')) {{
                    sidebar.classList.remove('expanded');
                    icon.innerHTML = '&#9776;';
                }} else {{
                    sidebar.classList.add('expanded');
                    icon.innerHTML = '&times;';
                }}
            }}
        </script>
        """
        
        st.markdown(toggle_html, unsafe_allow_html=True)
    
    # Create sidebar container
    st.markdown(f'<div class="sidebar-container-{key}">', unsafe_allow_html=True)
    
    # Create sidebar
    sidebar_class = f"sidebar-{key}" + (" expanded" if not st.session_state[f"sidebar_collapsed_{key}"] else "")
    st.markdown(f'<div class="{sidebar_class}">', unsafe_allow_html=True)
    
    # Render sidebar content
    st.markdown(f'<div class="sidebar-content-{key}">', unsafe_allow_html=True)
    content_func()
    st.markdown('</div>', unsafe_allow_html=True)
    
    # Close sidebar
    st.markdown('</div>', unsafe_allow_html=True)
    
    # Create main content container
    st.markdown(f'<div class="main-content-{key}">', unsafe_allow_html=True)
    
    # Return the main content container (will be closed by the caller)
    return lambda: st.markdown('</div></div>', unsafe_allow_html=True)

def responsive_table(
    data: List[Dict[str, Any]],
    columns: List[Dict[str, Any]],
    mobile_breakpoint: int = 600,
    key: Optional[str] = None
):
    """
    Create a responsive table that adapts to different screen sizes.
    
    Args:
        data: List of data objects
        columns: List of column definitions with keys:
            - field: Field name in data objects
            - header: Column header text
            - width: Optional column width
            - format: Optional function to format cell value
        mobile_breakpoint: Breakpoint for switching to mobile layout
        key: Unique key for the component
    """
    # Generate a unique key if not provided
    if key is None:
        key = f"responsive_table_{int(time.time() * 1000)}"
    
    # Create CSS for responsive table
    css = f"""
    <style>
    .responsive-table-{key} {{
        width: 100%;
        border-collapse: collapse;
        margin-bottom: var(--spacing-md);
    }}
    
    .responsive-table-{key} th {{
        background-color: var(--color-primary-main);
        color: var(--color-primary-contrast);
        text-align: left;
        padding: var(--spacing-sm);
        font-weight: 500;
    }}
    
    .responsive-table-{key} td {{
        padding: var(--spacing-sm);
        border-bottom: 1px solid var(--color-neutral-border);
    }}
    
    .responsive-table-{key} tr:nth-child(even) {{
        background-color: rgba(0, 0, 0, 0.02);
    }}
    
    .responsive-table-{key} tr:hover {{
        background-color: rgba(0, 0, 0, 0.05);
    }}
    
    /* Mobile styles */
    @media (max-width: {mobile_breakpoint}px) {{
        .responsive-table-{key} thead {{
            display: none;
        }}
        
        .responsive-table-{key} tbody tr {{
            display: block;
            margin-bottom: var(--spacing-md);
            border: 1px solid var(--color-neutral-border);
            border-radius: var(--radius-md);
            overflow: hidden;
        }}
        
        .responsive-table-{key} tbody td {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid var(--color-neutral-border);
        }}
        
        .responsive-table-{key} tbody td:last-child {{
            border-bottom: none;
        }}
        
        .responsive-table-{key} td::before {{
            content: attr(data-label);
            font-weight: 500;
            margin-right: var(--spacing-md);
        }}
    }}
    </style>
    """
    
    # Apply CSS
    st.markdown(css, unsafe_allow_html=True)
    
    # Create table HTML
    table_html = f'<table class="responsive-table-{key}">'
    
    # Add table header
    table_html += '<thead><tr>'
    for column in columns:
        width_style = f' style="width: {column["width"]}"' if "width" in column else ''
        table_html += f'<th{width_style}>{column["header"]}</th>'
    table_html += '</tr></thead>'
    
    # Add table body
    table_html += '<tbody>'
    for row in data:
        table_html += '<tr>'
        for column in columns:
            field = column["field"]
            value = row.get(field, "")
            
            # Format value if format function is provided
            if "format" in column and callable(column["format"]):
                value = column["format"](value)
            
            table_html += f'<td data-label="{column["header"]}">{value}</td>'
        table_html += '</tr>'
    table_html += '</tbody>'
    
    # Close table
    table_html += '</table>'
    
    # Display table
    st.markdown(table_html, unsafe_allow_html=True)

def responsive_tabs(
    tabs: Dict[str, Callable],
    desktop_style: str = "horizontal",  # "horizontal" or "vertical"
    mobile_style: str = "dropdown",     # "horizontal", "vertical", or "dropdown"
    key: Optional[str] = None
):
    """
    Create responsive tabs that adapt to different screen sizes.
    
    Args:
        tabs: Dictionary mapping tab labels to content functions
        desktop_style: Tab style on desktop screens
        mobile_style: Tab style on mobile screens
        key: Unique key for the component
    """
    # Generate a unique key if not provided
    if key is None:
        key = f"responsive_tabs_{int(time.time() * 1000)}"
    
    # Create session state for active tab if it doesn't exist
    if f"active_tab_{key}" not in st.session_state:
        st.session_state[f"active_tab_{key}"] = list(tabs.keys())[0]
    
    # Create CSS for responsive tabs
    css = f"""
    <style>
    .tabs-container-{key} {{
        width: 100%;
    }}
    
    .tabs-header-{key} {{
        display: flex;
        {
            'flex-direction: row;' if desktop_style == 'horizontal' else
            'flex-direction: column; width: 200px; float: left;'
        }
        margin-bottom: {
            'var(--spacing-md);' if desktop_style == 'horizontal' else '0;'
        }
    }}
    
    .tab-{key} {{
        padding: var(--spacing-sm) var(--spacing-md);
        cursor: pointer;
        border-bottom: {
            '2px solid transparent;' if desktop_style == 'horizontal' else 'none;'
        }
        border-right: {
            '2px solid transparent;' if desktop_style == 'vertical' else 'none;'
        }
        transition: all 0.2s ease;
    }}
    
    .tab-{key}.active {{
        border-bottom-color: {
            'var(--color-primary-main);' if desktop_style == 'horizontal' else 'transparent;'
        }
        border-right-color: {
            'var(--color-primary-main);' if desktop_style == 'vertical' else 'transparent;'
        }
        color: var(--color-primary-main);
        font-weight: 500;
    }}
    
    .tab-{key}:hover {{
        background-color: rgba(0, 0, 0, 0.05);
    }}
    
    .tab-content-{key} {{
        {
            'margin-left: 220px;' if desktop_style == 'vertical' else ''
        }
        padding: var(--spacing-md);
        border: 1px solid var(--color-neutral-border);
        border-radius: var(--radius-md);
    }}
    
    .tabs-dropdown-{key} {{
        display: none;
        width: 100%;
        margin-bottom: var(--spacing-md);
    }}
    
    /* Mobile styles */
    @media (max-width: 599px) {{
        .tabs-header-{key} {{
            {
                'display: none;' if mobile_style == 'dropdown' else
                'flex-direction: row; overflow-x: auto;' if mobile_style == 'horizontal' else
                'flex-direction: column; width: 100%; float: none;'
            }
        }}
        
        .tabs-dropdown-{key} {{
            {
                'display: block;' if mobile_style == 'dropdown' else 'display: none;'
            }
        }}
        
        .tab-content-{key} {{
            margin-left: 0;
        }}
    }}
    </style>
    """
    
    # Apply CSS
    st.markdown(css, unsafe_allow_html=True)
    
    # Create tabs container
    st.markdown(f'<div class="tabs-container-{key}">', unsafe_allow_html=True)
    
    # Create dropdown for mobile if needed
    if mobile_style == "dropdown":
        selected_tab = st.selectbox(
            "Select Tab",
            options=list(tabs.keys()),
            index=list(tabs.keys()).index(st.session_state[f"active_tab_{key}"]),
            key=f"tabs_dropdown_{key}",
            label_visibility="collapsed"
        )
        
        # Update active tab in session state
        st.session_state[f"active_tab_{key}"] = selected_tab
    
    # Create tabs header
    st.markdown(f'<div class="tabs-header-{key}">', unsafe_allow_html=True)
    
    # Create tab buttons
    for tab_label in tabs.keys():
        active_class = "active" if tab_label == st.session_state[f"active_tab_{key}"] else ""
        
        tab_html = f"""
        <div
            class="tab-{key} {active_class}"
            id="tab-{key}-{tab_label.replace(' ', '_')}"
            onclick="setActiveTab('{key}', '{tab_label}')"
        >
            {tab_label}
        </div>
        """
        
        st.markdown(tab_html, unsafe_allow_html=True)
    
    # Close tabs header
    st.markdown('</div>', unsafe_allow_html=True)
    
    # Create tab content
    st.markdown(f'<div class="tab-content-{key}">', unsafe_allow_html=True)
    
    # Render active tab content
    active_tab = st.session_state[f"active_tab_{key}"]
    tabs[active_tab]()
    
    # Close tab content
    st.markdown('</div>', unsafe_allow_html=True)
    
    # Close tabs container
    st.markdown('</div>', unsafe_allow_html=True)
    
    # Add JavaScript for tab switching
    js = f"""
    <script>
        function setActiveTab(key, tabLabel) {{
            // This is handled by Streamlit's session state
            // We just need to trigger a rerun with the new active tab
            
            // Remove active class from all tabs
            const tabs = document.querySelectorAll(`.tab-${{key}}`);
            tabs.forEach(tab => tab.classList.remove('active'));
            
            // Add active class to selected tab
            const selectedTab = document.getElementById(`tab-${{key}}-${{tabLabel.replace(' ', '_')}}`);
            if (selectedTab) {{
                selectedTab.classList.add('active');
            }}
            
            // Update Streamlit session state via a hidden button click
            const hiddenButton = document.getElementById(`hidden_button_${{key}}_${{tabLabel.replace(' ', '_')}}`);
            if (hiddenButton) {{
                hiddenButton.click();
            }}
        }}
    </script>
    """
    
    st.markdown(js, unsafe_allow_html=True)
    
    # Create hidden buttons for each tab to update session state
    for tab_label in tabs.keys():
        button_key = f"hidden_button_{key}_{tab_label.replace(' ', '_')}"
        
        if st.button(
            "Hidden Button",
            key=button_key,
            on_click=lambda tab=tab_label: setattr(st.session_state, f"active_tab_{key}", tab),
            help="This button is used for tab switching",
            label_visibility="collapsed"
        ):
            st.rerun()

def responsive_image(
    image_path: str,
    desktop_width: str = "100%",
    tablet_width: str = "100%",
    mobile_width: str = "100%",
    alt_text: str = "",
    key: Optional[str] = None
):
    """
    Create a responsive image that adapts to different screen sizes.
    
    Args:
        image_path: Path or URL to the image
        desktop_width: Width of the image on desktop screens
        tablet_width: Width of the image on tablet screens
        mobile_width: Width of the image on mobile screens
        alt_text: Alternative text for the image
        key: Unique key for the component
    """
    # Generate a unique key if not provided
    if key is None:
        key = f"responsive_image_{int(time.time() * 1000)}"
    
    # Create CSS for responsive image
    css = f"""
    <style>
    .responsive-image-{key} {{
        width: {desktop_width};
        max-width: 100%;
        height: auto;
        display: block;
    }}
    
    /* Tablet styles */
    @media (max-width: 1279px) and (min-width: 600px) {{
        .responsive-image-{key} {{
            width: {tablet_width};
        }}
    }}
    
    /* Mobile styles */
    @media (max-width: 599px) {{
        .responsive-image-{key} {{
            width: {mobile_width};
        }}
    }}
    </style>
    """
    
    # Apply CSS
    st.markdown(css, unsafe_allow_html=True)
    
    # Create image HTML
    image_html = f'<img src="{image_path}" alt="{alt_text}" class="responsive-image-{key}" />'
    
    # Display image
    st.markdown(image_html, unsafe_allow_html=True)

def responsive_video(
    video_path: str,
    desktop_width: str = "100%",
    tablet_width: str = "100%",
    mobile_width: str = "100%",
    controls: bool = True,
    autoplay: bool = False,
    loop: bool = False,
    muted: bool = False,
    key: Optional[str] = None
):
    """
    Create a responsive video that adapts to different screen sizes.
    
    Args:
        video_path: Path or URL to the video
        desktop_width: Width of the video on desktop screens
        tablet_width: Width of the video on tablet screens
        mobile_width: Width of the video on mobile screens
        controls: Whether to show video controls
        autoplay: Whether to autoplay the video
        loop: Whether to loop the video
        muted: Whether to mute the video
        key: Unique key for the component
    """
    # Generate a unique key if not provided
    if key is None:
        key = f"responsive_video_{int(time.time() * 1000)}"
    
    # Create CSS for responsive video
    css = f"""
    <style>
    .responsive-video-container-{key} {{
        position: relative;
        width: {desktop_width};
        max-width: 100%;
        height: 0;
        padding-bottom: 56.25%; /* 16:9 aspect ratio */
        overflow: hidden;
    }}
    
    .responsive-video-{key} {{
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
    }}
    
    /* Tablet styles */
    @media (max-width: 1279px) and (min-width: 600px) {{
        .responsive-video-container-{key} {{
            width: {tablet_width};
        }}
    }}
    
    /* Mobile styles */
    @media (max-width: 599px) {{
        .responsive-video-container-{key} {{
            width: {mobile_width};
        }}
    }}
    </style>
    """
    
    # Apply CSS
    st.markdown(css, unsafe_allow_html=True)
    
    # Create video attributes
    video_attrs = []
    if controls:
        video_attrs.append("controls")
    if autoplay:
        video_attrs.append("autoplay")
    if loop:
        video_attrs.append("loop")
    if muted:
        video_attrs.append("muted")
    
    video_attrs_str = " ".join(video_attrs)
    
    # Create video HTML
    video_html = f"""
    <div class="responsive-video-container-{key}">
        <video class="responsive-video-{key}" {video_attrs_str}>
            <source src="{video_path}" type="video/mp4">
            Your browser does not support the video tag.
        </video>
    </div>
    """
    
    # Display video
    st.markdown(video_html, unsafe_allow_html=True)

def responsive_iframe(
    url: str,
    desktop_width: str = "100%",
    tablet_width: str = "100%",
    mobile_width: str = "100%",
    aspect_ratio: str = "16:9",
    key: Optional[str] = None
):
    """
    Create a responsive iframe that adapts to different screen sizes.
    
    Args:
        url: URL to embed in the iframe
        desktop_width: Width of the iframe on desktop screens
        tablet_width: Width of the iframe on tablet screens
        mobile_width: Width of the iframe on mobile screens
        aspect_ratio: Aspect ratio of the iframe (e.g., "16:9", "4:3")
        key: Unique key for the component
    """
    # Generate a unique key if not provided
    if key is None:
        key = f"responsive_iframe_{int(time.time() * 1000)}"
    
    # Calculate padding-bottom based on aspect ratio
    if aspect_ratio == "16:9":
        padding_bottom = "56.25%"
    elif aspect_ratio == "4:3":
        padding_bottom = "75%"
    elif aspect_ratio == "1:1":
        padding_bottom = "100%"
    else:
        # Parse custom aspect ratio
        try:
            width, height = map(int, aspect_ratio.split(":"))
            padding_bottom = f"{(height / width) * 100}%"
        except:
            padding_bottom = "56.25%"  # Default to 16:9
    
    # Create CSS for responsive iframe
    css = f"""
    <style>
    .responsive-iframe-container-{key} {{
        position: relative;
        width: {desktop_width};
        max-width: 100%;
        height: 0;
        padding-bottom: {padding_bottom};
        overflow: hidden;
    }}
    
    .responsive-iframe-{key} {{
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        border: none;
    }}
    
    /* Tablet styles */
    @media (max-width: 1279px) and (min-width: 600px) {{
        .responsive-iframe-container-{key} {{
            width: {tablet_width};
        }}
    }}
    
    /* Mobile styles */
    @media (max-width: 599px) {{
        .responsive-iframe-container-{key} {{
            width: {mobile_width};
        }}
    }}
    </style>
    """
    
    # Apply CSS
    st.markdown(css, unsafe_allow_html=True)
    
    # Create iframe HTML
    iframe_html = f"""
    <div class="responsive-iframe-container-{key}">
        <iframe class="responsive-iframe-{key}" src="{url}" allowfullscreen></iframe>
    </div>
    """
    
    # Display iframe
    st.markdown(iframe_html, unsafe_allow_html=True)

def responsive_menu(
    items: List[Dict[str, Any]],
    orientation: str = "horizontal",  # "horizontal" or "vertical"
    mobile_collapse: bool = True,
    key: Optional[str] = None
):
    """
    Create a responsive menu that adapts to different screen sizes.
    
    Args:
        items: List of menu items with keys:
            - label: Item label
            - url: Optional URL
            - icon: Optional icon name
            - children: Optional list of submenu items
        orientation: Menu orientation on desktop
        mobile_collapse: Whether to collapse menu on mobile
        key: Unique key for the component
    """
    # Generate a unique key if not provided
    if key is None:
        key = f"responsive_menu_{int(time.time() * 1000)}"
    
    # Create session state for mobile menu expanded state if it doesn't exist
    if f"menu_expanded_{key}" not in st.session_state:
        st.session_state[f"menu_expanded_{key}"] = False
    
    # Create CSS for responsive menu
    css = f"""
    <style>
    .menu-container-{key} {{
        width: 100%;
        margin-bottom: var(--spacing-md);
    }}
    
    .menu-{key} {{
        display: flex;
        flex-direction: {
            'row' if orientation == 'horizontal' else 'column'
        };
        list-style: none;
        padding: 0;
        margin: 0;
        background-color: var(--color-neutral-paper);
        border-radius: var(--radius-md);
        overflow: hidden;
    }}
    
    .menu-item-{key} {{
        position: relative;
    }}
    
    .menu-link-{key} {{
        display: flex;
        align-items: center;
        padding: var(--spacing-sm) var(--spacing-md);
        color: var(--color-neutral-dark);
        text-decoration: none;
        transition: all 0.2s ease;
    }}
    
    .menu-link-{key}:hover {{
        background-color: rgba(0, 0, 0, 0.05);
        color: var(--color-primary-main);
    }}
    
    .menu-link-{key}.active {{
        background-color: var(--color-primary-main);
        color: var(--color-primary-contrast);
    }}
    
    .menu-icon-{key} {{
        margin-right: var(--spacing-sm);
    }}
    
    .submenu-{key} {{
        display: none;
        position: {
            'absolute' if orientation == 'horizontal' else 'static'
        };
        top: 100%;
        left: 0;
        min-width: 200px;
        background-color: var(--color-neutral-paper);
        border: 1px solid var(--color-neutral-border);
        border-radius: var(--radius-md);
        box-shadow: var(--shadow-md);
        z-index: 1000;
    }}
    
    .menu-item-{key}:hover .submenu-{key} {{
        display: block;
    }}
    
    .menu-toggle-{key} {{
        display: none;
        align-items: center;
        justify-content: space-between;
        padding: var(--spacing-sm) var(--spacing-md);
        background-color: var(--color-primary-main);
        color: var(--color-primary-contrast);
        cursor: pointer;
        border-radius: var(--radius-md);
    }}
    
    /* Mobile styles */
    @media (max-width: 599px) {{
        .menu-toggle-{key} {{
            display: {
                'flex' if mobile_collapse else 'none'
            };
        }}
        
        .menu-{key} {{
            flex-direction: column;
            display: {
                'none' if mobile_collapse else 'flex'
            };
        }}
        
        .menu-{key}.expanded {{
            display: flex;
        }}
        
        .submenu-{key} {{
            position: static;
            box-shadow: none;
            border: none;
            border-radius: 0;
            padding-left: var(--spacing-md);
        }}
    }}
    </style>
    """
    
    # Apply CSS
    st.markdown(css, unsafe_allow_html=True)
    
    # Create menu container
    st.markdown(f'<div class="menu-container-{key}">', unsafe_allow_html=True)
    
    # Create menu toggle for mobile
    if mobile_collapse:
        toggle_html = f"""
        <div
            class="menu-toggle-{key}"
            onclick="toggleMenu('{key}')"
        >
            <span>Menu</span>
            <span id="menu-toggle-icon-{key}">
                {
                    '&#9776;' if not st.session_state[f"menu_expanded_{key}"] else '&times;'
                }
            </span>
        </div>
        
        <script>
            function toggleMenu(key) {{
                const menu = document.querySelector(`.menu-${{key}}`);
                const icon = document.getElementById(`menu-toggle-icon-${{key}}`);
                
                if (menu.classList.contains('expanded')) {{
                    menu.classList.remove('expanded');
                    icon.innerHTML = '&#9776;';
                }} else {{
                    menu.classList.add('expanded');
                    icon.innerHTML = '&times;';
                }}
            }}
        </script>
        """
        
        st.markdown(toggle_html, unsafe_allow_html=True)
    
    # Create menu
    menu_class = f"menu-{key}" + (" expanded" if st.session_state[f"menu_expanded_{key}"] else "")
    st.markdown(f'<ul class="{menu_class}">', unsafe_allow_html=True)
    
    # Create menu items
    for item in items:
        # Get item properties
        label = item.get("label", "")
        url = item.get("url", "#")
        icon = item.get("icon", "")
        children = item.get("children", [])
        active = item.get("active", False)
        
        # Create item HTML
        item_html = f'<li class="menu-item-{key}">'
        
        # Create link HTML
        active_class = " active" if active else ""
        item_html += f'<a href="{url}" class="menu-link-{key}{active_class}">'
        
        # Add icon if provided
        if icon:
            item_html += f'<span class="menu-icon-{key} material-icons">{icon}</span>'
        
        # Add label
        item_html += label
        
        # Add dropdown indicator if has children
        if children:
            item_html += f'<span class="material-icons" style="margin-left: 4px; font-size: 16px;">arrow_drop_down</span>'
        
        # Close link
        item_html += '</a>'
        
        # Add submenu if has children
        if children:
            item_html += f'<ul class="submenu-{key}">'
            
            for child in children:
                # Get child properties
                child_label = child.get("label", "")
                child_url = child.get("url", "#")
                child_icon = child.get("icon", "")
                child_active = child.get("active", False)
                
                # Create child HTML
                child_active_class = " active" if child_active else ""
                item_html += f'<li class="menu-item-{key}"><a href="{child_url}" class="menu-link-{key}{child_active_class}">'
                
                # Add icon if provided
                if child_icon:
                    item_html += f'<span class="menu-icon-{key} material-icons">{child_icon}</span>'
                
                # Add label
                item_html += child_label
                
                # Close link and item
                item_html += '</a></li>'
            
            # Close submenu
            item_html += '</ul>'
        
        # Close item
        item_html += '</li>'
        
        # Add item to menu
        st.markdown(item_html, unsafe_allow_html=True)
    
    # Close menu
    st.markdown('</ul>', unsafe_allow_html=True)
    
    # Close menu container
    st.markdown('</div>', unsafe_allow_html=True)

def demo_responsive_layout():
    """
    Demonstrate all responsive layout components.
    """
    st.title("Responsive Layout Components Demo")
    
    st.header("Responsive Container")
    
    def container_content():
        st.write("This container adapts to different screen sizes.")
        st.write("Try resizing your browser window to see how it changes.")
    
    responsive_container(
        content_func=container_content,
        desktop_styles={
            "padding": "20px",
            "background-color": "#f0f4f8",
            "border-radius": "8px",
            "margin-bottom": "20px"
        },
        tablet_styles={
            "padding": "15px",
            "background-color": "#f0f4f8",
            "border-radius": "6px",
            "margin-bottom": "15px"
        },
        mobile_styles={
            "padding": "10px",
            "background-color": "#f0f4f8",
            "border-radius": "4px",
            "margin-bottom": "10px"
        }
    )
    
    st.header("Responsive Grid")
    
    def grid_item1():
        st.write("Grid Item 1")
        st.button("Button 1")
    
    def grid_item2():
        st.write("Grid Item 2")
        st.button("Button 2")
    
    def grid_item3():
        st.write("Grid Item 3")
        st.button("Button 3")
    
    def grid_item4():
        st.write("Grid Item 4")
        st.button("Button 4")
    
    responsive_grid(
        items=[grid_item1, grid_item2, grid_item3, grid_item4],
        desktop_columns=4,
        tablet_columns=2,
        mobile_columns=1
    )
    
    st.header("Responsive Columns")
    
    def column1():
        st.write("Column 1 (wider on desktop)")
        st.slider("Slider 1", 0, 100, 50)
    
    def column2():
        st.write("Column 2 (narrower on desktop)")
        st.slider("Slider 2", 0, 100, 50)
    
    responsive_columns(
        content_funcs=[column1, column2],
        desktop_widths=[2, 1],
        tablet_widths=[1, 1],
        mobile_widths=[1, 1]
    )
    
    st.header("Responsive Card")
    
    def card_content():
        st.write("This card adapts to different screen sizes.")
        st.button("Card Button")
    
    responsive_card(
        title="Responsive Card",
        subtitle="This card changes based on screen size",
        content_func=card_content,
        footer="Card Footer",
        desktop_styles={
            "max-width": "800px"
        },
        tablet_styles={
            "max-width": "100%"
        },
        mobile_styles={
            "max-width": "100%",
            "box-shadow": "none",
            "border": "1px solid #e0e0e0"
        }
    )
    
    st.header("Responsive Sidebar")
    
    def sidebar_content():
        st.write("Sidebar Content")
        st.checkbox("Option 1")
        st.checkbox("Option 2")
        st.button("Sidebar Button")
    
    def main_content():
        st.write("Main Content Area")
        st.write("This content appears next to the sidebar on desktop and below it on mobile.")
        st.slider("Main Content Slider", 0, 100, 50)
    
    close_sidebar = responsive_sidebar(
        content_func=sidebar_content,
        desktop_width="250px",
        tablet_width="200px",
        mobile_width="100%",
        collapsible=True
    )
    
    main_content()
    
    # Close the sidebar container
    close_sidebar()
    
    st.header("Responsive Table")
    
    # Sample data
    table_data = [
        {"id": 1, "name": "John Doe", "email": "john@example.com", "status": "Active"},
        {"id": 2, "name": "Jane Smith", "email": "jane@example.com", "status": "Inactive"},
        {"id": 3, "name": "Bob Johnson", "email": "bob@example.com", "status": "Active"}
    ]
    
    # Column definitions
    table_columns = [
        {"field": "id", "header": "ID", "width": "10%"},
        {"field": "name", "header": "Name", "width": "30%"},
        {"field": "email", "header": "Email", "width": "40%"},
        {"field": "status", "header": "Status", "width": "20%", "format": lambda x: f"<span style='color: {'green' if x == 'Active' else 'red'};'>{x}</span>"}
    ]
    
    responsive_table(
        data=table_data,
        columns=table_columns
    )
    
    st.header("Responsive Tabs")
    
    def tab1_content():
        st.write("Tab 1 Content")
        st.button("Tab 1 Button")
    
    def tab2_content():
        st.write("Tab 2 Content")
        st.slider("Tab 2 Slider", 0, 100, 50)
    
    def tab3_content():
        st.write("Tab 3 Content")
        st.checkbox("Tab 3 Checkbox")
    
    responsive_tabs(
        tabs={
            "Tab 1": tab1_content,
            "Tab 2": tab2_content,
            "Tab 3": tab3_content
        },
        desktop_style="horizontal",
        mobile_style="dropdown"
    )
    
    st.header("Responsive Image")
    
    responsive_image(
        image_path="https://via.placeholder.com/800x400",
        desktop_width="800px",
        tablet_width="100%",
        mobile_width="100%",
        alt_text="Placeholder Image"
    )
    
    st.header("Responsive Menu")
    
    responsive_menu(
        items=[
            {
                "label": "Home",
                "url": "#",
                "icon": "home",
                "active": True
            },
            {
                "label": "Products",
                "url": "#",
                "icon": "shopping_cart",
                "children": [
                    {"label": "Product 1", "url": "#"},
                    {"label": "Product 2", "url": "#"},
                    {"label": "Product 3", "url": "#"}
                ]
            },
            {
                "label": "About",
                "url": "#",
                "icon": "info"
            },
            {
                "label": "Contact",
                "url": "#",
                "icon": "email"
            }
        ],
        orientation="horizontal",
        mobile_collapse=True
    )

if __name__ == "__main__":
    # This will run when the script is executed directly
    st.set_page_config(page_title="Responsive Layout Demo", layout="wide")
    demo_responsive_layout()
