"""
Status indicator components for the Crustless Creations AI machine vision application.

This module provides reusable status indicator components for displaying system status,
camera status, and other monitoring information in the UI.
"""

import streamlit as st
from typing import Literal, Optional, Dict, Any, List, Tuple
import time

# Define status types and colors
StatusType = Literal["success", "warning", "error", "info", "offline"]
STATUS_COLORS = {
    "success": "#28a745",  # Green
    "warning": "#ffc107",  # Yellow
    "error": "#dc3545",    # Red
    "info": "#17a2b8",     # Blue
    "offline": "#6c757d",  # Gray
}

def circular_status_indicator(
    status: StatusType, 
    label: str, 
    tooltip: Optional[str] = None,
    size: int = 15
) -> None:
    """
    Display a circular status indicator with a label.
    
    Args:
        status: The status type (success, warning, error, info, offline)
        label: The label text to display next to the indicator
        tooltip: Optional tooltip text to display on hover
        size: Size of the indicator in pixels
    """
    color = STATUS_COLORS.get(status, STATUS_COLORS["offline"])
    
    # Create a container for the indicator and label
    container = st.container()
    
    with container:
        cols = st.columns([1, 10])
        
        with cols[0]:
            # Use HTML to create a circular indicator
            st.markdown(
                f"""
                <div style="
                    width: {size}px;
                    height: {size}px;
                    border-radius: 50%;
                    background-color: {color};
                    margin-top: 4px;
                    display: inline-block;
                    title="{tooltip or ''}";
                "></div>
                """,
                unsafe_allow_html=True
            )
        
        with cols[1]:
            st.markdown(f"**{label}**")
    
    # Add tooltip using JavaScript if provided
    if tooltip:
        st.markdown(
            f"""
            <script>
                document.querySelector('[title="{tooltip}"]').addEventListener('mouseover', function() {{
                    // Show tooltip logic would go here
                }});
            </script>
            """,
            unsafe_allow_html=True
        )

def status_badge(
    status: StatusType, 
    text: str, 
    icon: Optional[str] = None
) -> None:
    """
    Display a status badge with text and optional icon.
    
    Args:
        status: The status type (success, warning, error, info, offline)
        text: The text to display in the badge
        icon: Optional icon name from streamlit's icon set
    """
    color = STATUS_COLORS.get(status, STATUS_COLORS["offline"])
    
    # Determine text color (white for most, black for warning)
    text_color = "#212529" if status == "warning" else "#ffffff"
    
    # Create the badge
    if icon:
        st.markdown(
            f"""
            <div style="
                display: inline-block;
                padding: 0.25em 0.6em;
                font-size: 0.75em;
                font-weight: 700;
                line-height: 1;
                text-align: center;
                white-space: nowrap;
                vertical-align: baseline;
                border-radius: 0.25rem;
                background-color: {color};
                color: {text_color};
            ">
                <span>{icon} {text}</span>
            </div>
            """,
            unsafe_allow_html=True
        )
    else:
        st.markdown(
            f"""
            <div style="
                display: inline-block;
                padding: 0.25em 0.6em;
                font-size: 0.75em;
                font-weight: 700;
                line-height: 1;
                text-align: center;
                white-space: nowrap;
                vertical-align: baseline;
                border-radius: 0.25rem;
                background-color: {color};
                color: {text_color};
            ">
                {text}
            </div>
            """,
            unsafe_allow_html=True
        )

def progress_indicator(
    progress: float, 
    label: str, 
    show_percentage: bool = True
) -> None:
    """
    Display a progress indicator with label and optional percentage.
    
    Args:
        progress: Progress value between 0.0 and 1.0
        label: Label text to display
        show_percentage: Whether to show percentage text
    """
    # Ensure progress is between 0 and 1
    progress = max(0.0, min(1.0, progress))
    
    # Display label
    st.text(label)
    
    # Display progress bar
    st.progress(progress)
    
    # Show percentage if requested
    if show_percentage:
        st.text(f"{int(progress * 100)}%")

def resource_gauge(
    value: float, 
    label: str, 
    min_value: float = 0.0, 
    max_value: float = 100.0,
    warning_threshold: float = 70.0,
    critical_threshold: float = 90.0,
    unit: str = "%"
) -> None:
    """
    Display a resource utilization gauge.
    
    Args:
        value: Current value
        label: Label for the gauge
        min_value: Minimum value
        max_value: Maximum value
        warning_threshold: Threshold for warning status
        critical_threshold: Threshold for critical status
        unit: Unit to display
    """
    # Normalize value for progress bar
    normalized = (value - min_value) / (max_value - min_value)
    normalized = max(0.0, min(1.0, normalized))
    
    # Determine color based on thresholds
    normalized_warning = (warning_threshold - min_value) / (max_value - min_value)
    normalized_critical = (critical_threshold - min_value) / (max_value - min_value)
    
    if normalized >= normalized_critical:
        color = STATUS_COLORS["error"]
        status = "error"
    elif normalized >= normalized_warning:
        color = STATUS_COLORS["warning"]
        status = "warning"
    else:
        color = STATUS_COLORS["success"]
        status = "success"
    
    # Display label and value
    st.text(f"{label}: {value}{unit}")
    
    # Use a progress bar with custom styling
    st.markdown(
        f"""
        <div style="
            width: 100%;
            background-color: #e9ecef;
            border-radius: 0.25rem;
        ">
            <div style="
                width: {normalized * 100}%;
                height: 10px;
                background-color: {color};
                border-radius: 0.25rem;
            "></div>
        </div>
        """,
        unsafe_allow_html=True
    )
    
    # Add a small indicator of status
    st.markdown(
        f"""
        <div style="
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background-color: {color};
            display: inline-block;
            margin-right: 5px;
        "></div>
        <span style="font-size: 0.8em;">{status.capitalize()}</span>
        """,
        unsafe_allow_html=True
    )

def connection_quality_indicator(
    quality: float,  # 0.0 to 1.0
    label: str
) -> None:
    """
    Display a connection quality indicator with signal-like bars.
    
    Args:
        quality: Connection quality from 0.0 (worst) to 1.0 (best)
        label: Label for the indicator
    """
    # Ensure quality is between 0 and 1
    quality = max(0.0, min(1.0, quality))
    
    # Determine number of bars to fill (out of 5)
    filled_bars = int(quality * 5)
    
    # Determine color based on quality
    if quality >= 0.8:
        color = STATUS_COLORS["success"]
    elif quality >= 0.4:
        color = STATUS_COLORS["warning"]
    else:
        color = STATUS_COLORS["error"]
    
    # Create the bars
    bars_html = ""
    for i in range(5):
        bar_color = color if i < filled_bars else "#e9ecef"
        bar_height = 4 + (i * 2)  # Increasing heights
        bars_html += f"""
            <div style="
                width: 4px;
                height: {bar_height}px;
                background-color: {bar_color};
                margin-right: 2px;
                display: inline-block;
                vertical-align: baseline;
            "></div>
        """
    
    # Display the indicator
    st.markdown(
        f"""
        <div>
            <span>{label}</span>
            <div style="display: inline-block; margin-left: 10px;">
                {bars_html}
            </div>
        </div>
        """,
        unsafe_allow_html=True
    )

def alert_counter(
    counts: Dict[StatusType, int],
    show_total: bool = True
) -> None:
    """
    Display an alert counter with breakdown by severity.
    
    Args:
        counts: Dictionary with counts for each status type
        show_total: Whether to show the total count
    """
    total = sum(counts.values())
    
    # Create container
    container = st.container()
    
    with container:
        # Show total if requested
        if show_total:
            st.markdown(f"**Alerts: {total}**")
        
        # Show breakdown
        cols = st.columns(len(counts))
        
        for i, (status, count) in enumerate(counts.items()):
            with cols[i]:
                color = STATUS_COLORS.get(status, STATUS_COLORS["offline"])
                st.markdown(
                    f"""
                    <div style="text-align: center;">
                        <div style="
                            width: 20px;
                            height: 20px;
                            border-radius: 50%;
                            background-color: {color};
                            margin: 0 auto;
                        "></div>
                        <div style="font-size: 0.8em; margin-top: 5px;">
                            {status.capitalize()}: {count}
                        </div>
                    </div>
                    """,
                    unsafe_allow_html=True
                )

def system_status_panel() -> None:
    """
    Display a comprehensive system status panel with multiple indicators.
    """
    with st.container():
        st.markdown("### System Status")
        
        # Create a 2x2 grid for status indicators
        col1, col2 = st.columns(2)
        col3, col4 = st.columns(2)
        
        with col1:
            circular_status_indicator(
                "success", 
                "Host System", 
                tooltip="Host PC is running normally"
            )
            resource_gauge(
                45.2, 
                "CPU Usage", 
                warning_threshold=70.0,
                critical_threshold=90.0
            )
        
        with col2:
            circular_status_indicator(
                "warning", 
                "ADLINK Jetson", 
                tooltip="ADLINK Jetson is running with warnings"
            )
            resource_gauge(
                72.5, 
                "GPU Usage", 
                warning_threshold=70.0,
                critical_threshold=90.0
            )
        
        with col3:
            circular_status_indicator(
                "success", 
                "Database", 
                tooltip="Database is connected and operational"
            )
            resource_gauge(
                32.1, 
                "Disk Usage", 
                warning_threshold=70.0,
                critical_threshold=80.0
            )
        
        with col4:
            circular_status_indicator(
                "success", 
                "Network", 
                tooltip="Network is operational"
            )
            connection_quality_indicator(0.85, "Network Quality")
        
        # Add alert counter at the bottom
        st.markdown("---")
        alert_counter({
            "error": 0,
            "warning": 2,
            "info": 5
        })

def camera_status_panel(
    camera_statuses: Dict[str, Dict[str, Any]]
) -> None:
    """
    Display a panel showing the status of all cameras.
    
    Args:
        camera_statuses: Dictionary with camera information and status
    """
    with st.container():
        st.markdown("### Camera Status")
        
        # Create a grid for cameras
        cols = st.columns(len(camera_statuses))
        
        for i, (camera_id, info) in enumerate(camera_statuses.items()):
            with cols[i]:
                # Display camera name and status
                circular_status_indicator(
                    info["status"], 
                    info["name"], 
                    tooltip=info.get("tooltip", "")
                )
                
                # Display camera details
                st.markdown(f"**IP:** {info.get('ip', 'Unknown')}")
                st.markdown(f"**FPS:** {info.get('fps', 0)}")
                
                # Display connection quality
                connection_quality_indicator(
                    info.get("connection_quality", 0.0),
                    "Signal"
                )

def demo_status_indicators() -> None:
    """
    Demonstrate all status indicators with sample data.
    """
    st.title("Status Indicators Demo")
    
    st.markdown("## Circular Status Indicators")
    circular_status_indicator("success", "System Online", "System is running normally")
    circular_status_indicator("warning", "Low Disk Space", "Disk space below 20%")
    circular_status_indicator("error", "Camera Offline", "Camera connection lost")
    circular_status_indicator("info", "Processing", "Processing images")
    circular_status_indicator("offline", "Service Stopped", "Service is not running")
    
    st.markdown("## Status Badges")
    col1, col2, col3 = st.columns(3)
    with col1:
        status_badge("success", "Connected")
    with col2:
        status_badge("warning", "Degraded")
    with col3:
        status_badge("error", "Failed")
    
    st.markdown("## Progress Indicators")
    progress_indicator(0.75, "Processing Images")
    
    st.markdown("## Resource Gauges")
    col1, col2 = st.columns(2)
    with col1:
        resource_gauge(35.0, "CPU Usage")
        resource_gauge(82.0, "Memory Usage")
    with col2:
        resource_gauge(95.0, "Disk Usage")
        resource_gauge(60.0, "GPU Usage")
    
    st.markdown("## Connection Quality")
    col1, col2, col3 = st.columns(3)
    with col1:
        connection_quality_indicator(0.9, "Excellent")
    with col2:
        connection_quality_indicator(0.5, "Fair")
    with col3:
        connection_quality_indicator(0.2, "Poor")
    
    st.markdown("## Alert Counter")
    alert_counter({
        "error": 2,
        "warning": 5,
        "info": 10
    })
    
    st.markdown("## System Status Panel")
    system_status_panel()
    
    st.markdown("## Camera Status Panel")
    camera_statuses = {
        "cam1": {
            "name": "Top Camera",
            "status": "success",
            "tooltip": "Camera operating normally",
            "ip": "192.168.100.101",
            "fps": 20,
            "connection_quality": 0.95
        },
        "cam2": {
            "name": "Side Camera 1",
            "status": "warning",
            "tooltip": "Frame drops detected",
            "ip": "192.168.100.102",
            "fps": 18,
            "connection_quality": 0.7
        },
        "cam3": {
            "name": "Side Camera 2",
            "status": "success",
            "tooltip": "Camera operating normally",
            "ip": "192.168.100.103",
            "fps": 20,
            "connection_quality": 0.9
        },
        "cam4": {
            "name": "Bottom Camera",
            "status": "error",
            "tooltip": "Camera disconnected",
            "ip": "192.168.100.104",
            "fps": 0,
            "connection_quality": 0.0
        }
    }
    camera_status_panel(camera_statuses)

if __name__ == "__main__":
    # This will run when the script is executed directly
    demo_status_indicators()
