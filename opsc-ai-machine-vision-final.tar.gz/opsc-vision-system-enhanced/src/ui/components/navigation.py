"""
Navigation components for the Crustless Creations AI machine vision application.

This module provides navigation components for the application, including
sidebar navigation, breadcrumbs, and page management.
"""

import streamlit as st
from typing import Dict, List, Callable, Optional, Any, Tuple
import os
import sys

# Define page structure
class Page:
    """Class representing a page in the application."""
    
    def __init__(
        self, 
        id: str, 
        title: str, 
        icon: str, 
        function: Callable,
        parent: Optional[str] = None,
        order: int = 0,
        visible: bool = True
    ):
        """
        Initialize a Page object.
        
        Args:
            id: Unique identifier for the page
            title: Display title for the page
            icon: Icon name from streamlit's icon set
            function: Function to call when page is selected
            parent: Optional parent page ID for hierarchical navigation
            order: Order in the navigation (lower numbers appear first)
            visible: Whether the page is visible in navigation
        """
        self.id = id
        self.title = title
        self.icon = icon
        self.function = function
        self.parent = parent
        self.order = order
        self.visible = visible

class NavigationManager:
    """Manager for application navigation."""
    
    def __init__(self):
        """Initialize the NavigationManager."""
        self.pages: Dict[str, Page] = {}
        self.current_page_id: Optional[str] = None
        
        # Initialize session state for navigation if not exists
        if "nav_history" not in st.session_state:
            st.session_state.nav_history = []
        if "current_page" not in st.session_state:
            st.session_state.current_page = None
    
    def add_page(self, page: Page) -> None:
        """
        Add a page to the navigation.
        
        Args:
            page: Page object to add
        """
        self.pages[page.id] = page
    
    def get_page(self, page_id: str) -> Optional[Page]:
        """
        Get a page by ID.
        
        Args:
            page_id: ID of the page to retrieve
            
        Returns:
            Page object if found, None otherwise
        """
        return self.pages.get(page_id)
    
    def get_sorted_pages(self, parent: Optional[str] = None) -> List[Page]:
        """
        Get pages sorted by order, optionally filtered by parent.
        
        Args:
            parent: Optional parent page ID to filter by
            
        Returns:
            List of Page objects sorted by order
        """
        filtered_pages = [
            p for p in self.pages.values() 
            if p.parent == parent and p.visible
        ]
        return sorted(filtered_pages, key=lambda p: p.order)
    
    def navigate_to(self, page_id: str) -> None:
        """
        Navigate to a specific page.
        
        Args:
            page_id: ID of the page to navigate to
        """
        if page_id in self.pages:
            # Add current page to history if it exists
            if st.session_state.current_page:
                st.session_state.nav_history.append(st.session_state.current_page)
                # Limit history size
                if len(st.session_state.nav_history) > 10:
                    st.session_state.nav_history.pop(0)
            
            # Set current page
            st.session_state.current_page = page_id
            self.current_page_id = page_id
            
            # Force a rerun to update the UI
            st.rerun()
    
    def go_back(self) -> None:
        """Navigate back to the previous page."""
        if st.session_state.nav_history:
            previous_page = st.session_state.nav_history.pop()
            st.session_state.current_page = previous_page
            self.current_page_id = previous_page
            st.rerun()
    
    def render_sidebar_navigation(self) -> None:
        """Render the sidebar navigation menu."""
        st.sidebar.title("Crustless Creations")
        st.sidebar.markdown("### Quality Control System")
        
        # Add separator
        st.sidebar.markdown("---")
        
        # Render top-level pages
        for page in self.get_sorted_pages(parent=None):
            if st.sidebar.button(
                f":{page.icon}: {page.title}",
                key=f"nav_{page.id}",
                use_container_width=True,
                type="secondary" if st.session_state.current_page != page.id else "primary"
            ):
                self.navigate_to(page.id)
            
            # If this is the current page and it has children, show them
            if st.session_state.current_page == page.id:
                for child_page in self.get_sorted_pages(parent=page.id):
                    if st.sidebar.button(
                        f"   :{child_page.icon}: {child_page.title}",
                        key=f"nav_{child_page.id}",
                        use_container_width=True,
                        type="secondary"
                    ):
                        self.navigate_to(child_page.id)
        
        # Add separator
        st.sidebar.markdown("---")
        
        # Add system pages at the bottom
        system_pages = [p for p in self.pages.values() if p.parent == "system" and p.visible]
        for page in sorted(system_pages, key=lambda p: p.order):
            if st.sidebar.button(
                f":{page.icon}: {page.title}",
                key=f"nav_{page.id}",
                use_container_width=True,
                type="secondary" if st.session_state.current_page != page.id else "primary"
            ):
                self.navigate_to(page.id)
        
        # Add back button if history exists
        if st.session_state.nav_history:
            st.sidebar.markdown("---")
            if st.sidebar.button("← Back", key="nav_back"):
                self.go_back()
    
    def render_breadcrumbs(self) -> None:
        """Render breadcrumb navigation at the top of the page."""
        if not st.session_state.current_page:
            return
        
        current_page = self.pages[st.session_state.current_page]
        breadcrumbs = []
        
        # Add current page
        breadcrumbs.append((current_page.title, current_page.id))
        
        # Add parent pages
        parent_id = current_page.parent
        while parent_id and parent_id in self.pages:
            parent_page = self.pages[parent_id]
            breadcrumbs.append((parent_page.title, parent_id))
            parent_id = parent_page.parent
        
        # Reverse to get correct order
        breadcrumbs.reverse()
        
        # Render breadcrumbs
        breadcrumb_html = " &gt; ".join([
            f'<a href="#" id="breadcrumb_{page_id}" style="text-decoration: none; color: #4b9eff;">{title}</a>'
            for title, page_id in breadcrumbs[:-1]
        ] + [f'<span>{breadcrumbs[-1][0]}</span>'])
        
        st.markdown(f'<div style="margin-bottom: 1rem;">{breadcrumb_html}</div>', unsafe_allow_html=True)
        
        # Add JavaScript for breadcrumb clicks
        for _, page_id in breadcrumbs[:-1]:
            st.markdown(
                f"""
                <script>
                    document.getElementById("breadcrumb_{page_id}").addEventListener("click", function(e) {{
                        e.preventDefault();
                        // Use Streamlit's postMessage to communicate with Python
                        window.parent.postMessage({{
                            type: "streamlit:setComponentValue",
                            value: "{page_id}",
                            dataType: "string",
                            key: "breadcrumb_click"
                        }}, "*");
                    }});
                </script>
                """,
                unsafe_allow_html=True
            )
        
        # Handle breadcrumb clicks
        if "breadcrumb_click" in st.session_state:
            clicked_page = st.session_state.breadcrumb_click
            if clicked_page in self.pages:
                self.navigate_to(clicked_page)
                del st.session_state.breadcrumb_click
    
    def render_current_page(self) -> None:
        """Render the current page content."""
        if not st.session_state.current_page:
            # Default to first page if none selected
            sorted_pages = self.get_sorted_pages()
            if sorted_pages:
                st.session_state.current_page = sorted_pages[0].id
                self.current_page_id = sorted_pages[0].id
        
        if st.session_state.current_page:
            page = self.pages[st.session_state.current_page]
            
            # Render page title
            st.title(f":{page.icon}: {page.title}")
            
            # Render breadcrumbs
            self.render_breadcrumbs()
            
            # Render page content
            page.function()
    
    def render(self) -> None:
        """Render the complete navigation and current page."""
        self.render_sidebar_navigation()
        self.render_current_page()

# Create a global navigation manager instance
nav_manager = NavigationManager()

def register_page(
    id: str, 
    title: str, 
    icon: str, 
    function: Callable,
    parent: Optional[str] = None,
    order: int = 0,
    visible: bool = True
) -> None:
    """
    Register a page with the navigation manager.
    
    Args:
        id: Unique identifier for the page
        title: Display title for the page
        icon: Icon name from streamlit's icon set
        function: Function to call when page is selected
        parent: Optional parent page ID for hierarchical navigation
        order: Order in the navigation (lower numbers appear first)
        visible: Whether the page is visible in navigation
    """
    page = Page(id, title, icon, function, parent, order, visible)
    nav_manager.add_page(page)

def get_navigation_manager() -> NavigationManager:
    """
    Get the global navigation manager instance.
    
    Returns:
        NavigationManager instance
    """
    return nav_manager

def initialize_navigation() -> None:
    """Initialize the navigation with default pages."""
    # This function would be called to set up the initial navigation structure
    # It would register all the pages in the application
    pass

def render_navigation() -> None:
    """Render the navigation and current page."""
    nav_manager.render()

def demo_navigation() -> None:
    """Demonstrate the navigation system with sample pages."""
    # Define some demo page functions
    def dashboard_page():
        st.markdown("## Dashboard Content")
        st.write("This is the main dashboard page.")
        
        # Create some sample content
        col1, col2 = st.columns(2)
        with col1:
            st.metric("Sandwiches Inspected", "1,234", "+56")
        with col2:
            st.metric("Defect Rate", "0.8%", "-0.2%")
        
        st.markdown("### Recent Activity")
        st.write("No recent activity to display.")
    
    def camera_page():
        st.markdown("## Camera Monitoring")
        st.write("This page would show live camera feeds.")
        
        # Create a placeholder for camera feeds
        col1, col2 = st.columns(2)
        with col1:
            st.image("https://via.placeholder.com/640x480.png?text=Camera+1", use_column_width=True)
        with col2:
            st.image("https://via.placeholder.com/640x480.png?text=Camera+2", use_column_width=True)
    
    def defect_analysis_page():
        st.markdown("## Defect Analysis")
        st.write("This page would show defect statistics and analysis.")
        
        # Create some sample charts
        import numpy as np
        import pandas as pd
        
        # Sample data
        dates = pd.date_range(start='2025-04-01', end='2025-04-20')
        defect_rates = np.random.normal(1.0, 0.3, len(dates))
        defect_rates = np.maximum(defect_rates, 0)  # Ensure no negative rates
        
        df = pd.DataFrame({
            'Date': dates,
            'Defect Rate (%)': defect_rates
        })
        
        st.line_chart(df.set_index('Date'))
        
        # Defect types
        defect_types = {
            'Missing Filling': 45,
            'Uneven Cut': 30,
            'Crust Present': 15,
            'Foreign Object': 7,
            'Other': 3
        }
        
        defect_df = pd.DataFrame({
            'Defect Type': list(defect_types.keys()),
            'Count': list(defect_types.values())
        })
        
        st.bar_chart(defect_df.set_index('Defect Type'))
    
    def reports_page():
        st.markdown("## Reports")
        st.write("This page would allow generating and viewing reports.")
        
        # Create a sample report form
        with st.form("report_form"):
            st.write("Generate a new report")
            report_type = st.selectbox(
                "Report Type",
                ["Daily Production", "Defect Analysis", "System Performance"]
            )
            start_date = st.date_input("Start Date")
            end_date = st.date_input("End Date")
            include_charts = st.checkbox("Include Charts", value=True)
            include_raw_data = st.checkbox("Include Raw Data", value=False)
            
            submitted = st.form_submit_button("Generate Report")
            if submitted:
                st.success(f"Generated {report_type} report from {start_date} to {end_date}")
    
    def settings_page():
        st.markdown("## Settings")
        st.write("This page would contain application settings.")
        
        # Create sample settings
        st.markdown("### Camera Settings")
        camera_exposure = st.slider("Camera Exposure", 0, 100, 50)
        camera_gain = st.slider("Camera Gain", 0, 100, 25)
        
        st.markdown("### Detection Settings")
        detection_threshold = st.slider("Detection Threshold", 0.0, 1.0, 0.7)
        
        st.markdown("### System Settings")
        log_level = st.selectbox("Log Level", ["DEBUG", "INFO", "WARNING", "ERROR"])
        
        if st.button("Save Settings"):
            st.success("Settings saved successfully!")
    
    def user_management_page():
        st.markdown("## User Management")
        st.write("This page would manage user accounts and permissions.")
        
        # Create sample user list
        users = [
            {"username": "admin", "role": "Administrator", "last_login": "2025-04-20 08:30"},
            {"username": "operator1", "role": "Operator", "last_login": "2025-04-20 07:15"},
            {"username": "supervisor", "role": "Supervisor", "last_login": "2025-04-19 16:45"}
        ]
        
        st.markdown("### Users")
        for user in users:
            col1, col2, col3, col4 = st.columns([3, 3, 3, 1])
            with col1:
                st.write(user["username"])
            with col2:
                st.write(user["role"])
            with col3:
                st.write(user["last_login"])
            with col4:
                st.button("Edit", key=f"edit_{user['username']}")
        
        st.markdown("### Add New User")
        with st.form("add_user_form"):
            new_username = st.text_input("Username")
            new_password = st.text_input("Password", type="password")
            new_role = st.selectbox("Role", ["Administrator", "Supervisor", "Operator"])
            
            submitted = st.form_submit_button("Add User")
            if submitted and new_username:
                st.success(f"Added user {new_username} with role {new_role}")
    
    # Register pages
    register_page("dashboard", "Dashboard", "bar_chart", dashboard_page, order=0)
    register_page("camera", "Camera Monitoring", "camera", camera_page, order=1)
    register_page("defects", "Defect Analysis", "magnifying_glass", defect_analysis_page, order=2)
    register_page("reports", "Reports", "clipboard", reports_page, order=3)
    register_page("settings", "Settings", "gear", settings_page, parent="system", order=0)
    register_page("users", "User Management", "people", user_management_page, parent="system", order=1)
    
    # Render navigation
    render_navigation()

if __name__ == "__main__":
    # This will run when the script is executed directly
    st.set_page_config(
        page_title="Crustless Creations QC",
        page_icon="🥪",
        layout="wide",
        initial_sidebar_state="expanded"
    )
    demo_navigation()
