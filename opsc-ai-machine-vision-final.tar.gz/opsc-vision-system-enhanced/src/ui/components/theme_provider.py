"""
Theme provider for the OPSC Sandwich Quality Inspection System.

This module provides a theme provider that applies the design system
to the entire application and manages theme switching.
"""

import streamlit as st
from src.ui.components.design_system import load_design_system, apply_theme

def initialize_theme():
    """
    Initialize the application theme based on user preferences.
    This should be called at the beginning of the application.
    """
    # Load the design system
    load_design_system()
    
    # Check if theme is already in session state
    if 'theme' not in st.session_state:
        st.session_state.theme = 'light'
    
    # Apply the current theme
    apply_theme(st.session_state.theme)

def theme_selector():
    """
    Create a theme selector widget that allows users to switch between light and dark themes.
    """
    # Create a container for the theme selector
    with st.container():
        # Use columns to position the theme selector on the right
        cols = st.columns([4, 1])
        
        with cols[1]:
            # Create a selectbox for theme selection
            selected_theme = st.selectbox(
                "Theme",
                options=["Light", "Dark"],
                index=0 if st.session_state.theme == 'light' else 1,
                key="theme_selector"
            )
            
            # Update the theme if changed
            if (selected_theme == "Light" and st.session_state.theme != 'light') or \
               (selected_theme == "Dark" and st.session_state.theme != 'dark'):
                st.session_state.theme = 'light' if selected_theme == "Light" else 'dark'
                apply_theme(st.session_state.theme)
                st.experimental_rerun()

def apply_design_system_to_page(page_title=None, show_theme_selector=True):
    """
    Apply the design system to a page and set up the page structure.
    
    Args:
        page_title: Optional title to display at the top of the page
        show_theme_selector: Whether to show the theme selector
    """
    # Initialize the theme
    initialize_theme()
    
    # Show theme selector if requested
    if show_theme_selector:
        theme_selector()
    
    # Display page title if provided
    if page_title:
        st.markdown(f"<h1 class='typography-h1'>{page_title}</h1>", unsafe_allow_html=True)
        
    # Add a divider after the title
    if page_title:
        st.markdown("<hr style='margin-top: 0; margin-bottom: var(--spacing-md);'>", unsafe_allow_html=True)
