"""
Mobile responsive design for the OPSC Sandwich Quality Inspection System.

This module provides comprehensive mobile responsive implementation including:
- Mobile-first responsive layouts
- Touch-friendly controls
- Adaptive content presentation
- Device-specific optimizations
- Responsive navigation
"""

import streamlit as st
import pandas as pd
import numpy as np
import json
import sys
import os
from datetime import datetime, timedelta
import time
import random

# Add the parent directory to the path so we can import our components
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ui.components.material_ui import (
    load_material_icons, material_button, material_card, material_metric,
    material_tabs, material_data_table, material_progress, material_alert,
    material_badge, material_icon_button, material_divider, material_chip,
    material_select, material_text_field, material_checkbox, material_radio,
    material_slider, material_date_picker
)
from ui.components.theme_provider import apply_design_system_to_page
from ui.components.responsive_layout import (
    responsive_container, responsive_grid, responsive_columns, responsive_card,
    responsive_sidebar, responsive_table, responsive_tabs, responsive_image,
    responsive_menu
)
from ui.dark_mode import apply_theme, get_effective_theme

# Device detection
def detect_device_type():
    """
    Detect the user's device type using JavaScript.
    Returns 'mobile', 'tablet', or 'desktop'.
    """
    # Inject JavaScript to detect device type
    detect_device_js = """
    <script>
    // Function to detect device type
    function detectDeviceType() {
        const width = window.innerWidth;
        if (width < 768) {
            return 'mobile';
        } else if (width < 1024) {
            return 'tablet';
        } else {
            return 'desktop';
        }
    }
    
    // Store the detected device type in localStorage
    localStorage.setItem('device_type', detectDeviceType());
    
    // Listen for window resize events
    window.addEventListener('resize', function() {
        localStorage.setItem('device_type', detectDeviceType());
        // Only reload if the device type has changed
        const currentType = localStorage.getItem('device_type');
        const previousType = localStorage.getItem('previous_device_type');
        
        if (currentType !== previousType) {
            localStorage.setItem('previous_device_type', currentType);
            // Reload after a short delay to avoid multiple reloads during resizing
            clearTimeout(window.resizeTimer);
            window.resizeTimer = setTimeout(function() {
                window.location.reload();
            }, 500);
        }
    });
    </script>
    """
    
    # Inject the JavaScript
    st.markdown(detect_device_js, unsafe_allow_html=True)
    
    # Read the detected device type from localStorage using JavaScript
    read_device_js = """
    <script>
    // Function to send the detected device type to Streamlit
    function sendDeviceTypeToStreamlit() {
        const deviceType = localStorage.getItem('device_type') || 'desktop';
        localStorage.setItem('previous_device_type', deviceType);
        const deviceTypeInput = window.parent.document.querySelector('input[id="device_type"]');
        if (deviceTypeInput) {
            deviceTypeInput.value = deviceType;
            deviceTypeInput.dispatchEvent(new Event('input'));
        }
    }
    
    // Call the function when the page loads
    window.addEventListener('load', sendDeviceTypeToStreamlit);
    </script>
    """
    
    # Create a hidden input to receive the device type
    device_type = st.text_input("Device Type", value="desktop", key="device_type", label_visibility="collapsed")
    
    # Inject the JavaScript to read the device type
    st.markdown(read_device_js, unsafe_allow_html=True)
    
    return device_type

def detect_touch_capability():
    """
    Detect if the user's device has touch capability using JavaScript.
    Returns True if touch is supported, False otherwise.
    """
    # Inject JavaScript to detect touch capability
    detect_touch_js = """
    <script>
    // Function to detect touch capability
    function detectTouchCapability() {
        return 'ontouchstart' in window || navigator.maxTouchPoints > 0 || navigator.msMaxTouchPoints > 0;
    }
    
    // Store the detected touch capability in localStorage
    localStorage.setItem('touch_capability', detectTouchCapability());
    </script>
    """
    
    # Inject the JavaScript
    st.markdown(detect_touch_js, unsafe_allow_html=True)
    
    # Read the detected touch capability from localStorage using JavaScript
    read_touch_js = """
    <script>
    // Function to send the detected touch capability to Streamlit
    function sendTouchCapabilityToStreamlit() {
        const touchCapability = localStorage.getItem('touch_capability') === 'true';
        const touchCapabilityInput = window.parent.document.querySelector('input[id="touch_capability"]');
        if (touchCapabilityInput) {
            touchCapabilityInput.value = touchCapability;
            touchCapabilityInput.dispatchEvent(new Event('input'));
        }
    }
    
    // Call the function when the page loads
    window.addEventListener('load', sendTouchCapabilityToStreamlit);
    </script>
    """
    
    # Create a hidden input to receive the touch capability
    touch_capability = st.text_input("Touch Capability", value="false", key="touch_capability", label_visibility="collapsed")
    
    # Inject the JavaScript to read the touch capability
    st.markdown(read_touch_js, unsafe_allow_html=True)
    
    return touch_capability.lower() == "true"

def detect_screen_dimensions():
    """
    Detect the user's screen dimensions using JavaScript.
    Returns a tuple of (width, height) in pixels.
    """
    # Inject JavaScript to detect screen dimensions
    detect_dimensions_js = """
    <script>
    // Function to detect screen dimensions
    function detectScreenDimensions() {
        return {
            width: window.innerWidth,
            height: window.innerHeight
        };
    }
    
    // Store the detected screen dimensions in localStorage
    const dimensions = detectScreenDimensions();
    localStorage.setItem('screen_width', dimensions.width);
    localStorage.setItem('screen_height', dimensions.height);
    
    // Listen for window resize events
    window.addEventListener('resize', function() {
        const newDimensions = detectScreenDimensions();
        localStorage.setItem('screen_width', newDimensions.width);
        localStorage.setItem('screen_height', newDimensions.height);
        
        // Update inputs without reloading
        const widthInput = window.parent.document.querySelector('input[id="screen_width"]');
        const heightInput = window.parent.document.querySelector('input[id="screen_height"]');
        
        if (widthInput) {
            widthInput.value = newDimensions.width;
            widthInput.dispatchEvent(new Event('input'));
        }
        
        if (heightInput) {
            heightInput.value = newDimensions.height;
            heightInput.dispatchEvent(new Event('input'));
        }
    });
    </script>
    """
    
    # Inject the JavaScript
    st.markdown(detect_dimensions_js, unsafe_allow_html=True)
    
    # Read the detected screen dimensions from localStorage using JavaScript
    read_dimensions_js = """
    <script>
    // Function to send the detected screen dimensions to Streamlit
    function sendScreenDimensionsToStreamlit() {
        const width = localStorage.getItem('screen_width') || 1920;
        const height = localStorage.getItem('screen_height') || 1080;
        
        const widthInput = window.parent.document.querySelector('input[id="screen_width"]');
        const heightInput = window.parent.document.querySelector('input[id="screen_height"]');
        
        if (widthInput) {
            widthInput.value = width;
            widthInput.dispatchEvent(new Event('input'));
        }
        
        if (heightInput) {
            heightInput.value = height;
            heightInput.dispatchEvent(new Event('input'));
        }
    }
    
    // Call the function when the page loads
    window.addEventListener('load', sendScreenDimensionsToStreamlit);
    </script>
    """
    
    # Create hidden inputs to receive the screen dimensions
    width = st.text_input("Screen Width", value="1920", key="screen_width", label_visibility="collapsed")
    height = st.text_input("Screen Height", value="1080", key="screen_height", label_visibility="collapsed")
    
    # Inject the JavaScript to read the screen dimensions
    st.markdown(read_dimensions_js, unsafe_allow_html=True)
    
    try:
        return (int(width), int(height))
    except ValueError:
        return (1920, 1080)  # Default values if parsing fails

def detect_orientation():
    """
    Detect the user's device orientation using JavaScript.
    Returns 'portrait' or 'landscape'.
    """
    # Inject JavaScript to detect orientation
    detect_orientation_js = """
    <script>
    // Function to detect orientation
    function detectOrientation() {
        return window.innerWidth > window.innerHeight ? 'landscape' : 'portrait';
    }
    
    // Store the detected orientation in localStorage
    localStorage.setItem('orientation', detectOrientation());
    
    // Listen for window resize events
    window.addEventListener('resize', function() {
        localStorage.setItem('orientation', detectOrientation());
        
        // Update input without reloading
        const orientationInput = window.parent.document.querySelector('input[id="orientation"]');
        if (orientationInput) {
            orientationInput.value = detectOrientation();
            orientationInput.dispatchEvent(new Event('input'));
        }
    });
    </script>
    """
    
    # Inject the JavaScript
    st.markdown(detect_orientation_js, unsafe_allow_html=True)
    
    # Read the detected orientation from localStorage using JavaScript
    read_orientation_js = """
    <script>
    // Function to send the detected orientation to Streamlit
    function sendOrientationToStreamlit() {
        const orientation = localStorage.getItem('orientation') || 'landscape';
        const orientationInput = window.parent.document.querySelector('input[id="orientation"]');
        if (orientationInput) {
            orientationInput.value = orientation;
            orientationInput.dispatchEvent(new Event('input'));
        }
    }
    
    // Call the function when the page loads
    window.addEventListener('load', sendOrientationToStreamlit);
    </script>
    """
    
    # Create a hidden input to receive the orientation
    orientation = st.text_input("Orientation", value="landscape", key="orientation", label_visibility="collapsed")
    
    # Inject the JavaScript to read the orientation
    st.markdown(read_orientation_js, unsafe_allow_html=True)
    
    return orientation

def detect_browser():
    """
    Detect the user's browser using JavaScript.
    Returns the browser name and version.
    """
    # Inject JavaScript to detect browser
    detect_browser_js = """
    <script>
    // Function to detect browser
    function detectBrowser() {
        const userAgent = navigator.userAgent;
        let browserName = "Unknown";
        let browserVersion = "Unknown";
        
        // Chrome
        if (userAgent.indexOf("Chrome") > -1) {
            browserName = "Chrome";
            browserVersion = userAgent.match(/Chrome\/([\d.]+)/)[1];
        }
        // Firefox
        else if (userAgent.indexOf("Firefox") > -1) {
            browserName = "Firefox";
            browserVersion = userAgent.match(/Firefox\/([\d.]+)/)[1];
        }
        // Safari
        else if (userAgent.indexOf("Safari") > -1) {
            browserName = "Safari";
            browserVersion = userAgent.match(/Version\/([\d.]+)/)[1];
        }
        // Edge
        else if (userAgent.indexOf("Edg") > -1) {
            browserName = "Edge";
            browserVersion = userAgent.match(/Edg\/([\d.]+)/)[1];
        }
        // IE
        else if (userAgent.indexOf("MSIE") > -1 || userAgent.indexOf("Trident") > -1) {
            browserName = "Internet Explorer";
            browserVersion = userAgent.match(/(?:MSIE |rv:)([\d.]+)/)[1];
        }
        
        return {
            name: browserName,
            version: browserVersion
        };
    }
    
    // Store the detected browser in localStorage
    const browser = detectBrowser();
    localStorage.setItem('browser_name', browser.name);
    localStorage.setItem('browser_version', browser.version);
    </script>
    """
    
    # Inject the JavaScript
    st.markdown(detect_browser_js, unsafe_allow_html=True)
    
    # Read the detected browser from localStorage using JavaScript
    read_browser_js = """
    <script>
    // Function to send the detected browser to Streamlit
    function sendBrowserToStreamlit() {
        const browserName = localStorage.getItem('browser_name') || 'Unknown';
        const browserVersion = localStorage.getItem('browser_version') || 'Unknown';
        
        const browserNameInput = window.parent.document.querySelector('input[id="browser_name"]');
        const browserVersionInput = window.parent.document.querySelector('input[id="browser_version"]');
        
        if (browserNameInput) {
            browserNameInput.value = browserName;
            browserNameInput.dispatchEvent(new Event('input'));
        }
        
        if (browserVersionInput) {
            browserVersionInput.value = browserVersion;
            browserVersionInput.dispatchEvent(new Event('input'));
        }
    }
    
    // Call the function when the page loads
    window.addEventListener('load', sendBrowserToStreamlit);
    </script>
    """
    
    # Create hidden inputs to receive the browser information
    browser_name = st.text_input("Browser Name", value="Unknown", key="browser_name", label_visibility="collapsed")
    browser_version = st.text_input("Browser Version", value="Unknown", key="browser_version", label_visibility="collapsed")
    
    # Inject the JavaScript to read the browser information
    st.markdown(read_browser_js, unsafe_allow_html=True)
    
    return {
        "name": browser_name,
        "version": browser_version
    }

# Mobile-specific optimizations
def optimize_for_mobile():
    """
    Apply mobile-specific optimizations using CSS and JavaScript.
    """
    # Mobile-specific CSS
    mobile_css = """
    <style>
    @media (max-width: 767px) {
        /* Increase touch target sizes */
        button, .stButton > button, .stSelectbox > div > div > div {
            min-height: 44px;
            min-width: 44px;
        }
        
        /* Increase font sizes for readability */
        body {
            font-size: 16px;
        }
        
        h1 {
            font-size: 24px;
        }
        
        h2 {
            font-size: 20px;
        }
        
        h3 {
            font-size: 18px;
        }
        
        /* Reduce padding to maximize content area */
        .stApp {
            padding: 1rem 0.5rem;
        }
        
        /* Make sidebar full-width when open */
        section[data-testid="stSidebar"] {
            width: 100% !important;
            min-width: 100% !important;
            max-width: 100% !important;
        }
        
        /* Adjust metrics for mobile */
        [data-testid="metric-container"] {
            padding: 0.5rem;
        }
        
        /* Adjust charts for mobile */
        [data-testid="stChart"] {
            height: auto !important;
        }
        
        /* Adjust dataframes for mobile */
        [data-testid="stDataFrame"] {
            overflow-x: auto;
        }
        
        /* Custom component adjustments */
        .material-card {
            padding: 0.75rem;
        }
        
        .material-card-header {
            padding-bottom: 0.5rem;
            margin-bottom: 0.5rem;
        }
        
        .material-button {
            padding: 0.5rem 0.75rem;
        }
        
        .material-tabs {
            overflow-x: auto;
            white-space: nowrap;
        }
        
        .material-tab {
            padding: 0.5rem 0.75rem;
        }
        
        .material-data-table {
            overflow-x: auto;
        }
        
        /* Hide certain elements on mobile */
        .hide-on-mobile {
            display: none !important;
        }
        
        /* Show mobile-only elements */
        .show-on-mobile {
            display: block !important;
        }
    }
    </style>
    """
    
    # Inject the CSS
    st.markdown(mobile_css, unsafe_allow_html=True)
    
    # Mobile-specific JavaScript
    mobile_js = """
    <script>
    // Function to apply mobile optimizations
    function applyMobileOptimizations() {
        // Detect if mobile
        const isMobile = window.innerWidth < 768;
        
        if (isMobile) {
            // Add mobile class to body
            document.body.classList.add('mobile');
            
            // Disable hover effects for better touch experience
            const style = document.createElement('style');
            style.innerHTML = `
                @media (max-width: 767px) {
                    * {
                        -webkit-tap-highlight-color: rgba(0,0,0,0);
                    }
                    
                    *:hover {
                        transition: none !important;
                    }
                }
            `;
            document.head.appendChild(style);
            
            // Add viewport meta tag if not present
            if (!document.querySelector('meta[name="viewport"]')) {
                const meta = document.createElement('meta');
                meta.name = 'viewport';
                meta.content = 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no';
                document.head.appendChild(meta);
            }
            
            // Add touch event handlers for better responsiveness
            document.addEventListener('touchstart', function() {}, {passive: true});
        }
    }
    
    // Call the function when the page loads
    window.addEventListener('load', applyMobileOptimizations);
    </script>
    """
    
    # Inject the JavaScript
    st.markdown(mobile_js, unsafe_allow_html=True)

# Tablet-specific optimizations
def optimize_for_tablet():
    """
    Apply tablet-specific optimizations using CSS and JavaScript.
    """
    # Tablet-specific CSS
    tablet_css = """
    <style>
    @media (min-width: 768px) and (max-width: 1023px) {
        /* Adjust touch target sizes for tablet */
        button, .stButton > button, .stSelectbox > div > div > div {
            min-height: 40px;
            min-width: 40px;
        }
        
        /* Adjust font sizes for tablet */
        body {
            font-size: 15px;
        }
        
        h1 {
            font-size: 28px;
        }
        
        h2 {
            font-size: 24px;
        }
        
        h3 {
            font-size: 20px;
        }
        
        /* Adjust padding for tablet */
        .stApp {
            padding: 1.5rem 1rem;
        }
        
        /* Adjust sidebar width for tablet */
        section[data-testid="stSidebar"] {
            width: 300px !important;
            min-width: 300px !important;
            max-width: 300px !important;
        }
        
        /* Custom component adjustments */
        .material-card {
            padding: 1rem;
        }
        
        .material-card-header {
            padding-bottom: 0.75rem;
            margin-bottom: 0.75rem;
        }
        
        .material-button {
            padding: 0.5rem 1rem;
        }
        
        /* Hide certain elements on tablet */
        .hide-on-tablet {
            display: none !important;
        }
        
        /* Show tablet-only elements */
        .show-on-tablet {
            display: block !important;
        }
    }
    </style>
    """
    
    # Inject the CSS
    st.markdown(tablet_css, unsafe_allow_html=True)
    
    # Tablet-specific JavaScript
    tablet_js = """
    <script>
    // Function to apply tablet optimizations
    function applyTabletOptimizations() {
        // Detect if tablet
        const isTablet = window.innerWidth >= 768 && window.innerWidth < 1024;
        
        if (isTablet) {
            // Add tablet class to body
            document.body.classList.add('tablet');
            
            // Add viewport meta tag if not present
            if (!document.querySelector('meta[name="viewport"]')) {
                const meta = document.createElement('meta');
                meta.name = 'viewport';
                meta.content = 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no';
                document.head.appendChild(meta);
            }
            
            // Add touch event handlers for better responsiveness
            document.addEventListener('touchstart', function() {}, {passive: true});
        }
    }
    
    // Call the function when the page loads
    window.addEventListener('load', applyTabletOptimizations);
    </script>
    """
    
    # Inject the JavaScript
    st.markdown(tablet_js, unsafe_allow_html=True)

# Desktop-specific optimizations
def optimize_for_desktop():
    """
    Apply desktop-specific optimizations using CSS and JavaScript.
    """
    # Desktop-specific CSS
    desktop_css = """
    <style>
    @media (min-width: 1024px) {
        /* Adjust font sizes for desktop */
        body {
            font-size: 16px;
        }
        
        h1 {
            font-size: 32px;
        }
        
        h2 {
            font-size: 28px;
        }
        
        h3 {
            font-size: 24px;
        }
        
        /* Adjust padding for desktop */
        .stApp {
            padding: 2rem;
        }
        
        /* Adjust sidebar width for desktop */
        section[data-testid="stSidebar"] {
            width: 320px !important;
            min-width: 320px !important;
            max-width: 320px !important;
        }
        
        /* Custom component adjustments */
        .material-card {
            padding: 1.5rem;
        }
        
        .material-card-header {
            padding-bottom: 1rem;
            margin-bottom: 1rem;
        }
        
        .material-button {
            padding: 0.5rem 1.25rem;
        }
        
        /* Hide certain elements on desktop */
        .hide-on-desktop {
            display: none !important;
        }
        
        /* Show desktop-only elements */
        .show-on-desktop {
            display: block !important;
        }
    }
    </style>
    """
    
    # Inject the CSS
    st.markdown(desktop_css, unsafe_allow_html=True)
    
    # Desktop-specific JavaScript
    desktop_js = """
    <script>
    // Function to apply desktop optimizations
    function applyDesktopOptimizations() {
        // Detect if desktop
        const isDesktop = window.innerWidth >= 1024;
        
        if (isDesktop) {
            // Add desktop class to body
            document.body.classList.add('desktop');
            
            // Enable hover effects
            const style = document.createElement('style');
            style.innerHTML = `
                @media (min-width: 1024px) {
                    .hover-effect:hover {
                        transition: all 0.2s ease-in-out;
                    }
                }
            `;
            document.head.appendChild(style);
            
            // Add keyboard navigation support
            document.addEventListener('keydown', function(e) {
                // Tab navigation
                if (e.key === 'Tab') {
                    document.body.classList.add('keyboard-navigation');
                }
            });
            
            // Remove keyboard navigation class on mouse click
            document.addEventListener('mousedown', function() {
                document.body.classList.remove('keyboard-navigation');
            });
        }
    }
    
    // Call the function when the page loads
    window.addEventListener('load', applyDesktopOptimizations);
    </script>
    """
    
    # Inject the JavaScript
    st.markdown(desktop_js, unsafe_allow_html=True)

# Touch-friendly controls
def apply_touch_friendly_controls():
    """
    Apply touch-friendly controls using CSS and JavaScript.
    """
    # Touch-friendly CSS
    touch_css = """
    <style>
    /* Increase touch target sizes */
    .touch-friendly button, 
    .touch-friendly .stButton > button, 
    .touch-friendly .stSelectbox > div > div > div,
    .touch-friendly .stMultiselect > div > div > div {
        min-height: 44px;
        min-width: 44px;
    }
    
    /* Add spacing between touch targets */
    .touch-friendly button + button,
    .touch-friendly .stButton + .stButton {
        margin-left: 8px;
    }
    
    /* Make sliders easier to use on touch devices */
    .touch-friendly .stSlider > div > div > div > div {
        height: 24px;
        width: 24px;
        margin-top: -12px;
    }
    
    /* Make checkboxes and radio buttons easier to tap */
    .touch-friendly .stCheckbox > div > div > label,
    .touch-friendly .stRadio > div > div > label {
        padding: 8px 0;
        display: block;
    }
    
    /* Improve dropdown menus for touch */
    .touch-friendly .stSelectbox > div > div > div > div {
        padding: 12px 8px;
    }
    
    /* Custom touch-friendly components */
    .touch-friendly .material-button {
        padding: 12px 16px;
    }
    
    .touch-friendly .material-icon-button {
        min-width: 44px;
        min-height: 44px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .touch-friendly .material-tab {
        padding: 12px 16px;
    }
    
    .touch-friendly .material-chip {
        padding: 8px 12px;
    }
    
    /* Add active state for touch feedback */
    .touch-friendly button:active,
    .touch-friendly .stButton > button:active,
    .touch-friendly .material-button:active,
    .touch-friendly .material-icon-button:active {
        transform: scale(0.97);
    }
    </style>
    """
    
    # Inject the CSS
    st.markdown(touch_css, unsafe_allow_html=True)
    
    # Touch-friendly JavaScript
    touch_js = """
    <script>
    // Function to apply touch-friendly controls
    function applyTouchFriendlyControls() {
        // Detect if touch device
        const isTouch = 'ontouchstart' in window || navigator.maxTouchPoints > 0 || navigator.msMaxTouchPoints > 0;
        
        if (isTouch) {
            // Add touch-friendly class to body
            document.body.classList.add('touch-friendly');
            
            // Disable double-tap zoom on buttons and controls
            const touchElements = document.querySelectorAll('button, .stButton > button, .stSelectbox, .stMultiselect, .stCheckbox, .stRadio, .material-button, .material-icon-button, .material-tab, .material-chip');
            
            touchElements.forEach(element => {
                element.addEventListener('touchend', function(e) {
                    e.preventDefault();
                    // Trigger click after a short delay
                    setTimeout(() => {
                        element.click();
                    }, 10);
                });
            });
            
            // Add active state for touch feedback
            document.addEventListener('touchstart', function(e) {
                const target = e.target.closest('button, .stButton > button, .material-button, .material-icon-button');
                if (target) {
                    target.classList.add('active');
                }
            }, {passive: true});
            
            document.addEventListener('touchend', function(e) {
                const activeElements = document.querySelectorAll('.active');
                activeElements.forEach(element => {
                    element.classList.remove('active');
                });
            }, {passive: true});
        }
    }
    
    // Call the function when the page loads
    window.addEventListener('load', applyTouchFriendlyControls);
    </script>
    """
    
    # Inject the JavaScript
    st.markdown(touch_js, unsafe_allow_html=True)

# Responsive navigation
def create_responsive_navigation(items, active_item=None):
    """
    Create a responsive navigation menu that adapts to different screen sizes.
    
    Parameters:
    - items: List of dictionaries with 'name', 'icon', and 'url' keys
    - active_item: Name of the currently active item
    
    Returns:
    - None (renders the navigation directly)
    """
    # Detect device type
    device_type = detect_device_type()
    
    # Desktop navigation (horizontal)
    if device_type == 'desktop':
        st.markdown(
            """
            <style>
            .desktop-nav {
                display: flex;
                background-color: var(--color-background-secondary);
                border-radius: 4px;
                margin-bottom: 20px;
                overflow: hidden;
            }
            
            .desktop-nav-item {
                flex: 1;
                text-align: center;
                padding: 12px 16px;
                color: var(--color-text-secondary);
                text-decoration: none;
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 8px;
                transition: background-color 0.2s ease;
            }
            
            .desktop-nav-item:hover {
                background-color: var(--color-background-tertiary);
            }
            
            .desktop-nav-item.active {
                background-color: var(--color-primary-main);
                color: var(--color-text-primary);
            }
            
            .desktop-nav-item .material-icons {
                font-size: 20px;
            }
            </style>
            """,
            unsafe_allow_html=True
        )
        
        # Create the navigation HTML
        nav_html = '<div class="desktop-nav">'
        
        for item in items:
            active_class = "active" if item['name'] == active_item else ""
            nav_html += f"""
            <a href="{item['url']}" class="desktop-nav-item {active_class}">
                <span class="material-icons">{item['icon']}</span>
                <span>{item['name']}</span>
            </a>
            """
        
        nav_html += '</div>'
        
        st.markdown(nav_html, unsafe_allow_html=True)
    
    # Tablet navigation (horizontal with smaller text)
    elif device_type == 'tablet':
        st.markdown(
            """
            <style>
            .tablet-nav {
                display: flex;
                background-color: var(--color-background-secondary);
                border-radius: 4px;
                margin-bottom: 16px;
                overflow-x: auto;
                white-space: nowrap;
                -webkit-overflow-scrolling: touch;
            }
            
            .tablet-nav-item {
                padding: 10px 14px;
                color: var(--color-text-secondary);
                text-decoration: none;
                display: flex;
                align-items: center;
                gap: 6px;
                transition: background-color 0.2s ease;
            }
            
            .tablet-nav-item:hover {
                background-color: var(--color-background-tertiary);
            }
            
            .tablet-nav-item.active {
                background-color: var(--color-primary-main);
                color: var(--color-text-primary);
            }
            
            .tablet-nav-item .material-icons {
                font-size: 18px;
            }
            </style>
            """,
            unsafe_allow_html=True
        )
        
        # Create the navigation HTML
        nav_html = '<div class="tablet-nav">'
        
        for item in items:
            active_class = "active" if item['name'] == active_item else ""
            nav_html += f"""
            <a href="{item['url']}" class="tablet-nav-item {active_class}">
                <span class="material-icons">{item['icon']}</span>
                <span>{item['name']}</span>
            </a>
            """
        
        nav_html += '</div>'
        
        st.markdown(nav_html, unsafe_allow_html=True)
    
    # Mobile navigation (bottom bar with icons only)
    else:
        st.markdown(
            """
            <style>
            .mobile-nav {
                display: flex;
                background-color: var(--color-background-secondary);
                position: fixed;
                bottom: 0;
                left: 0;
                right: 0;
                z-index: 1000;
                box-shadow: 0 -2px 5px rgba(0, 0, 0, 0.1);
            }
            
            .mobile-nav-item {
                flex: 1;
                text-align: center;
                padding: 8px 4px;
                color: var(--color-text-secondary);
                text-decoration: none;
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                gap: 4px;
                font-size: 12px;
            }
            
            .mobile-nav-item.active {
                color: var(--color-primary-main);
            }
            
            .mobile-nav-item .material-icons {
                font-size: 24px;
            }
            
            /* Add padding to the bottom of the page to account for the fixed navigation */
            body {
                padding-bottom: 60px;
            }
            </style>
            """,
            unsafe_allow_html=True
        )
        
        # Create the navigation HTML
        nav_html = '<div class="mobile-nav">'
        
        for item in items:
            active_class = "active" if item['name'] == active_item else ""
            nav_html += f"""
            <a href="{item['url']}" class="mobile-nav-item {active_class}">
                <span class="material-icons">{item['icon']}</span>
                <span>{item['name']}</span>
            </a>
            """
        
        nav_html += '</div>'
        
        st.markdown(nav_html, unsafe_allow_html=True)

# Responsive data visualization
def create_responsive_chart(data, chart_type="line", x=None, y=None, title=None, height=None):
    """
    Create a responsive chart that adapts to different screen sizes.
    
    Parameters:
    - data: DataFrame or dictionary containing the data
    - chart_type: Type of chart ('line', 'bar', 'scatter', 'area', 'pie')
    - x: Column name for x-axis
    - y: Column name(s) for y-axis (can be a list for multiple series)
    - title: Chart title
    - height: Chart height (will be adjusted for mobile)
    
    Returns:
    - None (renders the chart directly)
    """
    # Detect device type
    device_type = detect_device_type()
    
    # Adjust height based on device type
    if height is None:
        if device_type == 'mobile':
            height = 250
        elif device_type == 'tablet':
            height = 350
        else:
            height = 400
    else:
        # Scale provided height for mobile and tablet
        if device_type == 'mobile':
            height = int(height * 0.6)
        elif device_type == 'tablet':
            height = int(height * 0.8)
    
    # Convert data to DataFrame if it's a dictionary
    if isinstance(data, dict):
        data = pd.DataFrame(data)
    
    # Create the chart based on type
    if chart_type == "line":
        st.line_chart(data, x=x, y=y, height=height)
    elif chart_type == "bar":
        st.bar_chart(data, x=x, y=y, height=height)
    elif chart_type == "scatter":
        # For scatter plots, we need to use Plotly
        import plotly.express as px
        
        fig = px.scatter(data, x=x, y=y, title=title)
        fig.update_layout(height=height)
        st.plotly_chart(fig, use_container_width=True)
    elif chart_type == "area":
        st.area_chart(data, x=x, y=y, height=height)
    elif chart_type == "pie":
        # For pie charts, we need to use Plotly
        import plotly.express as px
        
        fig = px.pie(data, names=x, values=y, title=title)
        fig.update_layout(height=height)
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.warning(f"Unsupported chart type: {chart_type}")

# Responsive data tables
def create_responsive_data_table(data, columns=None, max_rows=None, hide_columns_mobile=None):
    """
    Create a responsive data table that adapts to different screen sizes.
    
    Parameters:
    - data: DataFrame or dictionary containing the data
    - columns: List of columns to display (if None, all columns are displayed)
    - max_rows: Maximum number of rows to display (if None, all rows are displayed)
    - hide_columns_mobile: List of columns to hide on mobile devices
    
    Returns:
    - None (renders the table directly)
    """
    # Detect device type
    device_type = detect_device_type()
    
    # Convert data to DataFrame if it's a dictionary
    if isinstance(data, dict):
        data = pd.DataFrame(data)
    
    # Filter columns if specified
    if columns is not None:
        data = data[columns]
    
    # Hide columns on mobile if specified
    if device_type == 'mobile' and hide_columns_mobile is not None:
        for col in hide_columns_mobile:
            if col in data.columns:
                data = data.drop(columns=[col])
    
    # Limit rows if specified
    if max_rows is not None:
        data = data.head(max_rows)
    
    # Add responsive styling
    st.markdown(
        """
        <style>
        /* Responsive table styles */
        .responsive-table-container {
            overflow-x: auto;
            margin-bottom: 16px;
        }
        
        @media (max-width: 767px) {
            .dataframe {
                font-size: 12px;
            }
            
            .dataframe th, .dataframe td {
                padding: 4px 8px;
            }
        }
        </style>
        """,
        unsafe_allow_html=True
    )
    
    # Wrap the table in a responsive container
    st.markdown('<div class="responsive-table-container">', unsafe_allow_html=True)
    st.dataframe(data)
    st.markdown('</div>', unsafe_allow_html=True)

# Responsive images
def display_responsive_image(image_path, caption=None, use_container_width=True):
    """
    Display an image that adapts to different screen sizes.
    
    Parameters:
    - image_path: Path to the image file
    - caption: Optional caption for the image
    - use_container_width: Whether to use the full container width
    
    Returns:
    - None (displays the image directly)
    """
    # Detect device type
    device_type = detect_device_type()
    
    # Add responsive styling
    st.markdown(
        """
        <style>
        /* Responsive image styles */
        .responsive-image-container {
            margin-bottom: 16px;
        }
        
        .responsive-image-container img {
            max-width: 100%;
            height: auto;
            border-radius: 4px;
        }
        
        .responsive-image-caption {
            margin-top: 8px;
            font-size: 14px;
            color: var(--color-text-secondary);
            text-align: center;
        }
        
        @media (max-width: 767px) {
            .responsive-image-caption {
                font-size: 12px;
            }
        }
        </style>
        """,
        unsafe_allow_html=True
    )
    
    # Display the image
    st.image(image_path, caption=caption, use_column_width=use_container_width)

# Responsive layout grid
def create_responsive_grid(items, columns_desktop=3, columns_tablet=2, columns_mobile=1):
    """
    Create a responsive grid layout that adapts to different screen sizes.
    
    Parameters:
    - items: List of content items to display in the grid
    - columns_desktop: Number of columns on desktop
    - columns_tablet: Number of columns on tablet
    - columns_mobile: Number of columns on mobile
    
    Returns:
    - None (renders the grid directly)
    """
    # Detect device type
    device_type = detect_device_type()
    
    # Determine number of columns based on device type
    if device_type == 'mobile':
        num_columns = columns_mobile
    elif device_type == 'tablet':
        num_columns = columns_tablet
    else:
        num_columns = columns_desktop
    
    # Create columns
    cols = st.columns(num_columns)
    
    # Distribute items across columns
    for i, item in enumerate(items):
        with cols[i % num_columns]:
            st.markdown(item, unsafe_allow_html=True)

# Mobile app wrapper
def create_mobile_app_wrapper(title, content_func, show_back_button=False, back_url=None):
    """
    Create a mobile app-like wrapper for the content.
    
    Parameters:
    - title: Page title
    - content_func: Function that renders the main content
    - show_back_button: Whether to show a back button
    - back_url: URL to navigate to when the back button is clicked
    
    Returns:
    - None (renders the wrapper directly)
    """
    # Detect device type
    device_type = detect_device_type()
    
    # Add mobile app styling
    st.markdown(
        """
        <style>
        /* Mobile app wrapper styles */
        .mobile-app-wrapper {
            max-width: 100%;
            margin: 0 auto;
            padding: 0;
        }
        
        .mobile-app-header {
            display: flex;
            align-items: center;
            padding: 12px 16px;
            background-color: var(--color-background-secondary);
            border-bottom: 1px solid var(--color-border-light);
            position: sticky;
            top: 0;
            z-index: 100;
        }
        
        .mobile-app-title {
            flex-grow: 1;
            font-size: 18px;
            font-weight: 500;
            margin: 0;
            text-align: center;
        }
        
        .mobile-app-back-button {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            border-radius: 20px;
            background: none;
            border: none;
            cursor: pointer;
            color: var(--color-text-primary);
        }
        
        .mobile-app-content {
            padding: 16px;
        }
        
        @media (min-width: 768px) {
            .mobile-app-wrapper {
                max-width: 768px;
                border-radius: 8px;
                box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
                margin: 20px auto;
                overflow: hidden;
            }
        }
        </style>
        """,
        unsafe_allow_html=True
    )
    
    # Create the mobile app wrapper
    st.markdown('<div class="mobile-app-wrapper">', unsafe_allow_html=True)
    
    # Create the header
    header_html = '<div class="mobile-app-header">'
    
    if show_back_button:
        header_html += f"""
        <a href="{back_url or '#'}" class="mobile-app-back-button">
            <span class="material-icons">arrow_back</span>
        </a>
        """
    else:
        header_html += '<div style="width: 40px;"></div>'
    
    header_html += f'<h1 class="mobile-app-title">{title}</h1>'
    header_html += '<div style="width: 40px;"></div>'
    header_html += '</div>'
    
    st.markdown(header_html, unsafe_allow_html=True)
    
    # Create the content container
    st.markdown('<div class="mobile-app-content">', unsafe_allow_html=True)
    
    # Render the content
    content_func()
    
    # Close the containers
    st.markdown('</div>', unsafe_allow_html=True)
    st.markdown('</div>', unsafe_allow_html=True)

# Orientation handling
def handle_orientation_change():
    """
    Handle device orientation changes.
    """
    # Detect orientation
    orientation = detect_orientation()
    
    # Add orientation-specific styling
    st.markdown(
        f"""
        <style>
        /* Orientation-specific styles */
        body {{
            orientation: {orientation};
        }}
        
        @media (orientation: portrait) {{
            .landscape-only {{
                display: none !important;
            }}
            
            .portrait-only {{
                display: block !important;
            }}
        }}
        
        @media (orientation: landscape) {{
            .portrait-only {{
                display: none !important;
            }}
            
            .landscape-only {{
                display: block !important;
            }}
        }}
        </style>
        """,
        unsafe_allow_html=True
    )
    
    # Add JavaScript for orientation change handling
    orientation_js = """
    <script>
    // Function to handle orientation changes
    function handleOrientationChange() {
        const orientation = window.innerWidth > window.innerHeight ? 'landscape' : 'portrait';
        document.body.setAttribute('data-orientation', orientation);
        
        // Dispatch a custom event for orientation change
        const event = new CustomEvent('orientationchange', {
            detail: { orientation: orientation }
        });
        document.dispatchEvent(event);
    }
    
    // Call the function when the page loads
    window.addEventListener('load', handleOrientationChange);
    
    // Listen for resize events (which include orientation changes)
    window.addEventListener('resize', handleOrientationChange);
    </script>
    """
    
    st.markdown(orientation_js, unsafe_allow_html=True)
    
    return orientation

# Main responsive design function
def apply_responsive_design():
    """
    Apply responsive design to the application.
    """
    # Detect device information
    device_type = detect_device_type()
    touch_capability = detect_touch_capability()
    screen_dimensions = detect_screen_dimensions()
    orientation = detect_orientation()
    browser = detect_browser()
    
    # Apply device-specific optimizations
    if device_type == 'mobile':
        optimize_for_mobile()
    elif device_type == 'tablet':
        optimize_for_tablet()
    else:
        optimize_for_desktop()
    
    # Apply touch-friendly controls if device has touch capability
    if touch_capability:
        apply_touch_friendly_controls()
    
    # Handle orientation changes
    handle_orientation_change()
    
    # Apply theme
    effective_theme = apply_theme()
    
    # Return device information for use in the application
    return {
        'device_type': device_type,
        'touch_capability': touch_capability,
        'screen_dimensions': screen_dimensions,
        'orientation': orientation,
        'browser': browser,
        'theme': effective_theme
    }

# Demo page to showcase mobile responsive design
def render_mobile_responsive_demo():
    """
    Render a demo page showcasing mobile responsive design.
    """
    # Apply design system to the page
    apply_design_system_to_page("Mobile Responsive Demo")
    
    # Load Material Icons
    load_material_icons()
    
    # Apply responsive design and get device information
    device_info = apply_responsive_design()
    
    # Page header
    st.markdown(f"# Mobile Responsive Demo")
    
    st.markdown("""
    This page demonstrates the mobile responsive design features of the OPSC Sandwich Quality Inspection System.
    The interface automatically adapts to different screen sizes and device types.
    """)
    
    # Device information
    st.markdown("## Device Information")
    
    device_info_html = f"""
    <div style="background-color: var(--color-background-card); padding: 16px; border-radius: 8px; margin-bottom: 20px;">
        <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
            <span style="color: var(--color-text-secondary);">Device Type:</span>
            <span style="font-weight: 500;">{device_info['device_type'].capitalize()}</span>
        </div>
        <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
            <span style="color: var(--color-text-secondary);">Touch Capability:</span>
            <span style="font-weight: 500;">{str(device_info['touch_capability']).capitalize()}</span>
        </div>
        <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
            <span style="color: var(--color-text-secondary);">Screen Dimensions:</span>
            <span style="font-weight: 500;">{device_info['screen_dimensions'][0]} x {device_info['screen_dimensions'][1]}</span>
        </div>
        <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
            <span style="color: var(--color-text-secondary);">Orientation:</span>
            <span style="font-weight: 500;">{device_info['orientation'].capitalize()}</span>
        </div>
        <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
            <span style="color: var(--color-text-secondary);">Browser:</span>
            <span style="font-weight: 500;">{device_info['browser']['name']} {device_info['browser']['version']}</span>
        </div>
        <div style="display: flex; justify-content: space-between;">
            <span style="color: var(--color-text-secondary);">Theme:</span>
            <span style="font-weight: 500;">{device_info['theme'].capitalize()}</span>
        </div>
    </div>
    """
    
    st.markdown(device_info_html, unsafe_allow_html=True)
    
    # Responsive navigation demo
    st.markdown("## Responsive Navigation")
    
    st.markdown("""
    The navigation adapts to different screen sizes:
    - Desktop: Horizontal navigation with text and icons
    - Tablet: Horizontal scrollable navigation with text and icons
    - Mobile: Bottom navigation bar with icons and small text
    """)
    
    # Create navigation items
    nav_items = [
        {'name': 'Dashboard', 'icon': 'dashboard', 'url': '#dashboard'},
        {'name': 'Cameras', 'icon': 'videocam', 'url': '#cameras'},
        {'name': 'Analytics', 'icon': 'analytics', 'url': '#analytics'},
        {'name': 'Settings', 'icon': 'settings', 'url': '#settings'},
        {'name': 'Help', 'icon': 'help', 'url': '#help'}
    ]
    
    # Render the navigation
    create_responsive_navigation(nav_items, active_item='Dashboard')
    
    # Responsive layout demo
    st.markdown("## Responsive Layout")
    
    st.markdown("""
    The layout adapts to different screen sizes, reorganizing content to provide the best experience on each device.
    """)
    
    # Create responsive grid based on device type
    if device_info['device_type'] == 'desktop':
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.metric("Total Sandwiches", "12,458", "+2.5%")
        
        with col2:
            st.metric("Defect Rate", "1.2%", "-0.3%")
        
        with col3:
            st.metric("Production Rate", "250/hr", "+5%")
    elif device_info['device_type'] == 'tablet':
        col1, col2 = st.columns(2)
        
        with col1:
            st.metric("Total Sandwiches", "12,458", "+2.5%")
            st.metric("Production Rate", "250/hr", "+5%")
        
        with col2:
            st.metric("Defect Rate", "1.2%", "-0.3%")
    else:
        st.metric("Total Sandwiches", "12,458", "+2.5%")
        st.metric("Defect Rate", "1.2%", "-0.3%")
        st.metric("Production Rate", "250/hr", "+5%")
    
    # Responsive charts demo
    st.markdown("## Responsive Charts")
    
    st.markdown("""
    Charts automatically resize based on screen size, ensuring they remain readable on all devices.
    """)
    
    # Create sample data
    chart_data = {
        "Date": [f"2025-04-{i:02d}" for i in range(1, 22)],
        "Production": [random.randint(200, 300) for _ in range(21)],
        "Defects": [random.randint(2, 8) for _ in range(21)]
    }
    
    # Convert to DataFrame
    chart_df = pd.DataFrame(chart_data)
    
    # Create responsive chart
    create_responsive_chart(chart_df, chart_type="line", x="Date", y=["Production", "Defects"], title="Production Trends")
    
    # Responsive tables demo
    st.markdown("## Responsive Tables")
    
    st.markdown("""
    Tables adapt to different screen sizes, hiding less important columns on mobile and adjusting formatting for readability.
    """)
    
    # Create sample data
    table_data = {
        "Timestamp": [
            (datetime.now() - timedelta(minutes=i*5)).strftime("%H:%M:%S")
            for i in range(5)
        ],
        "Camera": ["Top Camera", "Side Camera 1", "Side Camera 2", "Bottom Camera", "Top Camera"],
        "Defect Type": ["Missing Filling", "Uneven Cut", "Crust Present", "Foreign Object", "Discoloration"],
        "Confidence": ["98%", "95%", "92%", "97%", "94%"],
        "Inspector": ["System", "System", "Manual", "System", "System"],
        "Action Taken": ["Rejected", "Rejected", "Rejected", "Rejected", "Rejected"]
    }
    
    # Create responsive table
    create_responsive_data_table(
        table_data,
        hide_columns_mobile=["Inspector", "Action Taken"]
    )
    
    # Touch-friendly controls demo
    st.markdown("## Touch-Friendly Controls")
    
    st.markdown("""
    Controls are optimized for touch devices with larger touch targets and appropriate spacing.
    """)
    
    # Create touch-friendly controls based on device type
    if device_info['touch_capability']:
        st.markdown('<div class="touch-friendly">', unsafe_allow_html=True)
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.button("Primary Button", type="primary")
        st.checkbox("Enable Notifications", value=True)
        st.radio("View Mode", options=["Live Feed", "Defect Detection", "Calibration"])
    
    with col2:
        st.selectbox("Camera", options=["Top Camera", "Side Camera 1", "Side Camera 2", "Bottom Camera"])
        st.slider("Refresh Rate (seconds)", min_value=1, max_value=30, value=5)
        st.text_input("Search", placeholder="Search...")
    
    if device_info['touch_capability']:
        st.markdown('</div>', unsafe_allow_html=True)
    
    # Orientation-specific content demo
    st.markdown("## Orientation-Specific Content")
    
    st.markdown("""
    Some content is optimized for specific orientations and will adapt when you rotate your device.
    """)
    
    # Portrait-only content
    st.markdown(
        """
        <div class="portrait-only" style="background-color: var(--color-background-card); padding: 16px; border-radius: 8px; margin-bottom: 20px; text-align: center;">
            <span class="material-icons" style="font-size: 48px; color: var(--color-primary-main);">stay_current_portrait</span>
            <h3>Portrait Mode Content</h3>
            <p>This content is optimized for portrait orientation and is only visible in portrait mode.</p>
        </div>
        """,
        unsafe_allow_html=True
    )
    
    # Landscape-only content
    st.markdown(
        """
        <div class="landscape-only" style="background-color: var(--color-background-card); padding: 16px; border-radius: 8px; margin-bottom: 20px; text-align: center;">
            <span class="material-icons" style="font-size: 48px; color: var(--color-primary-main);">stay_current_landscape</span>
            <h3>Landscape Mode Content</h3>
            <p>This content is optimized for landscape orientation and is only visible in landscape mode.</p>
        </div>
        """,
        unsafe_allow_html=True
    )
    
    # Current orientation message
    st.markdown(
        f"""
        <div style="background-color: var(--color-background-card); padding: 16px; border-radius: 8px; margin-bottom: 20px; text-align: center;">
            <p>Your device is currently in <strong>{device_info['orientation']}</strong> orientation.</p>
            <p>Rotate your device to see how the content adapts.</p>
        </div>
        """,
        unsafe_allow_html=True
    )
    
    # Mobile app demo
    st.markdown("## Mobile App Experience")
    
    st.markdown("""
    The system can provide a mobile app-like experience with app-style navigation and layouts.
    """)
    
    if st.button("Open Mobile App Demo"):
        st.session_state.show_mobile_app_demo = True
    
    if 'show_mobile_app_demo' in st.session_state and st.session_state.show_mobile_app_demo:
        def mobile_app_content():
            st.markdown("### Welcome to the Mobile App")
            
            st.markdown("""
            This is a demonstration of how the OPSC Sandwich Quality Inspection System can provide a mobile app-like experience.
            """)
            
            # Sample content
            st.metric("Today's Production", "2,458", "+5%")
            
            # Sample chart
            chart_data = {
                "Hour": [f"{i:02d}:00" for i in range(6, 18)],
                "Production": [random.randint(100, 250) for _ in range(12)]
            }
            
            create_responsive_chart(chart_data, chart_type="bar", x="Hour", y="Production", title="Today's Production by Hour")
            
            # Sample actions
            st.markdown("### Quick Actions")
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.button("View Cameras", key="mobile_view_cameras")
                st.button("View Reports", key="mobile_view_reports")
            
            with col2:
                st.button("Check Status", key="mobile_check_status")
                st.button("Settings", key="mobile_settings")
            
            # Close button
            if st.button("Close Demo"):
                st.session_state.show_mobile_app_demo = False
                st.rerun()
        
        create_mobile_app_wrapper(
            title="OPSC Mobile",
            content_func=mobile_app_content,
            show_back_button=True
        )
    
    # Implementation details
    st.markdown("## Implementation Details")
    
    st.markdown("""
    The mobile responsive design implementation includes:
    
    1. **Device Detection**: Automatic detection of device type, screen size, orientation, and touch capability
    2. **Responsive Layouts**: Layouts that adapt to different screen sizes and orientations
    3. **Touch Optimization**: Larger touch targets and appropriate spacing for touch devices
    4. **Adaptive Content**: Content that adjusts based on available screen space
    5. **Responsive Navigation**: Navigation that changes format based on device type
    6. **Responsive Data Visualization**: Charts and tables that resize and reformat for different screens
    7. **Orientation Handling**: Support for both portrait and landscape orientations
    8. **Mobile App Experience**: App-like interface for mobile users
    """)
    
    # Reset button
    if st.button("Reset Demo"):
        for key in list(st.session_state.keys()):
            if key.startswith("show_"):
                del st.session_state[key]
        st.rerun()

if __name__ == "__main__":
    st.set_page_config(
        page_title="OPSC Mobile Responsive Demo",
        page_icon="📱",
        layout="wide",
        initial_sidebar_state="expanded"
    )
    render_mobile_responsive_demo()
