"""
Reports page for the Crustless Creations AI machine vision application.

This module implements the reporting interface that allows generating, viewing,
and exporting various reports related to production and quality control.
"""

import streamlit as st
import pandas as pd
import numpy as np
import time
from datetime import datetime, timedelta
import sys
import os
import plotly.express as px
import plotly.graph_objects as go

# Add the parent directory to the path so we can import our components
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ui.components.dashboard import (
    card, chart_card, grid_dashboard, dashboard_header, tabbed_interface
)

def render_reports():
    """Render the reports page."""
    
    # Dashboard header
    dashboard_header(
        "Reports",
        "Generate and view production and quality control reports",
        None,
        [("Export All Reports", lambda: st.session_state.update(export_all_clicked=True))]
    )
    
    # Report generation section
    st.markdown("### Generate New Report")
    
    with st.form("report_generation_form"):
        col1, col2 = st.columns(2)
        
        with col1:
            report_type = st.selectbox(
                "Report Type:",
                [
                    "Daily Production Summary",
                    "Defect Analysis Report",
                    "System Performance Report",
                    "Quality Control Compliance",
                    "Shift Comparison Report",
                    "Custom Report"
                ]
            )
            
            report_format = st.selectbox(
                "Report Format:",
                ["PDF", "Excel", "CSV", "HTML"]
            )
        
        with col2:
            start_date = st.date_input(
                "Start Date:",
                value=datetime.now() - timedelta(days=7),
                max_value=datetime.now()
            )
            
            end_date = st.date_input(
                "End Date:",
                value=datetime.now(),
                max_value=datetime.now(),
                min_value=start_date
            )
        
        # Report options
        st.markdown("#### Report Options")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            include_charts = st.checkbox("Include Charts and Graphs", value=True)
            include_raw_data = st.checkbox("Include Raw Data Tables", value=True)
        
        with col2:
            include_executive_summary = st.checkbox("Include Executive Summary", value=True)
            include_recommendations = st.checkbox("Include Recommendations", value=True)
        
        with col3:
            include_images = st.checkbox("Include Sample Images", value=False)
            include_comparison = st.checkbox("Include Historical Comparison", value=True)
        
        # Submit button
        submitted = st.form_submit_button("Generate Report", use_container_width=True)
        
        if submitted:
            st.success(f"Generating {report_type} from {start_date} to {end_date}...")
            # In a real application, this would trigger the report generation process
            st.session_state.report_generated = True
    
    # Separator
    st.markdown("---")
    
    # Recent reports section
    st.markdown("### Recent Reports")
    
    # Sample recent reports
    recent_reports = [
        {
            "title": "Daily Production Summary",
            "date": "2025-04-19",
            "type": "PDF",
            "size": "1.2 MB",
            "status": "completed"
        },
        {
            "title": "Defect Analysis Report",
            "date": "2025-04-18",
            "type": "Excel",
            "size": "3.5 MB",
            "status": "completed"
        },
        {
            "title": "Quality Control Compliance",
            "date": "2025-04-15",
            "type": "PDF",
            "size": "2.8 MB",
            "status": "completed"
        },
        {
            "title": "System Performance Report",
            "date": "2025-04-12",
            "type": "PDF",
            "size": "1.5 MB",
            "status": "completed"
        },
        {
            "title": "Shift Comparison Report",
            "date": "2025-04-10",
            "type": "Excel",
            "size": "2.2 MB",
            "status": "completed"
        }
    ]
    
    # Add a newly generated report if the form was submitted
    if "report_generated" in st.session_state and st.session_state.report_generated:
        recent_reports.insert(0, {
            "title": report_type,
            "date": datetime.now().strftime("%Y-%m-%d"),
            "type": report_format,
            "size": "2.1 MB",
            "status": "completed"
        })
        st.session_state.report_generated = False
    
    # Display recent reports
    for i, report in enumerate(recent_reports):
        col1, col2, col3, col4, col5 = st.columns([3, 2, 1, 1, 2])
        
        with col1:
            st.markdown(f"**{report['title']}**")
        
        with col2:
            st.markdown(f"Date: {report['date']}")
        
        with col3:
            st.markdown(f"Type: {report['type']}")
        
        with col4:
            st.markdown(f"Size: {report['size']}")
        
        with col5:
            col1, col2 = st.columns(2)
            with col1:
                if st.button("View", key=f"view_{i}"):
                    st.session_state[f"view_report_{i}"] = True
            
            with col2:
                if st.button("Download", key=f"download_{i}"):
                    st.session_state[f"download_report_{i}"] = True
        
        st.markdown("---")
    
    # Separator
    st.markdown("---")
    
    # Scheduled reports section
    st.markdown("### Scheduled Reports")
    
    # Add new schedule form
    with st.expander("Add New Scheduled Report"):
        with st.form("schedule_form"):
            col1, col2 = st.columns(2)
            
            with col1:
                scheduled_report_type = st.selectbox(
                    "Report Type:",
                    [
                        "Daily Production Summary",
                        "Defect Analysis Report",
                        "System Performance Report",
                        "Quality Control Compliance",
                        "Shift Comparison Report"
                    ],
                    key="scheduled_type"
                )
                
                frequency = st.selectbox(
                    "Frequency:",
                    ["Daily", "Weekly", "Monthly", "Quarterly"]
                )
            
            with col2:
                recipients = st.text_area(
                    "Recipients (email addresses, one per line):",
                    height=100
                )
                
                report_format = st.selectbox(
                    "Report Format:",
                    ["PDF", "Excel", "CSV", "HTML"],
                    key="scheduled_format"
                )
            
            schedule_submitted = st.form_submit_button("Add Schedule", use_container_width=True)
            
            if schedule_submitted:
                st.success(f"Added new scheduled {scheduled_report_type} report ({frequency})")
    
    # Sample scheduled reports
    scheduled_reports = [
        {
            "title": "Daily Production Summary",
            "frequency": "Daily",
            "recipients": "production@crustlesscreations.com",
            "format": "PDF",
            "next_run": "2025-04-21"
        },
        {
            "title": "Defect Analysis Report",
            "frequency": "Weekly",
            "recipients": "quality@crustlesscreations.com",
            "format": "Excel",
            "next_run": "2025-04-26"
        },
        {
            "title": "System Performance Report",
            "frequency": "Monthly",
            "recipients": "it@crustlesscreations.com",
            "format": "PDF",
            "next_run": "2025-05-01"
        }
    ]
    
    # Display scheduled reports
    for i, report in enumerate(scheduled_reports):
        col1, col2, col3, col4, col5 = st.columns([3, 2, 3, 2, 2])
        
        with col1:
            st.markdown(f"**{report['title']}**")
        
        with col2:
            st.markdown(f"Frequency: {report['frequency']}")
        
        with col3:
            st.markdown(f"Recipients: {report['recipients']}")
        
        with col4:
            st.markdown(f"Next Run: {report['next_run']}")
        
        with col5:
            col1, col2 = st.columns(2)
            with col1:
                if st.button("Edit", key=f"edit_{i}"):
                    st.session_state[f"edit_schedule_{i}"] = True
            
            with col2:
                if st.button("Delete", key=f"delete_{i}"):
                    st.session_state[f"delete_schedule_{i}"] = True
        
        st.markdown("---")
    
    # Separator
    st.markdown("---")
    
    # Report templates section
    st.markdown("### Report Templates")
    
    # Sample report templates
    report_templates = [
        {
            "title": "Standard Daily Report",
            "description": "Standard daily production and quality metrics",
            "sections": "Production summary, Defect analysis, System performance",
            "last_modified": "2025-03-15"
        },
        {
            "title": "Executive Summary",
            "description": "Condensed report for management review",
            "sections": "KPIs, Critical issues, Recommendations",
            "last_modified": "2025-03-10"
        },
        {
            "title": "Compliance Report",
            "description": "Detailed report for regulatory compliance",
            "sections": "Quality metrics, Traceability, Documentation",
            "last_modified": "2025-02-28"
        },
        {
            "title": "Custom Template 1",
            "description": "User-defined custom report template",
            "sections": "User-defined sections",
            "last_modified": "2025-04-05"
        }
    ]
    
    # Display report templates
    col1, col2 = st.columns(2)
    
    for i, template in enumerate(report_templates):
        # Alternate between columns
        with col1 if i % 2 == 0 else col2:
            with st.expander(template["title"]):
                st.markdown(f"**Description:** {template['description']}")
                st.markdown(f"**Sections:** {template['sections']}")
                st.markdown(f"**Last Modified:** {template['last_modified']}")
                
                col1, col2, col3 = st.columns(3)
                with col1:
                    if st.button("Use Template", key=f"use_{i}"):
                        st.session_state[f"use_template_{i}"] = True
                
                with col2:
                    if st.button("Edit Template", key=f"edit_template_{i}"):
                        st.session_state[f"edit_template_{i}"] = True
                
                with col3:
                    if st.button("Delete Template", key=f"delete_template_{i}"):
                        st.session_state[f"delete_template_{i}"] = True
    
    # Handle button clicks for report viewing
    for i in range(len(recent_reports)):
        if f"view_report_{i}" in st.session_state and st.session_state[f"view_report_{i}"]:
            show_report_preview(recent_reports[i])
            st.session_state[f"view_report_{i}"] = False
    
    # Handle export all button click
    if "export_all_clicked" in st.session_state and st.session_state.export_all_clicked:
        st.success("Exporting all reports to shared folder...")
        st.session_state.export_all_clicked = False

def show_report_preview(report):
    """Show a preview of the selected report."""
    
    st.markdown(f"## Report Preview: {report['title']}")
    
    # Create tabs for different report sections
    tabs = {
        "Summary": lambda: render_report_summary(report),
        "Charts": lambda: render_report_charts(report),
        "Data Tables": lambda: render_report_tables(report),
        "Recommendations": lambda: render_report_recommendations(report)
    }
    
    tabbed_interface(tabs)
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button("Download Report", use_container_width=True):
            st.success(f"Downloading {report['title']} ({report['type']})...")
    
    with col2:
        if st.button("Print Report", use_container_width=True):
            st.info("Preparing report for printing...")
    
    with col3:
        if st.button("Email Report", use_container_width=True):
            st.success("Report sent via email!")
    
    if st.button("Close Preview", use_container_width=True):
        pass

def render_report_summary(report):
    """Render the summary section of a report."""
    
    st.markdown("### Executive Summary")
    
    st.markdown("""
    This report provides an overview of production and quality metrics for the specified time period.
    Key findings and recommendations are highlighted below.
    """)
    
    # Key metrics
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric(
            label="Total Production",
            value="12,450 units",
            delta="+5.2%"
        )
    
    with col2:
        st.metric(
            label="Defect Rate",
            value="0.8%",
            delta="-0.2%",
            delta_color="inverse"
        )
    
    with col3:
        st.metric(
            label="Uptime",
            value="99.2%",
            delta="+0.5%"
        )
    
    with col4:
        st.metric(
            label="Quality Score",
            value="94.5",
            delta="+2.1"
        )
    
    # Summary text
    st.markdown("""
    ### Key Findings
    
    1. **Production Volume**: Total production increased by 5.2% compared to the previous period, exceeding the target by 3.1%.
    
    2. **Quality Metrics**: Overall defect rate decreased to 0.8%, representing a 20% improvement from the previous period.
    
    3. **System Performance**: System uptime improved to 99.2%, with only one scheduled maintenance event during the period.
    
    4. **Defect Patterns**: "Missing Filling" remains the most common defect type, but showed a 15% reduction following calibration adjustments.
    
    5. **Shift Analysis**: The night shift continues to show higher defect rates (1.2%) compared to morning (0.7%) and afternoon (0.9%) shifts.
    """)
    
    st.markdown("""
    ### Recommendations
    
    1. Continue monitoring the filling dispenser calibration to maintain the improvement in "Missing Filling" defects.
    
    2. Investigate the higher defect rates during the night shift, potentially through additional operator training.
    
    3. Schedule preventive maintenance for Camera 2, which is showing early signs of performance degradation.
    
    4. Consider implementing the proposed software update to improve detection accuracy for "Foreign Object" defects.
    """)

def render_report_charts(report):
    """Render the charts section of a report."""
    
    st.markdown("### Charts and Visualizations")
    
    # Production trend
    def production_trend_chart():
        # Generate sample data
        dates = pd.date_range(start='2025-04-01', end='2025-04-20')
        production = np.cumsum(np.random.normal(500, 50, len(dates)))
        
        df = pd.DataFrame({
            'Date': dates,
            'Production': production
        })
        
        fig = px.line(
            df, 
            x='Date', 
            y='Production',
            title='Daily Production Trend',
            markers=True
        )
        fig.update_layout(
            xaxis_title='Date',
            yaxis_title='Units Produced',
            hovermode='x unified'
        )
        st.plotly_chart(fig, use_container_width=True)
    
    chart_card(
        title="Production Trend",
        chart_function=production_trend_chart,
        key="production_trend_card"
    )
    
    # Defect distribution
    def defect_distribution_chart():
        # Sample defect distribution data
        defect_types = {
            'Missing Filling': 45,
            'Uneven Cut': 30,
            'Crust Present': 15,
            'Foreign Object': 7,
            'Other': 3
        }
        
        defect_df = pd.DataFrame({
            'Defect Type': list(defect_types.keys()),
            'Count': list(defect_types.values())
        })
        
        fig = px.pie(
            defect_df,
            values='Count',
            names='Defect Type',
            title='Defect Distribution by Type',
            color_discrete_sequence=px.colors.qualitative.Set1
        )
        fig.update_traces(textposition='inside', textinfo='percent+label')
        st.plotly_chart(fig, use_container_width=True)
    
    # Quality metrics by shift
    def shift_comparison_chart():
        shifts = ["Morning", "Afternoon", "Night"]
        metrics = {
            "Defect Rate (%)": [0.7, 0.9, 1.2],
            "Production Speed (units/min)": [245, 250, 240],
            "Uptime (%)": [99.5, 99.3, 98.8]
        }
        
        # Create a DataFrame
        df = pd.DataFrame({
            'Shift': shifts * len(metrics),
            'Metric': [k for k in metrics.keys() for _ in shifts],
            'Value': [v for values in metrics.values() for v in values]
        })
        
        fig = px.bar(
            df,
            x='Shift',
            y='Value',
            color='Metric',
            barmode='group',
            title='Quality Metrics by Shift',
            color_discrete_sequence=px.colors.qualitative.Safe
        )
        fig.update_layout(
            xaxis_title='Shift',
            yaxis_title='Value',
            legend_title='Metric'
        )
        st.plotly_chart(fig, use_container_width=True)
    
    col1, col2 = st.columns(2)
    
    with col1:
        chart_card(
            title="Defect Distribution",
            chart_function=defect_distribution_chart,
            key="defect_distribution_card"
        )
    
    with col2:
        chart_card(
            title="Quality Metrics by Shift",
            chart_function=shift_comparison_chart,
            key="shift_comparison_card"
        )
    
    # System performance
    def system_performance_chart():
        # Generate sample data
        dates = pd.date_range(start='2025-04-01', end='2025-04-20')
        cpu_usage = np.random.normal(50, 10, len(dates))
        memory_usage = np.random.normal(60, 8, len(dates))
        gpu_usage = np.random.normal(40, 15, len(dates))
        
        df = pd.DataFrame({
            'Date': dates,
            'CPU Usage (%)': cpu_usage,
            'Memory Usage (%)': memory_usage,
            'GPU Usage (%)': gpu_usage
        })
        
        fig = px.line(
            df,
            x='Date',
            y=['CPU Usage (%)', 'Memory Usage (%)', 'GPU Usage (%)'],
            title='System Resource Utilization',
            markers=True
        )
        fig.update_layout(
            xaxis_title='Date',
            yaxis_title='Utilization (%)',
            hovermode='x unified',
            legend_title='Resource'
        )
        st.plotly_chart(fig, use_container_width=True)
    
    chart_card(
        title="System Performance",
        chart_function=system_performance_chart,
        key="system_performance_card"
    )

def render_report_tables(report):
    """Render the data tables section of a report."""
    
    st.markdown("### Data Tables")
    
    # Production summary table
    st.markdown("#### Production Summary")
    
    # Generate sample data
    dates = pd.date_range(start='2025-04-01', end='2025-04-20')
    production_data = []
    
    for date in dates:
        production_data.append({
            'Date': date.strftime('%Y-%m-%d'),
            'Units Produced': np.random.randint(9000, 11000),
            'Defective Units': np.random.randint(50, 150),
            'Defect Rate (%)': np.random.uniform(0.5, 1.5),
            'Production Time (h)': np.random.uniform(22.5, 24.0),
            'Downtime (min)': np.random.randint(0, 90)
        })
    
    df_production = pd.DataFrame(production_data)
    st.dataframe(df_production, use_container_width=True)
    
    # Defect summary table
    st.markdown("#### Defect Summary by Type")
    
    defect_types = ["Missing Filling", "Uneven Cut", "Crust Present", "Foreign Object", "Other"]
    defect_data = []
    
    for defect_type in defect_types:
        defect_data.append({
            'Defect Type': defect_type,
            'Count': np.random.randint(10, 100),
            'Percentage (%)': np.random.uniform(5, 50),
            'Avg. Confidence': np.random.uniform(0.8, 0.95),
            'False Positives': np.random.randint(0, 10),
            'Primary Camera': np.random.choice(["Top", "Side 1", "Side 2", "Bottom"])
        })
    
    df_defects = pd.DataFrame(defect_data)
    st.dataframe(df_defects, use_container_width=True)
    
    # Shift comparison table
    st.markdown("#### Shift Comparison")
    
    shifts = ["Morning", "Afternoon", "Night"]
    shift_data = []
    
    for shift in shifts:
        shift_data.append({
            'Shift': shift,
            'Units Produced': np.random.randint(3000, 4000),
            'Defect Rate (%)': np.random.uniform(0.7, 1.2),
            'Production Speed (units/min)': np.random.uniform(240, 255),
            'Uptime (%)': np.random.uniform(98.5, 99.5),
            'Operator Count': np.random.randint(2, 4)
        })
    
    df_shifts = pd.DataFrame(shift_data)
    st.dataframe(df_shifts, use_container_width=True)
    
    # System performance table
    st.markdown("#### System Performance")
    
    system_data = []
    
    for date in dates:
        system_data.append({
            'Date': date.strftime('%Y-%m-%d'),
            'CPU Usage (%)': np.random.uniform(40, 60),
            'Memory Usage (%)': np.random.uniform(50, 70),
            'GPU Usage (%)': np.random.uniform(30, 50),
            'Disk Usage (%)': np.random.uniform(60, 80),
            'Network Bandwidth (MB/s)': np.random.uniform(10, 30),
            'Inference Time (ms)': np.random.uniform(80, 120)
        })
    
    df_system = pd.DataFrame(system_data)
    st.dataframe(df_system, use_container_width=True)
    
    # Export options
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button("Export to Excel", use_container_width=True):
            st.success("Data exported to Excel!")
    
    with col2:
        if st.button("Export to CSV", use_container_width=True):
            st.success("Data exported to CSV!")
    
    with col3:
        if st.button("Copy to Clipboard", use_container_width=True):
            st.success("Data copied to clipboard!")

def render_report_recommendations(report):
    """Render the recommendations section of a report."""
    
    st.markdown("### Recommendations and Action Items")
    
    st.markdown("""
    Based on the analysis of production and quality data for the reporting period,
    the following recommendations and action items have been identified:
    """)
    
    # Production recommendations
    st.markdown("#### Production Optimization")
    
    st.markdown("""
    1. **Filling Dispenser Calibration**: Continue monitoring the filling dispenser calibration
       to maintain the improvement in "Missing Filling" defects. Schedule weekly calibration checks.
       
       *Priority: High | Assigned to: Production Team | Due: Weekly*
    
    2. **Production Speed Optimization**: Current production speed (250 units/min) is within target range.
       No adjustments needed at this time, but continue monitoring for any changes in defect rates.
       
       *Priority: Medium | Assigned to: Production Team | Due: Ongoing*
    
    3. **Material Supply Chain**: Investigate recent variations in bread consistency that may be
       contributing to the "Uneven Cut" defects. Coordinate with suppliers to ensure consistent quality.
       
       *Priority: Medium | Assigned to: Procurement | Due: 2025-05-01*
    """)
    
    # Quality recommendations
    st.markdown("#### Quality Improvement")
    
    st.markdown("""
    1. **Night Shift Quality**: Investigate the higher defect rates during the night shift (1.2% vs. 0.8% average).
       Consider additional operator training or adjustments to lighting conditions.
       
       *Priority: High | Assigned to: Quality Team | Due: 2025-04-30*
    
    2. **Foreign Object Detection**: Implement the proposed software update to improve detection accuracy
       for "Foreign Object" defects. Current false positive rate is above target threshold.
       
       *Priority: High | Assigned to: IT Team | Due: 2025-04-25*
    
    3. **Quality Sampling Procedure**: Review and update the manual quality sampling procedure to ensure
       alignment with automated detection results. Current sampling rate may be insufficient.
       
       *Priority: Medium | Assigned to: Quality Team | Due: 2025-05-15*
    """)
    
    # System recommendations
    st.markdown("#### System Maintenance")
    
    st.markdown("""
    1. **Camera Maintenance**: Schedule preventive maintenance for Camera 2 (Side Camera 1),
       which is showing early signs of performance degradation (18 FPS vs. 20 FPS target).
       
       *Priority: High | Assigned to: Maintenance Team | Due: 2025-04-23*
    
    2. **Disk Space Management**: Current disk usage is at 82%, approaching the 85% alert threshold.
       Implement the automated archiving procedure for images older than 30 days.
       
       *Priority: Medium | Assigned to: IT Team | Due: 2025-04-22*
    
    3. **System Backup**: Perform a full system backup before implementing the scheduled software update.
       Ensure all configuration files and calibration data are included in the backup.
       
       *Priority: High | Assigned to: IT Team | Due: 2025-04-24*
    """)
    
    # Training recommendations
    st.markdown("#### Training and Documentation")
    
    st.markdown("""
    1. **Operator Training**: Conduct refresher training for all operators on the updated quality standards
       and defect identification procedures. Focus on night shift operators.
       
       *Priority: Medium | Assigned to: Training Team | Due: 2025-05-10*
    
    2. **Documentation Update**: Update the system documentation to reflect recent changes in
       the defect classification criteria and camera calibration procedures.
       
       *Priority: Low | Assigned to: Documentation Team | Due: 2025-05-20*
    
    3. **Knowledge Base**: Develop a searchable knowledge base of common defects and troubleshooting
       procedures to improve operator response to quality issues.
       
       *Priority: Medium | Assigned to: Knowledge Management | Due: 2025-06-01*
    """)
    
    # Action tracking
    st.markdown("#### Action Tracking")
    
    # Sample action items
    action_items = [
        {
            "action": "Filling Dispenser Calibration",
            "assigned_to": "Production Team",
            "due_date": "Weekly",
            "status": "On Track",
            "priority": "High"
        },
        {
            "action": "Night Shift Quality Investigation",
            "assigned_to": "Quality Team",
            "due_date": "2025-04-30",
            "status": "Not Started",
            "priority": "High"
        },
        {
            "action": "Camera 2 Maintenance",
            "assigned_to": "Maintenance Team",
            "due_date": "2025-04-23",
            "status": "Scheduled",
            "priority": "High"
        },
        {
            "action": "Foreign Object Detection Update",
            "assigned_to": "IT Team",
            "due_date": "2025-04-25",
            "status": "In Progress",
            "priority": "High"
        },
        {
            "action": "Disk Space Management",
            "assigned_to": "IT Team",
            "due_date": "2025-04-22",
            "status": "In Progress",
            "priority": "Medium"
        }
    ]
    
    # Create DataFrame
    df_actions = pd.DataFrame(action_items)
    
    # Display as table
    st.dataframe(df_actions, use_container_width=True)
    
    # Export actions
    if st.button("Export Action Items", use_container_width=True):
        st.success("Action items exported to task management system!")

if __name__ == "__main__":
    st.set_page_config(
        page_title="Crustless Creations - Reports",
        page_icon="🥪",
        layout="wide",
        initial_sidebar_state="expanded"
    )
    render_reports()
