"""
Settings page for the Crustless Creations AI machine vision application.

This module implements the settings interface that allows configuring various
aspects of the application, including camera settings, detection parameters,
system settings, and user preferences.
"""

import streamlit as st
import pandas as pd
import numpy as np
import time
from datetime import datetime
import sys
import os

# Add the parent directory to the path so we can import our components
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ui.components.dashboard import (
    card, dashboard_header, tabbed_interface
)

def render_settings():
    """Render the settings page."""
    
    # Dashboard header
    dashboard_header(
        "Settings",
        "Configure application settings and parameters",
        None,
        [("Save All Settings", lambda: st.session_state.update(save_all_clicked=True))]
    )
    
    # Create tabs for different settings categories
    tabs = {
        "Camera Settings": render_camera_settings,
        "Detection Settings": render_detection_settings,
        "System Settings": render_system_settings,
        "User Preferences": render_user_preferences,
        "Backup & Restore": render_backup_restore
    }
    
    tabbed_interface(tabs)
    
    # Handle save all button click
    if "save_all_clicked" in st.session_state and st.session_state.save_all_clicked:
        st.success("All settings saved successfully!")
        st.session_state.save_all_clicked = False

def render_camera_settings():
    """Render camera settings tab."""
    
    st.markdown("### Camera Configuration")
    
    # Camera selection
    camera_options = {
        "top": "Top Camera",
        "side1": "Side Camera 1",
        "side2": "Side Camera 2",
        "bottom": "Bottom Camera"
    }
    
    selected_camera = st.selectbox(
        "Select camera to configure:",
        options=list(camera_options.keys()),
        format_func=lambda x: camera_options[x]
    )
    
    # Camera connection settings
    st.markdown("#### Connection Settings")
    
    col1, col2 = st.columns(2)
    
    with col1:
        camera_ip = st.text_input(
            "Camera IP Address:",
            value=f"192.168.100.{101 + list(camera_options.keys()).index(selected_camera)}"
        )
        
        camera_model = st.selectbox(
            "Camera Model:",
            ["Basler acA2500-20gc", "Basler acA1920-40gc", "Basler acA1280-60gc"],
            index=0
        )
    
    with col2:
        packet_size = st.number_input(
            "Packet Size (bytes):",
            min_value=1500,
            max_value=9000,
            value=8192,
            step=1
        )
        
        inter_packet_delay = st.number_input(
            "Inter-Packet Delay (ticks):",
            min_value=0,
            max_value=100,
            value=10,
            step=1
        )
    
    # Image acquisition settings
    st.markdown("#### Image Acquisition")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        exposure_time = st.slider(
            "Exposure Time (μs):",
            min_value=1000,
            max_value=50000,
            value=10000,
            step=1000
        )
        
        auto_exposure = st.checkbox("Auto Exposure", value=False)
    
    with col2:
        gain = st.slider(
            "Gain (dB):",
            min_value=0.0,
            max_value=24.0,
            value=5.0,
            step=0.1
        )
        
        auto_gain = st.checkbox("Auto Gain", value=False)
    
    with col3:
        frame_rate = st.slider(
            "Frame Rate (FPS):",
            min_value=1,
            max_value=30,
            value=20,
            step=1
        )
        
        trigger_mode = st.selectbox(
            "Trigger Mode:",
            ["Free-running", "Hardware Trigger", "Software Trigger"],
            index=0
        )
    
    # Image format settings
    st.markdown("#### Image Format")
    
    col1, col2 = st.columns(2)
    
    with col1:
        pixel_format = st.selectbox(
            "Pixel Format:",
            ["Mono8", "RGB8", "BGR8", "BayerRG8"],
            index=1
        )
        
        width = st.number_input(
            "Width (pixels):",
            min_value=1,
            max_value=2448,
            value=2448,
            step=1
        )
        
        height = st.number_input(
            "Height (pixels):",
            min_value=1,
            max_value=2048,
            value=2048,
            step=1
        )
    
    with col2:
        offset_x = st.number_input(
            "X Offset:",
            min_value=0,
            max_value=2448 - width,
            value=0,
            step=1
        )
        
        offset_y = st.number_input(
            "Y Offset:",
            min_value=0,
            max_value=2048 - height,
            value=0,
            step=1
        )
        
        col1, col2 = st.columns(2)
        
        with col1:
            reverse_x = st.checkbox("Reverse X", value=False)
        
        with col2:
            reverse_y = st.checkbox("Reverse Y", value=False)
    
    # Camera positioning
    st.markdown("#### Camera Position")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        position_name = st.selectbox(
            "Position:",
            ["Top", "Side Left", "Side Right", "Bottom"],
            index=list(camera_options.keys()).index(selected_camera)
        )
    
    with col2:
        mounting_height = st.number_input(
            "Mounting Height (mm):",
            min_value=100,
            max_value=1000,
            value=500,
            step=10
        )
    
    with col3:
        angle = st.slider(
            "Angle (degrees):",
            min_value=0,
            max_value=90,
            value=45 if "side" in selected_camera else 90,
            step=1
        )
    
    # Save button
    if st.button("Save Camera Settings", use_container_width=True):
        st.success(f"Settings saved for {camera_options[selected_camera]}!")
    
    # Camera calibration
    st.markdown("### Camera Calibration")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("#### Calibration Status")
        
        # Display calibration status
        if selected_camera in ["top", "bottom"]:
            st.success("✓ Camera is calibrated")
            st.markdown("Last calibration: 2025-04-15")
            st.markdown("Reprojection error: 0.32 pixels")
        else:
            st.warning("⚠ Calibration needed")
            st.markdown("Last calibration: Never")
            st.markdown("Reprojection error: N/A")
    
    with col2:
        st.markdown("#### Calibration Actions")
        
        calibration_type = st.selectbox(
            "Calibration Type:",
            ["Intrinsic", "Extrinsic", "Full Calibration"],
            index=2
        )
        
        pattern_type = st.selectbox(
            "Calibration Pattern:",
            ["Checkerboard", "ChArUco", "AprilTag"],
            index=0
        )
        
        if st.button("Start Calibration Process", use_container_width=True):
            st.info("Calibration process started. Please follow the on-screen instructions.")

def render_detection_settings():
    """Render detection settings tab."""
    
    st.markdown("### Detection Parameters")
    
    # Model selection
    st.markdown("#### AI Model Configuration")
    
    col1, col2 = st.columns(2)
    
    with col1:
        model_type = st.selectbox(
            "Model Type:",
            ["YOLOv8", "Faster R-CNN", "EfficientDet", "Custom Model"],
            index=0
        )
        
        model_version = st.selectbox(
            "Model Version:",
            ["v1.0.0 (2025-03-15)", "v0.9.2 (2025-02-28)", "v0.9.1 (2025-02-10)"],
            index=0
        )
    
    with col2:
        confidence_threshold = st.slider(
            "Confidence Threshold:",
            min_value=0.0,
            max_value=1.0,
            value=0.7,
            step=0.05,
            format="%.2f"
        )
        
        iou_threshold = st.slider(
            "IoU Threshold:",
            min_value=0.0,
            max_value=1.0,
            value=0.45,
            step=0.05,
            format="%.2f"
        )
    
    # Defect type configuration
    st.markdown("#### Defect Type Configuration")
    
    defect_types = [
        {"name": "Missing Filling", "enabled": True, "threshold": 0.75, "color": "#FF5733"},
        {"name": "Uneven Cut", "enabled": True, "threshold": 0.70, "color": "#33FF57"},
        {"name": "Crust Present", "enabled": True, "threshold": 0.80, "color": "#3357FF"},
        {"name": "Foreign Object", "enabled": True, "threshold": 0.90, "color": "#FF33F5"},
        {"name": "Other", "enabled": True, "threshold": 0.85, "color": "#F5FF33"}
    ]
    
    for i, defect in enumerate(defect_types):
        col1, col2, col3, col4 = st.columns([3, 2, 2, 1])
        
        with col1:
            defect["enabled"] = st.checkbox(
                defect["name"],
                value=defect["enabled"],
                key=f"defect_enabled_{i}"
            )
        
        with col2:
            defect["threshold"] = st.slider(
                "Threshold:",
                min_value=0.0,
                max_value=1.0,
                value=defect["threshold"],
                step=0.05,
                format="%.2f",
                key=f"defect_threshold_{i}"
            )
        
        with col3:
            defect["color"] = st.color_picker(
                "Color:",
                value=defect["color"],
                key=f"defect_color_{i}"
            )
        
        with col4:
            st.markdown("<br>", unsafe_allow_html=True)  # Add spacing
            if st.button("Reset", key=f"reset_defect_{i}"):
                st.session_state[f"defect_threshold_{i}"] = defect_types[i]["threshold"]
                st.session_state[f"defect_color_{i}"] = defect_types[i]["color"]
                st.rerun()
    
    # Processing parameters
    st.markdown("#### Processing Parameters")
    
    col1, col2 = st.columns(2)
    
    with col1:
        max_detections = st.number_input(
            "Maximum Detections per Image:",
            min_value=1,
            max_value=100,
            value=20,
            step=1
        )
        
        batch_size = st.number_input(
            "Inference Batch Size:",
            min_value=1,
            max_value=16,
            value=4,
            step=1
        )
    
    with col2:
        inference_size = st.selectbox(
            "Inference Size:",
            ["320×320", "416×416", "512×512", "640×640", "Original Size"],
            index=3
        )
        
        precision = st.selectbox(
            "Inference Precision:",
            ["FP32", "FP16", "INT8"],
            index=1
        )
    
    # Advanced settings
    with st.expander("Advanced Detection Settings"):
        col1, col2 = st.columns(2)
        
        with col1:
            nms_threshold = st.slider(
                "NMS Threshold:",
                min_value=0.0,
                max_value=1.0,
                value=0.45,
                step=0.05,
                format="%.2f"
            )
            
            warmup_iterations = st.number_input(
                "Warmup Iterations:",
                min_value=0,
                max_value=100,
                value=10,
                step=1
            )
        
        with col2:
            enable_augmentation = st.checkbox("Enable Test-Time Augmentation", value=False)
            
            augmentation_types = st.multiselect(
                "Augmentation Types:",
                ["Flip", "Rotate", "Scale", "Brightness", "Contrast"],
                default=["Flip", "Rotate"],
                disabled=not enable_augmentation
            )
    
    # Save button
    if st.button("Save Detection Settings", use_container_width=True):
        st.success("Detection settings saved successfully!")
    
    # Model management
    st.markdown("### Model Management")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("#### Local Models")
        
        local_models = [
            {"name": "sandwich_detector_v1.0.0", "type": "YOLOv8", "date": "2025-03-15", "size": "14.2 MB"},
            {"name": "sandwich_detector_v0.9.2", "type": "YOLOv8", "date": "2025-02-28", "size": "14.0 MB"},
            {"name": "sandwich_detector_v0.9.1", "type": "YOLOv8", "date": "2025-02-10", "size": "13.8 MB"}
        ]
        
        for model in local_models:
            col1, col2, col3 = st.columns([3, 2, 1])
            
            with col1:
                st.markdown(f"**{model['name']}**")
                st.markdown(f"Type: {model['type']}")
            
            with col2:
                st.markdown(f"Date: {model['date']}")
                st.markdown(f"Size: {model['size']}")
            
            with col3:
                st.markdown("<br>", unsafe_allow_html=True)  # Add spacing
                if model == local_models[0]:
                    st.button("Active", key=f"active_{model['name']}", disabled=True)
                else:
                    if st.button("Activate", key=f"activate_{model['name']}"):
                        st.success(f"Activated {model['name']}!")
        
        if st.button("Import Model", use_container_width=True):
            st.info("Model import dialog would open here.")
    
    with col2:
        st.markdown("#### Roboflow Integration")
        
        api_key = st.text_input(
            "Roboflow API Key:",
            value="••••••••••••••••••••••••••••••",
            type="password"
        )
        
        project_id = st.text_input(
            "Project ID:",
            value="crustless-sandwich-qc"
        )
        
        available_versions = [
            "Version 5 (2025-03-15)",
            "Version 4 (2025-02-28)",
            "Version 3 (2025-02-10)",
            "Version 2 (2025-01-20)",
            "Version 1 (2025-01-05)"
        ]
        
        selected_version = st.selectbox(
            "Available Versions:",
            available_versions,
            index=0
        )
        
        col1, col2 = st.columns(2)
        
        with col1:
            if st.button("Test Connection", use_container_width=True):
                st.success("Connection successful!")
        
        with col2:
            if st.button("Download Selected Version", use_container_width=True):
                st.info("Downloading model... This may take a few minutes.")

def render_system_settings():
    """Render system settings tab."""
    
    st.markdown("### System Configuration")
    
    # Performance settings
    st.markdown("#### Performance Settings")
    
    col1, col2 = st.columns(2)
    
    with col1:
        processing_threads = st.slider(
            "Processing Threads:",
            min_value=1,
            max_value=16,
            value=8,
            step=1
        )
        
        gpu_memory_allocation = st.slider(
            "GPU Memory Allocation (%):",
            min_value=10,
            max_value=100,
            value=70,
            step=5
        )
    
    with col2:
        max_frame_rate = st.slider(
            "Maximum Frame Rate:",
            min_value=1,
            max_value=30,
            value=20,
            step=1
        )
        
        buffer_size = st.slider(
            "Frame Buffer Size:",
            min_value=1,
            max_value=100,
            value=30,
            step=1
        )
    
    # Storage settings
    st.markdown("#### Storage Settings")
    
    col1, col2 = st.columns(2)
    
    with col1:
        image_storage_days = st.number_input(
            "Store Defect Images for (days):",
            min_value=1,
            max_value=365,
            value=30,
            step=1
        )
        
        log_retention_days = st.number_input(
            "Log Retention Period (days):",
            min_value=1,
            max_value=365,
            value=90,
            step=1
        )
    
    with col2:
        storage_path = st.text_input(
            "Storage Path:",
            value="/data/opsc-vision-system"
        )
        
        max_storage_usage = st.slider(
            "Maximum Storage Usage (%):",
            min_value=50,
            max_value=95,
            value=85,
            step=5
        )
    
    # Network settings
    st.markdown("#### Network Settings")
    
    col1, col2 = st.columns(2)
    
    with col1:
        host_ip = st.text_input(
            "Host IP Address:",
            value="192.168.100.10"
        )
        
        jetson_ip = st.text_input(
            "ADLINK Jetson IP Address:",
            value="192.168.100.20"
        )
    
    with col2:
        network_mtu = st.number_input(
            "Network MTU:",
            min_value=1500,
            max_value=9000,
            value=9000,
            step=1
        )
        
        udp_buffer_size = st.number_input(
            "UDP Buffer Size (bytes):",
            min_value=65536,
            max_value=16777216,
            value=4194304,
            step=65536,
            format="%d"
        )
    
    # Logging settings
    st.markdown("#### Logging Settings")
    
    col1, col2 = st.columns(2)
    
    with col1:
        log_level = st.selectbox(
            "Log Level:",
            ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"],
            index=1
        )
        
        log_file_path = st.text_input(
            "Log File Path:",
            value="/data/opsc-vision-system/logs/app.log"
        )
    
    with col2:
        max_log_size = st.number_input(
            "Maximum Log File Size (MB):",
            min_value=1,
            max_value=1000,
            value=100,
            step=1
        )
        
        log_backup_count = st.number_input(
            "Log Backup Count:",
            min_value=1,
            max_value=100,
            value=10,
            step=1
        )
    
    # Advanced system settings
    with st.expander("Advanced System Settings"):
        col1, col2 = st.columns(2)
        
        with col1:
            enable_watchdog = st.checkbox("Enable System Watchdog", value=True)
            
            watchdog_timeout = st.number_input(
                "Watchdog Timeout (seconds):",
                min_value=10,
                max_value=300,
                value=60,
                step=10,
                disabled=not enable_watchdog
            )
            
            enable_auto_restart = st.checkbox("Enable Automatic Restart on Failure", value=True)
        
        with col2:
            enable_performance_monitoring = st.checkbox("Enable Performance Monitoring", value=True)
            
            monitoring_interval = st.number_input(
                "Monitoring Interval (seconds):",
                min_value=1,
                max_value=60,
                value=5,
                step=1,
                disabled=not enable_performance_monitoring
            )
            
            enable_remote_access = st.checkbox("Enable Remote Access", value=False)
    
    # Save button
    if st.button("Save System Settings", use_container_width=True):
        st.success("System settings saved successfully!")
        st.warning("Some settings may require a system restart to take effect.")

def render_user_preferences():
    """Render user preferences tab."""
    
    st.markdown("### User Interface Preferences")
    
    # Theme settings
    st.markdown("#### Theme Settings")
    
    col1, col2 = st.columns(2)
    
    with col1:
        theme = st.selectbox(
            "UI Theme:",
            ["Light", "Dark", "System Default"],
            index=2
        )
        
        accent_color = st.color_picker(
            "Accent Color:",
            value="#FF4B4B"
        )
    
    with col2:
        sidebar_state = st.selectbox(
            "Default Sidebar State:",
            ["Expanded", "Collapsed", "Auto"],
            index=0
        )
        
        layout_width = st.selectbox(
            "Layout Width:",
            ["Wide", "Centered", "Auto"],
            index=0
        )
    
    # Dashboard preferences
    st.markdown("#### Dashboard Preferences")
    
    col1, col2 = st.columns(2)
    
    with col1:
        default_page = st.selectbox(
            "Default Page:",
            ["Dashboard", "Camera Monitoring", "Defect Analysis", "Reports", "Settings"],
            index=0
        )
        
        refresh_interval = st.number_input(
            "Dashboard Refresh Interval (seconds):",
            min_value=0,
            max_value=3600,
            value=30,
            step=5,
            help="0 to disable auto-refresh"
        )
    
    with col2:
        chart_animation = st.checkbox("Enable Chart Animations", value=True)
        
        show_tooltips = st.checkbox("Show Tooltips", value=True)
        
        enable_notifications = st.checkbox("Enable Browser Notifications", value=True)
    
    # Camera view preferences
    st.markdown("#### Camera View Preferences")
    
    col1, col2 = st.columns(2)
    
    with col1:
        default_camera_layout = st.selectbox(
            "Default Camera Layout:",
            ["Single View", "2×2 Grid", "1+3 Layout", "Side by Side"],
            index=1
        )
        
        default_camera = st.selectbox(
            "Default Camera (for Single View):",
            ["Top Camera", "Side Camera 1", "Side Camera 2", "Bottom Camera"],
            index=0
        )
    
    with col2:
        detection_box_thickness = st.slider(
            "Detection Box Thickness:",
            min_value=1,
            max_value=10,
            value=2,
            step=1
        )
        
        detection_text_size = st.slider(
            "Detection Text Size:",
            min_value=0.5,
            max_value=2.0,
            value=1.0,
            step=0.1
        )
    
    # Notification settings
    st.markdown("#### Notification Settings")
    
    col1, col2 = st.columns(2)
    
    with col1:
        notify_on_defect = st.checkbox("Notify on Critical Defects", value=True)
        
        notify_on_system_event = st.checkbox("Notify on System Events", value=True)
        
        notify_on_completion = st.checkbox("Notify on Task Completion", value=True)
    
    with col2:
        notification_sound = st.checkbox("Play Notification Sounds", value=True)
        
        notification_volume = st.slider(
            "Notification Volume:",
            min_value=0,
            max_value=100,
            value=50,
            step=5,
            disabled=not notification_sound
        )
    
    # User information
    st.markdown("#### User Information")
    
    col1, col2 = st.columns(2)
    
    with col1:
        user_name = st.text_input(
            "Display Name:",
            value="Administrator"
        )
        
        user_email = st.text_input(
            "Email Address:",
            value="admin@crustlesscreations.com"
        )
    
    with col2:
        user_role = st.selectbox(
            "User Role:",
            ["Administrator", "Supervisor", "Operator", "Maintenance", "Quality Control"],
            index=0,
            disabled=True
        )
        
        language = st.selectbox(
            "Language:",
            ["English", "Spanish", "French", "German", "Chinese"],
            index=0
        )
    
    # Save button
    if st.button("Save User Preferences", use_container_width=True):
        st.success("User preferences saved successfully!")

def render_backup_restore():
    """Render backup and restore tab."""
    
    st.markdown("### Backup and Restore")
    
    # Backup settings
    st.markdown("#### Backup Configuration")
    
    col1, col2 = st.columns(2)
    
    with col1:
        backup_location = st.text_input(
            "Backup Location:",
            value="/data/backups"
        )
        
        backup_retention = st.number_input(
            "Backup Retention (days):",
            min_value=1,
            max_value=365,
            value=30,
            step=1
        )
    
    with col2:
        backup_schedule = st.selectbox(
            "Automatic Backup Schedule:",
            ["Daily", "Weekly", "Monthly", "Disabled"],
            index=1
        )
        
        backup_time = st.time_input(
            "Backup Time:",
            value=datetime.strptime("02:00", "%H:%M").time()
        )
    
    # Backup components
    st.markdown("#### Backup Components")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        backup_config = st.checkbox("Configuration Files", value=True)
        backup_database = st.checkbox("Database", value=True)
        backup_models = st.checkbox("AI Models", value=True)
    
    with col2:
        backup_logs = st.checkbox("Log Files", value=False)
        backup_images = st.checkbox("Defect Images", value=True)
        backup_reports = st.checkbox("Generated Reports", value=True)
    
    with col3:
        backup_calibration = st.checkbox("Camera Calibration", value=True)
        backup_user_prefs = st.checkbox("User Preferences", value=True)
        backup_system_state = st.checkbox("System State", value=True)
    
    # Manual backup
    st.markdown("#### Manual Backup")
    
    col1, col2 = st.columns(2)
    
    with col1:
        backup_name = st.text_input(
            "Backup Name:",
            value=f"manual_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        )
        
        backup_description = st.text_area(
            "Backup Description:",
            value="Manual backup before system update"
        )
    
    with col2:
        backup_encryption = st.checkbox("Encrypt Backup", value=True)
        
        if backup_encryption:
            backup_password = st.text_input(
                "Encryption Password:",
                type="password"
            )
            
            backup_confirm_password = st.text_input(
                "Confirm Password:",
                type="password"
            )
    
    if st.button("Create Backup Now", use_container_width=True):
        if backup_encryption and (not backup_password or backup_password != backup_confirm_password):
            st.error("Encryption passwords do not match or are empty!")
        else:
            st.success("Backup created successfully!")
            st.info(f"Backup saved to: {backup_location}/{backup_name}.zip")
    
    # Restore from backup
    st.markdown("#### Restore from Backup")
    
    # Sample backup list
    backups = [
        {"name": "auto_backup_20250419_020000", "date": "2025-04-19 02:00:00", "size": "156 MB", "type": "Automatic"},
        {"name": "pre_update_backup_20250418_143022", "date": "2025-04-18 14:30:22", "size": "152 MB", "type": "Manual"},
        {"name": "auto_backup_20250418_020000", "date": "2025-04-18 02:00:00", "size": "155 MB", "type": "Automatic"},
        {"name": "auto_backup_20250417_020000", "date": "2025-04-17 02:00:00", "size": "154 MB", "type": "Automatic"},
        {"name": "calibration_backup_20250415_103245", "date": "2025-04-15 10:32:45", "size": "150 MB", "type": "Manual"}
    ]
    
    selected_backup = st.selectbox(
        "Select Backup to Restore:",
        options=[b["name"] for b in backups],
        format_func=lambda x: f"{x} ({next(b['date'] for b in backups if b['name'] == x)})"
    )
    
    # Get selected backup details
    selected_backup_details = next(b for b in backups if b["name"] == selected_backup)
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown(f"**Date:** {selected_backup_details['date']}")
    
    with col2:
        st.markdown(f"**Size:** {selected_backup_details['size']}")
    
    with col3:
        st.markdown(f"**Type:** {selected_backup_details['type']}")
    
    # Restore options
    st.markdown("#### Restore Options")
    
    col1, col2 = st.columns(2)
    
    with col1:
        restore_config = st.checkbox("Restore Configuration", value=True)
        restore_database = st.checkbox("Restore Database", value=True)
        restore_models = st.checkbox("Restore AI Models", value=True)
        restore_calibration = st.checkbox("Restore Camera Calibration", value=True)
    
    with col2:
        restore_user_prefs = st.checkbox("Restore User Preferences", value=True)
        restore_images = st.checkbox("Restore Defect Images", value=False)
        restore_reports = st.checkbox("Restore Generated Reports", value=False)
        restore_system_state = st.checkbox("Restore System State", value=True)
    
    # Restore confirmation
    st.warning("⚠️ Restoring from backup will overwrite current system data. This action cannot be undone.")
    
    restore_confirmation = st.text_input(
        "Type 'RESTORE' to confirm:",
        help="This confirmation is case-sensitive"
    )
    
    if st.button("Restore from Backup", use_container_width=True, disabled=restore_confirmation != "RESTORE"):
        if restore_confirmation == "RESTORE":
            st.success("Restoration process started!")
            st.info("The system will restart automatically after restoration is complete.")
        else:
            st.error("Please type 'RESTORE' to confirm.")

if __name__ == "__main__":
    st.set_page_config(
        page_title="Crustless Creations - Settings",
        page_icon="🥪",
        layout="wide",
        initial_sidebar_state="expanded"
    )
    render_settings()
