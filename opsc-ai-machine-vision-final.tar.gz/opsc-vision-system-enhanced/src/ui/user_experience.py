"""
User experience improvements for the OPSC Sandwich Quality Inspection System.

This module provides enhanced user experience features including:
- Guided onboarding and tutorials
- Customizable user preferences
- Keyboard shortcuts
- Notification system
- Search functionality
- Context-sensitive help
"""

import streamlit as st
import pandas as pd
import numpy as np
import json
import time
from datetime import datetime, timedelta
import sys
import os
import random

# Add the parent directory to the path so we can import our components
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ui.components.material_ui import (
    load_material_icons, material_button, material_card, material_metric,
    material_tabs, material_data_table, material_progress, material_alert,
    material_badge, material_icon_button, material_divider, material_chip,
    material_select, material_text_field, material_checkbox, material_radio,
    material_slider, material_date_picker
)
from ui.components.theme_provider import apply_design_system_to_page
from ui.components.responsive_layout import (
    responsive_container, responsive_grid, responsive_columns, responsive_card,
    responsive_sidebar, responsive_table, responsive_tabs, responsive_image,
    responsive_menu
)

# User preferences management
def load_user_preferences():
    """Load user preferences from session state or initialize defaults."""
    if 'user_preferences' not in st.session_state:
        # Default preferences
        st.session_state.user_preferences = {
            'theme': 'light',
            'dashboard_layout': 'standard',
            'camera_default_view': 'Live Feed',
            'notifications_enabled': True,
            'sound_enabled': True,
            'auto_refresh': True,
            'refresh_interval': 30,  # seconds
            'show_tooltips': True,
            'compact_view': False,
            'keyboard_shortcuts_enabled': True,
            'language': 'English',
            'date_format': 'MM/DD/YYYY',
            'time_format': '24h',
            'defect_highlight_color': 'red',
            'onboarding_completed': False,
            'tutorial_completed': False,
            'last_visited_page': 'dashboard'
        }
    
    return st.session_state.user_preferences

def save_user_preferences(preferences):
    """Save user preferences to session state."""
    st.session_state.user_preferences = preferences

# Notification system
def get_notifications():
    """Get current notifications from session state or initialize empty list."""
    if 'notifications' not in st.session_state:
        st.session_state.notifications = []
    
    return st.session_state.notifications

def add_notification(message, type='info', source=None, action=None, read=False):
    """Add a new notification to the notification list."""
    notifications = get_notifications()
    
    notification = {
        'id': int(time.time() * 1000),  # Unique ID based on timestamp
        'message': message,
        'type': type,  # 'info', 'warning', 'error', 'success'
        'source': source,
        'timestamp': datetime.now(),
        'read': read,
        'action': action  # Optional action to take when notification is clicked
    }
    
    notifications.append(notification)
    st.session_state.notifications = notifications
    
    # Limit to 100 notifications to prevent excessive memory usage
    if len(notifications) > 100:
        st.session_state.notifications = notifications[-100:]

def mark_notification_as_read(notification_id):
    """Mark a notification as read."""
    notifications = get_notifications()
    
    for notification in notifications:
        if notification['id'] == notification_id:
            notification['read'] = True
    
    st.session_state.notifications = notifications

def clear_notifications():
    """Clear all notifications."""
    st.session_state.notifications = []

def get_unread_notification_count():
    """Get the count of unread notifications."""
    notifications = get_notifications()
    return sum(1 for n in notifications if not n['read'])

# Keyboard shortcuts
def register_keyboard_shortcuts():
    """Register keyboard shortcuts via JavaScript."""
    shortcuts_js = """
    <script>
    document.addEventListener('keydown', function(e) {
        // Only process shortcuts if not in an input field
        if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') {
            return;
        }
        
        // Check if keyboard shortcuts are enabled
        const keyboardShortcutsEnabled = JSON.parse(localStorage.getItem('keyboard_shortcuts_enabled') || 'true');
        if (!keyboardShortcutsEnabled) {
            return;
        }
        
        // Dashboard shortcuts
        if (e.key === 'd' && e.altKey) {
            // Navigate to dashboard
            window.location.href = '/';
        }
        else if (e.key === 'c' && e.altKey) {
            // Navigate to camera view
            window.location.href = '/camera';
        }
        else if (e.key === 'a' && e.altKey) {
            // Navigate to analytics
            window.location.href = '/analytics';
        }
        else if (e.key === 's' && e.altKey) {
            // Navigate to settings
            window.location.href = '/settings';
        }
        else if (e.key === 'h' && e.altKey) {
            // Toggle help panel
            const helpButton = document.getElementById('help_button');
            if (helpButton) {
                helpButton.click();
            }
        }
        else if (e.key === 'r' && e.altKey) {
            // Refresh data
            const refreshButton = document.getElementById('refresh_button');
            if (refreshButton) {
                refreshButton.click();
            }
        }
        else if (e.key === 'f' && e.altKey) {
            // Focus search
            const searchInput = document.getElementById('search_input');
            if (searchInput) {
                searchInput.focus();
            }
        }
        else if (e.key === 'n' && e.altKey) {
            // Open notifications
            const notificationsButton = document.getElementById('notifications_button');
            if (notificationsButton) {
                notificationsButton.click();
            }
        }
        else if (e.key === 'Escape') {
            // Close any open modal or panel
            const closeButtons = document.querySelectorAll('.close-button');
            if (closeButtons.length > 0) {
                closeButtons[closeButtons.length - 1].click();
            }
        }
    });
    
    // Store keyboard shortcuts setting in localStorage
    function updateKeyboardShortcutsSetting(enabled) {
        localStorage.setItem('keyboard_shortcuts_enabled', JSON.stringify(enabled));
    }
    </script>
    """
    
    st.markdown(shortcuts_js, unsafe_allow_html=True)

# Search functionality
def search_system(query):
    """Search the system for the given query."""
    if not query:
        return []
    
    # In a real implementation, this would search the database
    # For demo purposes, we'll return mock results
    
    # Categories to search
    categories = [
        {'name': 'Dashboard', 'items': ['Production Overview', 'Defect Analysis', 'System Status', 'Camera Status']},
        {'name': 'Cameras', 'items': ['Top Camera', 'Side Camera 1', 'Side Camera 2', 'Bottom Camera', 'Camera Settings', 'Calibration']},
        {'name': 'Analytics', 'items': ['Production Reports', 'Defect Trends', 'Quality Metrics', 'Performance Analysis']},
        {'name': 'Settings', 'items': ['User Preferences', 'System Configuration', 'Network Settings', 'Notification Settings']},
        {'name': 'Help', 'items': ['User Manual', 'Troubleshooting', 'FAQ', 'Contact Support']}
    ]
    
    # Search for matches
    results = []
    query_lower = query.lower()
    
    for category in categories:
        for item in category['items']:
            if query_lower in item.lower():
                results.append({
                    'category': category['name'],
                    'item': item,
                    'url': f"/{category['name'].lower()}/{item.lower().replace(' ', '_')}"
                })
    
    return results

# Guided tutorials
def get_tutorial_steps(tutorial_name):
    """Get the steps for a specific tutorial."""
    tutorials = {
        'dashboard': [
            {
                'title': 'Welcome to the Dashboard',
                'content': 'This is your main control center for monitoring the sandwich quality inspection system.',
                'target': '.dashboard-header',
                'position': 'bottom'
            },
            {
                'title': 'Production Metrics',
                'content': 'These cards show key metrics about your production line, including total sandwiches inspected and defect rates.',
                'target': '.metrics-row',
                'position': 'bottom'
            },
            {
                'title': 'Production Trends',
                'content': 'This chart shows production volume and defect rates over time. You can change the time period using the selector above.',
                'target': '.production-chart',
                'position': 'top'
            },
            {
                'title': 'Camera Status',
                'content': 'Monitor the status of all cameras in the system. Click on a camera to view its live feed.',
                'target': '.camera-status-card',
                'position': 'left'
            },
            {
                'title': 'Recent Defects',
                'content': 'View the most recent defects detected by the system. Click "View All" to see the complete list.',
                'target': '.recent-defects-card',
                'position': 'right'
            },
            {
                'title': 'Quick Actions',
                'content': 'Perform common tasks like camera calibration and report generation with a single click.',
                'target': '.quick-actions-card',
                'position': 'top'
            },
            {
                'title': 'System Status',
                'content': 'Monitor the health of all system components, including the host PC, Jetson device, and network.',
                'target': '.system-status-sidebar',
                'position': 'right'
            },
            {
                'title': 'Dashboard Complete',
                'content': 'You\'ve completed the dashboard tutorial! Explore the other sections of the application to learn more.',
                'target': 'body',
                'position': 'center'
            }
        ],
        'camera': [
            {
                'title': 'Welcome to Camera View',
                'content': 'This page allows you to monitor and control all cameras in the system.',
                'target': '.camera-header',
                'position': 'bottom'
            },
            {
                'title': 'Camera Selector',
                'content': 'Use this dropdown to switch between different cameras in the system.',
                'target': '.camera-selector',
                'position': 'bottom'
            },
            {
                'title': 'View Modes',
                'content': 'Switch between different viewing modes, including Live Feed, Defect Detection, and Calibration.',
                'target': '.view-mode-selector',
                'position': 'bottom'
            },
            {
                'title': 'Camera Feed',
                'content': 'This is the live feed from the selected camera. Defects will be highlighted when detected.',
                'target': '.camera-feed',
                'position': 'top'
            },
            {
                'title': 'Camera Controls',
                'content': 'Adjust camera settings like exposure, gain, and white balance using these controls.',
                'target': '.camera-controls-sidebar',
                'position': 'left'
            },
            {
                'title': 'Camera Analytics',
                'content': 'View performance metrics and defect history for the selected camera.',
                'target': '.camera-analytics-card',
                'position': 'top'
            },
            {
                'title': 'Camera History',
                'content': 'Browse recent images and event logs for the selected camera.',
                'target': '.camera-history-card',
                'position': 'top'
            },
            {
                'title': 'Camera Actions',
                'content': 'Perform actions like calibration, diagnostics, and video recording.',
                'target': '.camera-actions-card',
                'position': 'top'
            },
            {
                'title': 'Camera View Complete',
                'content': 'You\'ve completed the camera view tutorial! Try adjusting some settings to see how they affect the image.',
                'target': 'body',
                'position': 'center'
            }
        ]
    }
    
    return tutorials.get(tutorial_name, [])

def render_tutorial(tutorial_name):
    """Render a guided tutorial for the specified feature."""
    tutorial_steps = get_tutorial_steps(tutorial_name)
    
    if not tutorial_steps:
        return
    
    # Initialize tutorial state if not exists
    if 'tutorial_step' not in st.session_state:
        st.session_state.tutorial_step = 0
    
    current_step = tutorial_steps[st.session_state.tutorial_step]
    
    # Create tutorial overlay
    tutorial_html = f"""
    <div class="tutorial-overlay" id="tutorial-overlay">
        <div class="tutorial-card" style="position: fixed; z-index: 1000; background: white; border-radius: 8px; 
                                         box-shadow: 0 4px 12px rgba(0,0,0,0.15); padding: 16px; max-width: 300px;">
            <h3 style="margin-top: 0;">{current_step['title']}</h3>
            <p>{current_step['content']}</p>
            <div style="display: flex; justify-content: space-between; margin-top: 16px;">
                <button onclick="prevTutorialStep()" 
                        style="background: none; border: 1px solid #ccc; border-radius: 4px; padding: 8px 16px;"
                        {'' if st.session_state.tutorial_step > 0 else 'disabled style="opacity: 0.5;"'}>
                    Previous
                </button>
                <button onclick="nextTutorialStep()" 
                        style="background: var(--color-primary-main); color: white; border: none; border-radius: 4px; padding: 8px 16px;">
                    {
                        'Next' if st.session_state.tutorial_step < len(tutorial_steps) - 1 else 'Finish'
                    }
                </button>
            </div>
        </div>
    </div>
    
    <script>
    function positionTutorialCard() {
        const overlay = document.getElementById('tutorial-overlay');
        const card = overlay.querySelector('.tutorial-card');
        const target = document.querySelector('{current_step['target']}');
        
        if (!target) {
            // Center in viewport if target not found
            card.style.top = '50%';
            card.style.left = '50%';
            card.style.transform = 'translate(-50%, -50%)';
            return;
        }
        
        const targetRect = target.getBoundingClientRect();
        const position = '{current_step['position']}';
        
        if (position === 'top') {
            card.style.top = (targetRect.top - card.offsetHeight - 10) + 'px';
            card.style.left = (targetRect.left + targetRect.width / 2 - card.offsetWidth / 2) + 'px';
        } else if (position === 'bottom') {
            card.style.top = (targetRect.bottom + 10) + 'px';
            card.style.left = (targetRect.left + targetRect.width / 2 - card.offsetWidth / 2) + 'px';
        } else if (position === 'left') {
            card.style.top = (targetRect.top + targetRect.height / 2 - card.offsetHeight / 2) + 'px';
            card.style.left = (targetRect.left - card.offsetWidth - 10) + 'px';
        } else if (position === 'right') {
            card.style.top = (targetRect.top + targetRect.height / 2 - card.offsetHeight / 2) + 'px';
            card.style.left = (targetRect.right + 10) + 'px';
        } else if (position === 'center') {
            card.style.top = '50%';
            card.style.left = '50%';
            card.style.transform = 'translate(-50%, -50%)';
        }
        
        // Ensure card is within viewport
        const cardRect = card.getBoundingClientRect();
        if (cardRect.top < 10) {
            card.style.top = '10px';
        }
        if (cardRect.left < 10) {
            card.style.left = '10px';
        }
        if (cardRect.right > window.innerWidth - 10) {
            card.style.left = (window.innerWidth - card.offsetWidth - 10) + 'px';
        }
        if (cardRect.bottom > window.innerHeight - 10) {
            card.style.top = (window.innerHeight - card.offsetHeight - 10) + 'px';
        }
    }
    
    function highlightTarget() {
        // Remove any existing highlights
        const existingHighlight = document.querySelector('.tutorial-highlight');
        if (existingHighlight) {
            existingHighlight.remove();
        }
        
        const target = document.querySelector('{current_step['target']}');
        if (!target || '{current_step['target']}' === 'body') {
            return;
        }
        
        // Create highlight effect
        const targetRect = target.getBoundingClientRect();
        const highlight = document.createElement('div');
        highlight.className = 'tutorial-highlight';
        highlight.style.position = 'fixed';
        highlight.style.top = targetRect.top + 'px';
        highlight.style.left = targetRect.left + 'px';
        highlight.style.width = targetRect.width + 'px';
        highlight.style.height = targetRect.height + 'px';
        highlight.style.border = '2px solid var(--color-primary-main)';
        highlight.style.borderRadius = '4px';
        highlight.style.boxShadow = '0 0 0 5000px rgba(0, 0, 0, 0.3)';
        highlight.style.zIndex = '999';
        highlight.style.pointerEvents = 'none';
        
        document.body.appendChild(highlight);
    }
    
    function nextTutorialStep() {
        const tutorialStepElement = document.getElementById('tutorial_step');
        const currentStep = parseInt(tutorialStepElement.value);
        const totalSteps = {len(tutorial_steps)};
        
        if (currentStep < totalSteps - 1) {
            tutorialStepElement.value = currentStep + 1;
            
            // Trigger form submission to update state
            const nextButton = document.getElementById('tutorial_next_button');
            nextButton.click();
        } else {
            // End tutorial
            const finishButton = document.getElementById('tutorial_finish_button');
            finishButton.click();
        }
    }
    
    function prevTutorialStep() {
        const tutorialStepElement = document.getElementById('tutorial_step');
        const currentStep = parseInt(tutorialStepElement.value);
        
        if (currentStep > 0) {
            tutorialStepElement.value = currentStep - 1;
            
            // Trigger form submission to update state
            const prevButton = document.getElementById('tutorial_prev_button');
            prevButton.click();
        }
    }
    
    // Position the tutorial card when the page loads
    window.addEventListener('load', function() {
        positionTutorialCard();
        highlightTarget();
    });
    
    // Reposition on window resize
    window.addEventListener('resize', function() {
        positionTutorialCard();
        highlightTarget();
    });
    
    // Initial positioning
    positionTutorialCard();
    highlightTarget();
    </script>
    """
    
    st.markdown(tutorial_html, unsafe_allow_html=True)
    
    # Hidden form elements to handle tutorial navigation
    with st.form(key="tutorial_navigation_form", clear_on_submit=True):
        st.number_input("Step", value=st.session_state.tutorial_step, key="tutorial_step", label_visibility="collapsed")
        
        col1, col2, col3 = st.columns([1, 1, 1])
        
        with col1:
            prev_clicked = st.form_submit_button("Previous", key="tutorial_prev_button")
        
        with col2:
            next_clicked = st.form_submit_button("Next", key="tutorial_next_button")
        
        with col3:
            finish_clicked = st.form_submit_button("Finish", key="tutorial_finish_button")
    
    # Handle form submission
    if prev_clicked and st.session_state.tutorial_step > 0:
        st.session_state.tutorial_step -= 1
        st.rerun()
    
    if next_clicked and st.session_state.tutorial_step < len(tutorial_steps) - 1:
        st.session_state.tutorial_step += 1
        st.rerun()
    
    if finish_clicked:
        # Mark tutorial as completed
        preferences = load_user_preferences()
        preferences['tutorial_completed'] = True
        save_user_preferences(preferences)
        
        # End tutorial
        if 'tutorial_step' in st.session_state:
            del st.session_state.tutorial_step
        
        st.rerun()

# Context-sensitive help
def get_help_content(context):
    """Get help content for the specified context."""
    help_content = {
        'dashboard': {
            'title': 'Dashboard Help',
            'content': """
            ## Dashboard Overview
            
            The dashboard provides a real-time overview of your sandwich quality inspection system. Here you can monitor:
            
            - Production metrics and trends
            - Defect rates and types
            - Camera status
            - System health
            
            ### Key Features
            
            - **Metrics Cards**: Show key performance indicators at a glance
            - **Production Chart**: Visualizes production volume and defect rates over time
            - **Camera Status**: Displays the status of all cameras in the system
            - **Recent Defects**: Lists the most recently detected defects
            - **Quick Actions**: Provides one-click access to common tasks
            
            ### Tips
            
            - Use the date range selector to change the time period for the data displayed
            - Click on a camera in the Camera Status panel to go directly to its live feed
            - Hover over charts for detailed information
            """
        },
        'camera': {
            'title': 'Camera View Help',
            'content': """
            ## Camera View
            
            The camera view allows you to monitor and control all cameras in the system. Here you can:
            
            - View live camera feeds
            - Detect and analyze defects
            - Calibrate cameras
            - Adjust camera settings
            
            ### Key Features
            
            - **Camera Selector**: Switch between different cameras
            - **View Modes**: Choose between Live Feed, Defect Detection, Calibration, and Thermal View
            - **Camera Controls**: Adjust settings like exposure, gain, and white balance
            - **Camera Analytics**: View performance metrics and defect history
            
            ### Tips
            
            - Use the Calibration mode when setting up a new camera or after moving a camera
            - Adjust exposure and gain settings to optimize image quality
            - Use the Thermal View to identify potential hotspots or issues
            - Check the Camera History to review recent images and events
            """
        },
        'analytics': {
            'title': 'Analytics Help',
            'content': """
            ## Analytics
            
            The analytics page provides detailed insights into your production data. Here you can:
            
            - Analyze production trends
            - Identify defect patterns
            - Generate reports
            - Export data for further analysis
            
            ### Key Features
            
            - **Production Analysis**: Detailed breakdown of production metrics
            - **Defect Analysis**: In-depth analysis of defect types, rates, and patterns
            - **Quality Metrics**: Comprehensive quality indicators
            - **Report Generation**: Create and export custom reports
            
            ### Tips
            
            - Use filters to focus on specific time periods, production lines, or product types
            - Export data to CSV for further analysis in external tools
            - Schedule regular reports to track performance over time
            - Look for correlations between defect rates and other factors
            """
        },
        'settings': {
            'title': 'Settings Help',
            'content': """
            ## Settings
            
            The settings page allows you to customize the system to your preferences. Here you can:
            
            - Adjust user interface preferences
            - Configure system settings
            - Manage notifications
            - Set up keyboard shortcuts
            
            ### Key Features
            
            - **User Preferences**: Customize the user interface
            - **System Configuration**: Configure system-wide settings
            - **Notification Settings**: Manage how and when you receive notifications
            - **Keyboard Shortcuts**: Set up and customize keyboard shortcuts
            
            ### Tips
            
            - Enable keyboard shortcuts for faster navigation
            - Customize notification settings to focus on important alerts
            - Adjust the theme to match your environment (light/dark)
            - Configure auto-refresh to keep data up-to-date
            """
        }
    }
    
    return help_content.get(context, {
        'title': 'Help Center',
        'content': """
        ## Help Center
        
        Welcome to the OPSC Sandwich Quality Inspection System help center. Select a topic from the sidebar to get detailed help on specific features.
        
        ### Quick Links
        
        - [Dashboard Help](#dashboard)
        - [Camera View Help](#camera)
        - [Analytics Help](#analytics)
        - [Settings Help](#settings)
        
        ### Need More Help?
        
        Contact support at support@opsc-vision.com or call +1-555-123-4567.
        """
    })

def render_help_panel(context):
    """Render a context-sensitive help panel."""
    help_content = get_help_content(context)
    
    with st.sidebar:
        st.markdown(f"# {help_content['title']}")
        st.markdown(help_content['content'])
        
        st.markdown("---")
        
        st.markdown("### Other Help Topics")
        for topic in ['dashboard', 'camera', 'analytics', 'settings']:
            if topic != context:
                if st.button(f"{topic.capitalize()} Help", key=f"help_{topic}"):
                    st.session_state.help_context = topic
                    st.rerun()
        
        st.markdown("---")
        
        if st.button("Start Tutorial", key="start_tutorial"):
            st.session_state.show_tutorial = True
            st.session_state.tutorial_step = 0
            st.rerun()
        
        if st.button("Close Help", key="close_help"):
            st.session_state.show_help = False
            st.rerun()

# User onboarding
def render_onboarding():
    """Render the onboarding experience for new users."""
    if 'onboarding_step' not in st.session_state:
        st.session_state.onboarding_step = 0
    
    onboarding_steps = [
        {
            'title': 'Welcome to OPSC Sandwich Quality Inspection System',
            'content': """
            Welcome to the OPSC Sandwich Quality Inspection System! This system helps you monitor and control your sandwich production line quality.
            
            Let's take a few moments to set up your experience and learn the basics.
            """,
            'image': None
        },
        {
            'title': 'Choose Your Theme',
            'content': """
            Select a theme that works best for your environment. You can always change this later in Settings.
            """,
            'options': [
                {'label': 'Light Theme', 'value': 'light', 'icon': 'light_mode'},
                {'label': 'Dark Theme', 'value': 'dark', 'icon': 'dark_mode'},
                {'label': 'Auto (System)', 'value': 'auto', 'icon': 'brightness_auto'}
            ],
            'option_key': 'theme'
        },
        {
            'title': 'Notification Preferences',
            'content': """
            How would you like to receive notifications? You can adjust these settings later.
            """,
            'checkboxes': [
                {'label': 'In-app notifications', 'value': True, 'key': 'notifications_enabled'},
                {'label': 'Sound alerts', 'value': True, 'key': 'sound_enabled'},
                {'label': 'Critical alerts only', 'value': False, 'key': 'critical_alerts_only'}
            ]
        },
        {
            'title': 'Dashboard Layout',
            'content': """
            Choose your preferred dashboard layout. This determines how information is organized on your main screen.
            """,
            'options': [
                {'label': 'Standard', 'value': 'standard', 'description': 'Balanced view with all key metrics'},
                {'label': 'Production Focus', 'value': 'production', 'description': 'Emphasizes production metrics and trends'},
                {'label': 'Quality Focus', 'value': 'quality', 'description': 'Emphasizes defect detection and quality metrics'},
                {'label': 'Compact', 'value': 'compact', 'description': 'Condensed view for smaller screens'}
            ],
            'option_key': 'dashboard_layout'
        },
        {
            'title': 'Enable Keyboard Shortcuts?',
            'content': """
            Keyboard shortcuts can help you navigate the system more efficiently. Would you like to enable them?
            
            Examples:
            - Alt+D: Go to Dashboard
            - Alt+C: Go to Camera View
            - Alt+A: Go to Analytics
            - Alt+S: Go to Settings
            - Alt+H: Open Help
            - Alt+R: Refresh Data
            """,
            'yes_no': {
                'key': 'keyboard_shortcuts_enabled',
                'default': True
            }
        },
        {
            'title': 'Setup Complete!',
            'content': """
            Your system is now set up according to your preferences. You can change any of these settings later in the Settings page.
            
            Would you like to take a quick tour of the system?
            """,
            'buttons': [
                {'label': 'Start Tutorial', 'action': 'start_tutorial', 'primary': True},
                {'label': 'Skip for Now', 'action': 'skip_tutorial', 'primary': False}
            ]
        }
    ]
    
    current_step = onboarding_steps[st.session_state.onboarding_step]
    
    # Create a card for the onboarding step
    st.markdown(
        f"""
        <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
            <h1>{current_step['title']}</h1>
            <div style="margin-bottom: 20px;">
                {current_step['content']}
            </div>
        </div>
        """,
        unsafe_allow_html=True
    )
    
    # Render step-specific content
    if 'image' in current_step and current_step['image']:
        st.image(current_step['image'], use_column_width=True)
    
    if 'options' in current_step and 'option_key' in current_step:
        option_key = current_step['option_key']
        options = current_step['options']
        
        if 'icon' in options[0]:
            # Render as icon buttons
            cols = st.columns(len(options))
            for i, option in enumerate(options):
                with cols[i]:
                    st.markdown(
                        f"""
                        <div style="text-align: center;">
                            <span class="material-icons" style="font-size: 48px;">{option['icon']}</span>
                            <div>{option['label']}</div>
                        </div>
                        """,
                        unsafe_allow_html=True
                    )
                    if st.button("Select", key=f"option_{i}"):
                        st.session_state[option_key] = option['value']
                        st.session_state.onboarding_step += 1
                        st.rerun()
        else:
            # Render as radio buttons with descriptions
            for i, option in enumerate(options):
                col1, col2 = st.columns([1, 3])
                with col1:
                    selected = st.radio("", [option['label']], key=f"radio_{i}", label_visibility="collapsed")
                    if selected:
                        st.session_state[option_key] = option['value']
                
                with col2:
                    if 'description' in option:
                        st.markdown(f"*{option['description']}*")
            
            if st.button("Continue", key="continue_options"):
                st.session_state.onboarding_step += 1
                st.rerun()
    
    if 'checkboxes' in current_step:
        for checkbox in current_step['checkboxes']:
            st.session_state[checkbox['key']] = st.checkbox(
                checkbox['label'],
                value=checkbox['value'],
                key=f"checkbox_{checkbox['key']}"
            )
        
        if st.button("Continue", key="continue_checkboxes"):
            st.session_state.onboarding_step += 1
            st.rerun()
    
    if 'yes_no' in current_step:
        yes_no = current_step['yes_no']
        col1, col2 = st.columns(2)
        
        with col1:
            if st.button("Yes", key="yes_button"):
                st.session_state[yes_no['key']] = True
                st.session_state.onboarding_step += 1
                st.rerun()
        
        with col2:
            if st.button("No", key="no_button"):
                st.session_state[yes_no['key']] = False
                st.session_state.onboarding_step += 1
                st.rerun()
    
    if 'buttons' in current_step:
        cols = st.columns(len(current_step['buttons']))
        
        for i, button in enumerate(current_step['buttons']):
            with cols[i]:
                if st.button(
                    button['label'],
                    key=f"action_button_{i}",
                    type="primary" if button.get('primary', False) else "secondary"
                ):
                    if button['action'] == 'start_tutorial':
                        # Mark onboarding as completed
                        preferences = load_user_preferences()
                        preferences['onboarding_completed'] = True
                        save_user_preferences(preferences)
                        
                        # Start tutorial
                        st.session_state.show_tutorial = True
                        st.session_state.tutorial_step = 0
                        
                        # Clear onboarding state
                        if 'onboarding_step' in st.session_state:
                            del st.session_state.onboarding_step
                        
                        st.rerun()
                    
                    elif button['action'] == 'skip_tutorial':
                        # Mark onboarding as completed
                        preferences = load_user_preferences()
                        preferences['onboarding_completed'] = True
                        save_user_preferences(preferences)
                        
                        # Clear onboarding state
                        if 'onboarding_step' in st.session_state:
                            del st.session_state.onboarding_step
                        
                        st.rerun()
    
    # Navigation buttons (except for last step which has its own buttons)
    if 'buttons' not in current_step:
        col1, col2, col3 = st.columns([1, 2, 1])
        
        with col1:
            if st.session_state.onboarding_step > 0:
                if st.button("Back", key="back_button"):
                    st.session_state.onboarding_step -= 1
                    st.rerun()
        
        with col3:
            if st.button("Next", key="next_button"):
                st.session_state.onboarding_step += 1
                st.rerun()

# Notification center
def render_notification_center():
    """Render the notification center panel."""
    notifications = get_notifications()
    
    st.markdown("## Notifications")
    
    if not notifications:
        st.markdown("No notifications to display.")
    else:
        # Group notifications by date
        today = datetime.now().date()
        yesterday = today - timedelta(days=1)
        
        today_notifications = [n for n in notifications if n['timestamp'].date() == today]
        yesterday_notifications = [n for n in notifications if n['timestamp'].date() == yesterday]
        older_notifications = [n for n in notifications if n['timestamp'].date() < yesterday]
        
        # Render notifications by group
        if today_notifications:
            st.markdown("### Today")
            render_notification_group(today_notifications)
        
        if yesterday_notifications:
            st.markdown("### Yesterday")
            render_notification_group(yesterday_notifications)
        
        if older_notifications:
            st.markdown("### Older")
            render_notification_group(older_notifications)
        
        # Clear all button
        if st.button("Clear All Notifications", key="clear_all_notifications"):
            clear_notifications()
            st.rerun()

def render_notification_group(notifications):
    """Render a group of notifications."""
    for notification in notifications:
        # Determine icon and color based on notification type
        icon = "info"
        color = "var(--color-info-main)"
        
        if notification['type'] == 'warning':
            icon = "warning"
            color = "var(--color-warning-main)"
        elif notification['type'] == 'error':
            icon = "error"
            color = "var(--color-error-main)"
        elif notification['type'] == 'success':
            icon = "check_circle"
            color = "var(--color-success-main)"
        
        # Create notification card
        st.markdown(
            f"""
            <div style="display: flex; align-items: flex-start; margin-bottom: 12px; padding: 8px; 
                       background-color: {
                           'rgba(0,0,0,0.05)' if notification['read'] else 'rgba(0,0,0,0)'
                       }; 
                       border-radius: 4px;">
                <span class="material-icons" style="color: {color}; margin-right: 8px; font-size: 20px;">
                    {icon}
                </span>
                <div style="flex-grow: 1;">
                    <div style="font-weight: {
                        '400' if notification['read'] else '500'
                    };">{notification['message']}</div>
                    <div style="font-size: 12px; color: var(--color-neutral-main);">
                        {notification['timestamp'].strftime('%H:%M')}
                        {f" • {notification['source']}" if notification['source'] else ""}
                    </div>
                </div>
            </div>
            """,
            unsafe_allow_html=True
        )
        
        # Mark as read when displayed
        if not notification['read']:
            mark_notification_as_read(notification['id'])

# Search panel
def render_search_panel():
    """Render the search panel."""
    st.markdown("## Search")
    
    query = st.text_input("Search", key="search_query", placeholder="Search for anything...")
    
    if query:
        results = search_system(query)
        
        if results:
            st.markdown(f"Found {len(results)} results for '{query}':")
            
            # Group results by category
            categories = {}
            for result in results:
                category = result['category']
                if category not in categories:
                    categories[category] = []
                categories[category].append(result)
            
            # Display results by category
            for category, category_results in categories.items():
                st.markdown(f"### {category}")
                
                for result in category_results:
                    if st.button(result['item'], key=f"result_{result['item']}"):
                        # In a real app, this would navigate to the result URL
                        st.session_state.search_result_clicked = result['url']
                        st.rerun()
        else:
            st.markdown(f"No results found for '{query}'.")
            
            st.markdown("### Suggestions:")
            st.markdown("- Check your spelling")
            st.markdown("- Try more general keywords")
            st.markdown("- Try different keywords")

# User preferences panel
def render_user_preferences():
    """Render the user preferences panel."""
    preferences = load_user_preferences()
    
    st.markdown("## User Preferences")
    
    # Theme selection
    st.markdown("### Appearance")
    theme = st.selectbox(
        "Theme",
        options=["light", "dark", "auto"],
        format_func=lambda x: x.capitalize(),
        index=["light", "dark", "auto"].index(preferences['theme']),
        key="pref_theme"
    )
    
    # Dashboard layout
    dashboard_layout = st.selectbox(
        "Dashboard Layout",
        options=["standard", "production", "quality", "compact"],
        format_func=lambda x: x.capitalize(),
        index=["standard", "production", "quality", "compact"].index(preferences['dashboard_layout']),
        key="pref_dashboard_layout"
    )
    
    # Compact view
    compact_view = st.checkbox(
        "Compact View",
        value=preferences['compact_view'],
        key="pref_compact_view"
    )
    
    st.markdown("### Notifications")
    
    # Notification settings
    notifications_enabled = st.checkbox(
        "Enable Notifications",
        value=preferences['notifications_enabled'],
        key="pref_notifications_enabled"
    )
    
    sound_enabled = st.checkbox(
        "Enable Sound Alerts",
        value=preferences['sound_enabled'],
        key="pref_sound_enabled"
    )
    
    st.markdown("### Data Refresh")
    
    # Auto refresh
    auto_refresh = st.checkbox(
        "Auto Refresh",
        value=preferences['auto_refresh'],
        key="pref_auto_refresh"
    )
    
    refresh_interval = st.slider(
        "Refresh Interval (seconds)",
        min_value=5,
        max_value=120,
        value=preferences['refresh_interval'],
        step=5,
        key="pref_refresh_interval",
        disabled=not auto_refresh
    )
    
    st.markdown("### Accessibility")
    
    # Keyboard shortcuts
    keyboard_shortcuts_enabled = st.checkbox(
        "Enable Keyboard Shortcuts",
        value=preferences['keyboard_shortcuts_enabled'],
        key="pref_keyboard_shortcuts_enabled"
    )
    
    show_tooltips = st.checkbox(
        "Show Tooltips",
        value=preferences['show_tooltips'],
        key="pref_show_tooltips"
    )
    
    st.markdown("### Regional Settings")
    
    # Language
    language = st.selectbox(
        "Language",
        options=["English", "Spanish", "French", "German", "Chinese"],
        index=["English", "Spanish", "French", "German", "Chinese"].index(preferences['language']),
        key="pref_language"
    )
    
    # Date format
    date_format = st.selectbox(
        "Date Format",
        options=["MM/DD/YYYY", "DD/MM/YYYY", "YYYY-MM-DD"],
        index=["MM/DD/YYYY", "DD/MM/YYYY", "YYYY-MM-DD"].index(preferences['date_format']),
        key="pref_date_format"
    )
    
    # Time format
    time_format = st.selectbox(
        "Time Format",
        options=["12h", "24h"],
        index=["12h", "24h"].index(preferences['time_format']),
        key="pref_time_format"
    )
    
    # Save button
    if st.button("Save Preferences", key="save_preferences"):
        # Update preferences
        preferences['theme'] = theme
        preferences['dashboard_layout'] = dashboard_layout
        preferences['compact_view'] = compact_view
        preferences['notifications_enabled'] = notifications_enabled
        preferences['sound_enabled'] = sound_enabled
        preferences['auto_refresh'] = auto_refresh
        preferences['refresh_interval'] = refresh_interval
        preferences['keyboard_shortcuts_enabled'] = keyboard_shortcuts_enabled
        preferences['show_tooltips'] = show_tooltips
        preferences['language'] = language
        preferences['date_format'] = date_format
        preferences['time_format'] = time_format
        
        # Save preferences
        save_user_preferences(preferences)
        
        # Show success message
        st.success("Preferences saved successfully!")
    
    # Reset button
    if st.button("Reset to Defaults", key="reset_preferences"):
        # Clear preferences
        if 'user_preferences' in st.session_state:
            del st.session_state.user_preferences
        
        # Reload default preferences
        load_user_preferences()
        
        # Show success message
        st.success("Preferences reset to defaults!")
        
        # Rerun to update UI
        st.rerun()

# Main app header with user experience features
def render_app_header(title, page_context):
    """Render the application header with user experience features."""
    # Load user preferences
    preferences = load_user_preferences()
    
    # Register keyboard shortcuts
    if preferences['keyboard_shortcuts_enabled']:
        register_keyboard_shortcuts()
    
    # Check if onboarding is needed
    if not preferences['onboarding_completed'] and 'onboarding_step' not in st.session_state:
        st.session_state.onboarding_step = 0
        render_onboarding()
        return
    
    # Check if tutorial is active
    if 'show_tutorial' in st.session_state and st.session_state.show_tutorial:
        render_tutorial(page_context)
    
    # Create header container
    st.markdown(
        f"""
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <div>
                <h1 style="margin-bottom: 0;">{title}</h1>
            </div>
            <div style="display: flex; gap: 8px;">
                <div id="search_button"></div>
                <div id="notifications_button"></div>
                <div id="help_button"></div>
                <div id="user_menu_button"></div>
            </div>
        </div>
        """,
        unsafe_allow_html=True
    )
    
    # Create action buttons
    col1, col2, col3, col4 = st.columns([1, 1, 1, 1])
    
    with col1:
        search_clicked = material_icon_button(
            icon="search",
            tooltip="Search",
            key="search_icon"
        )
    
    with col2:
        # Get unread notification count
        unread_count = get_unread_notification_count()
        
        notifications_clicked = material_icon_button(
            icon="notifications",
            tooltip="Notifications",
            badge=unread_count if unread_count > 0 else None,
            key="notifications_icon"
        )
    
    with col3:
        help_clicked = material_icon_button(
            icon="help",
            tooltip="Help",
            key="help_icon"
        )
    
    with col4:
        user_menu_clicked = material_icon_button(
            icon="account_circle",
            tooltip="User Menu",
            key="user_menu_icon"
        )
    
    # Handle button clicks
    if search_clicked:
        st.session_state.show_search = True
        st.session_state.show_notifications = False
        st.session_state.show_help = False
        st.session_state.show_user_menu = False
    
    if notifications_clicked:
        st.session_state.show_notifications = True
        st.session_state.show_search = False
        st.session_state.show_help = False
        st.session_state.show_user_menu = False
    
    if help_clicked:
        st.session_state.show_help = True
        st.session_state.help_context = page_context
        st.session_state.show_search = False
        st.session_state.show_notifications = False
        st.session_state.show_user_menu = False
    
    if user_menu_clicked:
        st.session_state.show_user_menu = True
        st.session_state.show_search = False
        st.session_state.show_notifications = False
        st.session_state.show_help = False
    
    # Render panels based on state
    if 'show_search' in st.session_state and st.session_state.show_search:
        with st.sidebar:
            render_search_panel()
            
            if st.button("Close", key="close_search"):
                st.session_state.show_search = False
                st.rerun()
    
    if 'show_notifications' in st.session_state and st.session_state.show_notifications:
        with st.sidebar:
            render_notification_center()
            
            if st.button("Close", key="close_notifications"):
                st.session_state.show_notifications = False
                st.rerun()
    
    if 'show_help' in st.session_state and st.session_state.show_help:
        render_help_panel(st.session_state.help_context)
    
    if 'show_user_menu' in st.session_state and st.session_state.show_user_menu:
        with st.sidebar:
            render_user_preferences()
            
            if st.button("Close", key="close_user_menu"):
                st.session_state.show_user_menu = False
                st.rerun()

# Demo page to showcase user experience features
def render_ux_demo():
    """Render a demo page showcasing user experience features."""
    # Apply design system to the page
    apply_design_system_to_page("User Experience Demo")
    
    # Load Material Icons
    load_material_icons()
    
    # Render app header
    render_app_header("User Experience Demo", "dashboard")
    
    # Main content
    st.markdown("## User Experience Features Demo")
    
    st.markdown("""
    This page demonstrates the enhanced user experience features of the OPSC Sandwich Quality Inspection System.
    Explore the different features using the cards below.
    """)
    
    # Feature showcase
    col1, col2 = st.columns(2)
    
    with col1:
        def onboarding_demo():
            st.markdown("Start the onboarding experience for new users.")
            
            if st.button("Start Onboarding", key="start_onboarding"):
                # Reset onboarding state
                st.session_state.onboarding_step = 0
                
                # Reset onboarding completion flag
                preferences = load_user_preferences()
                preferences['onboarding_completed'] = False
                save_user_preferences(preferences)
                
                st.rerun()
        
        material_card(
            title="Onboarding Experience",
            content_func=onboarding_demo,
            key="onboarding_card"
        )
        
        def tutorial_demo():
            st.markdown("Start a guided tutorial for different parts of the application.")
            
            tutorial_type = st.selectbox(
                "Tutorial Type",
                options=["dashboard", "camera"],
                format_func=lambda x: x.capitalize(),
                key="tutorial_type"
            )
            
            if st.button("Start Tutorial", key="start_tutorial_demo"):
                st.session_state.show_tutorial = True
                st.session_state.tutorial_step = 0
                st.session_state.tutorial_type = tutorial_type
                st.rerun()
        
        material_card(
            title="Guided Tutorials",
            content_func=tutorial_demo,
            key="tutorial_card"
        )
        
        def notification_demo():
            st.markdown("Generate sample notifications to see how they appear in the system.")
            
            notification_type = st.selectbox(
                "Notification Type",
                options=["info", "warning", "error", "success"],
                key="notification_type"
            )
            
            notification_message = st.text_input(
                "Message",
                value="Sample notification message",
                key="notification_message"
            )
            
            if st.button("Add Notification", key="add_notification"):
                add_notification(
                    message=notification_message,
                    type=notification_type,
                    source="Demo",
                    read=False
                )
                st.success("Notification added! Click the notification icon in the header to view.")
        
        material_card(
            title="Notification System",
            content_func=notification_demo,
            key="notification_card"
        )
    
    with col2:
        def keyboard_shortcuts_demo():
            st.markdown("""
            The system supports keyboard shortcuts for faster navigation. Here are some examples:
            
            - Alt+D: Go to Dashboard
            - Alt+C: Go to Camera View
            - Alt+A: Go to Analytics
            - Alt+S: Go to Settings
            - Alt+H: Open Help
            - Alt+R: Refresh Data
            - Alt+F: Focus Search
            - Alt+N: Open Notifications
            - Escape: Close any open panel
            """)
            
            shortcuts_enabled = st.checkbox(
                "Enable Keyboard Shortcuts",
                value=load_user_preferences()['keyboard_shortcuts_enabled'],
                key="shortcuts_enabled"
            )
            
            if shortcuts_enabled != load_user_preferences()['keyboard_shortcuts_enabled']:
                preferences = load_user_preferences()
                preferences['keyboard_shortcuts_enabled'] = shortcuts_enabled
                save_user_preferences(preferences)
                
                # Update JavaScript
                st.markdown(
                    f"""
                    <script>
                    updateKeyboardShortcutsSetting({str(shortcuts_enabled).lower()});
                    </script>
                    """,
                    unsafe_allow_html=True
                )
        
        material_card(
            title="Keyboard Shortcuts",
            content_func=keyboard_shortcuts_demo,
            key="shortcuts_card"
        )
        
        def help_system_demo():
            st.markdown("""
            The context-sensitive help system provides relevant information based on the current page.
            """)
            
            help_context = st.selectbox(
                "Help Context",
                options=["dashboard", "camera", "analytics", "settings"],
                format_func=lambda x: x.capitalize(),
                key="help_context"
            )
            
            if st.button("Open Help", key="open_help_demo"):
                st.session_state.show_help = True
                st.session_state.help_context = help_context
                st.rerun()
        
        material_card(
            title="Context-Sensitive Help",
            content_func=help_system_demo,
            key="help_card"
        )
        
        def search_demo():
            st.markdown("""
            The search system allows you to quickly find information across the application.
            """)
            
            search_query = st.text_input(
                "Search Query",
                value="camera",
                key="search_query_demo"
            )
            
            if st.button("Search", key="search_demo"):
                st.session_state.show_search = True
                st.session_state.search_query = search_query
                st.rerun()
        
        material_card(
            title="Search System",
            content_func=search_demo,
            key="search_card"
        )
    
    # User preferences
    def preferences_demo():
        st.markdown("""
        The user preferences system allows users to customize their experience.
        Click the user icon in the header to access the full preferences panel.
        """)
        
        col1, col2 = st.columns(2)
        
        with col1:
            preferences = load_user_preferences()
            
            theme = st.selectbox(
                "Theme",
                options=["light", "dark", "auto"],
                format_func=lambda x: x.capitalize(),
                index=["light", "dark", "auto"].index(preferences['theme']),
                key="theme_demo"
            )
            
            if theme != preferences['theme']:
                preferences['theme'] = theme
                save_user_preferences(preferences)
                st.success("Theme updated!")
        
        with col2:
            dashboard_layout = st.selectbox(
                "Dashboard Layout",
                options=["standard", "production", "quality", "compact"],
                format_func=lambda x: x.capitalize(),
                index=["standard", "production", "quality", "compact"].index(preferences['dashboard_layout']),
                key="layout_demo"
            )
            
            if dashboard_layout != preferences['dashboard_layout']:
                preferences['dashboard_layout'] = dashboard_layout
                save_user_preferences(preferences)
                st.success("Dashboard layout updated!")
        
        if st.button("Open Full Preferences", key="open_preferences"):
            st.session_state.show_user_menu = True
            st.rerun()
    
    material_card(
        title="User Preferences",
        content_func=preferences_demo,
        key="preferences_card"
    )
    
    # Reset demo
    st.markdown("---")
    
    if st.button("Reset All Demo Settings", key="reset_demo"):
        # Clear all demo-related session state
        for key in list(st.session_state.keys()):
            if key.startswith("show_") or key.endswith("_demo") or key in [
                "onboarding_step", "tutorial_step", "search_query", "help_context"
            ]:
                del st.session_state[key]
        
        # Reset user preferences
        if 'user_preferences' in st.session_state:
            del st.session_state.user_preferences
        
        # Reset notifications
        if 'notifications' in st.session_state:
            del st.session_state.notifications
        
        # Reload default preferences
        load_user_preferences()
        
        st.success("All demo settings reset!")
        st.rerun()

if __name__ == "__main__":
    st.set_page_config(
        page_title="OPSC User Experience Demo",
        page_icon="🥪",
        layout="wide",
        initial_sidebar_state="expanded"
    )
    render_ux_demo()
