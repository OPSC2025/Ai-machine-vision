"""
Tests for UI components of the OPSC Sandwich Quality Inspection System.

This module provides comprehensive tests for all UI components including:
- Material UI components
- Responsive layout components
- Interactive dashboard
- Camera views
- User experience features
- Dark mode support
- Mobile responsive design
- Backend integration
"""

import unittest
import sys
import os
import streamlit as st
import pandas as pd
import numpy as np
from unittest.mock import MagicMock, patch
from PIL import Image
import io
import json
from datetime import datetime, timedelta

# Add the parent directory to the path so we can import our components
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

# Import UI components
from ui.components.material_ui import (
    load_material_icons, material_button, material_card, material_metric,
    material_tabs, material_data_table, material_progress, material_alert,
    material_badge, material_icon_button, material_divider, material_chip,
    material_select, material_text_field, material_checkbox, material_radio,
    material_slider, material_date_picker
)
from ui.components.theme_provider import apply_design_system_to_page, get_theme_colors
from ui.components.responsive_layout import (
    responsive_container, responsive_grid, responsive_columns, responsive_card,
    responsive_sidebar, responsive_table, responsive_tabs, responsive_image,
    responsive_menu
)
from ui.components.design_system import (
    get_color_palette, get_typography, get_spacing, get_shadows, get_border_radius,
    apply_text_style, apply_color_style, apply_spacing
)
from ui.dark_mode import apply_theme, get_effective_theme, toggle_theme
from ui.mobile_responsive import (
    detect_device_type, detect_touch_capability, detect_screen_dimensions,
    detect_orientation, detect_browser, apply_responsive_design
)
from ui.backend_integration import (
    APIClient, DataFetcher, RealtimeUpdater, AuthManager, FormManager,
    ErrorHandler, BackendIntegration
)

class TestMaterialUIComponents(unittest.TestCase):
    """Test cases for Material UI components."""
    
    def setUp(self):
        """Set up test environment."""
        # Mock Streamlit
        self.st_mock = MagicMock()
        self.markdown_mock = MagicMock()
        self.button_mock = MagicMock()
        self.metric_mock = MagicMock()
        self.columns_mock = MagicMock()
        
        # Patch Streamlit functions
        self.st_patch = patch('ui.components.material_ui.st', self.st_mock)
        self.markdown_patch = patch('ui.components.material_ui.st.markdown', self.markdown_mock)
        self.button_patch = patch('ui.components.material_ui.st.button', self.button_mock)
        self.metric_patch = patch('ui.components.material_ui.st.metric', self.metric_mock)
        self.columns_patch = patch('ui.components.material_ui.st.columns', self.columns_mock)
        
        # Start patches
        self.st_patch.start()
        self.markdown_patch.start()
        self.button_patch.start()
        self.metric_patch.start()
        self.columns_patch.start()
    
    def tearDown(self):
        """Clean up after tests."""
        # Stop patches
        self.st_patch.stop()
        self.markdown_patch.stop()
        self.button_patch.stop()
        self.metric_patch.stop()
        self.columns_patch.stop()
    
    def test_load_material_icons(self):
        """Test loading Material Icons."""
        load_material_icons()
        self.markdown_mock.assert_called_once()
        call_args = self.markdown_mock.call_args[0][0]
        self.assertIn('<link href="https://fonts.googleapis.com/icon?family=Material+Icons"', call_args)
    
    def test_material_button(self):
        """Test Material Button component."""
        # Set up button mock to return True (clicked)
        self.button_mock.return_value = True
        
        # Test primary button
        result = material_button("Test Button", variant="primary")
        self.button_mock.assert_called_once()
        self.assertTrue(result)
        
        # Reset mock
        self.button_mock.reset_mock()
        
        # Test secondary button
        result = material_button("Test Button", variant="secondary", icon="add")
        self.button_mock.assert_called_once()
        
        # Reset mock
        self.button_mock.reset_mock()
        
        # Test disabled button
        result = material_button("Test Button", disabled=True)
        self.button_mock.assert_called_once()
        call_kwargs = self.button_mock.call_args[1]
        self.assertTrue(call_kwargs.get('disabled', False))
    
    def test_material_card(self):
        """Test Material Card component."""
        # Test basic card
        with material_card("Test Card"):
            self.st_mock.write.call_args = "Card content"
        
        self.markdown_mock.assert_called()
        
        # Reset mock
        self.markdown_mock.reset_mock()
        
        # Test card with custom styles
        with material_card("Test Card", elevation=3, padding="large"):
            self.st_mock.write.call_args = "Card content"
        
        self.markdown_mock.assert_called()
    
    def test_material_metric(self):
        """Test Material Metric component."""
        material_metric("Test Metric", "100", "+10%")
        self.metric_mock.assert_called_once()
        call_args = self.metric_mock.call_args[0]
        self.assertEqual(call_args[0], "Test Metric")
        self.assertEqual(call_args[1], "100")
        self.assertEqual(call_args[2], "+10%")
    
    def test_material_tabs(self):
        """Test Material Tabs component."""
        tabs = ["Tab 1", "Tab 2", "Tab 3"]
        selected = material_tabs(tabs)
        self.markdown_mock.assert_called()
        
        # Test with default selection
        selected = material_tabs(tabs, default_tab=1)
        self.assertEqual(selected, 1)
    
    def test_material_data_table(self):
        """Test Material Data Table component."""
        data = pd.DataFrame({
            "Name": ["John", "Jane", "Bob"],
            "Age": [30, 25, 40],
            "City": ["New York", "London", "Paris"]
        })
        
        material_data_table(data)
        self.markdown_mock.assert_called()
    
    def test_material_alert(self):
        """Test Material Alert component."""
        material_alert("Test alert", severity="info")
        self.markdown_mock.assert_called_once()
        
        # Reset mock
        self.markdown_mock.reset_mock()
        
        # Test with different severity
        material_alert("Test alert", severity="error")
        self.markdown_mock.assert_called_once()
    
    def test_material_badge(self):
        """Test Material Badge component."""
        material_badge("Test Badge", count=5)
        self.markdown_mock.assert_called_once()
        
        # Reset mock
        self.markdown_mock.reset_mock()
        
        # Test with max count
        material_badge("Test Badge", count=100, max_count=99)
        self.markdown_mock.assert_called_once()
        call_args = self.markdown_mock.call_args[0][0]
        self.assertIn("99+", call_args)

class TestResponsiveLayoutComponents(unittest.TestCase):
    """Test cases for Responsive Layout components."""
    
    def setUp(self):
        """Set up test environment."""
        # Mock Streamlit
        self.st_mock = MagicMock()
        self.markdown_mock = MagicMock()
        self.columns_mock = MagicMock()
        
        # Patch Streamlit functions
        self.st_patch = patch('ui.components.responsive_layout.st', self.st_mock)
        self.markdown_patch = patch('ui.components.responsive_layout.st.markdown', self.markdown_mock)
        self.columns_patch = patch('ui.components.responsive_layout.st.columns', self.columns_mock)
        
        # Start patches
        self.st_patch.start()
        self.markdown_patch.start()
        self.columns_patch.start()
    
    def tearDown(self):
        """Clean up after tests."""
        # Stop patches
        self.st_patch.stop()
        self.markdown_patch.stop()
        self.columns_patch.stop()
    
    def test_responsive_container(self):
        """Test Responsive Container component."""
        with responsive_container():
            self.st_mock.write.call_args = "Container content"
        
        self.markdown_mock.assert_called()
    
    def test_responsive_grid(self):
        """Test Responsive Grid component."""
        # Mock columns to return a list of column objects
        column_mock = MagicMock()
        self.columns_mock.return_value = [column_mock, column_mock, column_mock]
        
        # Test grid with items
        items = ["Item 1", "Item 2", "Item 3", "Item 4", "Item 5"]
        responsive_grid(items, columns=3)
        
        # Should create columns
        self.columns_mock.assert_called_once_with(3)
        
        # Should write items to columns
        self.assertEqual(column_mock.markdown.call_count, 5)
    
    def test_responsive_columns(self):
        """Test Responsive Columns component."""
        # Mock columns to return a list of column objects
        column_mock = MagicMock()
        self.columns_mock.return_value = [column_mock, column_mock]
        
        # Test responsive columns
        col1, col2 = responsive_columns(2)
        
        # Should create columns
        self.columns_mock.assert_called_once_with(2)
        
        # Should return column objects
        self.assertEqual(col1, column_mock)
        self.assertEqual(col2, column_mock)
    
    def test_responsive_card(self):
        """Test Responsive Card component."""
        with responsive_card("Test Card"):
            self.st_mock.write.call_args = "Card content"
        
        self.markdown_mock.assert_called()
    
    def test_responsive_table(self):
        """Test Responsive Table component."""
        data = pd.DataFrame({
            "Name": ["John", "Jane", "Bob"],
            "Age": [30, 25, 40],
            "City": ["New York", "London", "Paris"]
        })
        
        responsive_table(data)
        self.markdown_mock.assert_called()

class TestThemeProvider(unittest.TestCase):
    """Test cases for Theme Provider."""
    
    def setUp(self):
        """Set up test environment."""
        # Mock Streamlit
        self.st_mock = MagicMock()
        self.markdown_mock = MagicMock()
        
        # Patch Streamlit functions
        self.st_patch = patch('ui.components.theme_provider.st', self.st_mock)
        self.markdown_patch = patch('ui.components.theme_provider.st.markdown', self.markdown_mock)
        
        # Start patches
        self.st_patch.start()
        self.markdown_patch.start()
    
    def tearDown(self):
        """Clean up after tests."""
        # Stop patches
        self.st_patch.stop()
        self.markdown_patch.stop()
    
    def test_apply_design_system_to_page(self):
        """Test applying design system to page."""
        apply_design_system_to_page("Test Page")
        
        # Should set page config
        self.st_mock.set_page_config.assert_called_once()
        
        # Should apply CSS
        self.markdown_mock.assert_called()
    
    def test_get_theme_colors(self):
        """Test getting theme colors."""
        colors = get_theme_colors()
        
        # Should return a dictionary of colors
        self.assertIsInstance(colors, dict)
        self.assertIn('primary', colors)
        self.assertIn('secondary', colors)
        self.assertIn('background', colors)
        self.assertIn('text', colors)

class TestDesignSystem(unittest.TestCase):
    """Test cases for Design System."""
    
    def test_get_color_palette(self):
        """Test getting color palette."""
        palette = get_color_palette()
        
        # Should return a dictionary of colors
        self.assertIsInstance(palette, dict)
        self.assertIn('primary', palette)
        self.assertIn('secondary', palette)
        self.assertIn('error', palette)
        self.assertIn('warning', palette)
        self.assertIn('info', palette)
        self.assertIn('success', palette)
    
    def test_get_typography(self):
        """Test getting typography."""
        typography = get_typography()
        
        # Should return a dictionary of typography styles
        self.assertIsInstance(typography, dict)
        self.assertIn('h1', typography)
        self.assertIn('h2', typography)
        self.assertIn('body1', typography)
        self.assertIn('button', typography)
    
    def test_get_spacing(self):
        """Test getting spacing."""
        spacing = get_spacing()
        
        # Should return a dictionary of spacing values
        self.assertIsInstance(spacing, dict)
        self.assertIn('xs', spacing)
        self.assertIn('sm', spacing)
        self.assertIn('md', spacing)
        self.assertIn('lg', spacing)
        self.assertIn('xl', spacing)
    
    def test_get_shadows(self):
        """Test getting shadows."""
        shadows = get_shadows()
        
        # Should return a dictionary of shadow values
        self.assertIsInstance(shadows, dict)
        self.assertIn(0, shadows)
        self.assertIn(1, shadows)
        self.assertIn(2, shadows)
        self.assertIn(3, shadows)
    
    def test_get_border_radius(self):
        """Test getting border radius."""
        border_radius = get_border_radius()
        
        # Should return a dictionary of border radius values
        self.assertIsInstance(border_radius, dict)
        self.assertIn('none', border_radius)
        self.assertIn('sm', border_radius)
        self.assertIn('md', border_radius)
        self.assertIn('lg', border_radius)
        self.assertIn('pill', border_radius)

class TestDarkMode(unittest.TestCase):
    """Test cases for Dark Mode."""
    
    def setUp(self):
        """Set up test environment."""
        # Mock Streamlit
        self.st_mock = MagicMock()
        self.markdown_mock = MagicMock()
        self.session_state_mock = {}
        
        # Patch Streamlit functions
        self.st_patch = patch('ui.dark_mode.st', self.st_mock)
        self.markdown_patch = patch('ui.dark_mode.st.markdown', self.markdown_mock)
        self.session_state_patch = patch('ui.dark_mode.st.session_state', self.session_state_mock)
        
        # Start patches
        self.st_patch.start()
        self.markdown_patch.start()
        self.session_state_patch.start()
    
    def tearDown(self):
        """Clean up after tests."""
        # Stop patches
        self.st_patch.stop()
        self.markdown_patch.stop()
        self.session_state_patch.stop()
    
    def test_apply_theme(self):
        """Test applying theme."""
        # Test with no theme in session state
        theme = apply_theme()
        
        # Should default to light theme
        self.assertEqual(theme, 'light')
        
        # Test with theme in session state
        self.session_state_mock['theme'] = 'dark'
        theme = apply_theme()
        
        # Should use theme from session state
        self.assertEqual(theme, 'dark')
    
    def test_get_effective_theme(self):
        """Test getting effective theme."""
        # Test with no theme in session state
        theme = get_effective_theme()
        
        # Should default to light theme
        self.assertEqual(theme, 'light')
        
        # Test with theme in session state
        self.session_state_mock['theme'] = 'dark'
        theme = get_effective_theme()
        
        # Should use theme from session state
        self.assertEqual(theme, 'dark')
    
    def test_toggle_theme(self):
        """Test toggling theme."""
        # Test with no theme in session state
        toggle_theme()
        
        # Should set theme to dark
        self.assertEqual(self.session_state_mock['theme'], 'dark')
        
        # Test with light theme in session state
        self.session_state_mock['theme'] = 'light'
        toggle_theme()
        
        # Should set theme to dark
        self.assertEqual(self.session_state_mock['theme'], 'dark')
        
        # Test with dark theme in session state
        self.session_state_mock['theme'] = 'dark'
        toggle_theme()
        
        # Should set theme to light
        self.assertEqual(self.session_state_mock['theme'], 'light')

class TestMobileResponsive(unittest.TestCase):
    """Test cases for Mobile Responsive Design."""
    
    def setUp(self):
        """Set up test environment."""
        # Mock Streamlit
        self.st_mock = MagicMock()
        self.markdown_mock = MagicMock()
        self.text_input_mock = MagicMock()
        
        # Patch Streamlit functions
        self.st_patch = patch('ui.mobile_responsive.st', self.st_mock)
        self.markdown_patch = patch('ui.mobile_responsive.st.markdown', self.markdown_mock)
        self.text_input_patch = patch('ui.mobile_responsive.st.text_input', self.text_input_mock)
        
        # Start patches
        self.st_patch.start()
        self.markdown_patch.start()
        self.text_input_patch.start()
    
    def tearDown(self):
        """Clean up after tests."""
        # Stop patches
        self.st_patch.stop()
        self.markdown_patch.stop()
        self.text_input_patch.stop()
    
    def test_detect_device_type(self):
        """Test detecting device type."""
        # Mock text_input to return device type
        self.text_input_mock.return_value = 'desktop'
        
        # Test detection
        device_type = detect_device_type()
        
        # Should return device type
        self.assertEqual(device_type, 'desktop')
        
        # Should inject JavaScript
        self.markdown_mock.assert_called()
    
    def test_detect_touch_capability(self):
        """Test detecting touch capability."""
        # Mock text_input to return touch capability
        self.text_input_mock.return_value = 'true'
        
        # Test detection
        touch_capability = detect_touch_capability()
        
        # Should return touch capability
        self.assertTrue(touch_capability)
        
        # Should inject JavaScript
        self.markdown_mock.assert_called()
    
    def test_detect_screen_dimensions(self):
        """Test detecting screen dimensions."""
        # Mock text_input to return screen dimensions
        self.text_input_mock.side_effect = ['1920', '1080']
        
        # Test detection
        dimensions = detect_screen_dimensions()
        
        # Should return screen dimensions
        self.assertEqual(dimensions, (1920, 1080))
        
        # Should inject JavaScript
        self.markdown_mock.assert_called()
    
    def test_detect_orientation(self):
        """Test detecting orientation."""
        # Mock text_input to return orientation
        self.text_input_mock.return_value = 'landscape'
        
        # Test detection
        orientation = detect_orientation()
        
        # Should return orientation
        self.assertEqual(orientation, 'landscape')
        
        # Should inject JavaScript
        self.markdown_mock.assert_called()
    
    def test_apply_responsive_design(self):
        """Test applying responsive design."""
        # Mock device detection functions
        with patch('ui.mobile_responsive.detect_device_type', return_value='desktop'), \
             patch('ui.mobile_responsive.detect_touch_capability', return_value=False), \
             patch('ui.mobile_responsive.detect_screen_dimensions', return_value=(1920, 1080)), \
             patch('ui.mobile_responsive.detect_orientation', return_value='landscape'), \
             patch('ui.mobile_responsive.detect_browser', return_value={'name': 'Chrome', 'version': '100.0.0.0'}), \
             patch('ui.mobile_responsive.apply_theme', return_value='light'):
            
            # Test applying responsive design
            device_info = apply_responsive_design()
            
            # Should return device info
            self.assertEqual(device_info['device_type'], 'desktop')
            self.assertEqual(device_info['touch_capability'], False)
            self.assertEqual(device_info['screen_dimensions'], (1920, 1080))
            self.assertEqual(device_info['orientation'], 'landscape')
            self.assertEqual(device_info['browser']['name'], 'Chrome')
            self.assertEqual(device_info['theme'], 'light')

class TestBackendIntegration(unittest.TestCase):
    """Test cases for Backend Integration."""
    
    def setUp(self):
        """Set up test environment."""
        # Mock requests
        self.requests_mock = MagicMock()
        self.response_mock = MagicMock()
        self.response_mock.json.return_value = {'key': 'value'}
        self.response_mock.raise_for_status = MagicMock()
        self.requests_mock.get.return_value = self.response_mock
        self.requests_mock.post.return_value = self.response_mock
        self.requests_mock.put.return_value = self.response_mock
        self.requests_mock.delete.return_value = self.response_mock
        
        # Patch requests
        self.requests_patch = patch('ui.backend_integration.requests', self.requests_mock)
        
        # Start patches
        self.requests_patch.start()
    
    def tearDown(self):
        """Clean up after tests."""
        # Stop patches
        self.requests_patch.stop()
    
    def test_api_client(self):
        """Test API Client."""
        # Create API client
        api_client = APIClient(base_url='http://localhost:8000/api')
        
        # Test GET request
        response = api_client.get('endpoint')
        
        # Should make GET request
        self.requests_mock.Session.return_value.get.assert_called_once()
        
        # Should return response JSON
        self.assertEqual(response, {'key': 'value'})
        
        # Test POST request
        response = api_client.post('endpoint', json={'data': 'value'})
        
        # Should make POST request
        self.requests_mock.Session.return_value.post.assert_called_once()
        
        # Should return response JSON
        self.assertEqual(response, {'key': 'value'})
    
    def test_data_fetcher(self):
        """Test Data Fetcher."""
        # Create API client mock
        api_client_mock = MagicMock()
        api_client_mock.get.return_value = {'key': 'value'}
        
        # Create data fetcher
        data_fetcher = DataFetcher(api_client=api_client_mock)
        
        # Test get_data
        response = data_fetcher.get_data('endpoint')
        
        # Should make API request
        api_client_mock.get.assert_called_once_with('endpoint', params=None)
        
        # Should return response
        self.assertEqual(response, {'key': 'value'})
        
        # Test get_data with caching
        api_client_mock.reset_mock()
        response = data_fetcher.get_data('endpoint')
        
        # Should not make API request (cached)
        api_client_mock.get.assert_not_called()
        
        # Should return cached response
        self.assertEqual(response, {'key': 'value'})
        
        # Test get_data with force refresh
        api_client_mock.reset_mock()
        response = data_fetcher.get_data('endpoint', force_refresh=True)
        
        # Should make API request
        api_client_mock.get.assert_called_once_with('endpoint', params=None)
        
        # Should return response
        self.assertEqual(response, {'key': 'value'})
    
    def test_auth_manager(self):
        """Test Auth Manager."""
        # Create API client mock
        api_client_mock = MagicMock()
        api_client_mock.post.return_value = {
            'token': 'test_token',
            'user': {
                'id': 1,
                'username': 'test_user',
                'email': 'test@example.com',
                'roles': ['admin'],
                'permissions': ['view_dashboard', 'edit_settings']
            }
        }
        
        # Create auth manager
        auth_manager = AuthManager(api_client=api_client_mock)
        
        # Test login
        result = auth_manager.login('test_user', 'password')
        
        # Should make API request
        api_client_mock.post.assert_called_once_with('auth/login', json={
            'username': 'test_user',
            'password': 'password'
        })
        
        # Should return True
        self.assertTrue(result)
        
        # Should set auth token
        api_client_mock.set_auth_token.assert_called_once_with('test_token')
        
        # Test is_authenticated
        api_client_mock.auth_token = 'test_token'
        result = auth_manager.is_authenticated()
        
        # Should return True
        self.assertTrue(result)
        
        # Test has_permission
        result = auth_manager.has_permission('view_dashboard')
        
        # Should return True
        self.assertTrue(result)
        
        # Test has_permission (not found)
        result = auth_manager.has_permission('delete_data')
        
        # Should return False
        self.assertFalse(result)
    
    def test_backend_integration(self):
        """Test Backend Integration."""
        # Create backend integration
        with patch('ui.backend_integration.APIClient'), \
             patch('ui.backend_integration.DataFetcher'), \
             patch('ui.backend_integration.RealtimeUpdater'), \
             patch('ui.backend_integration.AuthManager'), \
             patch('ui.backend_integration.FormManager'), \
             patch('ui.backend_integration.DashboardBackend'), \
             patch('ui.backend_integration.CameraBackend'), \
             patch('ui.backend_integration.AnalyticsBackend'), \
             patch('ui.backend_integration.SettingsBackend'):
            
            # Create backend integration
            backend = BackendIntegration(base_url='http://localhost:8000/api')
            
            # Should create component backends
            self.assertIsNotNone(backend.dashboard)
            self.assertIsNotNone(backend.camera)
            self.assertIsNotNone(backend.analytics)
            self.assertIsNotNone(backend.settings)

if __name__ == '__main__':
    unittest.main()
