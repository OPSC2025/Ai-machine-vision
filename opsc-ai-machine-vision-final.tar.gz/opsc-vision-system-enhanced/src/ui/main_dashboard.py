"""
Material UI integration for the main dashboard of the OPSC Sandwich Quality Inspection System.

This module enhances the main dashboard with Material Design components,
creating a more polished and interactive user interface.
"""

import streamlit as st
import pandas as pd
import numpy as np
import time
from datetime import datetime, timedelta
import sys
import os

# Add the parent directory to the path so we can import our components
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ui.components.material_ui import (
    load_material_icons, material_button, material_card, material_metric,
    material_tabs, material_data_table, material_progress, material_alert,
    material_badge, material_icon_button, material_divider, material_chip
)
from ui.components.theme_provider import apply_design_system_to_page

def render_dashboard():
    """Render the main dashboard page with Material UI components."""
    
    # Apply design system to the page
    apply_design_system_to_page("Quality Control Dashboard")
    
    # Load Material Icons
    load_material_icons()
    
    # Dashboard header with action buttons
    st.markdown(
        """
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <div>
                <h1 style="margin-bottom: 0;">Quality Control Dashboard</h1>
                <p style="margin-top: 0; color: var(--color-neutral-main);">Crustless Creations - Real-time Monitoring</p>
            </div>
            <div style="display: flex; gap: 10px;">
        """,
        unsafe_allow_html=True
    )
    
    col1, col2 = st.columns([10, 2])
    
    with col2:
        refresh_clicked = material_button(
            "Refresh Data", 
            icon="refresh", 
            type="outlined",
            key="refresh_dashboard"
        )
        
        if refresh_clicked:
            st.rerun()
    
    st.markdown("</div></div>", unsafe_allow_html=True)
    
    # Date range indicator
    st.markdown(
        f"""
        <div style="margin-bottom: 20px; color: var(--color-neutral-main);">
            <span>Period: {(datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")} to {datetime.now().strftime("%Y-%m-%d")}</span>
        </div>
        """,
        unsafe_allow_html=True
    )
    
    # Top metrics row
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        material_metric(
            label="Sandwiches Inspected",
            value="1,234",
            delta="+56",
            key="sandwiches_inspected"
        )
    
    with col2:
        material_metric(
            label="Defect Rate",
            value="0.8%",
            delta="-0.2%",
            delta_color="inverse",
            key="defect_rate"
        )
    
    with col3:
        material_metric(
            label="Production Speed",
            value="250 units/min",
            key="production_speed"
        )
    
    with col4:
        material_metric(
            label="Uptime",
            value="99.8%",
            key="uptime"
        )
    
    # System status and defect trend
    col1, col2 = st.columns([1, 2])
    
    with col1:
        def system_status_content():
            # System status indicators
            st.markdown("### System Components")
            
            # Host System
            col1, col2 = st.columns([3, 1])
            with col1:
                st.markdown(
                    """
                    <div style="display: flex; align-items: center;">
                        <span class="material-icons" style="color: var(--color-success-main); margin-right: 8px;">check_circle</span>
                        <span><strong>Host System</strong></span>
                    </div>
                    """,
                    unsafe_allow_html=True
                )
            with col2:
                st.markdown("<span>Online</span>", unsafe_allow_html=True)
            
            material_progress(0.45, label="CPU Usage", show_percentage=True)
            material_progress(0.60, label="Memory Usage", show_percentage=True)
            
            material_divider()
            
            # ADLINK Jetson
            col1, col2 = st.columns([3, 1])
            with col1:
                st.markdown(
                    """
                    <div style="display: flex; align-items: center;">
                        <span class="material-icons" style="color: var(--color-warning-main); margin-right: 8px;">warning</span>
                        <span><strong>ADLINK Jetson</strong></span>
                    </div>
                    """,
                    unsafe_allow_html=True
                )
            with col2:
                st.markdown("<span>Warning</span>", unsafe_allow_html=True)
            
            material_progress(0.72, label="GPU Usage", color="warning", show_percentage=True)
            material_progress(0.85, label="Temperature", color="warning", show_percentage=True)
            
            material_divider()
            
            # Database
            col1, col2 = st.columns([3, 1])
            with col1:
                st.markdown(
                    """
                    <div style="display: flex; align-items: center;">
                        <span class="material-icons" style="color: var(--color-success-main); margin-right: 8px;">check_circle</span>
                        <span><strong>Database</strong></span>
                    </div>
                    """,
                    unsafe_allow_html=True
                )
            with col2:
                st.markdown("<span>Online</span>", unsafe_allow_html=True)
            
            material_progress(0.32, label="Disk Usage", show_percentage=True)
            
            material_divider()
            
            # Network
            col1, col2 = st.columns([3, 1])
            with col1:
                st.markdown(
                    """
                    <div style="display: flex; align-items: center;">
                        <span class="material-icons" style="color: var(--color-success-main); margin-right: 8px;">check_circle</span>
                        <span><strong>Network</strong></span>
                    </div>
                    """,
                    unsafe_allow_html=True
                )
            with col2:
                st.markdown("<span>Online</span>", unsafe_allow_html=True)
            
            # Network quality indicator
            st.markdown(
                """
                <div style="display: flex; align-items: center; margin-top: 8px;">
                    <span style="margin-right: 8px;">Signal Quality:</span>
                    <div style="display: flex; gap: 2px;">
                        <div style="width: 4px; height: 8px; background-color: var(--color-success-main); border-radius: 1px;"></div>
                        <div style="width: 4px; height: 12px; background-color: var(--color-success-main); border-radius: 1px;"></div>
                        <div style="width: 4px; height: 16px; background-color: var(--color-success-main); border-radius: 1px;"></div>
                        <div style="width: 4px; height: 20px; background-color: var(--color-success-main); border-radius: 1px;"></div>
                        <div style="width: 4px; height: 24px; background-color: var(--color-neutral-border); border-radius: 1px;"></div>
                    </div>
                    <span style="margin-left: 8px;">85%</span>
                </div>
                """,
                unsafe_allow_html=True
            )
            
            material_divider()
            
            # Alert summary
            st.markdown("### Alerts")
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.markdown(
                    """
                    <div style="text-align: center;">
                        <div style="font-size: 24px; font-weight: bold; color: var(--color-error-main);">0</div>
                        <div style="font-size: 14px; color: var(--color-neutral-main);">Critical</div>
                    </div>
                    """,
                    unsafe_allow_html=True
                )
            
            with col2:
                st.markdown(
                    """
                    <div style="text-align: center;">
                        <div style="font-size: 24px; font-weight: bold; color: var(--color-warning-main);">2</div>
                        <div style="font-size: 14px; color: var(--color-neutral-main);">Warnings</div>
                    </div>
                    """,
                    unsafe_allow_html=True
                )
            
            with col3:
                st.markdown(
                    """
                    <div style="text-align: center;">
                        <div style="font-size: 24px; font-weight: bold; color: var(--color-info-main);">5</div>
                        <div style="font-size: 14px; color: var(--color-neutral-main);">Info</div>
                    </div>
                    """,
                    unsafe_allow_html=True
                )
        
        material_card(
            title="System Status",
            content_func=system_status_content,
            key="system_status_card"
        )
    
    with col2:
        def defect_trend_chart():
            # Generate sample data for demonstration
            dates = pd.date_range(start=datetime.now() - timedelta(days=30), end=datetime.now(), freq='D')
            defect_rates = np.random.normal(1.0, 0.3, len(dates))
            defect_rates = np.maximum(defect_rates, 0)  # Ensure no negative rates
            
            df = pd.DataFrame({
                'Date': dates,
                'Defect Rate (%)': defect_rates
            })
            
            st.line_chart(df.set_index('Date'))
            
            # Add interactive elements
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown("**Average Rate:** 0.92%")
                st.markdown("**Trend:** Decreasing")
            
            with col2:
                st.markdown("**Min Rate:** 0.41%")
                st.markdown("**Max Rate:** 1.58%")
            
            # Add time range selector
            time_range = st.select_slider(
                "Time Range",
                options=["7 Days", "14 Days", "30 Days", "90 Days"],
                value="30 Days"
            )
        
        material_card(
            title="Defect Rate Trend",
            subtitle="30-Day Rolling Average",
            content_func=defect_trend_chart,
            footer="Source: Quality Control Database",
            key="defect_trend_card"
        )
    
    # Camera status and recent defects
    col1, col2 = st.columns(2)
    
    with col1:
        def camera_status_content():
            # Sample camera data
            camera_data = {
                "Top Camera": {
                    "status": "success",
                    "fps": "20/20",
                    "connection": 0.95
                },
                "Side Camera 1": {
                    "status": "warning",
                    "fps": "18/20",
                    "connection": 0.75
                },
                "Side Camera 2": {
                    "status": "success",
                    "fps": "20/20",
                    "connection": 0.90
                },
                "Bottom Camera": {
                    "status": "success",
                    "fps": "20/20",
                    "connection": 0.85
                }
            }
            
            for camera_name, data in camera_data.items():
                status_color = "var(--color-success-main)" if data["status"] == "success" else "var(--color-warning-main)"
                
                st.markdown(
                    f"""
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
                        <div style="display: flex; align-items: center;">
                            <span class="material-icons" style="color: {status_color}; margin-right: 8px;">
                                {"check_circle" if data["status"] == "success" else "warning"}
                            </span>
                            <span><strong>{camera_name}</strong></span>
                        </div>
                        <div>
                            <span style="margin-right: 16px;">FPS: {data["fps"]}</span>
                            <span>Signal: {int(data["connection"] * 100)}%</span>
                        </div>
                    </div>
                    """,
                    unsafe_allow_html=True
                )
                
                # Add connection quality bar
                st.markdown(
                    f"""
                    <div style="height: 4px; background-color: var(--color-neutral-border); border-radius: 2px; margin-bottom: 16px;">
                        <div style="height: 100%; width: {data["connection"] * 100}%; background-color: {status_color}; border-radius: 2px;"></div>
                    </div>
                    """,
                    unsafe_allow_html=True
                )
            
            col1, col2 = st.columns(2)
            
            with col1:
                calibrate_clicked = material_button(
                    "Calibrate Cameras",
                    icon="tune",
                    type="outlined",
                    key="calibrate_cameras"
                )
            
            with col2:
                view_clicked = material_button(
                    "View All Cameras",
                    icon="visibility",
                    type="outlined",
                    key="view_cameras"
                )
            
            if calibrate_clicked:
                st.session_state.calibration_clicked = True
            
            if view_clicked:
                st.session_state.view_cameras_clicked = True
        
        material_card(
            title="Camera Status",
            content_func=camera_status_content,
            key="camera_status_card"
        )
    
    with col2:
        def recent_defects_content():
            # Sample defect data
            defects = [
                {"time": "10:45:23", "type": "Missing Filling", "confidence": "98%", "camera": "Side 1"},
                {"time": "10:42:17", "type": "Uneven Cut", "confidence": "87%", "camera": "Top"},
                {"time": "10:38:52", "type": "Crust Present", "confidence": "92%", "camera": "Bottom"},
                {"time": "10:35:11", "type": "Missing Filling", "confidence": "95%", "camera": "Side 2"},
                {"time": "10:30:45", "type": "Foreign Object", "confidence": "99%", "camera": "Top"}
            ]
            
            # Create a table header
            st.markdown(
                """
                <div style="display: grid; grid-template-columns: 1fr 1.5fr 1fr 1fr; gap: 8px; margin-bottom: 8px; font-weight: bold;">
                    <div>Time</div>
                    <div>Type</div>
                    <div>Confidence</div>
                    <div>Camera</div>
                </div>
                <div style="height: 1px; background-color: var(--color-neutral-border); margin-bottom: 8px;"></div>
                """,
                unsafe_allow_html=True
            )
            
            # Create table rows
            for defect in defects:
                # Determine color based on defect type
                color = "var(--color-error-main)"
                if defect["type"] == "Missing Filling":
                    color = "var(--color-warning-main)"
                elif defect["type"] == "Uneven Cut":
                    color = "var(--color-info-main)"
                elif defect["type"] == "Crust Present":
                    color = "var(--color-secondary-main)"
                elif defect["type"] == "Foreign Object":
                    color = "var(--color-error-main)"
                
                st.markdown(
                    f"""
                    <div style="display: grid; grid-template-columns: 1fr 1.5fr 1fr 1fr; gap: 8px; margin-bottom: 12px; align-items: center;">
                        <div>{defect["time"]}</div>
                        <div>
                            <span style="display: inline-block; width: 10px; height: 10px; border-radius: 50%; background-color: {color}; margin-right: 6px;"></span>
                            {defect["type"]}
                        </div>
                        <div>{defect["confidence"]}</div>
                        <div>{defect["camera"]}</div>
                    </div>
                    """,
                    unsafe_allow_html=True
                )
            
            col1, col2 = st.columns(2)
            
            with col1:
                view_all_clicked = material_button(
                    "View All Defects",
                    icon="list",
                    type="outlined",
                    key="view_all_defects"
                )
            
            with col2:
                export_clicked = material_button(
                    "Export Data",
                    icon="download",
                    type="outlined",
                    key="export_defects"
                )
            
            if view_all_clicked:
                st.session_state.view_all_defects_clicked = True
            
            if export_clicked:
                st.session_state.export_defects_clicked = True
        
        material_card(
            title="Recent Defects",
            content_func=recent_defects_content,
            key="recent_defects_card"
        )
    
    # Bottom row - defect distribution and quick actions
    col1, col2 = st.columns(2)
    
    with col1:
        def defect_distribution_chart():
            # Sample defect distribution data
            defect_types = {
                'Missing Filling': 45,
                'Uneven Cut': 30,
                'Crust Present': 15,
                'Foreign Object': 7,
                'Other': 3
            }
            
            defect_df = pd.DataFrame({
                'Defect Type': list(defect_types.keys()),
                'Count': list(defect_types.values())
            })
            
            st.bar_chart(defect_df.set_index('Defect Type'))
            
            # Add interactive filters
            col1, col2 = st.columns(2)
            
            with col1:
                st.selectbox(
                    "Group By",
                    ["Defect Type", "Camera", "Shift", "Product"],
                    key="group_by_defect"
                )
            
            with col2:
                st.selectbox(
                    "Time Period",
                    ["Today", "Yesterday", "This Week", "This Month"],
                    key="time_period_defect"
                )
        
        material_card(
            title="Defect Distribution",
            content_func=defect_distribution_chart,
            key="defect_distribution_card"
        )
    
    with col2:
        def quick_actions_content():
            # Create a grid of action cards
            col1, col2 = st.columns(2)
            
            with col1:
                # Camera Calibration
                st.markdown(
                    """
                    <div style="padding: 16px; border: 1px solid var(--color-neutral-border); border-radius: 8px; margin-bottom: 16px;">
                        <div style="display: flex; align-items: center; margin-bottom: 8px;">
                            <span class="material-icons" style="color: var(--color-primary-main); margin-right: 8px;">camera</span>
                            <span style="font-weight: 500;">Camera Calibration</span>
                        </div>
                        <p style="font-size: 14px; margin-bottom: 16px;">Run camera calibration procedure</p>
                    """,
                    unsafe_allow_html=True
                )
                
                calibration_clicked = material_button(
                    "Calibrate",
                    type="contained",
                    size="small",
                    full_width=True,
                    key="calibration_action"
                )
                
                st.markdown("</div>", unsafe_allow_html=True)
                
                # System Maintenance
                st.markdown(
                    """
                    <div style="padding: 16px; border: 1px solid var(--color-neutral-border); border-radius: 8px;">
                        <div style="display: flex; align-items: center; margin-bottom: 8px;">
                            <span class="material-icons" style="color: var(--color-primary-main); margin-right: 8px;">build</span>
                            <span style="font-weight: 500;">System Maintenance</span>
                        </div>
                        <p style="font-size: 14px; margin-bottom: 16px;">Run system diagnostics and maintenance</p>
                    """,
                    unsafe_allow_html=True
                )
                
                maintenance_clicked = material_button(
                    "Run Diagnostics",
                    type="contained",
                    size="small",
                    full_width=True,
                    key="maintenance_action"
                )
                
                st.markdown("</div>", unsafe_allow_html=True)
            
            with col2:
                # Generate Report
                st.markdown(
                    """
                    <div style="padding: 16px; border: 1px solid var(--color-neutral-border); border-radius: 8px; margin-bottom: 16px;">
                        <div style="display: flex; align-items: center; margin-bottom: 8px;">
                            <span class="material-icons" style="color: var(--color-primary-main); margin-right: 8px;">description</span>
                            <span style="font-weight: 500;">Generate Report</span>
                        </div>
                        <p style="font-size: 14px; margin-bottom: 16px;">Create a daily production report</p>
                    """,
                    unsafe_allow_html=True
                )
                
                report_clicked = material_button(
                    "Generate",
                    type="contained",
                    size="small",
                    full_width=True,
                    key="report_action"
                )
                
                st.markdown("</div>", unsafe_allow_html=True)
                
                # System Alerts
                st.markdown(
                    """
                    <div style="padding: 16px; border: 1px solid var(--color-neutral-border); border-radius: 8px;">
                        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px;">
                            <div style="display: flex; align-items: center;">
                                <span class="material-icons" style="color: var(--color-primary-main); margin-right: 8px;">notifications</span>
                                <span style="font-weight: 500;">System Alerts</span>
                            </div>
                            <span style="background-color: var(--color-warning-main); color: white; padding: 2px 8px; border-radius: 10px; font-size: 12px;">2</span>
                        </div>
                    """,
                    unsafe_allow_html=True
                )
                
                material_alert(
                    "Low disk space warning (82% used)",
                    severity="warning",
                    icon="storage",
                    key="disk_space_alert"
                )
                
                material_alert(
                    "ADLINK temperature high (85°C)",
                    severity="warning",
                    icon="thermostat",
                    key="temperature_alert"
                )
                
                view_alerts_clicked = material_button(
                    "View All Alerts",
                    type="outlined",
                    size="small",
                    full_width=True,
                    key="view_alerts_action"
                )
                
                st.markdown("</div>", unsafe_allow_html=True)
            
            # Handle button clicks
            if calibration_clicked:
                st.session_state.calibration_clicked = True
            
            if report_clicked:
                st.session_state.report_clicked = True
            
            if maintenance_clicked:
                st.session_state.maintenance_clicked = True
            
            if view_alerts_clicked:
                st.session_state.view_alerts_clicked = True
        
        material_card(
            title="Quick Actions",
            content_func=quick_actions_content,
            key="quick_actions_card"
        )
    
    # Handle action button clicks
    if "calibration_clicked" in st.session_state and st.session_state.calibration_clicked:
        material_alert("Camera calibration started! This will take approximately 2 minutes.", severity="info")
        st.session_state.calibration_clicked = False
    
    if "report_clicked" in st.session_state and st.session_state.report_clicked:
        material_alert("Report generation started! The report will be available in the Reports section when complete.", severity="info")
        st.session_state.report_clicked = False
    
    if "maintenance_clicked" in st.session_state and st.session_state.maintenance_clicked:
        material_alert("System diagnostics started! This will take approximately 5 minutes.", severity="info")
        st.session_state.maintenance_clicked = False

if __name__ == "__main__":
    st.set_page_config(
        page_title="Crustless Creations QC Dashboard",
        page_icon="🥪",
        layout="wide",
        initial_sidebar_state="expanded"
    )
    render_dashboard()
