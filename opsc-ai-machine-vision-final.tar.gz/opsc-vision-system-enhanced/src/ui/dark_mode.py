"""
Dark mode support for the OPSC Sandwich Quality Inspection System.

This module provides comprehensive dark mode implementation including:
- Dark theme color palette
- Theme switching functionality
- Theme persistence
- Automatic theme detection
- Component-specific dark mode styling
"""

import streamlit as st
import json
import sys
import os
from datetime import datetime

# Add the parent directory to the path so we can import our components
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ui.components.theme_provider import apply_design_system_to_page

# Dark mode color palette
DARK_THEME = {
    # Primary colors
    "color-primary-lightest": "#4f83cc",
    "color-primary-lighter": "#3a6db3",
    "color-primary-light": "#2e5c9e",
    "color-primary-main": "#1a4b8c",
    "color-primary-dark": "#133a70",
    "color-primary-darker": "#0d2a54",
    "color-primary-darkest": "#071a38",
    
    # Secondary colors
    "color-secondary-lightest": "#f0b86c",
    "color-secondary-lighter": "#eda654",
    "color-secondary-light": "#ea953c",
    "color-secondary-main": "#e78324",
    "color-secondary-dark": "#d0721a",
    "color-secondary-darker": "#b86215",
    "color-secondary-darkest": "#a05211",
    
    # Success colors
    "color-success-lightest": "#7dd87d",
    "color-success-lighter": "#5ecd5e",
    "color-success-light": "#40c340",
    "color-success-main": "#2eb82e",
    "color-success-dark": "#259325",
    "color-success-darker": "#1c6e1c",
    "color-success-darkest": "#144a14",
    
    # Warning colors
    "color-warning-lightest": "#ffd580",
    "color-warning-lighter": "#ffc966",
    "color-warning-light": "#ffbd4d",
    "color-warning-main": "#ffb333",
    "color-warning-dark": "#e69b1a",
    "color-warning-darker": "#cc8800",
    "color-warning-darkest": "#b37400",
    
    # Error colors
    "color-error-lightest": "#ff8080",
    "color-error-lighter": "#ff6666",
    "color-error-light": "#ff4d4d",
    "color-error-main": "#ff3333",
    "color-error-dark": "#e61919",
    "color-error-darker": "#cc0000",
    "color-error-darkest": "#b30000",
    
    # Info colors
    "color-info-lightest": "#80d4ff",
    "color-info-lighter": "#66c9ff",
    "color-info-light": "#4dbfff",
    "color-info-main": "#33b5ff",
    "color-info-dark": "#1a9be6",
    "color-info-darker": "#0080cc",
    "color-info-darkest": "#0066b3",
    
    # Neutral colors (dark mode specific)
    "color-neutral-lightest": "#ffffff",
    "color-neutral-lighter": "#e0e0e0",
    "color-neutral-light": "#b0b0b0",
    "color-neutral-main": "#909090",
    "color-neutral-dark": "#606060",
    "color-neutral-darker": "#303030",
    "color-neutral-darkest": "#121212",
    
    # Background colors (dark mode specific)
    "color-background-primary": "#121212",
    "color-background-secondary": "#1e1e1e",
    "color-background-tertiary": "#2d2d2d",
    "color-background-card": "#252525",
    "color-background-elevated": "#353535",
    
    # Border colors (dark mode specific)
    "color-border-light": "#404040",
    "color-border-main": "#505050",
    "color-border-dark": "#606060",
    
    # Text colors (dark mode specific)
    "color-text-primary": "#ffffff",
    "color-text-secondary": "#b0b0b0",
    "color-text-disabled": "#707070",
    "color-text-hint": "#909090",
    
    # Shadow colors (dark mode specific)
    "color-shadow-light": "rgba(0, 0, 0, 0.2)",
    "color-shadow-main": "rgba(0, 0, 0, 0.4)",
    "color-shadow-dark": "rgba(0, 0, 0, 0.6)",
}

# Light mode color palette (for reference and switching)
LIGHT_THEME = {
    # Primary colors
    "color-primary-lightest": "#e6f0ff",
    "color-primary-lighter": "#b3d1ff",
    "color-primary-light": "#80b3ff",
    "color-primary-main": "#4d94ff",
    "color-primary-dark": "#1a75ff",
    "color-primary-darker": "#0057cc",
    "color-primary-darkest": "#003d8f",
    
    # Secondary colors
    "color-secondary-lightest": "#fff5e6",
    "color-secondary-lighter": "#ffe0b3",
    "color-secondary-light": "#ffcc80",
    "color-secondary-main": "#ffb84d",
    "color-secondary-dark": "#ffa31a",
    "color-secondary-darker": "#e68a00",
    "color-secondary-darkest": "#b36b00",
    
    # Success colors
    "color-success-lightest": "#e6ffe6",
    "color-success-lighter": "#b3ffb3",
    "color-success-light": "#80ff80",
    "color-success-main": "#4dff4d",
    "color-success-dark": "#1aff1a",
    "color-success-darker": "#00e600",
    "color-success-darkest": "#00b300",
    
    # Warning colors
    "color-warning-lightest": "#fff8e6",
    "color-warning-lighter": "#ffebb3",
    "color-warning-light": "#ffdf80",
    "color-warning-main": "#ffd24d",
    "color-warning-dark": "#ffc61a",
    "color-warning-darker": "#e6ac00",
    "color-warning-darkest": "#b38600",
    
    # Error colors
    "color-error-lightest": "#ffe6e6",
    "color-error-lighter": "#ffb3b3",
    "color-error-light": "#ff8080",
    "color-error-main": "#ff4d4d",
    "color-error-dark": "#ff1a1a",
    "color-error-darker": "#e60000",
    "color-error-darkest": "#b30000",
    
    # Info colors
    "color-info-lightest": "#e6f7ff",
    "color-info-lighter": "#b3e7ff",
    "color-info-light": "#80d8ff",
    "color-info-main": "#4dc9ff",
    "color-info-dark": "#1abaff",
    "color-info-darker": "#00a3e6",
    "color-info-darkest": "#007fb3",
    
    # Neutral colors
    "color-neutral-lightest": "#ffffff",
    "color-neutral-lighter": "#f5f5f5",
    "color-neutral-light": "#e0e0e0",
    "color-neutral-main": "#9e9e9e",
    "color-neutral-dark": "#616161",
    "color-neutral-darker": "#424242",
    "color-neutral-darkest": "#212121",
    
    # Background colors
    "color-background-primary": "#ffffff",
    "color-background-secondary": "#f5f5f5",
    "color-background-tertiary": "#eeeeee",
    "color-background-card": "#ffffff",
    "color-background-elevated": "#ffffff",
    
    # Border colors
    "color-border-light": "#e0e0e0",
    "color-border-main": "#bdbdbd",
    "color-border-dark": "#9e9e9e",
    
    # Text colors
    "color-text-primary": "#212121",
    "color-text-secondary": "#757575",
    "color-text-disabled": "#9e9e9e",
    "color-text-hint": "#bdbdbd",
    
    # Shadow colors
    "color-shadow-light": "rgba(0, 0, 0, 0.1)",
    "color-shadow-main": "rgba(0, 0, 0, 0.2)",
    "color-shadow-dark": "rgba(0, 0, 0, 0.3)",
}

def get_system_theme_preference():
    """
    Detect system theme preference using JavaScript.
    Returns 'dark' or 'light' based on system preference.
    """
    # Inject JavaScript to detect system theme preference
    detect_theme_js = """
    <script>
    // Function to detect system theme preference
    function detectSystemTheme() {
        if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
            return 'dark';
        } else {
            return 'light';
        }
    }
    
    // Store the detected theme in localStorage
    localStorage.setItem('system_theme_preference', detectSystemTheme());
    
    // Listen for changes in system theme preference
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', function(e) {
        localStorage.setItem('system_theme_preference', e.matches ? 'dark' : 'light');
        // Reload the page to apply the new theme
        if (localStorage.getItem('theme_mode') === 'auto') {
            window.location.reload();
        }
    });
    </script>
    """
    
    # Inject the JavaScript
    st.markdown(detect_theme_js, unsafe_allow_html=True)
    
    # Read the detected theme from localStorage using JavaScript
    read_theme_js = """
    <script>
    // Function to send the detected theme to Streamlit
    function sendThemeToStreamlit() {
        const systemTheme = localStorage.getItem('system_theme_preference') || 'light';
        const themeModeInput = window.parent.document.querySelector('input[id="system_theme_preference"]');
        if (themeModeInput) {
            themeModeInput.value = systemTheme;
            themeModeInput.dispatchEvent(new Event('input'));
        }
    }
    
    // Call the function when the page loads
    window.addEventListener('load', sendThemeToStreamlit);
    </script>
    """
    
    # Create a hidden input to receive the theme preference
    system_theme = st.text_input("System Theme Preference", value="light", key="system_theme_preference", label_visibility="collapsed")
    
    # Inject the JavaScript to read the theme
    st.markdown(read_theme_js, unsafe_allow_html=True)
    
    return system_theme

def get_current_theme_mode():
    """
    Get the current theme mode from user preferences.
    Returns 'light', 'dark', or 'auto'.
    """
    # Check if user preferences exist in session state
    if 'user_preferences' in st.session_state and 'theme' in st.session_state.user_preferences:
        return st.session_state.user_preferences['theme']
    
    # Default to 'light' if no preference is set
    return 'light'

def get_effective_theme():
    """
    Get the effective theme based on user preference and system setting.
    Returns 'light' or 'dark'.
    """
    theme_mode = get_current_theme_mode()
    
    if theme_mode == 'auto':
        # Use system preference
        system_theme = get_system_theme_preference()
        return system_theme
    else:
        # Use user preference
        return theme_mode

def apply_theme(theme_mode=None):
    """
    Apply the specified theme to the application.
    If theme_mode is None, use the current theme mode.
    """
    if theme_mode is None:
        theme_mode = get_current_theme_mode()
    
    # Update user preferences
    if 'user_preferences' in st.session_state:
        st.session_state.user_preferences['theme'] = theme_mode
    
    # Determine the effective theme
    effective_theme = get_effective_theme()
    
    # Apply the theme using JavaScript
    theme_colors = DARK_THEME if effective_theme == 'dark' else LIGHT_THEME
    
    # Create CSS variables for the theme
    css_variables = ":root {\n"
    for key, value in theme_colors.items():
        css_variables += f"  --{key}: {value};\n"
    css_variables += "}\n"
    
    # Additional dark mode specific styles
    if effective_theme == 'dark':
        css_variables += """
        /* Dark mode specific styles */
        .stApp {
            background-color: var(--color-background-primary);
            color: var(--color-text-primary);
        }
        
        .stTextInput > div > div > input {
            background-color: var(--color-background-tertiary);
            color: var(--color-text-primary);
            border-color: var(--color-border-main);
        }
        
        .stTextInput > div > div > input:focus {
            border-color: var(--color-primary-main);
        }
        
        .stSelectbox > div > div > div {
            background-color: var(--color-background-tertiary);
            color: var(--color-text-primary);
            border-color: var(--color-border-main);
        }
        
        .stSlider > div > div > div > div {
            background-color: var(--color-primary-main);
        }
        
        .stSlider > div > div > div > div > div {
            background-color: var(--color-primary-lighter);
        }
        
        .stCheckbox > div > div > label > span {
            color: var(--color-text-primary);
        }
        
        .stRadio > div > div > label > span {
            color: var(--color-text-primary);
        }
        
        .stTabs > div > div > div > div {
            background-color: var(--color-background-secondary);
            color: var(--color-text-primary);
        }
        
        .stTabs > div > div > div > div[aria-selected="true"] {
            background-color: var(--color-primary-main);
            color: var(--color-text-primary);
        }
        
        .stMarkdown a {
            color: var(--color-primary-lighter);
        }
        
        .stMarkdown a:hover {
            color: var(--color-primary-lightest);
        }
        
        .stMarkdown code {
            background-color: var(--color-background-tertiary);
            color: var(--color-text-primary);
        }
        
        .stMarkdown pre {
            background-color: var(--color-background-tertiary);
            color: var(--color-text-primary);
        }
        
        .stMarkdown table {
            border-color: var(--color-border-main);
        }
        
        .stMarkdown th {
            background-color: var(--color-background-tertiary);
            color: var(--color-text-primary);
            border-color: var(--color-border-main);
        }
        
        .stMarkdown td {
            border-color: var(--color-border-main);
        }
        
        .stMarkdown tr:nth-child(even) {
            background-color: var(--color-background-secondary);
        }
        
        .stDataFrame {
            border-color: var(--color-border-main);
        }
        
        .stDataFrame th {
            background-color: var(--color-background-tertiary);
            color: var(--color-text-primary);
            border-color: var(--color-border-main);
        }
        
        .stDataFrame td {
            border-color: var(--color-border-main);
        }
        
        .stDataFrame tr:nth-child(even) {
            background-color: var(--color-background-secondary);
        }
        
        .stButton > button {
            background-color: var(--color-primary-main);
            color: var(--color-text-primary);
            border-color: var(--color-primary-dark);
        }
        
        .stButton > button:hover {
            background-color: var(--color-primary-dark);
            border-color: var(--color-primary-darker);
        }
        
        .stButton > button:active {
            background-color: var(--color-primary-darker);
            border-color: var(--color-primary-darkest);
        }
        
        .stButton > button:disabled {
            background-color: var(--color-neutral-dark);
            color: var(--color-text-disabled);
            border-color: var(--color-neutral-darker);
        }
        
        /* Custom component styles */
        .material-card {
            background-color: var(--color-background-card);
            color: var(--color-text-primary);
            border-color: var(--color-border-main);
            box-shadow: 0 2px 8px var(--color-shadow-main);
        }
        
        .material-card-header {
            border-bottom-color: var(--color-border-light);
        }
        
        .material-button {
            background-color: var(--color-primary-main);
            color: var(--color-text-primary);
            border-color: var(--color-primary-dark);
        }
        
        .material-button:hover {
            background-color: var(--color-primary-dark);
            border-color: var(--color-primary-darker);
        }
        
        .material-button.outlined {
            background-color: transparent;
            color: var(--color-primary-main);
            border-color: var(--color-primary-main);
        }
        
        .material-button.outlined:hover {
            background-color: rgba(26, 75, 140, 0.1);
        }
        
        .material-button.text {
            background-color: transparent;
            color: var(--color-primary-main);
            border-color: transparent;
        }
        
        .material-button.text:hover {
            background-color: rgba(26, 75, 140, 0.1);
        }
        
        .material-metric {
            background-color: var(--color-background-card);
            color: var(--color-text-primary);
            border-color: var(--color-border-light);
        }
        
        .material-metric-value {
            color: var(--color-primary-main);
        }
        
        .material-alert {
            background-color: var(--color-background-tertiary);
            border-color: var(--color-border-main);
        }
        
        .material-alert.info {
            background-color: rgba(26, 155, 230, 0.1);
            border-color: var(--color-info-main);
        }
        
        .material-alert.success {
            background-color: rgba(37, 147, 37, 0.1);
            border-color: var(--color-success-main);
        }
        
        .material-alert.warning {
            background-color: rgba(230, 155, 26, 0.1);
            border-color: var(--color-warning-main);
        }
        
        .material-alert.error {
            background-color: rgba(230, 25, 25, 0.1);
            border-color: var(--color-error-main);
        }
        
        .material-data-table {
            background-color: var(--color-background-card);
            color: var(--color-text-primary);
            border-color: var(--color-border-main);
        }
        
        .material-data-table th {
            background-color: var(--color-background-tertiary);
            color: var(--color-text-primary);
            border-color: var(--color-border-main);
        }
        
        .material-data-table td {
            border-color: var(--color-border-light);
        }
        
        .material-data-table tr:nth-child(even) {
            background-color: var(--color-background-secondary);
        }
        
        .material-tabs {
            background-color: var(--color-background-secondary);
            color: var(--color-text-primary);
            border-color: var(--color-border-main);
        }
        
        .material-tab {
            color: var(--color-text-secondary);
        }
        
        .material-tab.active {
            color: var(--color-primary-main);
            border-bottom-color: var(--color-primary-main);
        }
        
        .material-tab:hover {
            color: var(--color-primary-light);
            background-color: rgba(26, 75, 140, 0.1);
        }
        
        .material-progress {
            background-color: var(--color-background-tertiary);
        }
        
        .material-progress-bar {
            background-color: var(--color-primary-main);
        }
        
        .material-badge {
            background-color: var(--color-primary-main);
            color: var(--color-text-primary);
        }
        
        .material-badge.success {
            background-color: var(--color-success-main);
        }
        
        .material-badge.warning {
            background-color: var(--color-warning-main);
        }
        
        .material-badge.error {
            background-color: var(--color-error-main);
        }
        
        .material-badge.info {
            background-color: var(--color-info-main);
        }
        
        .material-chip {
            background-color: var(--color-background-tertiary);
            color: var(--color-text-primary);
            border-color: var(--color-border-light);
        }
        
        .material-chip.primary {
            background-color: var(--color-primary-main);
            color: var(--color-text-primary);
            border-color: var(--color-primary-dark);
        }
        
        .material-chip.success {
            background-color: var(--color-success-main);
            color: var(--color-text-primary);
            border-color: var(--color-success-dark);
        }
        
        .material-chip.warning {
            background-color: var(--color-warning-main);
            color: var(--color-text-primary);
            border-color: var(--color-warning-dark);
        }
        
        .material-chip.error {
            background-color: var(--color-error-main);
            color: var(--color-text-primary);
            border-color: var(--color-error-dark);
        }
        
        .material-chip.info {
            background-color: var(--color-info-main);
            color: var(--color-text-primary);
            border-color: var(--color-info-dark);
        }
        
        .material-divider {
            background-color: var(--color-border-light);
        }
        
        .material-icon-button {
            color: var(--color-text-primary);
        }
        
        .material-icon-button:hover {
            background-color: rgba(255, 255, 255, 0.1);
        }
        
        .material-text-field {
            background-color: var(--color-background-tertiary);
            color: var(--color-text-primary);
            border-color: var(--color-border-main);
        }
        
        .material-text-field:focus {
            border-color: var(--color-primary-main);
        }
        
        .material-select {
            background-color: var(--color-background-tertiary);
            color: var(--color-text-primary);
            border-color: var(--color-border-main);
        }
        
        .material-select:focus {
            border-color: var(--color-primary-main);
        }
        
        .material-checkbox {
            color: var(--color-text-primary);
        }
        
        .material-checkbox-checked {
            color: var(--color-primary-main);
        }
        
        .material-radio {
            color: var(--color-text-primary);
        }
        
        .material-radio-checked {
            color: var(--color-primary-main);
        }
        
        .material-slider {
            background-color: var(--color-background-tertiary);
        }
        
        .material-slider-track {
            background-color: var(--color-primary-main);
        }
        
        .material-slider-thumb {
            background-color: var(--color-primary-lighter);
            border-color: var(--color-primary-main);
        }
        
        /* Responsive layout components */
        .responsive-container {
            background-color: var(--color-background-primary);
            color: var(--color-text-primary);
        }
        
        .responsive-card {
            background-color: var(--color-background-card);
            color: var(--color-text-primary);
            border-color: var(--color-border-main);
            box-shadow: 0 2px 8px var(--color-shadow-main);
        }
        
        .responsive-sidebar {
            background-color: var(--color-background-secondary);
            color: var(--color-text-primary);
            border-color: var(--color-border-main);
        }
        
        .responsive-table {
            background-color: var(--color-background-card);
            color: var(--color-text-primary);
            border-color: var(--color-border-main);
        }
        
        .responsive-table th {
            background-color: var(--color-background-tertiary);
            color: var(--color-text-primary);
            border-color: var(--color-border-main);
        }
        
        .responsive-table td {
            border-color: var(--color-border-light);
        }
        
        .responsive-tabs {
            background-color: var(--color-background-secondary);
            color: var(--color-text-primary);
            border-color: var(--color-border-main);
        }
        
        .responsive-tab {
            color: var(--color-text-secondary);
        }
        
        .responsive-tab.active {
            color: var(--color-primary-main);
            border-bottom-color: var(--color-primary-main);
        }
        
        .responsive-menu {
            background-color: var(--color-background-secondary);
            color: var(--color-text-primary);
            border-color: var(--color-border-main);
            box-shadow: 0 2px 8px var(--color-shadow-main);
        }
        
        .responsive-menu-item {
            color: var(--color-text-primary);
        }
        
        .responsive-menu-item:hover {
            background-color: var(--color-background-tertiary);
        }
        
        .responsive-menu-item.active {
            background-color: var(--color-primary-main);
            color: var(--color-text-primary);
        }
        """
    
    # Apply the CSS
    st.markdown(f"<style>{css_variables}</style>", unsafe_allow_html=True)
    
    # Store the current theme in localStorage for persistence
    store_theme_js = f"""
    <script>
    // Store the current theme mode
    localStorage.setItem('theme_mode', '{theme_mode}');
    
    // Store the effective theme
    localStorage.setItem('effective_theme', '{effective_theme}');
    </script>
    """
    
    st.markdown(store_theme_js, unsafe_allow_html=True)
    
    return effective_theme

def render_theme_switcher():
    """
    Render a theme switcher component.
    """
    current_theme_mode = get_current_theme_mode()
    
    st.markdown("### Theme Settings")
    
    # Theme mode selection
    theme_mode = st.radio(
        "Theme Mode",
        options=["light", "dark", "auto"],
        format_func=lambda x: {
            "light": "Light Mode",
            "dark": "Dark Mode",
            "auto": "Auto (System)"
        }[x],
        index=["light", "dark", "auto"].index(current_theme_mode),
        horizontal=True,
        key="theme_mode_selector"
    )
    
    # Apply theme if changed
    if theme_mode != current_theme_mode:
        apply_theme(theme_mode)
        st.rerun()
    
    # Show current effective theme
    effective_theme = get_effective_theme()
    
    st.markdown(f"**Current Theme:** {effective_theme.capitalize()}")
    
    if theme_mode == "auto":
        system_theme = get_system_theme_preference()
        st.markdown(f"**System Preference:** {system_theme.capitalize()}")
    
    # Theme preview
    st.markdown("### Theme Preview")
    
    # Create a preview of the current theme
    preview_html = f"""
    <div style="display: flex; flex-wrap: wrap; gap: 16px; margin-bottom: 16px;">
        <div style="flex: 1; min-width: 200px;">
            <h4>Primary Colors</h4>
            <div style="display: flex; flex-direction: column; gap: 8px;">
                <div style="background-color: var(--color-primary-lightest); color: var(--color-text-primary); padding: 8px; border-radius: 4px;">Primary Lightest</div>
                <div style="background-color: var(--color-primary-lighter); color: var(--color-text-primary); padding: 8px; border-radius: 4px;">Primary Lighter</div>
                <div style="background-color: var(--color-primary-light); color: var(--color-text-primary); padding: 8px; border-radius: 4px;">Primary Light</div>
                <div style="background-color: var(--color-primary-main); color: var(--color-text-primary); padding: 8px; border-radius: 4px;">Primary Main</div>
                <div style="background-color: var(--color-primary-dark); color: var(--color-text-primary); padding: 8px; border-radius: 4px;">Primary Dark</div>
                <div style="background-color: var(--color-primary-darker); color: var(--color-text-primary); padding: 8px; border-radius: 4px;">Primary Darker</div>
                <div style="background-color: var(--color-primary-darkest); color: var(--color-text-primary); padding: 8px; border-radius: 4px;">Primary Darkest</div>
            </div>
        </div>
        
        <div style="flex: 1; min-width: 200px;">
            <h4>Secondary Colors</h4>
            <div style="display: flex; flex-direction: column; gap: 8px;">
                <div style="background-color: var(--color-secondary-lightest); color: var(--color-text-primary); padding: 8px; border-radius: 4px;">Secondary Lightest</div>
                <div style="background-color: var(--color-secondary-lighter); color: var(--color-text-primary); padding: 8px; border-radius: 4px;">Secondary Lighter</div>
                <div style="background-color: var(--color-secondary-light); color: var(--color-text-primary); padding: 8px; border-radius: 4px;">Secondary Light</div>
                <div style="background-color: var(--color-secondary-main); color: var(--color-text-primary); padding: 8px; border-radius: 4px;">Secondary Main</div>
                <div style="background-color: var(--color-secondary-dark); color: var(--color-text-primary); padding: 8px; border-radius: 4px;">Secondary Dark</div>
                <div style="background-color: var(--color-secondary-darker); color: var(--color-text-primary); padding: 8px; border-radius: 4px;">Secondary Darker</div>
                <div style="background-color: var(--color-secondary-darkest); color: var(--color-text-primary); padding: 8px; border-radius: 4px;">Secondary Darkest</div>
            </div>
        </div>
        
        <div style="flex: 1; min-width: 200px;">
            <h4>Status Colors</h4>
            <div style="display: flex; flex-direction: column; gap: 8px;">
                <div style="background-color: var(--color-success-main); color: var(--color-text-primary); padding: 8px; border-radius: 4px;">Success</div>
                <div style="background-color: var(--color-warning-main); color: var(--color-text-primary); padding: 8px; border-radius: 4px;">Warning</div>
                <div style="background-color: var(--color-error-main); color: var(--color-text-primary); padding: 8px; border-radius: 4px;">Error</div>
                <div style="background-color: var(--color-info-main); color: var(--color-text-primary); padding: 8px; border-radius: 4px;">Info</div>
            </div>
            
            <h4>Neutral Colors</h4>
            <div style="display: flex; flex-direction: column; gap: 8px;">
                <div style="background-color: var(--color-neutral-lightest); color: var(--color-text-primary); padding: 8px; border-radius: 4px; border: 1px solid var(--color-border-light);">Neutral Lightest</div>
                <div style="background-color: var(--color-neutral-lighter); color: var(--color-text-primary); padding: 8px; border-radius: 4px;">Neutral Lighter</div>
                <div style="background-color: var(--color-neutral-light); color: var(--color-text-primary); padding: 8px; border-radius: 4px;">Neutral Light</div>
                <div style="background-color: var(--color-neutral-main); color: var(--color-text-primary); padding: 8px; border-radius: 4px;">Neutral Main</div>
                <div style="background-color: var(--color-neutral-dark); color: var(--color-text-primary); padding: 8px; border-radius: 4px;">Neutral Dark</div>
                <div style="background-color: var(--color-neutral-darker); color: var(--color-text-primary); padding: 8px; border-radius: 4px;">Neutral Darker</div>
                <div style="background-color: var(--color-neutral-darkest); color: var(--color-text-primary); padding: 8px; border-radius: 4px;">Neutral Darkest</div>
            </div>
        </div>
        
        <div style="flex: 1; min-width: 200px;">
            <h4>Background Colors</h4>
            <div style="display: flex; flex-direction: column; gap: 8px;">
                <div style="background-color: var(--color-background-primary); color: var(--color-text-primary); padding: 8px; border-radius: 4px; border: 1px solid var(--color-border-light);">Background Primary</div>
                <div style="background-color: var(--color-background-secondary); color: var(--color-text-primary); padding: 8px; border-radius: 4px;">Background Secondary</div>
                <div style="background-color: var(--color-background-tertiary); color: var(--color-text-primary); padding: 8px; border-radius: 4px;">Background Tertiary</div>
                <div style="background-color: var(--color-background-card); color: var(--color-text-primary); padding: 8px; border-radius: 4px;">Background Card</div>
                <div style="background-color: var(--color-background-elevated); color: var(--color-text-primary); padding: 8px; border-radius: 4px;">Background Elevated</div>
            </div>
            
            <h4>Text Colors</h4>
            <div style="display: flex; flex-direction: column; gap: 8px;">
                <div style="background-color: var(--color-background-card); padding: 8px; border-radius: 4px;">
                    <span style="color: var(--color-text-primary);">Text Primary</span>
                </div>
                <div style="background-color: var(--color-background-card); padding: 8px; border-radius: 4px;">
                    <span style="color: var(--color-text-secondary);">Text Secondary</span>
                </div>
                <div style="background-color: var(--color-background-card); padding: 8px; border-radius: 4px;">
                    <span style="color: var(--color-text-disabled);">Text Disabled</span>
                </div>
                <div style="background-color: var(--color-background-card); padding: 8px; border-radius: 4px;">
                    <span style="color: var(--color-text-hint);">Text Hint</span>
                </div>
            </div>
        </div>
    </div>
    """
    
    st.markdown(preview_html, unsafe_allow_html=True)
    
    # UI Component Preview
    st.markdown("### UI Component Preview")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.button("Primary Button", type="primary")
        st.button("Secondary Button")
        
        st.text_input("Text Input", value="Sample text")
        
        st.selectbox("Select", options=["Option 1", "Option 2", "Option 3"])
        
        st.checkbox("Checkbox", value=True)
        
        st.radio("Radio", options=["Option 1", "Option 2", "Option 3"])
        
        st.slider("Slider", min_value=0, max_value=100, value=50)
    
    with col2:
        st.markdown("#### Alert Box")
        st.info("This is an info alert")
        st.success("This is a success alert")
        st.warning("This is a warning alert")
        st.error("This is an error alert")
        
        st.markdown("#### Code Block")
        st.code("""
def hello_world():
    print("Hello, World!")
    return True
        """)
        
        st.markdown("#### Data Table")
        st.dataframe({
            "Name": ["John", "Jane", "Bob"],
            "Age": [30, 25, 40],
            "City": ["New York", "London", "Paris"]
        })

def render_dark_mode_demo():
    """
    Render a demo page for dark mode.
    """
    # Apply design system to the page
    apply_design_system_to_page("Dark Mode Demo")
    
    # Apply the current theme
    effective_theme = apply_theme()
    
    st.markdown(f"# Dark Mode Demo - {effective_theme.capitalize()} Theme")
    
    st.markdown("""
    This page demonstrates the dark mode support for the OPSC Sandwich Quality Inspection System.
    You can switch between light, dark, and auto modes using the controls below.
    """)
    
    # Theme switcher
    render_theme_switcher()
    
    # Demo content
    st.markdown("## Application Preview")
    
    st.markdown("""
    Below is a preview of how the application looks in the current theme.
    """)
    
    # Mock dashboard preview
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Total Sandwiches", "12,458", "+2.5%")
    
    with col2:
        st.metric("Defect Rate", "1.2%", "-0.3%")
    
    with col3:
        st.metric("Production Rate", "250/hr", "+5%")
    
    with col4:
        st.metric("Quality Score", "98.8%", "+0.3%")
    
    # Mock chart
    chart_data = {
        "Date": [f"2025-04-{i:02d}" for i in range(1, 22)],
        "Production": [random.randint(200, 300) for _ in range(21)],
        "Defects": [random.randint(2, 8) for _ in range(21)]
    }
    
    st.markdown("### Production Trends")
    st.line_chart(chart_data, x="Date", y=["Production", "Defects"])
    
    # Mock camera feed
    st.markdown("### Camera Feed")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        <div style="background-color: var(--color-background-tertiary); padding: 16px; border-radius: 4px; text-align: center;">
            <div style="color: var(--color-text-secondary); font-style: italic;">Camera Feed Placeholder</div>
            <div style="height: 200px; background-color: var(--color-background-card); border: 1px solid var(--color-border-main); border-radius: 4px; display: flex; align-items: center; justify-content: center;">
                <span class="material-icons" style="font-size: 48px; color: var(--color-text-secondary);">videocam</span>
            </div>
            <div style="margin-top: 8px; font-size: 14px; color: var(--color-text-secondary);">Top Camera - Live Feed</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown("""
        <div style="background-color: var(--color-background-tertiary); padding: 16px; border-radius: 4px; text-align: center;">
            <div style="color: var(--color-text-secondary); font-style: italic;">Camera Feed Placeholder</div>
            <div style="height: 200px; background-color: var(--color-background-card); border: 1px solid var(--color-border-main); border-radius: 4px; display: flex; align-items: center; justify-content: center;">
                <span class="material-icons" style="font-size: 48px; color: var(--color-text-secondary);">videocam</span>
            </div>
            <div style="margin-top: 8px; font-size: 14px; color: var(--color-text-secondary);">Side Camera 1 - Live Feed</div>
        </div>
        """, unsafe_allow_html=True)
    
    # Mock data table
    st.markdown("### Recent Defects")
    
    defect_data = {
        "Timestamp": [
            (datetime.now() - timedelta(minutes=i*5)).strftime("%H:%M:%S")
            for i in range(5)
        ],
        "Camera": ["Top Camera", "Side Camera 1", "Side Camera 2", "Bottom Camera", "Top Camera"],
        "Defect Type": ["Missing Filling", "Uneven Cut", "Crust Present", "Foreign Object", "Discoloration"],
        "Confidence": ["98%", "95%", "92%", "97%", "94%"]
    }
    
    st.dataframe(defect_data)
    
    # Mock system status
    st.markdown("### System Status")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown("""
        <div style="background-color: var(--color-background-card); padding: 16px; border-radius: 4px; border: 1px solid var(--color-border-light);">
            <div style="display: flex; align-items: center; margin-bottom: 8px;">
                <span class="material-icons" style="color: var(--color-success-main); margin-right: 8px;">check_circle</span>
                <div style="font-weight: 500;">Host System</div>
            </div>
            <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
                <span style="color: var(--color-text-secondary);">CPU:</span>
                <span>32%</span>
            </div>
            <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
                <span style="color: var(--color-text-secondary);">Memory:</span>
                <span>2.4 GB / 16 GB</span>
            </div>
            <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
                <span style="color: var(--color-text-secondary);">Disk:</span>
                <span>423 GB / 2 TB</span>
            </div>
            <div style="display: flex; justify-content: space-between;">
                <span style="color: var(--color-text-secondary);">Uptime:</span>
                <span>3d 7h 22m</span>
            </div>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown("""
        <div style="background-color: var(--color-background-card); padding: 16px; border-radius: 4px; border: 1px solid var(--color-border-light);">
            <div style="display: flex; align-items: center; margin-bottom: 8px;">
                <span class="material-icons" style="color: var(--color-success-main); margin-right: 8px;">check_circle</span>
                <div style="font-weight: 500;">Jetson Xavier NX</div>
            </div>
            <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
                <span style="color: var(--color-text-secondary);">CPU:</span>
                <span>45%</span>
            </div>
            <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
                <span style="color: var(--color-text-secondary);">GPU:</span>
                <span>38%</span>
            </div>
            <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
                <span style="color: var(--color-text-secondary);">Memory:</span>
                <span>3.2 GB / 8 GB</span>
            </div>
            <div style="display: flex; justify-content: space-between;">
                <span style="color: var(--color-text-secondary);">Temperature:</span>
                <span>42°C</span>
            </div>
        </div>
        """, unsafe_allow_html=True)
    
    with col3:
        st.markdown("""
        <div style="background-color: var(--color-background-card); padding: 16px; border-radius: 4px; border: 1px solid var(--color-border-light);">
            <div style="display: flex; align-items: center; margin-bottom: 8px;">
                <span class="material-icons" style="color: var(--color-warning-main); margin-right: 8px;">warning</span>
                <div style="font-weight: 500;">Network</div>
            </div>
            <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
                <span style="color: var(--color-text-secondary);">Status:</span>
                <span>Connected (Warning)</span>
            </div>
            <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
                <span style="color: var(--color-text-secondary);">Latency:</span>
                <span>15 ms</span>
            </div>
            <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
                <span style="color: var(--color-text-secondary);">Upload:</span>
                <span>2.3 Mbps</span>
            </div>
            <div style="display: flex; justify-content: space-between;">
                <span style="color: var(--color-text-secondary);">Download:</span>
                <span>8.7 Mbps</span>
            </div>
        </div>
        """, unsafe_allow_html=True)
    
    # Benefits of dark mode
    st.markdown("## Benefits of Dark Mode")
    
    st.markdown("""
    Dark mode offers several benefits for users:
    
    1. **Reduced Eye Strain**: Dark backgrounds can reduce eye strain, especially in low-light environments
    2. **Better Battery Life**: Dark mode can save battery life on devices with OLED or AMOLED screens
    3. **Improved Focus**: Dark backgrounds can help users focus on content by reducing visual distractions
    4. **Reduced Blue Light**: Dark mode can reduce blue light exposure, which may help with sleep patterns
    5. **Accessibility**: Some users with visual sensitivities prefer dark mode
    6. **Professional Appearance**: Dark interfaces often have a more professional, modern look
    """)
    
    # Implementation details
    st.markdown("## Implementation Details")
    
    st.markdown("""
    The dark mode implementation includes:
    
    1. **Complete Color System**: A comprehensive set of color variables for both light and dark themes
    2. **Theme Switching**: Ability to switch between light, dark, and system-based themes
    3. **System Detection**: Automatic detection of system theme preference
    4. **Theme Persistence**: Theme preference is saved and persists between sessions
    5. **Component Adaptation**: All UI components are adapted for both light and dark themes
    6. **Consistent Experience**: Consistent visual experience across all application pages
    """)
    
    # Reset button
    if st.button("Reset to Default Theme"):
        # Reset to light theme
        apply_theme("light")
        st.rerun()

if __name__ == "__main__":
    st.set_page_config(
        page_title="OPSC Dark Mode Demo",
        page_icon="🌓",
        layout="wide",
        initial_sidebar_state="expanded"
    )
    render_dark_mode_demo()
