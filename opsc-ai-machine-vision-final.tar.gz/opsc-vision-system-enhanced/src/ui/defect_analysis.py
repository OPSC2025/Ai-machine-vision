"""
Defect analysis page for the Crustless Creations AI machine vision application.

This module implements the defect analysis interface that displays defect statistics,
trends, and detailed analysis of detected defects.
"""

import streamlit as st
import pandas as pd
import numpy as np
import time
from datetime import datetime, timedelta
import sys
import os
import plotly.express as px
import plotly.graph_objects as go

# Add the parent directory to the path so we can import our components
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ui.components.dashboard import (
    card, chart_card, grid_dashboard, dashboard_header, tabbed_interface
)
from ui.components.status_indicators import (
    circular_status_indicator
)

def render_defect_analysis():
    """Render the defect analysis page."""
    
    # Dashboard header
    dashboard_header(
        "Defect Analysis",
        "Comprehensive analysis of detected defects",
        None,
        [("Export Data", lambda: st.session_state.update(export_clicked=True))]
    )
    
    # Date range selection
    st.markdown("### Time Period")
    col1, col2, col3 = st.columns([2, 2, 1])
    
    with col1:
        start_date = st.date_input(
            "Start date:",
            value=datetime.now() - timedelta(days=7),
            max_value=datetime.now()
        )
    
    with col2:
        end_date = st.date_input(
            "End date:",
            value=datetime.now(),
            max_value=datetime.now(),
            min_value=start_date
        )
    
    with col3:
        st.markdown("<br>", unsafe_allow_html=True)  # Add spacing
        if st.button("Apply Filter", use_container_width=True):
            st.success("Date filter applied!")
    
    # Quick date range buttons
    col1, col2, col3, col4, col5 = st.columns(5)
    
    with col1:
        if st.button("Today", use_container_width=True):
            st.session_state.update(date_range_clicked="today")
    
    with col2:
        if st.button("Yesterday", use_container_width=True):
            st.session_state.update(date_range_clicked="yesterday")
    
    with col3:
        if st.button("Last 7 Days", use_container_width=True):
            st.session_state.update(date_range_clicked="last_7_days")
    
    with col4:
        if st.button("Last 30 Days", use_container_width=True):
            st.session_state.update(date_range_clicked="last_30_days")
    
    with col5:
        if st.button("This Month", use_container_width=True):
            st.session_state.update(date_range_clicked="this_month")
    
    # Separator
    st.markdown("---")
    
    # Defect summary metrics
    st.markdown("### Defect Summary")
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric(
            label="Total Defects",
            value="124",
            delta="-18",
            delta_color="inverse"
        )
    
    with col2:
        st.metric(
            label="Defect Rate",
            value="0.8%",
            delta="-0.2%",
            delta_color="inverse"
        )
    
    with col3:
        st.metric(
            label="Most Common Defect",
            value="Missing Filling"
        )
    
    with col4:
        st.metric(
            label="Critical Defects",
            value="7",
            delta="-3",
            delta_color="inverse"
        )
    
    # Defect analysis tabs
    st.markdown("### Detailed Analysis")
    
    tabs = {
        "Defect Trends": render_defect_trends,
        "Defect Types": render_defect_types,
        "Defect Locations": render_defect_locations,
        "Defect Samples": render_defect_samples
    }
    
    tabbed_interface(tabs)
    
    # Handle export button click
    if "export_clicked" in st.session_state and st.session_state.export_clicked:
        st.success("Data exported successfully!")
        st.session_state.export_clicked = False

def render_defect_trends():
    """Render defect trend analysis."""
    
    # Create sample data for demonstration
    dates = pd.date_range(start=datetime.now() - timedelta(days=30), end=datetime.now(), freq='D')
    
    # Defect rate trend
    defect_rates = np.random.normal(1.0, 0.3, len(dates))
    defect_rates = np.maximum(defect_rates, 0)  # Ensure no negative rates
    
    # Defect counts by type
    defect_types = ["Missing Filling", "Uneven Cut", "Crust Present", "Foreign Object", "Other"]
    defect_counts = {}
    
    for defect_type in defect_types:
        # Generate random trend data for each defect type
        base_value = np.random.randint(3, 10)
        variation = np.random.normal(0, 1, len(dates))
        counts = np.maximum(base_value + variation, 0).astype(int)
        defect_counts[defect_type] = counts
    
    # Create DataFrame
    df_trend = pd.DataFrame({
        'Date': dates,
        'Defect Rate (%)': defect_rates
    })
    
    for defect_type in defect_types:
        df_trend[defect_type] = defect_counts[defect_type]
    
    # Defect rate trend chart
    def defect_rate_chart():
        fig = px.line(
            df_trend, 
            x='Date', 
            y='Defect Rate (%)',
            title='Defect Rate Trend',
            markers=True
        )
        fig.update_layout(
            xaxis_title='Date',
            yaxis_title='Defect Rate (%)',
            hovermode='x unified'
        )
        st.plotly_chart(fig, use_container_width=True)
    
    chart_card(
        title="Defect Rate Trend",
        chart_function=defect_rate_chart,
        key="defect_rate_trend_card"
    )
    
    # Defect counts by type chart
    def defect_counts_chart():
        # Melt the DataFrame to get it in the right format for a stacked area chart
        df_melted = pd.melt(
            df_trend, 
            id_vars=['Date'], 
            value_vars=defect_types,
            var_name='Defect Type', 
            value_name='Count'
        )
        
        fig = px.area(
            df_melted, 
            x='Date', 
            y='Count', 
            color='Defect Type',
            title='Defect Counts by Type',
            color_discrete_sequence=px.colors.qualitative.Set1
        )
        fig.update_layout(
            xaxis_title='Date',
            yaxis_title='Count',
            hovermode='x unified'
        )
        st.plotly_chart(fig, use_container_width=True)
    
    chart_card(
        title="Defect Counts by Type",
        chart_function=defect_counts_chart,
        key="defect_counts_chart_card"
    )
    
    # Shift comparison
    st.markdown("### Shift Comparison")
    
    # Create sample shift data
    shifts = ["Morning", "Afternoon", "Night"]
    shift_defect_rates = [0.7, 0.9, 1.2]
    
    def shift_comparison_chart():
        fig = px.bar(
            x=shifts, 
            y=shift_defect_rates,
            title='Defect Rate by Shift',
            labels={'x': 'Shift', 'y': 'Defect Rate (%)'},
            color=shift_defect_rates,
            color_continuous_scale='RdYlGn_r'
        )
        fig.update_layout(
            xaxis_title='Shift',
            yaxis_title='Defect Rate (%)',
            coloraxis_showscale=False
        )
        st.plotly_chart(fig, use_container_width=True)
    
    col1, col2 = st.columns(2)
    
    with col1:
        chart_card(
            title="Defect Rate by Shift",
            chart_function=shift_comparison_chart,
            key="shift_comparison_card"
        )
    
    with col2:
        # Statistical analysis
        def statistical_analysis():
            st.markdown("#### Statistical Highlights")
            st.markdown("- **Mean Defect Rate:** 0.8% ± 0.3%")
            st.markdown("- **Trend Analysis:** Decreasing (p < 0.05)")
            st.markdown("- **Shift Correlation:** Night shift has significantly higher defect rate (p < 0.01)")
            st.markdown("- **Day of Week Effect:** Monday shows 15% higher defect rate")
            st.markdown("- **Production Speed Correlation:** No significant correlation (r = 0.12)")
        
        card(
            title="Statistical Analysis",
            content=statistical_analysis,
            key="statistical_analysis_card"
        )

def render_defect_types():
    """Render defect type analysis."""
    
    # Create sample data for demonstration
    defect_types = {
        'Missing Filling': 45,
        'Uneven Cut': 30,
        'Crust Present': 15,
        'Foreign Object': 7,
        'Other': 3
    }
    
    defect_df = pd.DataFrame({
        'Defect Type': list(defect_types.keys()),
        'Count': list(defect_types.values())
    })
    
    # Calculate percentages
    total = defect_df['Count'].sum()
    defect_df['Percentage'] = (defect_df['Count'] / total * 100).round(1)
    
    # Pareto chart
    def pareto_chart():
        # Sort by count descending
        df_sorted = defect_df.sort_values('Count', ascending=False)
        
        # Calculate cumulative percentage
        df_sorted['Cumulative Percentage'] = df_sorted['Percentage'].cumsum()
        
        # Create the Pareto chart
        fig = go.Figure()
        
        # Add bars
        fig.add_trace(go.Bar(
            x=df_sorted['Defect Type'],
            y=df_sorted['Count'],
            name='Count',
            marker_color='rgb(55, 83, 109)'
        ))
        
        # Add cumulative percentage line
        fig.add_trace(go.Scatter(
            x=df_sorted['Defect Type'],
            y=df_sorted['Cumulative Percentage'],
            name='Cumulative %',
            marker=dict(color='rgb(255, 0, 0)'),
            yaxis='y2'
        ))
        
        # Layout
        fig.update_layout(
            title='Defect Types - Pareto Analysis',
            xaxis_title='Defect Type',
            yaxis_title='Count',
            yaxis2=dict(
                title='Cumulative %',
                overlaying='y',
                side='right',
                range=[0, 100]
            ),
            legend=dict(
                orientation="h",
                yanchor="bottom",
                y=1.02,
                xanchor="right",
                x=1
            )
        )
        
        st.plotly_chart(fig, use_container_width=True)
    
    chart_card(
        title="Defect Types - Pareto Analysis",
        chart_function=pareto_chart,
        key="pareto_chart_card"
    )
    
    # Defect type details
    st.markdown("### Defect Type Details")
    
    # Create tabs for each defect type
    defect_tabs = {}
    for defect_type in defect_types.keys():
        defect_tabs[defect_type] = lambda d=defect_type: render_defect_type_details(d)
    
    tabbed_interface(defect_tabs)

def render_defect_type_details(defect_type):
    """Render details for a specific defect type."""
    
    # Sample data for demonstration
    confidence_values = np.random.normal(0.85, 0.1, 100)
    confidence_values = np.clip(confidence_values, 0, 1)
    
    # Confidence distribution
    def confidence_histogram():
        fig = px.histogram(
            x=confidence_values,
            nbins=20,
            title=f'{defect_type} - Confidence Distribution',
            labels={'x': 'Confidence Score', 'y': 'Count'},
            color_discrete_sequence=['rgb(55, 83, 109)']
        )
        fig.update_layout(
            xaxis_title='Confidence Score',
            yaxis_title='Count',
            xaxis=dict(range=[0, 1])
        )
        st.plotly_chart(fig, use_container_width=True)
    
    col1, col2 = st.columns(2)
    
    with col1:
        chart_card(
            title=f"{defect_type} - Confidence Distribution",
            chart_function=confidence_histogram,
            key=f"confidence_histogram_{defect_type}"
        )
    
    with col2:
        # Defect details
        def defect_details():
            st.markdown(f"#### {defect_type} Details")
            st.markdown(f"- **Description:** {get_defect_description(defect_type)}")
            st.markdown(f"- **Average Confidence:** {np.mean(confidence_values):.2f}")
            st.markdown(f"- **Detection Threshold:** 0.70")
            st.markdown(f"- **False Positive Rate:** {np.random.uniform(0.01, 0.1):.2%}")
            st.markdown(f"- **Most Common Location:** {get_defect_location(defect_type)}")
            st.markdown(f"- **Recommended Action:** {get_defect_action(defect_type)}")
        
        card(
            title=f"{defect_type} Information",
            content=defect_details,
            key=f"defect_details_{defect_type}"
        )
    
    # Sample images
    st.markdown(f"### {defect_type} Samples")
    
    # In a real application, these would be actual defect images
    # For demonstration, we'll use placeholder images
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.image(
            "https://via.placeholder.com/300x300.png?text=Sample+1",
            caption=f"{defect_type} - Sample 1 (Conf: 0.92)",
            use_column_width=True
        )
    
    with col2:
        st.image(
            "https://via.placeholder.com/300x300.png?text=Sample+2",
            caption=f"{defect_type} - Sample 2 (Conf: 0.88)",
            use_column_width=True
        )
    
    with col3:
        st.image(
            "https://via.placeholder.com/300x300.png?text=Sample+3",
            caption=f"{defect_type} - Sample 3 (Conf: 0.85)",
            use_column_width=True
        )
    
    with col4:
        st.image(
            "https://via.placeholder.com/300x300.png?text=Sample+4",
            caption=f"{defect_type} - Sample 4 (Conf: 0.81)",
            use_column_width=True
        )

def render_defect_locations():
    """Render defect location analysis."""
    
    # In a real application, this would use actual defect location data
    # For demonstration, we'll create a heatmap with random data
    
    # Create a sample sandwich outline
    sandwich_width = 100
    sandwich_height = 60
    
    # Generate random defect locations
    num_defects = 200
    x_coords = np.random.normal(sandwich_width/2, sandwich_width/4, num_defects)
    y_coords = np.random.normal(sandwich_height/2, sandwich_height/4, num_defects)
    
    # Clip to sandwich boundaries
    x_coords = np.clip(x_coords, 0, sandwich_width)
    y_coords = np.clip(y_coords, 0, sandwich_height)
    
    # Create defect types for each point
    defect_types = np.random.choice(
        ["Missing Filling", "Uneven Cut", "Crust Present", "Foreign Object", "Other"],
        size=num_defects,
        p=[0.45, 0.30, 0.15, 0.07, 0.03]  # Probabilities matching our distribution
    )
    
    # Create DataFrame
    df_locations = pd.DataFrame({
        'x': x_coords,
        'y': y_coords,
        'Defect Type': defect_types
    })
    
    # Heatmap
    def heatmap_chart():
        fig = px.density_heatmap(
            df_locations, 
            x='x', 
            y='y',
            title='Defect Location Heatmap',
            nbinsx=20,
            nbinsy=12,
            color_continuous_scale='Viridis'
        )
        
        # Add sandwich outline
        fig.add_shape(
            type="rect",
            x0=0, y0=0,
            x1=sandwich_width, y1=sandwich_height,
            line=dict(color="Black", width=2),
            fillcolor="rgba(0,0,0,0)"
        )
        
        fig.update_layout(
            xaxis_title='X Position',
            yaxis_title='Y Position',
            xaxis=dict(range=[0, sandwich_width]),
            yaxis=dict(range=[0, sandwich_height])
        )
        
        st.plotly_chart(fig, use_container_width=True)
    
    chart_card(
        title="Defect Location Heatmap",
        chart_function=heatmap_chart,
        key="heatmap_chart_card"
    )
    
    # Scatter plot by defect type
    def scatter_chart():
        fig = px.scatter(
            df_locations, 
            x='x', 
            y='y',
            color='Defect Type',
            title='Defect Locations by Type',
            color_discrete_sequence=px.colors.qualitative.Set1
        )
        
        # Add sandwich outline
        fig.add_shape(
            type="rect",
            x0=0, y0=0,
            x1=sandwich_width, y1=sandwich_height,
            line=dict(color="Black", width=2),
            fillcolor="rgba(0,0,0,0)"
        )
        
        fig.update_layout(
            xaxis_title='X Position',
            yaxis_title='Y Position',
            xaxis=dict(range=[0, sandwich_width]),
            yaxis=dict(range=[0, sandwich_height]),
            legend=dict(
                orientation="h",
                yanchor="bottom",
                y=1.02,
                xanchor="right",
                x=1
            )
        )
        
        st.plotly_chart(fig, use_container_width=True)
    
    chart_card(
        title="Defect Locations by Type",
        chart_function=scatter_chart,
        key="scatter_chart_card"
    )
    
    # Location analysis by camera
    st.markdown("### Defect Detection by Camera")
    
    # Sample data for camera detection
    cameras = ["Top Camera", "Side Camera 1", "Side Camera 2", "Bottom Camera"]
    camera_counts = [78, 42, 35, 45]
    
    def camera_detection_chart():
        fig = px.bar(
            x=cameras, 
            y=camera_counts,
            title='Defects Detected by Camera',
            labels={'x': 'Camera', 'y': 'Number of Defects'},
            color=cameras,
            color_discrete_sequence=px.colors.qualitative.Pastel
        )
        fig.update_layout(
            xaxis_title='Camera',
            yaxis_title='Number of Defects',
            showlegend=False
        )
        st.plotly_chart(fig, use_container_width=True)
    
    col1, col2 = st.columns(2)
    
    with col1:
        chart_card(
            title="Defects Detected by Camera",
            chart_function=camera_detection_chart,
            key="camera_detection_card"
        )
    
    with col2:
        # Camera detection details
        def camera_details():
            st.markdown("#### Camera Detection Analysis")
            st.markdown("- **Top Camera:** Best for detecting missing filling (78% of cases)")
            st.markdown("- **Side Cameras:** Most effective for uneven cut detection")
            st.markdown("- **Bottom Camera:** Primary detector for foreign objects")
            st.markdown("- **Multi-camera Confirmation:** 32% of defects confirmed by multiple cameras")
            st.markdown("- **Detection Overlap:** 15% average overlap between cameras")
        
        card(
            title="Camera Detection Details",
            content=camera_details,
            key="camera_details_card"
        )

def render_defect_samples():
    """Render defect sample gallery."""
    
    # Filter controls
    st.markdown("### Filter Samples")
    col1, col2, col3 = st.columns(3)
    
    with col1:
        selected_defect_type = st.selectbox(
            "Defect type:",
            ["All Types", "Missing Filling", "Uneven Cut", "Crust Present", "Foreign Object", "Other"],
            index=0
        )
    
    with col2:
        selected_camera = st.selectbox(
            "Camera:",
            ["All Cameras", "Top Camera", "Side Camera 1", "Side Camera 2", "Bottom Camera"],
            index=0
        )
    
    with col3:
        min_confidence = st.slider(
            "Minimum confidence:",
            min_value=0.0,
            max_value=1.0,
            value=0.7,
            step=0.05,
            format="%.2f"
        )
    
    # Apply filters button
    if st.button("Apply Filters", use_container_width=True):
        st.success("Filters applied!")
    
    # Sample gallery
    st.markdown("### Defect Samples")
    
    # In a real application, these would be filtered based on the selections
    # For demonstration, we'll show a fixed set of samples
    
    # Create a 3x4 grid of sample images
    for row in range(3):
        cols = st.columns(4)
        
        for col in range(4):
            index = row * 4 + col + 1
            defect_type = get_sample_defect_type(index)
            confidence = np.random.uniform(0.75, 0.99)
            camera = get_sample_camera(index)
            timestamp = get_sample_timestamp(index)
            
            with cols[col]:
                st.image(
                    f"https://via.placeholder.com/300x300.png?text=Defect+{index}",
                    caption=f"{defect_type} (Conf: {confidence:.2f})",
                    use_column_width=True
                )
                
                st.markdown(f"**Camera:** {camera}")
                st.markdown(f"**Time:** {timestamp}")
                
                if st.button(f"View Details #{index}", key=f"details_{index}"):
                    st.session_state.update({f"view_details_{index}": True})
    
    # Pagination
    col1, col2, col3 = st.columns([1, 3, 1])
    
    with col2:
        st.markdown(
            """
            <div style="display: flex; justify-content: center;">
                <div style="margin: 0 10px;"><a href="#">Previous</a></div>
                <div style="margin: 0 10px;"><a href="#">1</a></div>
                <div style="margin: 0 10px;"><strong>2</strong></div>
                <div style="margin: 0 10px;"><a href="#">3</a></div>
                <div style="margin: 0 10px;"><a href="#">4</a></div>
                <div style="margin: 0 10px;"><a href="#">5</a></div>
                <div style="margin: 0 10px;"><a href="#">Next</a></div>
            </div>
            """,
            unsafe_allow_html=True
        )
    
    # Handle detail view clicks
    for i in range(1, 13):
        if f"view_details_{i}" in st.session_state and st.session_state[f"view_details_{i}"]:
            show_defect_detail_modal(i)
            st.session_state[f"view_details_{i}"] = False

def show_defect_detail_modal(index):
    """Show a modal with defect details."""
    
    defect_type = get_sample_defect_type(index)
    confidence = np.random.uniform(0.75, 0.99)
    camera = get_sample_camera(index)
    timestamp = get_sample_timestamp(index)
    
    st.markdown("### Defect Detail View")
    
    col1, col2 = st.columns([1, 1])
    
    with col1:
        st.image(
            f"https://via.placeholder.com/600x600.png?text=Defect+{index}+Detail",
            caption=f"Defect #{index}",
            use_column_width=True
        )
    
    with col2:
        st.markdown(f"**Defect Type:** {defect_type}")
        st.markdown(f"**Confidence Score:** {confidence:.2f}")
        st.markdown(f"**Detected By:** {camera}")
        st.markdown(f"**Timestamp:** {timestamp}")
        st.markdown(f"**Location:** X: {np.random.randint(10, 90)}, Y: {np.random.randint(10, 50)}")
        st.markdown(f"**Size:** {np.random.randint(5, 20)} x {np.random.randint(5, 20)} mm")
        st.markdown(f"**Sandwich ID:** PBJ-{np.random.randint(10000, 99999)}")
        st.markdown(f"**Batch Number:** B-{np.random.randint(1000, 9999)}")
        st.markdown(f"**Production Line:** Line {np.random.randint(1, 4)}")
        st.markdown(f"**Operator:** Operator {np.random.randint(1, 10)}")
        
        st.markdown("#### Actions")
        col1, col2 = st.columns(2)
        with col1:
            if st.button("Mark as False Positive", key=f"false_positive_{index}"):
                st.success("Marked as false positive!")
        
        with col2:
            if st.button("Add to Training Set", key=f"add_training_{index}"):
                st.success("Added to training set!")
    
    if st.button("Close Detail View", key=f"close_detail_{index}"):
        pass

# Helper functions

def get_defect_description(defect_type):
    """Get description for a defect type."""
    descriptions = {
        "Missing Filling": "Insufficient peanut butter or jelly filling detected in the sandwich.",
        "Uneven Cut": "Sandwich is not cut evenly, resulting in unequal halves.",
        "Crust Present": "Crust detected on sandwich edges, violating the crustless requirement.",
        "Foreign Object": "Non-food item or unexpected object detected in the sandwich.",
        "Other": "Miscellaneous defects not falling into standard categories."
    }
    return descriptions.get(defect_type, "No description available.")

def get_defect_location(defect_type):
    """Get common location for a defect type."""
    locations = {
        "Missing Filling": "Center region",
        "Uneven Cut": "Edge boundaries",
        "Crust Present": "Perimeter edges",
        "Foreign Object": "Random distribution",
        "Other": "Varies by specific defect"
    }
    return locations.get(defect_type, "Unknown location")

def get_defect_action(defect_type):
    """Get recommended action for a defect type."""
    actions = {
        "Missing Filling": "Adjust filling dispenser calibration",
        "Uneven Cut": "Check cutting blade alignment",
        "Crust Present": "Verify crust removal mechanism",
        "Foreign Object": "Inspect ingredient supply chain",
        "Other": "Investigate specific cause"
    }
    return actions.get(defect_type, "No specific action")

def get_sample_defect_type(index):
    """Get a defect type for a sample index."""
    defect_types = ["Missing Filling", "Uneven Cut", "Crust Present", "Foreign Object", "Other"]
    weights = [0.45, 0.30, 0.15, 0.07, 0.03]
    
    # Use a deterministic approach based on index
    seed = index * 123457 % 100
    if seed < weights[0] * 100:
        return defect_types[0]
    elif seed < (weights[0] + weights[1]) * 100:
        return defect_types[1]
    elif seed < (weights[0] + weights[1] + weights[2]) * 100:
        return defect_types[2]
    elif seed < (weights[0] + weights[1] + weights[2] + weights[3]) * 100:
        return defect_types[3]
    else:
        return defect_types[4]

def get_sample_camera(index):
    """Get a camera for a sample index."""
    cameras = ["Top Camera", "Side Camera 1", "Side Camera 2", "Bottom Camera"]
    return cameras[index % len(cameras)]

def get_sample_timestamp(index):
    """Get a timestamp for a sample index."""
    base_time = datetime.now() - timedelta(hours=12)
    offset = timedelta(minutes=index * 7)
    return (base_time + offset).strftime("%H:%M:%S")

if __name__ == "__main__":
    st.set_page_config(
        page_title="Crustless Creations - Defect Analysis",
        page_icon="🥪",
        layout="wide",
        initial_sidebar_state="expanded"
    )
    render_defect_analysis()
