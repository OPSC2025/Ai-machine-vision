"""
Interactive dashboard for the OPSC Sandwich Quality Inspection System.

This module provides an enhanced interactive dashboard with real-time data visualization,
interactive controls, and responsive design for optimal viewing on all devices.
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
import time
import random
import json
import sys
import os

# Add the parent directory to the path so we can import our components
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ui.components.material_ui import (
    load_material_icons, material_button, material_card, material_metric,
    material_tabs, material_data_table, material_progress, material_alert,
    material_badge, material_icon_button, material_divider, material_chip,
    material_select, material_text_field, material_checkbox, material_radio,
    material_slider, material_date_picker
)
from ui.components.theme_provider import apply_design_system_to_page
from ui.components.responsive_layout import (
    responsive_container, responsive_grid, responsive_columns, responsive_card,
    responsive_sidebar, responsive_table, responsive_tabs, responsive_image,
    responsive_menu
)

# Mock data generation functions
def generate_mock_production_data(days=30):
    """Generate mock production data for demonstration."""
    date_range = pd.date_range(end=datetime.now(), periods=days)
    
    # Base production numbers with some randomness
    base_production = np.random.normal(1200, 100, days)
    
    # Add weekly pattern (lower on weekends)
    weekday_effect = np.array([0 if d.weekday() >= 5 else 1 for d in date_range])
    production_with_weekday = base_production * (0.7 + 0.3 * weekday_effect)
    
    # Add some trend (increasing over time)
    trend = np.linspace(0.9, 1.1, days)
    production_with_trend = production_with_weekday * trend
    
    # Ensure no negative values and round to integers
    production = np.maximum(production_with_trend, 0).astype(int)
    
    # Generate defect rates with some correlation to production volume
    base_defect_rate = np.random.normal(0.01, 0.003, days)
    # Higher production slightly increases defect rate
    production_effect = (production / production.mean() - 1) * 0.002
    defect_rate = base_defect_rate + production_effect
    
    # Ensure defect rate is between 0.2% and 3%
    defect_rate = np.clip(defect_rate, 0.002, 0.03)
    
    # Calculate actual defects
    defects = (production * defect_rate).astype(int)
    
    # Create DataFrame
    df = pd.DataFrame({
        'date': date_range,
        'production': production,
        'defects': defects,
        'defect_rate': defect_rate
    })
    
    return df

def generate_mock_defect_types():
    """Generate mock defect type distribution."""
    defect_types = {
        'Missing Filling': random.randint(35, 50),
        'Uneven Cut': random.randint(20, 35),
        'Crust Present': random.randint(10, 20),
        'Foreign Object': random.randint(5, 10),
        'Discoloration': random.randint(3, 8),
        'Other': random.randint(1, 5)
    }
    
    return defect_types

def generate_mock_system_status():
    """Generate mock system status data."""
    return {
        'host': {
            'status': 'success',
            'cpu_usage': random.uniform(0.3, 0.6),
            'memory_usage': random.uniform(0.4, 0.7),
            'disk_usage': random.uniform(0.5, 0.85),
            'temperature': random.uniform(40, 60)
        },
        'jetson': {
            'status': 'warning' if random.random() < 0.3 else 'success',
            'gpu_usage': random.uniform(0.6, 0.9),
            'memory_usage': random.uniform(0.5, 0.8),
            'temperature': random.uniform(65, 85)
        },
        'database': {
            'status': 'success',
            'connections': random.randint(3, 12),
            'query_time_ms': random.uniform(5, 30),
            'disk_usage': random.uniform(0.2, 0.5)
        },
        'network': {
            'status': 'success',
            'latency_ms': random.uniform(2, 15),
            'bandwidth_usage': random.uniform(0.1, 0.4),
            'signal_quality': random.uniform(0.7, 0.95)
        }
    }

def generate_mock_camera_status():
    """Generate mock camera status data."""
    cameras = {
        'Top Camera': {
            'status': 'success',
            'fps': random.randint(18, 20),
            'max_fps': 20,
            'connection': random.uniform(0.9, 1.0),
            'temperature': random.uniform(35, 45)
        },
        'Side Camera 1': {
            'status': 'warning' if random.random() < 0.2 else 'success',
            'fps': random.randint(16, 20),
            'max_fps': 20,
            'connection': random.uniform(0.7, 0.95),
            'temperature': random.uniform(35, 50)
        },
        'Side Camera 2': {
            'status': 'success',
            'fps': random.randint(18, 20),
            'max_fps': 20,
            'connection': random.uniform(0.85, 1.0),
            'temperature': random.uniform(35, 45)
        },
        'Bottom Camera': {
            'status': 'success',
            'fps': random.randint(18, 20),
            'max_fps': 20,
            'connection': random.uniform(0.8, 1.0),
            'temperature': random.uniform(35, 45)
        }
    }
    
    return cameras

def generate_mock_alerts():
    """Generate mock system alerts."""
    alert_types = ['error', 'warning', 'info']
    alert_weights = [0.1, 0.3, 0.6]  # Probability distribution
    
    # Potential alerts by type
    potential_alerts = {
        'error': [
            {'message': 'Database connection lost', 'source': 'Database', 'icon': 'storage'},
            {'message': 'Camera connection failure', 'source': 'Camera System', 'icon': 'videocam_off'},
            {'message': 'Model inference error', 'source': 'AI System', 'icon': 'error'}
        ],
        'warning': [
            {'message': 'ADLINK temperature high (85°C)', 'source': 'Jetson', 'icon': 'thermostat'},
            {'message': 'Low disk space warning (82% used)', 'source': 'Storage', 'icon': 'storage'},
            {'message': 'Camera FPS dropping', 'source': 'Camera System', 'icon': 'speed'},
            {'message': 'Network latency increasing', 'source': 'Network', 'icon': 'wifi_tethering_error'}
        ],
        'info': [
            {'message': 'System update available', 'source': 'System', 'icon': 'system_update'},
            {'message': 'Daily backup completed', 'source': 'Backup', 'icon': 'backup'},
            {'message': 'Production run completed', 'source': 'Production', 'icon': 'done_all'},
            {'message': 'New defect pattern detected', 'source': 'AI System', 'icon': 'psychology'},
            {'message': 'Camera calibration recommended', 'source': 'Camera System', 'icon': 'camera'}
        ]
    }
    
    # Generate random number of alerts (0-2 errors, 0-3 warnings, 1-5 info)
    num_error = random.randint(0, 1 if random.random() < 0.8 else 2)
    num_warning = random.randint(0, 3)
    num_info = random.randint(1, 5)
    
    alerts = []
    
    # Add random alerts of each type
    for _ in range(num_error):
        alert = random.choice(potential_alerts['error']).copy()
        alert['type'] = 'error'
        alert['time'] = (datetime.now() - timedelta(minutes=random.randint(5, 120))).strftime('%H:%M:%S')
        alerts.append(alert)
    
    for _ in range(num_warning):
        alert = random.choice(potential_alerts['warning']).copy()
        alert['type'] = 'warning'
        alert['time'] = (datetime.now() - timedelta(minutes=random.randint(5, 240))).strftime('%H:%M:%S')
        alerts.append(alert)
    
    for _ in range(num_info):
        alert = random.choice(potential_alerts['info']).copy()
        alert['type'] = 'info'
        alert['time'] = (datetime.now() - timedelta(minutes=random.randint(5, 480))).strftime('%H:%M:%S')
        alerts.append(alert)
    
    # Sort by time (most recent first)
    alerts.sort(key=lambda x: x['time'], reverse=True)
    
    return alerts

def generate_mock_recent_defects(count=10):
    """Generate mock recent defect data."""
    defect_types = ['Missing Filling', 'Uneven Cut', 'Crust Present', 'Foreign Object', 'Discoloration']
    defect_weights = [0.4, 0.3, 0.15, 0.1, 0.05]  # Probability distribution
    
    cameras = ['Top', 'Side 1', 'Side 2', 'Bottom']
    
    defects = []
    
    for i in range(count):
        defect_type = random.choices(defect_types, weights=defect_weights)[0]
        
        # Confidence level based on defect type
        base_confidence = 0.85
        if defect_type == 'Missing Filling':
            confidence = random.uniform(0.92, 0.99)
        elif defect_type == 'Uneven Cut':
            confidence = random.uniform(0.85, 0.95)
        elif defect_type == 'Crust Present':
            confidence = random.uniform(0.88, 0.97)
        elif defect_type == 'Foreign Object':
            confidence = random.uniform(0.95, 0.99)
        else:  # Discoloration
            confidence = random.uniform(0.80, 0.92)
        
        # Time is more recent for lower index
        minutes_ago = i * random.randint(1, 5)
        
        defects.append({
            'time': (datetime.now() - timedelta(minutes=minutes_ago)).strftime('%H:%M:%S'),
            'type': defect_type,
            'confidence': f"{int(confidence * 100)}%",
            'camera': random.choice(cameras),
            'image_id': f"img_{int(time.time())}_{i}"
        })
    
    return defects

def render_interactive_dashboard():
    """Render the interactive dashboard with real-time data visualization."""
    
    # Apply design system to the page
    apply_design_system_to_page("Quality Control Dashboard")
    
    # Load Material Icons
    load_material_icons()
    
    # Initialize session state for filters if not exists
    if 'date_range' not in st.session_state:
        st.session_state.date_range = '30D'
    
    if 'refresh_counter' not in st.session_state:
        st.session_state.refresh_counter = 0
    
    # Dashboard header with action buttons
    st.markdown(
        """
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <div>
                <h1 style="margin-bottom: 0;">Quality Control Dashboard</h1>
                <p style="margin-top: 0; color: var(--color-neutral-main);">Crustless Creations - Real-time Monitoring</p>
            </div>
        </div>
        """,
        unsafe_allow_html=True
    )
    
    # Top action bar
    col1, col2, col3, col4 = st.columns([3, 2, 2, 1])
    
    with col1:
        # Date range selector
        date_options = {
            '7D': 'Last 7 Days',
            '14D': 'Last 14 Days',
            '30D': 'Last 30 Days',
            '90D': 'Last 90 Days'
        }
        selected_date = material_select(
            "Date Range",
            options=list(date_options.values()),
            default=date_options[st.session_state.date_range],
            key="date_range_selector"
        )
        
        # Update session state based on selection
        for key, value in date_options.items():
            if value == selected_date:
                st.session_state.date_range = key
    
    with col2:
        # Production line selector
        production_line = material_select(
            "Production Line",
            options=["All Lines", "Line 1", "Line 2", "Line 3"],
            default="All Lines",
            key="production_line_selector"
        )
    
    with col3:
        # Product type selector
        product_type = material_select(
            "Product Type",
            options=["All Products", "Classic", "Cheese", "Ham & Cheese", "Veggie"],
            default="All Products",
            key="product_type_selector"
        )
    
    with col4:
        # Refresh button
        refresh_clicked = material_button(
            "Refresh",
            icon="refresh",
            type="outlined",
            key="refresh_dashboard"
        )
        
        if refresh_clicked:
            st.session_state.refresh_counter += 1
            st.rerun()
    
    # Convert date range to number of days
    days_mapping = {'7D': 7, '14D': 14, '30D': 30, '90D': 90}
    days = days_mapping[st.session_state.date_range]
    
    # Generate mock data based on filters
    production_data = generate_mock_production_data(days)
    defect_types = generate_mock_defect_types()
    system_status = generate_mock_system_status()
    camera_status = generate_mock_camera_status()
    alerts = generate_mock_alerts()
    recent_defects = generate_mock_recent_defects()
    
    # Top metrics row
    def render_metrics():
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            total_production = production_data['production'].sum()
            prev_period_production = total_production * random.uniform(0.95, 1.05)
            delta = f"{int((total_production - prev_period_production) / prev_period_production * 100)}%"
            
            material_metric(
                label="Sandwiches Inspected",
                value=f"{total_production:,}",
                delta=delta,
                key="sandwiches_inspected"
            )
        
        with col2:
            avg_defect_rate = production_data['defect_rate'].mean() * 100
            prev_defect_rate = avg_defect_rate * random.uniform(0.9, 1.1)
            delta = f"{avg_defect_rate - prev_defect_rate:.1f}%"
            delta_color = "inverse" if avg_defect_rate < prev_defect_rate else "normal"
            
            material_metric(
                label="Defect Rate",
                value=f"{avg_defect_rate:.1f}%",
                delta=delta,
                delta_color=delta_color,
                key="defect_rate"
            )
        
        with col3:
            avg_production_per_day = int(production_data['production'].mean())
            production_per_min = int(avg_production_per_day / (60 * 8))  # Assuming 8-hour shifts
            
            material_metric(
                label="Production Speed",
                value=f"{production_per_min} units/min",
                key="production_speed"
            )
        
        with col4:
            uptime = random.uniform(98.5, 99.9)
            prev_uptime = uptime * random.uniform(0.99, 1.01)
            delta = f"{uptime - prev_uptime:.1f}%"
            delta_color = "normal" if uptime > prev_uptime else "inverse"
            
            material_metric(
                label="Uptime",
                value=f"{uptime:.1f}%",
                delta=delta,
                delta_color=delta_color,
                key="uptime"
            )
    
    responsive_container(
        content_func=render_metrics,
        desktop_styles={
            "margin-bottom": "24px"
        },
        mobile_styles={
            "margin-bottom": "16px"
        }
    )
    
    # Main dashboard content
    def render_main_content():
        # Create sidebar for system status
        def sidebar_content():
            st.markdown("## System Status")
            
            # Host System
            host_status = system_status['host']
            status_icon = "check_circle" if host_status['status'] == 'success' else "warning"
            status_color = "var(--color-success-main)" if host_status['status'] == 'success' else "var(--color-warning-main)"
            
            st.markdown(
                f"""
                <div style="display: flex; align-items: center; margin-bottom: 8px;">
                    <span class="material-icons" style="color: {status_color}; margin-right: 8px;">{status_icon}</span>
                    <span style="font-weight: 500;">Host System</span>
                </div>
                """,
                unsafe_allow_html=True
            )
            
            material_progress(host_status['cpu_usage'], label="CPU Usage", show_percentage=True)
            material_progress(host_status['memory_usage'], label="Memory Usage", show_percentage=True)
            material_progress(
                host_status['disk_usage'], 
                label="Disk Usage", 
                show_percentage=True,
                color="warning" if host_status['disk_usage'] > 0.8 else "primary"
            )
            
            st.markdown(f"Temperature: {host_status['temperature']:.1f}°C", unsafe_allow_html=True)
            
            material_divider()
            
            # ADLINK Jetson
            jetson_status = system_status['jetson']
            status_icon = "check_circle" if jetson_status['status'] == 'success' else "warning"
            status_color = "var(--color-success-main)" if jetson_status['status'] == 'success' else "var(--color-warning-main)"
            
            st.markdown(
                f"""
                <div style="display: flex; align-items: center; margin-bottom: 8px;">
                    <span class="material-icons" style="color: {status_color}; margin-right: 8px;">{status_icon}</span>
                    <span style="font-weight: 500;">ADLINK Jetson</span>
                </div>
                """,
                unsafe_allow_html=True
            )
            
            material_progress(
                jetson_status['gpu_usage'], 
                label="GPU Usage", 
                show_percentage=True,
                color="warning" if jetson_status['gpu_usage'] > 0.8 else "primary"
            )
            material_progress(jetson_status['memory_usage'], label="Memory Usage", show_percentage=True)
            
            temp_color = "primary"
            if jetson_status['temperature'] > 80:
                temp_color = "error"
            elif jetson_status['temperature'] > 70:
                temp_color = "warning"
                
            material_progress(
                jetson_status['temperature'] / 100, 
                label="Temperature", 
                show_value=f"{jetson_status['temperature']:.1f}°C",
                color=temp_color
            )
            
            material_divider()
            
            # Database
            db_status = system_status['database']
            status_icon = "check_circle" if db_status['status'] == 'success' else "warning"
            status_color = "var(--color-success-main)" if db_status['status'] == 'success' else "var(--color-warning-main)"
            
            st.markdown(
                f"""
                <div style="display: flex; align-items: center; margin-bottom: 8px;">
                    <span class="material-icons" style="color: {status_color}; margin-right: 8px;">{status_icon}</span>
                    <span style="font-weight: 500;">Database</span>
                </div>
                """,
                unsafe_allow_html=True
            )
            
            st.markdown(f"Active Connections: {db_status['connections']}", unsafe_allow_html=True)
            st.markdown(f"Avg Query Time: {db_status['query_time_ms']:.1f}ms", unsafe_allow_html=True)
            material_progress(db_status['disk_usage'], label="Storage Usage", show_percentage=True)
            
            material_divider()
            
            # Network
            net_status = system_status['network']
            status_icon = "check_circle" if net_status['status'] == 'success' else "warning"
            status_color = "var(--color-success-main)" if net_status['status'] == 'success' else "var(--color-warning-main)"
            
            st.markdown(
                f"""
                <div style="display: flex; align-items: center; margin-bottom: 8px;">
                    <span class="material-icons" style="color: {status_color}; margin-right: 8px;">{status_icon}</span>
                    <span style="font-weight: 500;">Network</span>
                </div>
                """,
                unsafe_allow_html=True
            )
            
            st.markdown(f"Latency: {net_status['latency_ms']:.1f}ms", unsafe_allow_html=True)
            material_progress(
                net_status['bandwidth_usage'], 
                label="Bandwidth Usage", 
                show_percentage=True
            )
            
            # Signal quality indicator
            signal_quality = int(net_status['signal_quality'] * 100)
            st.markdown(
                f"""
                <div style="display: flex; align-items: center; margin-top: 8px;">
                    <span style="margin-right: 8px;">Signal Quality:</span>
                    <div style="display: flex; gap: 2px;">
                        <div style="width: 4px; height: 8px; background-color: var(--color-success-main); border-radius: 1px;"></div>
                        <div style="width: 4px; height: 12px; background-color: var(--color-success-main); border-radius: 1px;"></div>
                        <div style="width: 4px; height: 16px; background-color: var(--color-success-main); border-radius: 1px;"></div>
                        <div style="width: 4px; height: 20px; background-color: {
                            'var(--color-success-main)' if signal_quality >= 80 else 'var(--color-neutral-border)'
                        }; border-radius: 1px;"></div>
                        <div style="width: 4px; height: 24px; background-color: {
                            'var(--color-success-main)' if signal_quality >= 95 else 'var(--color-neutral-border)'
                        }; border-radius: 1px;"></div>
                    </div>
                    <span style="margin-left: 8px;">{signal_quality}%</span>
                </div>
                """,
                unsafe_allow_html=True
            )
            
            material_divider()
            
            # Alert summary
            error_count = len([a for a in alerts if a['type'] == 'error'])
            warning_count = len([a for a in alerts if a['type'] == 'warning'])
            info_count = len([a for a in alerts if a['type'] == 'info'])
            
            st.markdown("## Alerts")
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.markdown(
                    f"""
                    <div style="text-align: center;">
                        <div style="font-size: 24px; font-weight: bold; color: var(--color-error-main);">{error_count}</div>
                        <div style="font-size: 14px; color: var(--color-neutral-main);">Critical</div>
                    </div>
                    """,
                    unsafe_allow_html=True
                )
            
            with col2:
                st.markdown(
                    f"""
                    <div style="text-align: center;">
                        <div style="font-size: 24px; font-weight: bold; color: var(--color-warning-main);">{warning_count}</div>
                        <div style="font-size: 14px; color: var(--color-neutral-main);">Warnings</div>
                    </div>
                    """,
                    unsafe_allow_html=True
                )
            
            with col3:
                st.markdown(
                    f"""
                    <div style="text-align: center;">
                        <div style="font-size: 24px; font-weight: bold; color: var(--color-info-main);">{info_count}</div>
                        <div style="font-size: 14px; color: var(--color-neutral-main);">Info</div>
                    </div>
                    """,
                    unsafe_allow_html=True
                )
            
            # Recent alerts
            st.markdown("### Recent Alerts")
            
            for i, alert in enumerate(alerts[:5]):
                alert_color = "var(--color-error-main)" if alert['type'] == 'error' else \
                             "var(--color-warning-main)" if alert['type'] == 'warning' else \
                             "var(--color-info-main)"
                
                st.markdown(
                    f"""
                    <div style="display: flex; align-items: center; margin-bottom: 8px;">
                        <span class="material-icons" style="color: {alert_color}; margin-right: 8px;">{alert['icon']}</span>
                        <div>
                            <div style="font-weight: 500;">{alert['message']}</div>
                            <div style="font-size: 12px; color: var(--color-neutral-main);">
                                {alert['source']} • {alert['time']}
                            </div>
                        </div>
                    </div>
                    """,
                    unsafe_allow_html=True
                )
            
            view_all_clicked = material_button(
                "View All Alerts",
                icon="notifications",
                type="outlined",
                full_width=True,
                key="view_all_alerts"
            )
            
            if view_all_clicked:
                st.session_state.view_all_alerts_clicked = True
        
        # Create main content area
        close_sidebar = responsive_sidebar(
            content_func=sidebar_content,
            desktop_width="280px",
            tablet_width="240px",
            mobile_width="100%",
            collapsible=True,
            default_collapsed_mobile=True,
            key="system_status_sidebar"
        )
        
        # Main content area (production trends and defect analysis)
        def main_area_content():
            # Production and Defect Trends
            def production_trend_content():
                # Prepare data for plotting
                df = production_data.copy()
                
                # Create tabs for different visualizations
                tab_options = {
                    "Production Volume": lambda: render_production_volume_tab(df),
                    "Defect Rate": lambda: render_defect_rate_tab(df),
                    "Combined View": lambda: render_combined_view_tab(df)
                }
                
                responsive_tabs(
                    tabs=tab_options,
                    desktop_style="horizontal",
                    mobile_style="dropdown",
                    key="production_trend_tabs"
                )
            
            def render_production_volume_tab(df):
                # Create a Plotly figure for production volume
                fig = px.bar(
                    df,
                    x='date',
                    y='production',
                    labels={'production': 'Sandwiches Produced', 'date': 'Date'},
                    title=''
                )
                
                # Customize the layout
                fig.update_layout(
                    height=400,
                    margin=dict(l=20, r=20, t=30, b=20),
                    plot_bgcolor='rgba(0,0,0,0)',
                    paper_bgcolor='rgba(0,0,0,0)',
                    xaxis=dict(
                        showgrid=False,
                        showline=True,
                        linecolor='rgba(0,0,0,0.2)'
                    ),
                    yaxis=dict(
                        showgrid=True,
                        gridcolor='rgba(0,0,0,0.1)',
                        showline=True,
                        linecolor='rgba(0,0,0,0.2)'
                    ),
                    hovermode='x unified'
                )
                
                # Add a trend line
                fig.add_trace(
                    go.Scatter(
                        x=df['date'],
                        y=df['production'].rolling(7).mean(),
                        mode='lines',
                        name='7-Day Average',
                        line=dict(color='rgba(255, 0, 0, 0.7)', width=2)
                    )
                )
                
                st.plotly_chart(fig, use_container_width=True)
                
                # Add interactive controls
                col1, col2 = st.columns(2)
                
                with col1:
                    st.markdown(f"**Average Production:** {int(df['production'].mean()):,} units/day")
                    st.markdown(f"**Total Production:** {int(df['production'].sum()):,} units")
                
                with col2:
                    st.markdown(f"**Highest Day:** {int(df['production'].max()):,} units")
                    st.markdown(f"**Lowest Day:** {int(df['production'].min()):,} units")
            
            def render_defect_rate_tab(df):
                # Create a Plotly figure for defect rate
                fig = px.line(
                    df,
                    x='date',
                    y='defect_rate',
                    labels={'defect_rate': 'Defect Rate', 'date': 'Date'},
                    title=''
                )
                
                # Convert to percentage for display
                fig.update_traces(y=df['defect_rate'] * 100)
                
                # Customize the layout
                fig.update_layout(
                    height=400,
                    margin=dict(l=20, r=20, t=30, b=20),
                    plot_bgcolor='rgba(0,0,0,0)',
                    paper_bgcolor='rgba(0,0,0,0)',
                    xaxis=dict(
                        showgrid=False,
                        showline=True,
                        linecolor='rgba(0,0,0,0.2)'
                    ),
                    yaxis=dict(
                        title='Defect Rate (%)',
                        showgrid=True,
                        gridcolor='rgba(0,0,0,0.1)',
                        showline=True,
                        linecolor='rgba(0,0,0,0.2)'
                    ),
                    hovermode='x unified'
                )
                
                # Add a trend line
                fig.add_trace(
                    go.Scatter(
                        x=df['date'],
                        y=df['defect_rate'].rolling(7).mean() * 100,  # Convert to percentage
                        mode='lines',
                        name='7-Day Average',
                        line=dict(color='rgba(255, 0, 0, 0.7)', width=2)
                    )
                )
                
                # Add threshold line
                fig.add_shape(
                    type="line",
                    x0=df['date'].min(),
                    y0=1.0,  # 1% threshold
                    x1=df['date'].max(),
                    y1=1.0,
                    line=dict(
                        color="rgba(255, 0, 0, 0.5)",
                        width=1,
                        dash="dash",
                    )
                )
                
                fig.add_annotation(
                    x=df['date'].max(),
                    y=1.0,
                    text="Target Threshold (1%)",
                    showarrow=False,
                    yshift=10,
                    font=dict(size=10, color="rgba(255, 0, 0, 0.7)")
                )
                
                st.plotly_chart(fig, use_container_width=True)
                
                # Add interactive controls
                col1, col2 = st.columns(2)
                
                with col1:
                    avg_defect_rate = df['defect_rate'].mean() * 100
                    st.markdown(f"**Average Defect Rate:** {avg_defect_rate:.2f}%")
                    
                    days_above_threshold = sum(df['defect_rate'] > 0.01)
                    st.markdown(f"**Days Above Threshold:** {days_above_threshold}")
                
                with col2:
                    max_defect_rate = df['defect_rate'].max() * 100
                    st.markdown(f"**Highest Defect Rate:** {max_defect_rate:.2f}%")
                    
                    min_defect_rate = df['defect_rate'].min() * 100
                    st.markdown(f"**Lowest Defect Rate:** {min_defect_rate:.2f}%")
            
            def render_combined_view_tab(df):
                # Create a figure with secondary y-axis
                fig = go.Figure()
                
                # Add production volume as bars
                fig.add_trace(
                    go.Bar(
                        x=df['date'],
                        y=df['production'],
                        name='Production Volume',
                        marker_color='rgba(58, 71, 80, 0.6)',
                        yaxis='y'
                    )
                )
                
                # Add defect rate as line on secondary axis
                fig.add_trace(
                    go.Scatter(
                        x=df['date'],
                        y=df['defect_rate'] * 100,  # Convert to percentage
                        name='Defect Rate (%)',
                        marker_color='rgba(246, 78, 139, 1)',
                        yaxis='y2'
                    )
                )
                
                # Customize the layout with two y-axes
                fig.update_layout(
                    height=400,
                    margin=dict(l=20, r=20, t=30, b=20),
                    plot_bgcolor='rgba(0,0,0,0)',
                    paper_bgcolor='rgba(0,0,0,0)',
                    xaxis=dict(
                        title='Date',
                        showgrid=False,
                        showline=True,
                        linecolor='rgba(0,0,0,0.2)'
                    ),
                    yaxis=dict(
                        title='Production Volume',
                        showgrid=True,
                        gridcolor='rgba(0,0,0,0.1)',
                        showline=True,
                        linecolor='rgba(0,0,0,0.2)'
                    ),
                    yaxis2=dict(
                        title='Defect Rate (%)',
                        overlaying='y',
                        side='right',
                        showgrid=False,
                        zeroline=False,
                        showline=True,
                        linecolor='rgba(246, 78, 139, 0.7)'
                    ),
                    legend=dict(
                        orientation="h",
                        yanchor="bottom",
                        y=1.02,
                        xanchor="right",
                        x=1
                    ),
                    hovermode='x unified'
                )
                
                # Add threshold line for defect rate
                fig.add_shape(
                    type="line",
                    x0=df['date'].min(),
                    y0=1.0,  # 1% threshold
                    x1=df['date'].max(),
                    y1=1.0,
                    line=dict(
                        color="rgba(255, 0, 0, 0.5)",
                        width=1,
                        dash="dash",
                    ),
                    yref='y2'
                )
                
                st.plotly_chart(fig, use_container_width=True)
                
                # Correlation analysis
                correlation = df['production'].corr(df['defect_rate'])
                
                st.markdown(f"**Correlation between Production Volume and Defect Rate:** {correlation:.2f}")
                
                if correlation > 0.5:
                    st.markdown("**Analysis:** Strong positive correlation suggests higher production volume may lead to higher defect rates. Consider optimizing production speed.")
                elif correlation > 0.2:
                    st.markdown("**Analysis:** Moderate positive correlation between production volume and defect rates. Monitor closely during high production periods.")
                elif correlation > -0.2:
                    st.markdown("**Analysis:** No significant correlation between production volume and defect rates. Production speed appears well-optimized.")
                else:
                    st.markdown("**Analysis:** Negative correlation suggests defect rates may actually improve with higher production. This could indicate better process stability at higher throughput.")
            
            responsive_card(
                title="Production & Defect Trends",
                subtitle=f"Data for the last {days} days",
                content_func=production_trend_content,
                key="production_trend_card"
            )
            
            # Camera Status and Defect Analysis
            col1, col2 = st.columns(2)
            
            with col1:
                def camera_status_content():
                    # Create tabs for camera views
                    tab_options = {
                        "Status": lambda: render_camera_status_tab(),
                        "Performance": lambda: render_camera_performance_tab()
                    }
                    
                    responsive_tabs(
                        tabs=tab_options,
                        desktop_style="horizontal",
                        mobile_style="dropdown",
                        key="camera_status_tabs"
                    )
                
                def render_camera_status_tab():
                    for camera_name, data in camera_status.items():
                        status_color = "var(--color-success-main)" if data["status"] == "success" else "var(--color-warning-main)"
                        status_icon = "check_circle" if data["status"] == "success" else "warning"
                        
                        st.markdown(
                            f"""
                            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
                                <div style="display: flex; align-items: center;">
                                    <span class="material-icons" style="color: {status_color}; margin-right: 8px;">
                                        {status_icon}
                                    </span>
                                    <span><strong>{camera_name}</strong></span>
                                </div>
                                <div>
                                    <span style="margin-right: 16px;">FPS: {data["fps"]}/{data["max_fps"]}</span>
                                    <span>Signal: {int(data["connection"] * 100)}%</span>
                                </div>
                            </div>
                            """,
                            unsafe_allow_html=True
                        )
                        
                        # Add connection quality bar
                        st.markdown(
                            f"""
                            <div style="height: 4px; background-color: var(--color-neutral-border); border-radius: 2px; margin-bottom: 16px;">
                                <div style="height: 100%; width: {data["connection"] * 100}%; background-color: {status_color}; border-radius: 2px;"></div>
                            </div>
                            """,
                            unsafe_allow_html=True
                        )
                    
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        calibrate_clicked = material_button(
                            "Calibrate Cameras",
                            icon="tune",
                            type="outlined",
                            key="calibrate_cameras"
                        )
                    
                    with col2:
                        view_clicked = material_button(
                            "View All Cameras",
                            icon="visibility",
                            type="outlined",
                            key="view_cameras"
                        )
                    
                    if calibrate_clicked:
                        st.session_state.calibration_clicked = True
                    
                    if view_clicked:
                        st.session_state.view_cameras_clicked = True
                
                def render_camera_performance_tab():
                    # Create sample data for camera performance over time
                    time_points = 24  # Last 24 hours
                    hours = list(range(-time_points + 1, 1))
                    
                    # Sample data for each camera
                    camera_perf_data = {}
                    for camera_name in camera_status.keys():
                        # Base FPS with some random variation
                        base_fps = camera_status[camera_name]['max_fps'] - 1
                        fps_values = []
                        
                        for i in range(time_points):
                            # More variation in the middle of the day
                            time_factor = 1 - abs(hours[i] + 12) / 24
                            variation = random.uniform(-2, 0) * time_factor
                            fps = max(base_fps + variation, base_fps - 3)
                            fps_values.append(fps)
                        
                        camera_perf_data[camera_name] = fps_values
                    
                    # Create a Plotly figure
                    fig = go.Figure()
                    
                    colors = ['rgba(31, 119, 180, 1)', 'rgba(255, 127, 14, 1)', 
                             'rgba(44, 160, 44, 1)', 'rgba(214, 39, 40, 1)']
                    
                    for i, (camera_name, fps_values) in enumerate(camera_perf_data.items()):
                        fig.add_trace(
                            go.Scatter(
                                x=hours,
                                y=fps_values,
                                mode='lines',
                                name=camera_name,
                                line=dict(color=colors[i % len(colors)], width=2)
                            )
                        )
                    
                    # Add threshold line
                    fig.add_shape(
                        type="line",
                        x0=hours[0],
                        y0=18,  # Minimum acceptable FPS
                        x1=hours[-1],
                        y1=18,
                        line=dict(
                            color="rgba(255, 0, 0, 0.5)",
                            width=1,
                            dash="dash",
                        )
                    )
                    
                    # Customize the layout
                    fig.update_layout(
                        height=300,
                        margin=dict(l=20, r=20, t=10, b=20),
                        plot_bgcolor='rgba(0,0,0,0)',
                        paper_bgcolor='rgba(0,0,0,0)',
                        xaxis=dict(
                            title='Hours Ago',
                            showgrid=False,
                            showline=True,
                            linecolor='rgba(0,0,0,0.2)'
                        ),
                        yaxis=dict(
                            title='FPS',
                            showgrid=True,
                            gridcolor='rgba(0,0,0,0.1)',
                            showline=True,
                            linecolor='rgba(0,0,0,0.2)',
                            range=[15, 21]  # Set y-axis range
                        ),
                        legend=dict(
                            orientation="h",
                            yanchor="bottom",
                            y=1.02,
                            xanchor="right",
                            x=1
                        ),
                        hovermode='x unified'
                    )
                    
                    st.plotly_chart(fig, use_container_width=True)
                    
                    # Camera health summary
                    st.markdown("### Camera Health Summary")
                    
                    # Calculate health metrics
                    health_data = []
                    for camera_name, data in camera_status.items():
                        fps_ratio = data['fps'] / data['max_fps']
                        connection_quality = data['connection']
                        
                        # Overall health score (0-100)
                        health_score = int((fps_ratio * 0.6 + connection_quality * 0.4) * 100)
                        
                        health_data.append({
                            'camera': camera_name,
                            'health_score': health_score,
                            'status': 'Good' if health_score >= 90 else 'Fair' if health_score >= 75 else 'Poor'
                        })
                    
                    # Create a simple table
                    for item in health_data:
                        status_color = "var(--color-success-main)" if item['status'] == 'Good' else \
                                      "var(--color-warning-main)" if item['status'] == 'Fair' else \
                                      "var(--color-error-main)"
                        
                        st.markdown(
                            f"""
                            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                                <span>{item['camera']}</span>
                                <div>
                                    <span style="margin-right: 8px;">{item['health_score']}%</span>
                                    <span style="color: {status_color};">{item['status']}</span>
                                </div>
                            </div>
                            """,
                            unsafe_allow_html=True
                        )
                
                responsive_card(
                    title="Camera System",
                    content_func=camera_status_content,
                    key="camera_status_card"
                )
            
            with col2:
                def defect_analysis_content():
                    # Create tabs for defect analysis
                    tab_options = {
                        "Distribution": lambda: render_defect_distribution_tab(),
                        "Recent Defects": lambda: render_recent_defects_tab()
                    }
                    
                    responsive_tabs(
                        tabs=tab_options,
                        desktop_style="horizontal",
                        mobile_style="dropdown",
                        key="defect_analysis_tabs"
                    )
                
                def render_defect_distribution_tab():
                    # Create a Plotly pie chart for defect distribution
                    defect_df = pd.DataFrame({
                        'Defect Type': list(defect_types.keys()),
                        'Count': list(defect_types.values())
                    })
                    
                    fig = px.pie(
                        defect_df,
                        values='Count',
                        names='Defect Type',
                        hole=0.4,
                        color_discrete_sequence=px.colors.qualitative.Set3
                    )
                    
                    # Customize the layout
                    fig.update_layout(
                        height=300,
                        margin=dict(l=20, r=20, t=10, b=10),
                        legend=dict(
                            orientation="h",
                            yanchor="bottom",
                            y=-0.2,
                            xanchor="center",
                            x=0.5
                        )
                    )
                    
                    st.plotly_chart(fig, use_container_width=True)
                    
                    # Add interactive filters
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        st.selectbox(
                            "Group By",
                            ["Defect Type", "Camera", "Shift", "Product"],
                            key="group_by_defect"
                        )
                    
                    with col2:
                        st.selectbox(
                            "Time Period",
                            ["Today", "Yesterday", "This Week", "This Month"],
                            key="time_period_defect"
                        )
                    
                    # Add defect insights
                    st.markdown("### Key Insights")
                    
                    # Find the most common defect
                    most_common_defect = max(defect_types.items(), key=lambda x: x[1])[0]
                    most_common_pct = defect_types[most_common_defect] / sum(defect_types.values()) * 100
                    
                    st.markdown(f"• Most common defect: **{most_common_defect}** ({most_common_pct:.1f}%)")
                    
                    # Calculate trend (random for demo)
                    trend_direction = random.choice(["increasing", "decreasing", "stable"])
                    trend_defect = random.choice(list(defect_types.keys()))
                    
                    st.markdown(f"• **{trend_defect}** defects are {trend_direction}")
                    
                    # Random insight
                    insights = [
                        "Defects are more common during shift changes",
                        "Temperature fluctuations correlate with increased defect rates",
                        "Line 2 shows 15% higher defect rates than other lines",
                        "Defect patterns suggest calibration may be needed"
                    ]
                    
                    st.markdown(f"• {random.choice(insights)}")
                
                def render_recent_defects_tab():
                    # Create a table header
                    st.markdown(
                        """
                        <div style="display: grid; grid-template-columns: 1fr 1.5fr 1fr 1fr; gap: 8px; margin-bottom: 8px; font-weight: bold;">
                            <div>Time</div>
                            <div>Type</div>
                            <div>Confidence</div>
                            <div>Camera</div>
                        </div>
                        <div style="height: 1px; background-color: var(--color-neutral-border); margin-bottom: 8px;"></div>
                        """,
                        unsafe_allow_html=True
                    )
                    
                    # Create table rows
                    for defect in recent_defects:
                        # Determine color based on defect type
                        color = "var(--color-error-main)"
                        if defect["type"] == "Missing Filling":
                            color = "var(--color-warning-main)"
                        elif defect["type"] == "Uneven Cut":
                            color = "var(--color-info-main)"
                        elif defect["type"] == "Crust Present":
                            color = "var(--color-secondary-main)"
                        elif defect["type"] == "Foreign Object":
                            color = "var(--color-error-main)"
                        
                        st.markdown(
                            f"""
                            <div style="display: grid; grid-template-columns: 1fr 1.5fr 1fr 1fr; gap: 8px; margin-bottom: 12px; align-items: center;">
                                <div>{defect["time"]}</div>
                                <div>
                                    <span style="display: inline-block; width: 10px; height: 10px; border-radius: 50%; background-color: {color}; margin-right: 6px;"></span>
                                    {defect["type"]}
                                </div>
                                <div>{defect["confidence"]}</div>
                                <div>{defect["camera"]}</div>
                            </div>
                            """,
                            unsafe_allow_html=True
                        )
                    
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        view_all_clicked = material_button(
                            "View All Defects",
                            icon="list",
                            type="outlined",
                            key="view_all_defects"
                        )
                    
                    with col2:
                        export_clicked = material_button(
                            "Export Data",
                            icon="download",
                            type="outlined",
                            key="export_defects"
                        )
                    
                    if view_all_clicked:
                        st.session_state.view_all_defects_clicked = True
                    
                    if export_clicked:
                        st.session_state.export_defects_clicked = True
                
                responsive_card(
                    title="Defect Analysis",
                    content_func=defect_analysis_content,
                    key="defect_analysis_card"
                )
            
            # Quick Actions
            def quick_actions_content():
                # Create a grid of action cards
                def render_action_cards():
                    action_cards = [
                        {
                            "title": "Camera Calibration",
                            "icon": "camera",
                            "description": "Run camera calibration procedure",
                            "button_text": "Calibrate",
                            "key": "calibration_action"
                        },
                        {
                            "title": "System Maintenance",
                            "icon": "build",
                            "description": "Run system diagnostics and maintenance",
                            "button_text": "Run Diagnostics",
                            "key": "maintenance_action"
                        },
                        {
                            "title": "Generate Report",
                            "icon": "description",
                            "description": "Create a daily production report",
                            "button_text": "Generate",
                            "key": "report_action"
                        },
                        {
                            "title": "Model Retraining",
                            "icon": "psychology",
                            "description": "Retrain AI model with latest data",
                            "button_text": "Retrain Model",
                            "key": "retrain_action"
                        }
                    ]
                    
                    def create_card(card_data):
                        st.markdown(
                            f"""
                            <div style="padding: 16px; border: 1px solid var(--color-neutral-border); border-radius: 8px; height: 100%;">
                                <div style="display: flex; align-items: center; margin-bottom: 8px;">
                                    <span class="material-icons" style="color: var(--color-primary-main); margin-right: 8px;">{card_data['icon']}</span>
                                    <span style="font-weight: 500;">{card_data['title']}</span>
                                </div>
                                <p style="font-size: 14px; margin-bottom: 16px;">{card_data['description']}</p>
                            """,
                            unsafe_allow_html=True
                        )
                        
                        button_clicked = material_button(
                            card_data['button_text'],
                            type="contained",
                            size="small",
                            full_width=True,
                            key=card_data['key']
                        )
                        
                        st.markdown("</div>", unsafe_allow_html=True)
                        
                        return button_clicked
                    
                    # Create a responsive grid for the action cards
                    responsive_grid(
                        items=[lambda card=card: create_card(card) for card in action_cards],
                        desktop_columns=4,
                        tablet_columns=2,
                        mobile_columns=1,
                        gap="16px",
                        key="quick_actions_grid"
                    )
                
                render_action_cards()
                
                # Handle button clicks
                if "calibration_action" in st.session_state and st.session_state.calibration_action:
                    material_alert("Camera calibration started! This will take approximately 2 minutes.", severity="info")
                    st.session_state.calibration_action = False
                
                if "maintenance_action" in st.session_state and st.session_state.maintenance_action:
                    material_alert("System diagnostics started! This will take approximately 5 minutes.", severity="info")
                    st.session_state.maintenance_action = False
                
                if "report_action" in st.session_state and st.session_state.report_action:
                    material_alert("Report generation started! The report will be available in the Reports section when complete.", severity="info")
                    st.session_state.report_action = False
                
                if "retrain_action" in st.session_state and st.session_state.retrain_action:
                    material_alert("Model retraining started! This process will run in the background and may take up to 30 minutes.", severity="info")
                    st.session_state.retrain_action = False
            
            responsive_card(
                title="Quick Actions",
                content_func=quick_actions_content,
                key="quick_actions_card"
            )
        
        main_area_content()
        
        # Close the sidebar container
        close_sidebar()
    
    render_main_content()
    
    # Handle action button clicks from other components
    if "calibration_clicked" in st.session_state and st.session_state.calibration_clicked:
        material_alert("Camera calibration started! This will take approximately 2 minutes.", severity="info")
        st.session_state.calibration_clicked = False
    
    if "view_cameras_clicked" in st.session_state and st.session_state.view_cameras_clicked:
        material_alert("Redirecting to camera view page...", severity="info")
        st.session_state.view_cameras_clicked = False
    
    if "view_all_defects_clicked" in st.session_state and st.session_state.view_all_defects_clicked:
        material_alert("Redirecting to defect analysis page...", severity="info")
        st.session_state.view_all_defects_clicked = False
    
    if "export_defects_clicked" in st.session_state and st.session_state.export_defects_clicked:
        material_alert("Exporting defect data to CSV...", severity="info")
        st.session_state.export_defects_clicked = False
    
    if "view_all_alerts_clicked" in st.session_state and st.session_state.view_all_alerts_clicked:
        material_alert("Redirecting to alerts page...", severity="info")
        st.session_state.view_all_alerts_clicked = False

if __name__ == "__main__":
    st.set_page_config(
        page_title="Crustless Creations QC Dashboard",
        page_icon="🥪",
        layout="wide",
        initial_sidebar_state="expanded"
    )
    render_interactive_dashboard()
