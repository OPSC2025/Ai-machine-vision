"""
Enhanced camera view module for the OPSC Sandwich Quality Inspection System.

This module provides an improved camera view interface with real-time monitoring,
camera controls, calibration tools, and image analysis features.
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
import time
import random
import json
import cv2
import io
import base64
from PIL import Image, ImageDraw, ImageFont
import sys
import os

# Add the parent directory to the path so we can import our components
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ui.components.material_ui import (
    load_material_icons, material_button, material_card, material_metric,
    material_tabs, material_data_table, material_progress, material_alert,
    material_badge, material_icon_button, material_divider, material_chip,
    material_select, material_text_field, material_checkbox, material_radio,
    material_slider, material_date_picker
)
from ui.components.theme_provider import apply_design_system_to_page
from ui.components.responsive_layout import (
    responsive_container, responsive_grid, responsive_columns, responsive_card,
    responsive_sidebar, responsive_table, responsive_tabs, responsive_image,
    responsive_menu, responsive_video
)

# Mock data generation functions
def generate_mock_camera_settings():
    """Generate mock camera settings for demonstration."""
    camera_settings = {
        'Top Camera': {
            'exposure': 15000,  # microseconds
            'gain': 5.0,        # dB
            'brightness': 50,   # percentage
            'contrast': 25,     # percentage
            'saturation': 50,   # percentage
            'white_balance': 5200,  # Kelvin
            'fps': 20,          # frames per second
            'resolution': '2448×2048',
            'format': 'MJPEG',
            'trigger_mode': 'Continuous',
            'ip_address': '192.168.1.101',
            'serial': 'BSL-A2500-20gc-0001'
        },
        'Side Camera 1': {
            'exposure': 12000,
            'gain': 4.5,
            'brightness': 45,
            'contrast': 30,
            'saturation': 50,
            'white_balance': 5000,
            'fps': 20,
            'resolution': '2448×2048',
            'format': 'MJPEG',
            'trigger_mode': 'Continuous',
            'ip_address': '192.168.1.102',
            'serial': 'BSL-A2500-20gc-0002'
        },
        'Side Camera 2': {
            'exposure': 12500,
            'gain': 4.8,
            'brightness': 48,
            'contrast': 28,
            'saturation': 50,
            'white_balance': 5100,
            'fps': 20,
            'resolution': '2448×2048',
            'format': 'MJPEG',
            'trigger_mode': 'Continuous',
            'ip_address': '192.168.1.103',
            'serial': 'BSL-A2500-20gc-0003'
        },
        'Bottom Camera': {
            'exposure': 14000,
            'gain': 5.2,
            'brightness': 52,
            'contrast': 26,
            'saturation': 50,
            'white_balance': 5150,
            'fps': 20,
            'resolution': '2448×2048',
            'format': 'MJPEG',
            'trigger_mode': 'Continuous',
            'ip_address': '192.168.1.104',
            'serial': 'BSL-A2500-20gc-0004'
        }
    }
    
    return camera_settings

def generate_mock_camera_status():
    """Generate mock camera status data."""
    cameras = {
        'Top Camera': {
            'status': 'success',
            'fps': random.randint(18, 20),
            'max_fps': 20,
            'connection': random.uniform(0.9, 1.0),
            'temperature': random.uniform(35, 45),
            'uptime': random.randint(120, 480)  # minutes
        },
        'Side Camera 1': {
            'status': 'warning' if random.random() < 0.2 else 'success',
            'fps': random.randint(16, 20),
            'max_fps': 20,
            'connection': random.uniform(0.7, 0.95),
            'temperature': random.uniform(35, 50),
            'uptime': random.randint(120, 480)
        },
        'Side Camera 2': {
            'status': 'success',
            'fps': random.randint(18, 20),
            'max_fps': 20,
            'connection': random.uniform(0.85, 1.0),
            'temperature': random.uniform(35, 45),
            'uptime': random.randint(120, 480)
        },
        'Bottom Camera': {
            'status': 'success',
            'fps': random.randint(18, 20),
            'max_fps': 20,
            'connection': random.uniform(0.8, 1.0),
            'temperature': random.uniform(35, 45),
            'uptime': random.randint(120, 480)
        }
    }
    
    return cameras

def generate_mock_camera_image(camera_name, width=640, height=480, with_defect=False, defect_type=None):
    """Generate a mock camera image with optional defect overlay."""
    # Create a blank image
    img = np.ones((height, width, 3), dtype=np.uint8) * 240
    
    # Add a sandwich-like shape
    center_x, center_y = width // 2, height // 2
    sandwich_width, sandwich_height = int(width * 0.7), int(height * 0.4)
    
    # Draw sandwich bread (light brown rectangle with rounded corners)
    cv2.rectangle(
        img,
        (center_x - sandwich_width // 2, center_y - sandwich_height // 2),
        (center_x + sandwich_width // 2, center_y + sandwich_height // 2),
        (210, 230, 250),  # Light brown color
        -1
    )
    
    # Add some texture to the bread
    for _ in range(100):
        x = random.randint(center_x - sandwich_width // 2, center_x + sandwich_width // 2)
        y = random.randint(center_y - sandwich_height // 2, center_y + sandwich_height // 2)
        radius = random.randint(1, 3)
        color = (200, 220, 240)  # Slightly darker spots
        cv2.circle(img, (x, y), radius, color, -1)
    
    # Add filling (darker rectangle)
    filling_width, filling_height = int(sandwich_width * 0.9), int(sandwich_height * 0.6)
    cv2.rectangle(
        img,
        (center_x - filling_width // 2, center_y - filling_height // 2),
        (center_x + filling_width // 2, center_y + filling_height // 2),
        (100, 140, 180),  # Darker color for filling
        -1
    )
    
    # Add camera name and timestamp
    font = cv2.FONT_HERSHEY_SIMPLEX
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cv2.putText(img, camera_name, (10, 30), font, 0.7, (0, 0, 0), 2)
    cv2.putText(img, timestamp, (width - 200, height - 20), font, 0.5, (0, 0, 0), 1)
    
    # Add a grid pattern to simulate calibration markers
    grid_spacing = 50
    grid_color = (220, 220, 220)
    for x in range(0, width, grid_spacing):
        cv2.line(img, (x, 0), (x, height), grid_color, 1)
    for y in range(0, height, grid_spacing):
        cv2.line(img, (0, y), (width, y), grid_color, 1)
    
    # Add defect if requested
    if with_defect:
        if defect_type is None:
            defect_types = ['Missing Filling', 'Uneven Cut', 'Crust Present', 'Foreign Object', 'Discoloration']
            defect_type = random.choice(defect_types)
        
        if defect_type == 'Missing Filling':
            # Create a gap in the filling
            gap_width = int(filling_width * 0.3)
            gap_x = random.randint(center_x - filling_width // 2, center_x + filling_width // 2 - gap_width)
            cv2.rectangle(
                img,
                (gap_x, center_y - filling_height // 2),
                (gap_x + gap_width, center_y + filling_height // 2),
                (210, 230, 250),  # Same as bread color
                -1
            )
            
            # Add bounding box and label
            cv2.rectangle(
                img,
                (gap_x - 5, center_y - filling_height // 2 - 5),
                (gap_x + gap_width + 5, center_y + filling_height // 2 + 5),
                (0, 0, 255),  # Red
                2
            )
            cv2.putText(img, "Missing Filling", (gap_x, center_y - filling_height // 2 - 10), 
                       font, 0.5, (0, 0, 255), 1)
            
        elif defect_type == 'Uneven Cut':
            # Draw jagged edge
            edge_x = center_x + sandwich_width // 2
            points = []
            for y in range(center_y - sandwich_height // 2, center_y + sandwich_height // 2, 10):
                offset = random.randint(-15, 5)
                points.append((edge_x + offset, y))
            
            # Connect points to form jagged edge
            for i in range(len(points) - 1):
                cv2.line(img, points[i], points[i+1], (210, 230, 250), 2)
            
            # Fill the area
            min_x = min(p[0] for p in points)
            max_x = max(p[0] for p in points)
            min_y = min(p[1] for p in points)
            max_y = max(p[1] for p in points)
            
            # Add bounding box and label
            cv2.rectangle(
                img,
                (edge_x - 5, min_y - 5),
                (max_x + 5, max_y + 5),
                (0, 255, 0),  # Green
                2
            )
            cv2.putText(img, "Uneven Cut", (edge_x - 80, min_y - 10), 
                       font, 0.5, (0, 255, 0), 1)
            
        elif defect_type == 'Crust Present':
            # Add brown crust-like area
            crust_y = center_y - sandwich_height // 2
            crust_height = int(sandwich_height * 0.15)
            cv2.rectangle(
                img,
                (center_x - sandwich_width // 2, crust_y),
                (center_x + sandwich_width // 2, crust_y + crust_height),
                (90, 120, 150),  # Darker brown for crust
                -1
            )
            
            # Add bounding box and label
            cv2.rectangle(
                img,
                (center_x - sandwich_width // 2 - 5, crust_y - 5),
                (center_x + sandwich_width // 2 + 5, crust_y + crust_height + 5),
                (255, 0, 0),  # Blue
                2
            )
            cv2.putText(img, "Crust Present", (center_x - sandwich_width // 2, crust_y - 10), 
                       font, 0.5, (255, 0, 0), 1)
            
        elif defect_type == 'Foreign Object':
            # Add a small foreign object
            object_x = random.randint(center_x - filling_width // 3, center_x + filling_width // 3)
            object_y = random.randint(center_y - filling_height // 3, center_y + filling_height // 3)
            object_size = random.randint(5, 10)
            
            # Draw the foreign object
            cv2.circle(img, (object_x, object_y), object_size, (0, 0, 0), -1)
            
            # Add bounding box and label
            cv2.rectangle(
                img,
                (object_x - object_size - 5, object_y - object_size - 5),
                (object_x + object_size + 5, object_y + object_size + 5),
                (0, 0, 255),  # Red
                2
            )
            cv2.putText(img, "Foreign Object", (object_x - object_size - 5, object_y - object_size - 10), 
                       font, 0.5, (0, 0, 255), 1)
            
        elif defect_type == 'Discoloration':
            # Add discolored area
            discolor_x = random.randint(center_x - filling_width // 3, center_x + filling_width // 3)
            discolor_y = random.randint(center_y - filling_height // 3, center_y + filling_height // 3)
            discolor_size = random.randint(15, 30)
            
            # Draw the discoloration
            cv2.circle(img, (discolor_x, discolor_y), discolor_size, (100, 100, 220), -1)
            
            # Add bounding box and label
            cv2.rectangle(
                img,
                (discolor_x - discolor_size - 5, discolor_y - discolor_size - 5),
                (discolor_x + discolor_size + 5, discolor_y + discolor_size + 5),
                (255, 165, 0),  # Orange
                2
            )
            cv2.putText(img, "Discoloration", (discolor_x - discolor_size - 5, discolor_y - discolor_size - 10), 
                       font, 0.5, (255, 165, 0), 1)
    
    # Convert to PIL Image
    img_pil = Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
    
    return img_pil

def get_image_base64(pil_img):
    """Convert PIL image to base64 string for HTML embedding."""
    buffered = io.BytesIO()
    pil_img.save(buffered, format="JPEG")
    img_str = base64.b64encode(buffered.getvalue()).decode()
    return img_str

def render_enhanced_camera_view():
    """Render the enhanced camera view interface."""
    
    # Apply design system to the page
    apply_design_system_to_page("Camera System")
    
    # Load Material Icons
    load_material_icons()
    
    # Initialize session state for camera view if not exists
    if 'selected_camera' not in st.session_state:
        st.session_state.selected_camera = 'Top Camera'
    
    if 'show_defects' not in st.session_state:
        st.session_state.show_defects = False
    
    if 'calibration_mode' not in st.session_state:
        st.session_state.calibration_mode = False
    
    if 'refresh_counter' not in st.session_state:
        st.session_state.refresh_counter = 0
    
    # Generate mock data
    camera_settings = generate_mock_camera_settings()
    camera_status = generate_mock_camera_status()
    
    # Page header
    st.markdown(
        """
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <div>
                <h1 style="margin-bottom: 0;">Camera System</h1>
                <p style="margin-top: 0; color: var(--color-neutral-main);">Crustless Creations - Camera Monitoring & Control</p>
            </div>
        </div>
        """,
        unsafe_allow_html=True
    )
    
    # Top action bar
    col1, col2, col3, col4 = st.columns([3, 2, 2, 1])
    
    with col1:
        # Camera selector
        camera_options = list(camera_settings.keys())
        selected_camera = material_select(
            "Camera",
            options=camera_options,
            default=st.session_state.selected_camera,
            key="camera_selector"
        )
        
        # Update session state based on selection
        st.session_state.selected_camera = selected_camera
    
    with col2:
        # View mode selector
        view_mode = material_select(
            "View Mode",
            options=["Live Feed", "Defect Detection", "Calibration", "Thermal View"],
            default="Live Feed",
            key="view_mode_selector"
        )
        
        # Update calibration mode based on selection
        st.session_state.calibration_mode = (view_mode == "Calibration")
        st.session_state.show_defects = (view_mode == "Defect Detection")
    
    with col3:
        # Resolution selector
        resolution = material_select(
            "Resolution",
            options=["Full (2448×2048)", "HD (1920×1080)", "Medium (1280×720)", "Low (640×480)"],
            default="HD (1920×1080)",
            key="resolution_selector"
        )
    
    with col4:
        # Refresh button
        refresh_clicked = material_button(
            "Refresh",
            icon="refresh",
            type="outlined",
            key="refresh_camera"
        )
        
        if refresh_clicked:
            st.session_state.refresh_counter += 1
            st.rerun()
    
    # Main camera view layout
    def render_main_content():
        # Create sidebar for camera controls
        def sidebar_content():
            st.markdown("## Camera Controls")
            
            # Camera status indicator
            camera_data = camera_status[st.session_state.selected_camera]
            status_icon = "check_circle" if camera_data["status"] == "success" else "warning"
            status_color = "var(--color-success-main)" if camera_data["status"] == "success" else "var(--color-warning-main)"
            
            st.markdown(
                f"""
                <div style="display: flex; align-items: center; margin-bottom: 16px;">
                    <span class="material-icons" style="color: {status_color}; margin-right: 8px; font-size: 24px;">
                        {status_icon}
                    </span>
                    <div>
                        <div style="font-weight: 500;">{st.session_state.selected_camera}</div>
                        <div style="font-size: 12px; color: var(--color-neutral-main);">
                            Status: {
                                "Online" if camera_data["status"] == "success" else "Warning"
                            }
                        </div>
                    </div>
                </div>
                """,
                unsafe_allow_html=True
            )
            
            # Camera performance metrics
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown(f"**FPS:** {camera_data['fps']}/{camera_data['max_fps']}")
                st.markdown(f"**Temp:** {camera_data['temperature']:.1f}°C")
            
            with col2:
                st.markdown(f"**Signal:** {int(camera_data['connection'] * 100)}%")
                st.markdown(f"**Uptime:** {camera_data['uptime']} min")
            
            material_divider()
            
            # Camera settings controls
            st.markdown("### Image Settings")
            
            # Exposure control
            exposure = st.slider(
                "Exposure (μs)",
                min_value=5000,
                max_value=30000,
                value=camera_settings[st.session_state.selected_camera]['exposure'],
                step=1000,
                key="exposure_slider"
            )
            
            # Gain control
            gain = st.slider(
                "Gain (dB)",
                min_value=0.0,
                max_value=10.0,
                value=camera_settings[st.session_state.selected_camera]['gain'],
                step=0.1,
                key="gain_slider"
            )
            
            # Brightness control
            brightness = st.slider(
                "Brightness",
                min_value=0,
                max_value=100,
                value=camera_settings[st.session_state.selected_camera]['brightness'],
                step=1,
                key="brightness_slider"
            )
            
            # Contrast control
            contrast = st.slider(
                "Contrast",
                min_value=0,
                max_value=100,
                value=camera_settings[st.session_state.selected_camera]['contrast'],
                step=1,
                key="contrast_slider"
            )
            
            # White balance control
            white_balance = st.slider(
                "White Balance (K)",
                min_value=2500,
                max_value=8000,
                value=camera_settings[st.session_state.selected_camera]['white_balance'],
                step=100,
                key="white_balance_slider"
            )
            
            material_divider()
            
            # Camera configuration
            st.markdown("### Camera Configuration")
            
            # Trigger mode
            trigger_mode = st.selectbox(
                "Trigger Mode",
                options=["Continuous", "Software Trigger", "Hardware Trigger", "Line Trigger"],
                index=0,
                key="trigger_mode_selector"
            )
            
            # Frame rate
            fps = st.slider(
                "Frame Rate (FPS)",
                min_value=1,
                max_value=30,
                value=camera_settings[st.session_state.selected_camera]['fps'],
                step=1,
                key="fps_slider"
            )
            
            material_divider()
            
            # Action buttons
            col1, col2 = st.columns(2)
            
            with col1:
                save_clicked = material_button(
                    "Save Settings",
                    icon="save",
                    type="contained",
                    key="save_settings"
                )
            
            with col2:
                reset_clicked = material_button(
                    "Reset Defaults",
                    icon="restart_alt",
                    type="outlined",
                    key="reset_defaults"
                )
            
            # Capture image button
            capture_clicked = material_button(
                "Capture Image",
                icon="photo_camera",
                type="contained",
                full_width=True,
                key="capture_image"
            )
            
            # Handle button clicks
            if save_clicked:
                st.session_state.save_clicked = True
            
            if reset_clicked:
                st.session_state.reset_clicked = True
            
            if capture_clicked:
                st.session_state.capture_clicked = True
            
            material_divider()
            
            # Camera information
            st.markdown("### Camera Information")
            
            info_items = [
                ("Model", "Basler acA2500-20gc"),
                ("Serial", camera_settings[st.session_state.selected_camera]['serial']),
                ("Resolution", camera_settings[st.session_state.selected_camera]['resolution']),
                ("Format", camera_settings[st.session_state.selected_camera]['format']),
                ("IP Address", camera_settings[st.session_state.selected_camera]['ip_address']),
                ("Firmware", "1.5.0"),
                ("Driver", "Pylon 7.4.0")
            ]
            
            for label, value in info_items:
                st.markdown(
                    f"""
                    <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
                        <span style="color: var(--color-neutral-main);">{label}:</span>
                        <span style="font-weight: 500;">{value}</span>
                    </div>
                    """,
                    unsafe_allow_html=True
                )
        
        # Create main content area
        close_sidebar = responsive_sidebar(
            content_func=sidebar_content,
            desktop_width="300px",
            tablet_width="250px",
            mobile_width="100%",
            collapsible=True,
            default_collapsed_mobile=True,
            key="camera_controls_sidebar"
        )
        
        # Main content area (camera feed and analysis)
        def main_area_content():
            # Camera feed card
            def camera_feed_content():
                # Generate a mock camera image
                with_defect = st.session_state.show_defects and random.random() < 0.7
                defect_type = random.choice(['Missing Filling', 'Uneven Cut', 'Crust Present', 'Foreign Object', 'Discoloration']) if with_defect else None
                
                # Parse resolution
                resolution_map = {
                    "Full (2448×2048)": (2448, 2048),
                    "HD (1920×1080)": (1920, 1080),
                    "Medium (1280×720)": (1280, 720),
                    "Low (640×480)": (640, 480)
                }
                
                width, height = resolution_map.get(resolution, (1280, 720))
                
                # Generate image based on view mode
                if view_mode == "Calibration":
                    # In calibration mode, show grid pattern
                    img = generate_mock_camera_image(st.session_state.selected_camera, width, height, False)
                    
                    # Add calibration overlay
                    draw = ImageDraw.Draw(img)
                    
                    # Draw center crosshair
                    center_x, center_y = width // 2, height // 2
                    crosshair_size = min(width, height) // 20
                    
                    draw.line((center_x - crosshair_size, center_y, center_x + crosshair_size, center_y), fill=(255, 0, 0), width=2)
                    draw.line((center_x, center_y - crosshair_size, center_x, center_y + crosshair_size), fill=(255, 0, 0), width=2)
                    
                    # Draw calibration points
                    point_radius = 5
                    margin = 100
                    points = [
                        (margin, margin),
                        (width - margin, margin),
                        (width - margin, height - margin),
                        (margin, height - margin),
                        (width // 2, margin),
                        (width - margin, height // 2),
                        (width // 2, height - margin),
                        (margin, height // 2)
                    ]
                    
                    for point in points:
                        draw.ellipse((point[0] - point_radius, point[1] - point_radius, 
                                     point[0] + point_radius, point[1] + point_radius), 
                                    fill=(0, 0, 255))
                    
                    # Add calibration text
                    draw.text((10, 10), "CALIBRATION MODE", fill=(255, 0, 0))
                    draw.text((10, height - 30), "Align markers with calibration points", fill=(255, 0, 0))
                    
                elif view_mode == "Thermal View":
                    # Create a thermal-like view
                    img = Image.new('RGB', (width, height), (0, 0, 0))
                    draw = ImageDraw.Draw(img)
                    
                    # Generate a thermal-like pattern
                    for x in range(0, width, 10):
                        for y in range(0, height, 10):
                            # Distance from center
                            dx = (x - width // 2) / (width // 2)
                            dy = (y - height // 2) / (height // 2)
                            distance = (dx**2 + dy**2)**0.5
                            
                            # Temperature decreases with distance from center
                            temp = max(0, min(255, int(255 * (1 - distance * 0.8 + random.uniform(-0.1, 0.1)))))
                            
                            # Map temperature to color (blue to red)
                            if temp < 85:
                                color = (0, 0, temp * 3)
                            elif temp < 170:
                                color = (0, (temp - 85) * 3, 255 - (temp - 85) * 3)
                            else:
                                color = ((temp - 170) * 3, 255 - (temp - 170) * 3, 0)
                            
                            # Draw a small rectangle for each point
                            draw.rectangle((x, y, x + 9, y + 9), fill=color)
                    
                    # Add temperature scale
                    scale_width = 20
                    scale_height = height - 40
                    scale_x = width - scale_width - 20
                    scale_y = 20
                    
                    for i in range(scale_height):
                        temp = 255 - int(i / scale_height * 255)
                        
                        if temp < 85:
                            color = (0, 0, temp * 3)
                        elif temp < 170:
                            color = (0, (temp - 85) * 3, 255 - (temp - 85) * 3)
                        else:
                            color = ((temp - 170) * 3, 255 - (temp - 170) * 3, 0)
                        
                        draw.line((scale_x, scale_y + i, scale_x + scale_width, scale_y + i), fill=color)
                    
                    # Add temperature labels
                    draw.text((scale_x - 25, scale_y), "Hot", fill=(255, 255, 255))
                    draw.text((scale_x - 35, scale_y + scale_height - 10), "Cold", fill=(255, 255, 255))
                    
                    # Add camera name and timestamp
                    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    draw.text((10, 10), st.session_state.selected_camera, fill=(255, 255, 255))
                    draw.text((10, 40), "THERMAL VIEW", fill=(255, 255, 255))
                    draw.text((width - 200, height - 30), timestamp, fill=(255, 255, 255))
                    
                else:
                    # Regular or defect detection view
                    img = generate_mock_camera_image(st.session_state.selected_camera, width, height, with_defect, defect_type)
                
                # Convert image to base64 for embedding
                img_base64 = get_image_base64(img)
                
                # Display the image with responsive sizing
                st.markdown(
                    f"""
                    <div style="text-align: center; margin-bottom: 16px;">
                        <img src="data:image/jpeg;base64,{img_base64}" 
                             style="max-width: 100%; height: auto; border: 1px solid var(--color-neutral-border);" />
                    </div>
                    """,
                    unsafe_allow_html=True
                )
                
                # Camera controls below the image
                col1, col2, col3, col4 = st.columns(4)
                
                with col1:
                    material_icon_button(
                        icon="zoom_in",
                        tooltip="Zoom In",
                        key="zoom_in_button"
                    )
                
                with col2:
                    material_icon_button(
                        icon="zoom_out",
                        tooltip="Zoom Out",
                        key="zoom_out_button"
                    )
                
                with col3:
                    material_icon_button(
                        icon="fit_screen",
                        tooltip="Fit to Screen",
                        key="fit_screen_button"
                    )
                
                with col4:
                    material_icon_button(
                        icon="fullscreen",
                        tooltip="Fullscreen",
                        key="fullscreen_button"
                    )
                
                # Display defect information if in defect detection mode and defect is present
                if st.session_state.show_defects and with_defect:
                    confidence = random.uniform(0.85, 0.99)
                    
                    material_alert(
                        f"Defect Detected: {defect_type} (Confidence: {confidence:.0%})",
                        severity="warning",
                        icon="warning",
                        key="defect_alert"
                    )
                
                # Display calibration instructions if in calibration mode
                if st.session_state.calibration_mode:
                    material_alert(
                        "Calibration Mode: Align the markers with the calibration points and click 'Run Calibration'",
                        severity="info",
                        icon="info",
                        key="calibration_alert"
                    )
                    
                    calibrate_clicked = material_button(
                        "Run Calibration",
                        icon="tune",
                        type="contained",
                        key="run_calibration"
                    )
                    
                    if calibrate_clicked:
                        st.session_state.run_calibration_clicked = True
            
            responsive_card(
                title=f"{st.session_state.selected_camera} - {view_mode}",
                subtitle=f"Resolution: {resolution}",
                content_func=camera_feed_content,
                key="camera_feed_card"
            )
            
            # Camera analytics and history
            col1, col2 = st.columns(2)
            
            with col1:
                def camera_analytics_content():
                    # Create tabs for different analytics
                    tab_options = {
                        "Performance": lambda: render_performance_tab(),
                        "Defect History": lambda: render_defect_history_tab()
                    }
                    
                    responsive_tabs(
                        tabs=tab_options,
                        desktop_style="horizontal",
                        mobile_style="dropdown",
                        key="camera_analytics_tabs"
                    )
                
                def render_performance_tab():
                    # Create sample data for camera performance over time
                    time_points = 24  # Last 24 hours
                    hours = list(range(-time_points + 1, 1))
                    
                    # Sample FPS data
                    base_fps = camera_status[st.session_state.selected_camera]['max_fps'] - 1
                    fps_values = []
                    
                    for i in range(time_points):
                        # More variation in the middle of the day
                        time_factor = 1 - abs(hours[i] + 12) / 24
                        variation = random.uniform(-2, 0) * time_factor
                        fps = max(base_fps + variation, base_fps - 3)
                        fps_values.append(fps)
                    
                    # Create a Plotly figure
                    fig = go.Figure()
                    
                    fig.add_trace(
                        go.Scatter(
                            x=hours,
                            y=fps_values,
                            mode='lines',
                            name='FPS',
                            line=dict(color='rgba(31, 119, 180, 1)', width=2)
                        )
                    )
                    
                    # Add threshold line
                    fig.add_shape(
                        type="line",
                        x0=hours[0],
                        y0=18,  # Minimum acceptable FPS
                        x1=hours[-1],
                        y1=18,
                        line=dict(
                            color="rgba(255, 0, 0, 0.5)",
                            width=1,
                            dash="dash",
                        )
                    )
                    
                    # Customize the layout
                    fig.update_layout(
                        height=250,
                        margin=dict(l=20, r=20, t=10, b=20),
                        plot_bgcolor='rgba(0,0,0,0)',
                        paper_bgcolor='rgba(0,0,0,0)',
                        xaxis=dict(
                            title='Hours Ago',
                            showgrid=False,
                            showline=True,
                            linecolor='rgba(0,0,0,0.2)'
                        ),
                        yaxis=dict(
                            title='FPS',
                            showgrid=True,
                            gridcolor='rgba(0,0,0,0.1)',
                            showline=True,
                            linecolor='rgba(0,0,0,0.2)',
                            range=[15, 21]  # Set y-axis range
                        ),
                        hovermode='x unified'
                    )
                    
                    st.plotly_chart(fig, use_container_width=True)
                    
                    # Performance metrics
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        st.markdown(f"**Avg FPS:** {sum(fps_values) / len(fps_values):.1f}")
                        st.markdown(f"**Min FPS:** {min(fps_values):.1f}")
                    
                    with col2:
                        st.markdown(f"**Max FPS:** {max(fps_values):.1f}")
                        st.markdown(f"**Target FPS:** {camera_status[st.session_state.selected_camera]['max_fps']}")
                    
                    # Temperature data
                    temp_values = []
                    for i in range(time_points):
                        base_temp = camera_status[st.session_state.selected_camera]['temperature']
                        time_factor = 1 - abs(hours[i] + 12) / 24
                        variation = random.uniform(-5, 5) * time_factor
                        temp = max(base_temp + variation, 30)
                        temp_values.append(temp)
                    
                    # Create a Plotly figure for temperature
                    fig2 = go.Figure()
                    
                    fig2.add_trace(
                        go.Scatter(
                            x=hours,
                            y=temp_values,
                            mode='lines',
                            name='Temperature',
                            line=dict(color='rgba(214, 39, 40, 1)', width=2)
                        )
                    )
                    
                    # Add threshold line
                    fig2.add_shape(
                        type="line",
                        x0=hours[0],
                        y0=70,  # Warning temperature
                        x1=hours[-1],
                        y1=70,
                        line=dict(
                            color="rgba(255, 165, 0, 0.5)",
                            width=1,
                            dash="dash",
                        )
                    )
                    
                    # Add critical threshold line
                    fig2.add_shape(
                        type="line",
                        x0=hours[0],
                        y0=80,  # Critical temperature
                        x1=hours[-1],
                        y1=80,
                        line=dict(
                            color="rgba(255, 0, 0, 0.5)",
                            width=1,
                            dash="dash",
                        )
                    )
                    
                    # Customize the layout
                    fig2.update_layout(
                        height=250,
                        margin=dict(l=20, r=20, t=10, b=20),
                        plot_bgcolor='rgba(0,0,0,0)',
                        paper_bgcolor='rgba(0,0,0,0)',
                        xaxis=dict(
                            title='Hours Ago',
                            showgrid=False,
                            showline=True,
                            linecolor='rgba(0,0,0,0.2)'
                        ),
                        yaxis=dict(
                            title='Temperature (°C)',
                            showgrid=True,
                            gridcolor='rgba(0,0,0,0.1)',
                            showline=True,
                            linecolor='rgba(0,0,0,0.2)'
                        ),
                        hovermode='x unified'
                    )
                    
                    st.plotly_chart(fig2, use_container_width=True)
                    
                    # Temperature metrics
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        st.markdown(f"**Avg Temp:** {sum(temp_values) / len(temp_values):.1f}°C")
                        st.markdown(f"**Min Temp:** {min(temp_values):.1f}°C")
                    
                    with col2:
                        st.markdown(f"**Max Temp:** {max(temp_values):.1f}°C")
                        st.markdown(f"**Warning Temp:** 70°C")
                
                def render_defect_history_tab():
                    # Generate sample defect history data
                    defect_types = ['Missing Filling', 'Uneven Cut', 'Crust Present', 'Foreign Object', 'Discoloration']
                    defect_counts = {}
                    
                    for defect_type in defect_types:
                        defect_counts[defect_type] = random.randint(5, 50)
                    
                    # Create a Plotly bar chart
                    defect_df = pd.DataFrame({
                        'Defect Type': list(defect_counts.keys()),
                        'Count': list(defect_counts.values())
                    })
                    
                    fig = px.bar(
                        defect_df,
                        x='Defect Type',
                        y='Count',
                        color='Count',
                        color_continuous_scale='Viridis',
                        title=''
                    )
                    
                    # Customize the layout
                    fig.update_layout(
                        height=250,
                        margin=dict(l=20, r=20, t=10, b=20),
                        plot_bgcolor='rgba(0,0,0,0)',
                        paper_bgcolor='rgba(0,0,0,0)',
                        xaxis=dict(
                            title='',
                            showgrid=False,
                            showline=True,
                            linecolor='rgba(0,0,0,0.2)'
                        ),
                        yaxis=dict(
                            title='Count',
                            showgrid=True,
                            gridcolor='rgba(0,0,0,0.1)',
                            showline=True,
                            linecolor='rgba(0,0,0,0.2)'
                        ),
                        coloraxis_showscale=False
                    )
                    
                    st.plotly_chart(fig, use_container_width=True)
                    
                    # Defect metrics
                    total_defects = sum(defect_counts.values())
                    most_common_defect = max(defect_counts.items(), key=lambda x: x[1])[0]
                    
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        st.markdown(f"**Total Defects:** {total_defects}")
                        st.markdown(f"**Most Common:** {most_common_defect}")
                    
                    with col2:
                        st.markdown(f"**Detection Rate:** {random.uniform(0.92, 0.99):.1%}")
                        st.markdown(f"**False Positives:** {random.uniform(0.01, 0.05):.1%}")
                    
                    # Recent defects table
                    st.markdown("### Recent Defects")
                    
                    # Generate sample recent defects
                    recent_defects = []
                    for i in range(5):
                        defect_type = random.choices(
                            defect_types, 
                            weights=[defect_counts[t] for t in defect_types],
                            k=1
                        )[0]
                        
                        minutes_ago = i * random.randint(5, 15)
                        confidence = random.uniform(0.85, 0.99)
                        
                        recent_defects.append({
                            'time': (datetime.now() - timedelta(minutes=minutes_ago)).strftime('%H:%M:%S'),
                            'type': defect_type,
                            'confidence': f"{confidence:.0%}"
                        })
                    
                    # Create a table
                    for defect in recent_defects:
                        st.markdown(
                            f"""
                            <div style="display: flex; justify-content: space-between; margin-bottom: 8px; padding: 4px 0; border-bottom: 1px solid var(--color-neutral-border);">
                                <span>{defect['time']}</span>
                                <span>{defect['type']}</span>
                                <span>{defect['confidence']}</span>
                            </div>
                            """,
                            unsafe_allow_html=True
                        )
                
                responsive_card(
                    title="Camera Analytics",
                    content_func=camera_analytics_content,
                    key="camera_analytics_card"
                )
            
            with col2:
                def camera_history_content():
                    # Create tabs for different history views
                    tab_options = {
                        "Recent Images": lambda: render_recent_images_tab(),
                        "Event Log": lambda: render_event_log_tab()
                    }
                    
                    responsive_tabs(
                        tabs=tab_options,
                        desktop_style="horizontal",
                        mobile_style="dropdown",
                        key="camera_history_tabs"
                    )
                
                def render_recent_images_tab():
                    # Generate sample recent images
                    num_images = 6
                    recent_images = []
                    
                    for i in range(num_images):
                        # Randomly decide if this image has a defect
                        with_defect = random.random() < 0.3
                        defect_type = random.choice(['Missing Filling', 'Uneven Cut', 'Crust Present', 'Foreign Object', 'Discoloration']) if with_defect else None
                        
                        # Generate a small thumbnail image
                        img = generate_mock_camera_image(st.session_state.selected_camera, 320, 240, with_defect, defect_type)
                        img_base64 = get_image_base64(img)
                        
                        # Generate timestamp
                        minutes_ago = i * random.randint(1, 5)
                        timestamp = (datetime.now() - timedelta(minutes=minutes_ago)).strftime('%H:%M:%S')
                        
                        recent_images.append({
                            'image': img_base64,
                            'timestamp': timestamp,
                            'has_defect': with_defect,
                            'defect_type': defect_type
                        })
                    
                    # Display images in a grid
                    cols = st.columns(3)
                    
                    for i, img_data in enumerate(recent_images):
                        with cols[i % 3]:
                            # Display image
                            st.markdown(
                                f"""
                                <div style="margin-bottom: 16px;">
                                    <img src="data:image/jpeg;base64,{img_data['image']}" 
                                         style="width: 100%; border: 1px solid var(--color-neutral-border); border-radius: 4px;" />
                                    <div style="display: flex; justify-content: space-between; margin-top: 4px; font-size: 12px;">
                                        <span>{img_data['timestamp']}</span>
                                        {
                                            f'<span style="color: var(--color-warning-main);">{img_data["defect_type"]}</span>'
                                            if img_data['has_defect'] else
                                            '<span style="color: var(--color-success-main);">No Defect</span>'
                                        }
                                    </div>
                                </div>
                                """,
                                unsafe_allow_html=True
                            )
                    
                    # View all button
                    view_all_clicked = material_button(
                        "View All Images",
                        icon="photo_library",
                        type="outlined",
                        full_width=True,
                        key="view_all_images"
                    )
                    
                    if view_all_clicked:
                        st.session_state.view_all_images_clicked = True
                
                def render_event_log_tab():
                    # Generate sample event log
                    event_types = [
                        {'type': 'info', 'icon': 'info', 'color': 'var(--color-info-main)'},
                        {'type': 'warning', 'icon': 'warning', 'color': 'var(--color-warning-main)'},
                        {'type': 'error', 'icon': 'error', 'color': 'var(--color-error-main)'},
                        {'type': 'success', 'icon': 'check_circle', 'color': 'var(--color-success-main)'}
                    ]
                    
                    event_messages = [
                        {'type': 'info', 'message': 'Camera connected'},
                        {'type': 'info', 'message': 'Stream started'},
                        {'type': 'warning', 'message': 'FPS dropped below threshold'},
                        {'type': 'error', 'message': 'Connection lost temporarily'},
                        {'type': 'success', 'message': 'Connection restored'},
                        {'type': 'info', 'message': 'Settings updated'},
                        {'type': 'warning', 'message': 'Temperature approaching threshold'},
                        {'type': 'info', 'message': 'Calibration performed'},
                        {'type': 'success', 'message': 'Defect detection enabled'},
                        {'type': 'error', 'message': 'Failed to save image'},
                        {'type': 'info', 'message': 'Resolution changed'},
                        {'type': 'warning', 'message': 'Low disk space for image storage'}
                    ]
                    
                    # Generate random events
                    num_events = 15
                    events = []
                    
                    for i in range(num_events):
                        event = random.choice(event_messages)
                        event_type = next(t for t in event_types if t['type'] == event['type'])
                        
                        minutes_ago = i * random.randint(2, 10)
                        timestamp = (datetime.now() - timedelta(minutes=minutes_ago)).strftime('%H:%M:%S')
                        
                        events.append({
                            'timestamp': timestamp,
                            'message': event['message'],
                            'icon': event_type['icon'],
                            'color': event_type['color']
                        })
                    
                    # Sort by timestamp (most recent first)
                    events.sort(key=lambda x: x['timestamp'], reverse=True)
                    
                    # Display events
                    for event in events:
                        st.markdown(
                            f"""
                            <div style="display: flex; align-items: center; margin-bottom: 8px; padding: 4px 0; border-bottom: 1px solid var(--color-neutral-border);">
                                <span class="material-icons" style="color: {event['color']}; margin-right: 8px; font-size: 18px;">
                                    {event['icon']}
                                </span>
                                <div style="flex-grow: 1;">
                                    <div>{event['message']}</div>
                                    <div style="font-size: 12px; color: var(--color-neutral-main);">{event['timestamp']}</div>
                                </div>
                            </div>
                            """,
                            unsafe_allow_html=True
                        )
                    
                    # Export log button
                    export_clicked = material_button(
                        "Export Log",
                        icon="download",
                        type="outlined",
                        full_width=True,
                        key="export_log"
                    )
                    
                    if export_clicked:
                        st.session_state.export_log_clicked = True
                
                responsive_card(
                    title="Camera History",
                    content_func=camera_history_content,
                    key="camera_history_card"
                )
            
            # Camera actions
            def camera_actions_content():
                # Create a grid of action buttons
                col1, col2, col3, col4 = st.columns(4)
                
                with col1:
                    calibrate_clicked = material_button(
                        "Calibrate Camera",
                        icon="tune",
                        type="outlined",
                        full_width=True,
                        key="calibrate_camera_action"
                    )
                
                with col2:
                    test_clicked = material_button(
                        "Run Diagnostics",
                        icon="build",
                        type="outlined",
                        full_width=True,
                        key="run_diagnostics_action"
                    )
                
                with col3:
                    record_clicked = material_button(
                        "Record Video",
                        icon="videocam",
                        type="outlined",
                        full_width=True,
                        key="record_video_action"
                    )
                
                with col4:
                    export_clicked = material_button(
                        "Export Settings",
                        icon="settings",
                        type="outlined",
                        full_width=True,
                        key="export_settings_action"
                    )
                
                # Handle button clicks
                if calibrate_clicked:
                    st.session_state.calibrate_camera_clicked = True
                
                if test_clicked:
                    st.session_state.run_diagnostics_clicked = True
                
                if record_clicked:
                    st.session_state.record_video_clicked = True
                
                if export_clicked:
                    st.session_state.export_settings_clicked = True
            
            responsive_card(
                title="Camera Actions",
                content_func=camera_actions_content,
                key="camera_actions_card"
            )
        
        main_area_content()
        
        # Close the sidebar container
        close_sidebar()
    
    render_main_content()
    
    # Handle action button clicks from other components
    if "save_clicked" in st.session_state and st.session_state.save_clicked:
        material_alert("Camera settings saved successfully!", severity="success")
        st.session_state.save_clicked = False
    
    if "reset_clicked" in st.session_state and st.session_state.reset_clicked:
        material_alert("Camera settings reset to defaults.", severity="info")
        st.session_state.reset_clicked = False
    
    if "capture_clicked" in st.session_state and st.session_state.capture_clicked:
        material_alert("Image captured and saved to gallery.", severity="success")
        st.session_state.capture_clicked = False
    
    if "run_calibration_clicked" in st.session_state and st.session_state.run_calibration_clicked:
        material_alert("Camera calibration completed successfully!", severity="success")
        st.session_state.run_calibration_clicked = False
    
    if "calibrate_camera_clicked" in st.session_state and st.session_state.calibrate_camera_clicked:
        material_alert("Switching to calibration mode...", severity="info")
        st.session_state.calibration_mode = True
        st.session_state.calibrate_camera_clicked = False
        st.rerun()
    
    if "run_diagnostics_clicked" in st.session_state and st.session_state.run_diagnostics_clicked:
        material_alert("Running camera diagnostics. This will take approximately 30 seconds.", severity="info")
        st.session_state.run_diagnostics_clicked = False
    
    if "record_video_clicked" in st.session_state and st.session_state.record_video_clicked:
        material_alert("Video recording started. Click again to stop recording.", severity="info")
        st.session_state.record_video_clicked = False
    
    if "export_settings_clicked" in st.session_state and st.session_state.export_settings_clicked:
        material_alert("Camera settings exported to file.", severity="success")
        st.session_state.export_settings_clicked = False
    
    if "view_all_images_clicked" in st.session_state and st.session_state.view_all_images_clicked:
        material_alert("Redirecting to image gallery...", severity="info")
        st.session_state.view_all_images_clicked = False
    
    if "export_log_clicked" in st.session_state and st.session_state.export_log_clicked:
        material_alert("Event log exported to file.", severity="success")
        st.session_state.export_log_clicked = False

if __name__ == "__main__":
    st.set_page_config(
        page_title="Crustless Creations Camera System",
        page_icon="🎥",
        layout="wide",
        initial_sidebar_state="expanded"
    )
    render_enhanced_camera_view()
