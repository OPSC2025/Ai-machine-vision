"""
Backend integration for the OPSC Sandwich Quality Inspection System UI.

This module provides comprehensive integration between the UI components and backend systems including:
- API client for backend communication
- Data fetching and caching
- Real-time updates
- Authentication integration
- Error handling
- Form submission
"""

import streamlit as st
import pandas as pd
import numpy as np
import json
import requests
import time
import sys
import os
import threading
import queue
import logging
from datetime import datetime, timedelta
import base64
import io
from PIL import Image
import traceback

# Add the parent directory to the path so we can import our components
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('backend_integration')

# API Client for backend communication
class APIClient:
    """Client for communicating with the backend API."""
    
    def __init__(self, base_url=None):
        """
        Initialize the API client.
        
        Parameters:
        - base_url: Base URL for the API. If None, will use the URL from session state or environment.
        """
        self.base_url = base_url or self._get_base_url()
        self.session = requests.Session()
        self.auth_token = self._get_auth_token()
        
        if self.auth_token:
            self.session.headers.update({
                'Authorization': f'Bearer {self.auth_token}'
            })
        
        self.session.headers.update({
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        })
    
    def _get_base_url(self):
        """Get the base URL from session state or environment."""
        if 'api_base_url' in st.session_state:
            return st.session_state.api_base_url
        
        # Default to localhost if not specified
        return os.environ.get('API_BASE_URL', 'http://localhost:8000/api')
    
    def _get_auth_token(self):
        """Get the authentication token from session state."""
        if 'auth_token' in st.session_state:
            return st.session_state.auth_token
        
        return None
    
    def set_auth_token(self, token):
        """
        Set the authentication token.
        
        Parameters:
        - token: JWT token for authentication
        """
        self.auth_token = token
        st.session_state.auth_token = token
        
        self.session.headers.update({
            'Authorization': f'Bearer {token}'
        })
    
    def clear_auth_token(self):
        """Clear the authentication token."""
        self.auth_token = None
        
        if 'auth_token' in st.session_state:
            del st.session_state.auth_token
        
        if 'Authorization' in self.session.headers:
            del self.session.headers['Authorization']
    
    def get(self, endpoint, params=None, timeout=10):
        """
        Make a GET request to the API.
        
        Parameters:
        - endpoint: API endpoint (without base URL)
        - params: Query parameters
        - timeout: Request timeout in seconds
        
        Returns:
        - Response data as dictionary
        
        Raises:
        - APIError: If the request fails
        """
        url = f"{self.base_url}/{endpoint.lstrip('/')}"
        
        try:
            response = self.session.get(url, params=params, timeout=timeout)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"API GET request failed: {str(e)}")
            raise APIError(f"API request failed: {str(e)}", response=getattr(e, 'response', None))
    
    def post(self, endpoint, data=None, json=None, timeout=10):
        """
        Make a POST request to the API.
        
        Parameters:
        - endpoint: API endpoint (without base URL)
        - data: Form data
        - json: JSON data
        - timeout: Request timeout in seconds
        
        Returns:
        - Response data as dictionary
        
        Raises:
        - APIError: If the request fails
        """
        url = f"{self.base_url}/{endpoint.lstrip('/')}"
        
        try:
            response = self.session.post(url, data=data, json=json, timeout=timeout)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"API POST request failed: {str(e)}")
            raise APIError(f"API request failed: {str(e)}", response=getattr(e, 'response', None))
    
    def put(self, endpoint, data=None, json=None, timeout=10):
        """
        Make a PUT request to the API.
        
        Parameters:
        - endpoint: API endpoint (without base URL)
        - data: Form data
        - json: JSON data
        - timeout: Request timeout in seconds
        
        Returns:
        - Response data as dictionary
        
        Raises:
        - APIError: If the request fails
        """
        url = f"{self.base_url}/{endpoint.lstrip('/')}"
        
        try:
            response = self.session.put(url, data=data, json=json, timeout=timeout)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"API PUT request failed: {str(e)}")
            raise APIError(f"API request failed: {str(e)}", response=getattr(e, 'response', None))
    
    def delete(self, endpoint, timeout=10):
        """
        Make a DELETE request to the API.
        
        Parameters:
        - endpoint: API endpoint (without base URL)
        - timeout: Request timeout in seconds
        
        Returns:
        - Response data as dictionary
        
        Raises:
        - APIError: If the request fails
        """
        url = f"{self.base_url}/{endpoint.lstrip('/')}"
        
        try:
            response = self.session.delete(url, timeout=timeout)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"API DELETE request failed: {str(e)}")
            raise APIError(f"API request failed: {str(e)}", response=getattr(e, 'response', None))
    
    def upload_file(self, endpoint, file_path, file_param='file', additional_data=None, timeout=30):
        """
        Upload a file to the API.
        
        Parameters:
        - endpoint: API endpoint (without base URL)
        - file_path: Path to the file to upload
        - file_param: Name of the file parameter
        - additional_data: Additional form data
        - timeout: Request timeout in seconds
        
        Returns:
        - Response data as dictionary
        
        Raises:
        - APIError: If the request fails
        """
        url = f"{self.base_url}/{endpoint.lstrip('/')}"
        
        try:
            with open(file_path, 'rb') as f:
                files = {file_param: f}
                response = self.session.post(url, files=files, data=additional_data, timeout=timeout)
                response.raise_for_status()
                return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"API file upload failed: {str(e)}")
            raise APIError(f"API file upload failed: {str(e)}", response=getattr(e, 'response', None))
        except IOError as e:
            logger.error(f"File read error: {str(e)}")
            raise APIError(f"File read error: {str(e)}")
    
    def download_file(self, endpoint, save_path, params=None, timeout=30):
        """
        Download a file from the API.
        
        Parameters:
        - endpoint: API endpoint (without base URL)
        - save_path: Path to save the downloaded file
        - params: Query parameters
        - timeout: Request timeout in seconds
        
        Returns:
        - Path to the downloaded file
        
        Raises:
        - APIError: If the request fails
        """
        url = f"{self.base_url}/{endpoint.lstrip('/')}"
        
        try:
            response = self.session.get(url, params=params, timeout=timeout, stream=True)
            response.raise_for_status()
            
            with open(save_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)
            
            return save_path
        except requests.exceptions.RequestException as e:
            logger.error(f"API file download failed: {str(e)}")
            raise APIError(f"API file download failed: {str(e)}", response=getattr(e, 'response', None))
        except IOError as e:
            logger.error(f"File write error: {str(e)}")
            raise APIError(f"File write error: {str(e)}")

class APIError(Exception):
    """Exception raised for API errors."""
    
    def __init__(self, message, response=None):
        """
        Initialize the exception.
        
        Parameters:
        - message: Error message
        - response: Response object from the failed request
        """
        self.message = message
        self.response = response
        self.status_code = getattr(response, 'status_code', None) if response else None
        self.response_text = getattr(response, 'text', None) if response else None
        
        # Try to parse response JSON
        self.response_json = None
        if response and hasattr(response, 'text'):
            try:
                self.response_json = response.json()
            except:
                pass
        
        super().__init__(self.message)

# Data fetching and caching
class DataFetcher:
    """Class for fetching and caching data from the backend."""
    
    def __init__(self, api_client=None):
        """
        Initialize the data fetcher.
        
        Parameters:
        - api_client: APIClient instance
        """
        self.api_client = api_client or APIClient()
        self.cache = {}
        self.cache_expiry = {}
        self.default_ttl = 60  # Default cache TTL in seconds
    
    def get_data(self, endpoint, params=None, ttl=None, force_refresh=False):
        """
        Get data from the API with caching.
        
        Parameters:
        - endpoint: API endpoint
        - params: Query parameters
        - ttl: Cache time-to-live in seconds (None to use default)
        - force_refresh: Whether to force a refresh from the API
        
        Returns:
        - Data from the API
        """
        cache_key = self._get_cache_key(endpoint, params)
        
        # Check if data is in cache and not expired
        if not force_refresh and cache_key in self.cache:
            if cache_key not in self.cache_expiry or self.cache_expiry[cache_key] > time.time():
                return self.cache[cache_key]
        
        # Fetch data from API
        data = self.api_client.get(endpoint, params=params)
        
        # Cache the data
        self.cache[cache_key] = data
        
        # Set cache expiry
        if ttl is not None:
            self.cache_expiry[cache_key] = time.time() + ttl
        elif ttl is not None:
            self.cache_expiry[cache_key] = time.time() + self.default_ttl
        
        return data
    
    def post_data(self, endpoint, data=None, json=None, invalidate_endpoints=None):
        """
        Post data to the API and invalidate related cache entries.
        
        Parameters:
        - endpoint: API endpoint
        - data: Form data
        - json: JSON data
        - invalidate_endpoints: List of endpoints to invalidate from cache
        
        Returns:
        - Response from the API
        """
        response = self.api_client.post(endpoint, data=data, json=json)
        
        # Invalidate cache for specified endpoints
        if invalidate_endpoints:
            for ep in invalidate_endpoints:
                self._invalidate_endpoint(ep)
        
        return response
    
    def put_data(self, endpoint, data=None, json=None, invalidate_endpoints=None):
        """
        Put data to the API and invalidate related cache entries.
        
        Parameters:
        - endpoint: API endpoint
        - data: Form data
        - json: JSON data
        - invalidate_endpoints: List of endpoints to invalidate from cache
        
        Returns:
        - Response from the API
        """
        response = self.api_client.put(endpoint, data=data, json=json)
        
        # Invalidate cache for specified endpoints
        if invalidate_endpoints:
            for ep in invalidate_endpoints:
                self._invalidate_endpoint(ep)
        
        return response
    
    def delete_data(self, endpoint, invalidate_endpoints=None):
        """
        Delete data from the API and invalidate related cache entries.
        
        Parameters:
        - endpoint: API endpoint
        - invalidate_endpoints: List of endpoints to invalidate from cache
        
        Returns:
        - Response from the API
        """
        response = self.api_client.delete(endpoint)
        
        # Invalidate cache for specified endpoints
        if invalidate_endpoints:
            for ep in invalidate_endpoints:
                self._invalidate_endpoint(ep)
        
        return response
    
    def clear_cache(self):
        """Clear the entire cache."""
        self.cache = {}
        self.cache_expiry = {}
    
    def _get_cache_key(self, endpoint, params):
        """
        Generate a cache key for the given endpoint and parameters.
        
        Parameters:
        - endpoint: API endpoint
        - params: Query parameters
        
        Returns:
        - Cache key string
        """
        if params:
            # Sort params to ensure consistent keys
            sorted_params = sorted(params.items())
            return f"{endpoint}:{json.dumps(sorted_params)}"
        
        return endpoint
    
    def _invalidate_endpoint(self, endpoint):
        """
        Invalidate all cache entries for the given endpoint.
        
        Parameters:
        - endpoint: API endpoint to invalidate
        """
        keys_to_remove = []
        
        for key in self.cache.keys():
            if key.startswith(f"{endpoint}:") or key == endpoint:
                keys_to_remove.append(key)
        
        for key in keys_to_remove:
            if key in self.cache:
                del self.cache[key]
            
            if key in self.cache_expiry:
                del self.cache_expiry[key]

# Real-time updates
class RealtimeUpdater:
    """Class for handling real-time updates from the backend."""
    
    def __init__(self, api_client=None, update_interval=5):
        """
        Initialize the real-time updater.
        
        Parameters:
        - api_client: APIClient instance
        - update_interval: Update interval in seconds
        """
        self.api_client = api_client or APIClient()
        self.update_interval = update_interval
        self.subscriptions = {}
        self.running = False
        self.update_thread = None
        self.update_queue = queue.Queue()
    
    def start(self):
        """Start the real-time updater."""
        if self.running:
            return
        
        self.running = True
        self.update_thread = threading.Thread(target=self._update_loop, daemon=True)
        self.update_thread.start()
    
    def stop(self):
        """Stop the real-time updater."""
        self.running = False
        if self.update_thread:
            self.update_thread.join(timeout=1)
            self.update_thread = None
    
    def subscribe(self, endpoint, callback, params=None):
        """
        Subscribe to updates for an endpoint.
        
        Parameters:
        - endpoint: API endpoint to subscribe to
        - callback: Function to call with updated data
        - params: Query parameters for the endpoint
        
        Returns:
        - Subscription ID
        """
        subscription_id = f"{endpoint}:{id(callback)}"
        
        self.subscriptions[subscription_id] = {
            'endpoint': endpoint,
            'callback': callback,
            'params': params,
            'last_update': 0
        }
        
        return subscription_id
    
    def unsubscribe(self, subscription_id):
        """
        Unsubscribe from updates.
        
        Parameters:
        - subscription_id: Subscription ID to unsubscribe
        """
        if subscription_id in self.subscriptions:
            del self.subscriptions[subscription_id]
    
    def _update_loop(self):
        """Background thread for fetching updates."""
        while self.running:
            try:
                current_time = time.time()
                
                # Check each subscription
                for sub_id, subscription in list(self.subscriptions.items()):
                    # Check if it's time to update
                    if current_time - subscription['last_update'] >= self.update_interval:
                        try:
                            # Fetch updated data
                            data = self.api_client.get(
                                subscription['endpoint'],
                                params=subscription['params']
                            )
                            
                            # Update last update time
                            subscription['last_update'] = current_time
                            
                            # Queue the callback
                            self.update_queue.put((subscription['callback'], data))
                        except Exception as e:
                            logger.error(f"Error updating subscription {sub_id}: {str(e)}")
                
                # Sleep for a short time
                time.sleep(0.1)
            except Exception as e:
                logger.error(f"Error in update loop: {str(e)}")
                time.sleep(1)
    
    def process_updates(self):
        """
        Process any pending updates.
        This should be called from the main thread.
        """
        try:
            while not self.update_queue.empty():
                callback, data = self.update_queue.get_nowait()
                try:
                    callback(data)
                except Exception as e:
                    logger.error(f"Error in update callback: {str(e)}")
                self.update_queue.task_done()
        except Exception as e:
            logger.error(f"Error processing updates: {str(e)}")

# Authentication integration
class AuthManager:
    """Class for managing authentication with the backend."""
    
    def __init__(self, api_client=None):
        """
        Initialize the authentication manager.
        
        Parameters:
        - api_client: APIClient instance
        """
        self.api_client = api_client or APIClient()
    
    def login(self, username, password):
        """
        Log in to the backend.
        
        Parameters:
        - username: Username
        - password: Password
        
        Returns:
        - True if login successful, False otherwise
        """
        try:
            response = self.api_client.post('auth/login', json={
                'username': username,
                'password': password
            })
            
            if 'token' in response:
                self.api_client.set_auth_token(response['token'])
                
                # Store user info in session state
                if 'user' in response:
                    st.session_state.user = response['user']
                
                return True
            
            return False
        except APIError as e:
            logger.error(f"Login failed: {str(e)}")
            return False
    
    def logout(self):
        """
        Log out from the backend.
        
        Returns:
        - True if logout successful, False otherwise
        """
        try:
            # Clear token from API client
            self.api_client.clear_auth_token()
            
            # Clear user info from session state
            if 'user' in st.session_state:
                del st.session_state.user
            
            return True
        except Exception as e:
            logger.error(f"Logout failed: {str(e)}")
            return False
    
    def is_authenticated(self):
        """
        Check if the user is authenticated.
        
        Returns:
        - True if authenticated, False otherwise
        """
        return self.api_client.auth_token is not None
    
    def get_current_user(self):
        """
        Get the current user information.
        
        Returns:
        - User information dictionary, or None if not authenticated
        """
        if not self.is_authenticated():
            return None
        
        if 'user' in st.session_state:
            return st.session_state.user
        
        try:
            user = self.api_client.get('auth/user')
            st.session_state.user = user
            return user
        except APIError:
            return None
    
    def has_permission(self, permission):
        """
        Check if the current user has a specific permission.
        
        Parameters:
        - permission: Permission to check
        
        Returns:
        - True if the user has the permission, False otherwise
        """
        user = self.get_current_user()
        
        if not user:
            return False
        
        # Check if user has the permission
        if 'permissions' in user:
            return permission in user['permissions']
        
        # Check if user has a role with the permission
        if 'roles' in user:
            for role in user['roles']:
                if 'permissions' in role and permission in role['permissions']:
                    return True
        
        return False
    
    def require_authentication(self):
        """
        Require authentication to access the current page.
        If not authenticated, redirect to login page.
        
        Returns:
        - True if authenticated, False otherwise
        """
        if not self.is_authenticated():
            st.warning("Please log in to access this page.")
            
            # Show login form
            with st.form("login_form"):
                username = st.text_input("Username")
                password = st.text_input("Password", type="password")
                submit = st.form_submit_button("Log In")
                
                if submit:
                    if self.login(username, password):
                        st.success("Login successful!")
                        st.rerun()
                    else:
                        st.error("Invalid username or password.")
            
            return False
        
        return True
    
    def require_permission(self, permission):
        """
        Require a specific permission to access the current page.
        If not authenticated or doesn't have the permission, show an error.
        
        Parameters:
        - permission: Permission to require
        
        Returns:
        - True if has permission, False otherwise
        """
        if not self.require_authentication():
            return False
        
        if not self.has_permission(permission):
            st.error(f"You don't have permission to access this page.")
            return False
        
        return True

# Form submission
class FormManager:
    """Class for managing form submissions to the backend."""
    
    def __init__(self, api_client=None):
        """
        Initialize the form manager.
        
        Parameters:
        - api_client: APIClient instance
        """
        self.api_client = api_client or APIClient()
    
    def submit_form(self, endpoint, form_data, method='post', success_message=None, error_message=None):
        """
        Submit a form to the backend.
        
        Parameters:
        - endpoint: API endpoint
        - form_data: Form data dictionary
        - method: HTTP method ('post' or 'put')
        - success_message: Message to show on success
        - error_message: Message to show on error
        
        Returns:
        - Response data if successful, None otherwise
        """
        try:
            if method.lower() == 'post':
                response = self.api_client.post(endpoint, json=form_data)
            elif method.lower() == 'put':
                response = self.api_client.put(endpoint, json=form_data)
            else:
                raise ValueError(f"Unsupported method: {method}")
            
            if success_message:
                st.success(success_message)
            
            return response
        except APIError as e:
            error_msg = error_message or f"Form submission failed: {str(e)}"
            
            # Try to extract error details from response
            if e.response_json and 'detail' in e.response_json:
                error_msg += f": {e.response_json['detail']}"
            
            st.error(error_msg)
            return None
    
    def validate_form(self, form_data, validation_rules):
        """
        Validate form data against rules.
        
        Parameters:
        - form_data: Form data dictionary
        - validation_rules: Dictionary of field names to validation functions
        
        Returns:
        - Dictionary of field names to error messages, or empty dict if valid
        """
        errors = {}
        
        for field, validator in validation_rules.items():
            if field in form_data:
                error = validator(form_data[field])
                if error:
                    errors[field] = error
        
        return errors
    
    def display_form_errors(self, errors):
        """
        Display form validation errors.
        
        Parameters:
        - errors: Dictionary of field names to error messages
        """
        if errors:
            error_html = "<ul style='color: red; margin-top: 0;'>"
            for field, error in errors.items():
                error_html += f"<li><strong>{field}:</strong> {error}</li>"
            error_html += "</ul>"
            
            st.markdown(error_html, unsafe_allow_html=True)
    
    def handle_file_upload(self, endpoint, uploaded_file, file_param='file', additional_data=None, success_message=None, error_message=None):
        """
        Handle file upload to the backend.
        
        Parameters:
        - endpoint: API endpoint
        - uploaded_file: Streamlit UploadedFile object
        - file_param: Name of the file parameter
        - additional_data: Additional form data
        - success_message: Message to show on success
        - error_message: Message to show on error
        
        Returns:
        - Response data if successful, None otherwise
        """
        try:
            # Save uploaded file to temporary location
            temp_file_path = f"/tmp/{uploaded_file.name}"
            with open(temp_file_path, "wb") as f:
                f.write(uploaded_file.getbuffer())
            
            # Upload file to API
            response = self.api_client.upload_file(
                endpoint,
                temp_file_path,
                file_param=file_param,
                additional_data=additional_data
            )
            
            # Clean up temporary file
            os.remove(temp_file_path)
            
            if success_message:
                st.success(success_message)
            
            return response
        except (APIError, IOError) as e:
            error_msg = error_message or f"File upload failed: {str(e)}"
            st.error(error_msg)
            
            # Clean up temporary file if it exists
            if 'temp_file_path' in locals() and os.path.exists(temp_file_path):
                os.remove(temp_file_path)
            
            return None

# Error handling
class ErrorHandler:
    """Class for handling errors in the UI."""
    
    @staticmethod
    def handle_api_error(func):
        """
        Decorator for handling API errors.
        
        Parameters:
        - func: Function to decorate
        
        Returns:
        - Decorated function
        """
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except APIError as e:
                ErrorHandler.display_api_error(e)
                return None
            except Exception as e:
                ErrorHandler.display_generic_error(e)
                return None
        
        return wrapper
    
    @staticmethod
    def display_api_error(error):
        """
        Display an API error to the user.
        
        Parameters:
        - error: APIError instance
        """
        # Log the error
        logger.error(f"API Error: {error.message}")
        if error.response_json:
            logger.error(f"Response: {json.dumps(error.response_json)}")
        
        # Display error message
        error_message = error.message
        
        # Try to extract more details from response
        if error.response_json:
            if 'detail' in error.response_json:
                error_message = error.response_json['detail']
            elif 'message' in error.response_json:
                error_message = error.response_json['message']
        
        # Show error based on status code
        if error.status_code == 401:
            st.error("Authentication error: Please log in again.")
            
            # Clear authentication if present
            if 'auth_token' in st.session_state:
                del st.session_state.auth_token
            
            if 'user' in st.session_state:
                del st.session_state.user
        
        elif error.status_code == 403:
            st.error("Permission denied: You don't have access to this resource.")
        
        elif error.status_code == 404:
            st.error("Resource not found: The requested resource does not exist.")
        
        elif error.status_code == 422:
            # Validation error
            st.error("Validation error:")
            
            if error.response_json and 'detail' in error.response_json:
                errors = error.response_json['detail']
                if isinstance(errors, list):
                    for err in errors:
                        if 'loc' in err and 'msg' in err:
                            field = '.'.join(str(x) for x in err['loc'])
                            st.error(f"- {field}: {err['msg']}")
                        else:
                            st.error(f"- {err}")
                else:
                    st.error(f"- {errors}")
        
        elif error.status_code and error.status_code >= 500:
            st.error("Server error: The server encountered an error. Please try again later.")
        
        else:
            st.error(f"Error: {error_message}")
    
    @staticmethod
    def display_generic_error(error):
        """
        Display a generic error to the user.
        
        Parameters:
        - error: Exception instance
        """
        # Log the error
        logger.error(f"Error: {str(error)}")
        logger.error(traceback.format_exc())
        
        # Display error message
        st.error(f"An error occurred: {str(error)}")
        
        # Show technical details in an expander
        with st.expander("Technical Details"):
            st.code(traceback.format_exc())

# Backend integration for specific components
class DashboardBackend:
    """Backend integration for the dashboard."""
    
    def __init__(self, api_client=None, data_fetcher=None, realtime_updater=None):
        """
        Initialize the dashboard backend.
        
        Parameters:
        - api_client: APIClient instance
        - data_fetcher: DataFetcher instance
        - realtime_updater: RealtimeUpdater instance
        """
        self.api_client = api_client or APIClient()
        self.data_fetcher = data_fetcher or DataFetcher(api_client=self.api_client)
        self.realtime_updater = realtime_updater or RealtimeUpdater(api_client=self.api_client)
    
    @ErrorHandler.handle_api_error
    def get_dashboard_metrics(self):
        """
        Get dashboard metrics from the backend.
        
        Returns:
        - Dashboard metrics data
        """
        return self.data_fetcher.get_data('dashboard/metrics', ttl=30)
    
    @ErrorHandler.handle_api_error
    def get_production_trends(self, time_range='day'):
        """
        Get production trends from the backend.
        
        Parameters:
        - time_range: Time range ('day', 'week', 'month', 'year')
        
        Returns:
        - Production trends data
        """
        return self.data_fetcher.get_data(
            'dashboard/production-trends',
            params={'time_range': time_range},
            ttl=60
        )
    
    @ErrorHandler.handle_api_error
    def get_defect_distribution(self, time_range='day'):
        """
        Get defect distribution from the backend.
        
        Parameters:
        - time_range: Time range ('day', 'week', 'month', 'year')
        
        Returns:
        - Defect distribution data
        """
        return self.data_fetcher.get_data(
            'dashboard/defect-distribution',
            params={'time_range': time_range},
            ttl=60
        )
    
    @ErrorHandler.handle_api_error
    def get_recent_defects(self, limit=10):
        """
        Get recent defects from the backend.
        
        Parameters:
        - limit: Maximum number of defects to return
        
        Returns:
        - Recent defects data
        """
        return self.data_fetcher.get_data(
            'dashboard/recent-defects',
            params={'limit': limit},
            ttl=30
        )
    
    @ErrorHandler.handle_api_error
    def get_system_status(self):
        """
        Get system status from the backend.
        
        Returns:
        - System status data
        """
        return self.data_fetcher.get_data('dashboard/system-status', ttl=30)
    
    @ErrorHandler.handle_api_error
    def get_camera_status(self):
        """
        Get camera status from the backend.
        
        Returns:
        - Camera status data
        """
        return self.data_fetcher.get_data('dashboard/camera-status', ttl=30)
    
    def subscribe_to_dashboard_updates(self, callback):
        """
        Subscribe to dashboard updates.
        
        Parameters:
        - callback: Function to call with updated data
        
        Returns:
        - Subscription ID
        """
        # Start the realtime updater if not already running
        if not self.realtime_updater.running:
            self.realtime_updater.start()
        
        # Subscribe to dashboard metrics
        return self.realtime_updater.subscribe('dashboard/metrics', callback)
    
    def process_updates(self):
        """Process any pending updates."""
        self.realtime_updater.process_updates()

class CameraBackend:
    """Backend integration for camera views."""
    
    def __init__(self, api_client=None, data_fetcher=None, realtime_updater=None):
        """
        Initialize the camera backend.
        
        Parameters:
        - api_client: APIClient instance
        - data_fetcher: DataFetcher instance
        - realtime_updater: RealtimeUpdater instance
        """
        self.api_client = api_client or APIClient()
        self.data_fetcher = data_fetcher or DataFetcher(api_client=self.api_client)
        self.realtime_updater = realtime_updater or RealtimeUpdater(api_client=self.api_client)
    
    @ErrorHandler.handle_api_error
    def get_cameras(self):
        """
        Get list of cameras from the backend.
        
        Returns:
        - List of cameras
        """
        return self.data_fetcher.get_data('cameras', ttl=300)
    
    @ErrorHandler.handle_api_error
    def get_camera(self, camera_id):
        """
        Get camera details from the backend.
        
        Parameters:
        - camera_id: Camera ID
        
        Returns:
        - Camera details
        """
        return self.data_fetcher.get_data(f'cameras/{camera_id}', ttl=60)
    
    @ErrorHandler.handle_api_error
    def get_camera_settings(self, camera_id):
        """
        Get camera settings from the backend.
        
        Parameters:
        - camera_id: Camera ID
        
        Returns:
        - Camera settings
        """
        return self.data_fetcher.get_data(f'cameras/{camera_id}/settings', ttl=60)
    
    @ErrorHandler.handle_api_error
    def update_camera_settings(self, camera_id, settings):
        """
        Update camera settings in the backend.
        
        Parameters:
        - camera_id: Camera ID
        - settings: Camera settings dictionary
        
        Returns:
        - Updated camera settings
        """
        return self.data_fetcher.put_data(
            f'cameras/{camera_id}/settings',
            json=settings,
            invalidate_endpoints=[f'cameras/{camera_id}/settings', f'cameras/{camera_id}']
        )
    
    @ErrorHandler.handle_api_error
    def get_camera_status(self, camera_id):
        """
        Get camera status from the backend.
        
        Parameters:
        - camera_id: Camera ID
        
        Returns:
        - Camera status
        """
        return self.data_fetcher.get_data(f'cameras/{camera_id}/status', ttl=30)
    
    @ErrorHandler.handle_api_error
    def get_camera_frame(self, camera_id, width=None, height=None):
        """
        Get current camera frame from the backend.
        
        Parameters:
        - camera_id: Camera ID
        - width: Desired width (optional)
        - height: Desired height (optional)
        
        Returns:
        - Camera frame as PIL Image
        """
        params = {}
        if width:
            params['width'] = width
        if height:
            params['height'] = height
        
        try:
            response = self.api_client.session.get(
                f"{self.api_client.base_url}/cameras/{camera_id}/frame",
                params=params,
                stream=True
            )
            response.raise_for_status()
            
            # Convert response content to PIL Image
            image = Image.open(io.BytesIO(response.content))
            return image
        except requests.exceptions.RequestException as e:
            logger.error(f"Error getting camera frame: {str(e)}")
            raise APIError(f"Error getting camera frame: {str(e)}", response=getattr(e, 'response', None))
        except Exception as e:
            logger.error(f"Error processing camera frame: {str(e)}")
            raise APIError(f"Error processing camera frame: {str(e)}")
    
    @ErrorHandler.handle_api_error
    def get_camera_performance(self, camera_id, time_range='day'):
        """
        Get camera performance metrics from the backend.
        
        Parameters:
        - camera_id: Camera ID
        - time_range: Time range ('hour', 'day', 'week', 'month')
        
        Returns:
        - Camera performance metrics
        """
        return self.data_fetcher.get_data(
            f'cameras/{camera_id}/performance',
            params={'time_range': time_range},
            ttl=60
        )
    
    @ErrorHandler.handle_api_error
    def get_camera_defects(self, camera_id, limit=10):
        """
        Get defects detected by a camera from the backend.
        
        Parameters:
        - camera_id: Camera ID
        - limit: Maximum number of defects to return
        
        Returns:
        - Camera defects
        """
        return self.data_fetcher.get_data(
            f'cameras/{camera_id}/defects',
            params={'limit': limit},
            ttl=60
        )
    
    @ErrorHandler.handle_api_error
    def calibrate_camera(self, camera_id):
        """
        Trigger camera calibration in the backend.
        
        Parameters:
        - camera_id: Camera ID
        
        Returns:
        - Calibration result
        """
        return self.data_fetcher.post_data(
            f'cameras/{camera_id}/calibrate',
            invalidate_endpoints=[
                f'cameras/{camera_id}/settings',
                f'cameras/{camera_id}/status',
                f'cameras/{camera_id}'
            ]
        )
    
    @ErrorHandler.handle_api_error
    def reset_camera_settings(self, camera_id):
        """
        Reset camera settings to defaults in the backend.
        
        Parameters:
        - camera_id: Camera ID
        
        Returns:
        - Reset result
        """
        return self.data_fetcher.post_data(
            f'cameras/{camera_id}/reset-settings',
            invalidate_endpoints=[
                f'cameras/{camera_id}/settings',
                f'cameras/{camera_id}'
            ]
        )
    
    @ErrorHandler.handle_api_error
    def capture_image(self, camera_id):
        """
        Capture a still image from the camera.
        
        Parameters:
        - camera_id: Camera ID
        
        Returns:
        - Capture result with image URL
        """
        return self.data_fetcher.post_data(f'cameras/{camera_id}/capture')
    
    def subscribe_to_camera_updates(self, camera_id, callback):
        """
        Subscribe to camera updates.
        
        Parameters:
        - camera_id: Camera ID
        - callback: Function to call with updated data
        
        Returns:
        - Subscription ID
        """
        # Start the realtime updater if not already running
        if not self.realtime_updater.running:
            self.realtime_updater.start()
        
        # Subscribe to camera status
        return self.realtime_updater.subscribe(f'cameras/{camera_id}/status', callback)
    
    def process_updates(self):
        """Process any pending updates."""
        self.realtime_updater.process_updates()

class AnalyticsBackend:
    """Backend integration for analytics views."""
    
    def __init__(self, api_client=None, data_fetcher=None):
        """
        Initialize the analytics backend.
        
        Parameters:
        - api_client: APIClient instance
        - data_fetcher: DataFetcher instance
        """
        self.api_client = api_client or APIClient()
        self.data_fetcher = data_fetcher or DataFetcher(api_client=self.api_client)
    
    @ErrorHandler.handle_api_error
    def get_production_data(self, start_date=None, end_date=None, interval='day'):
        """
        Get production data from the backend.
        
        Parameters:
        - start_date: Start date (ISO format string)
        - end_date: End date (ISO format string)
        - interval: Data interval ('hour', 'day', 'week', 'month')
        
        Returns:
        - Production data
        """
        params = {'interval': interval}
        if start_date:
            params['start_date'] = start_date
        if end_date:
            params['end_date'] = end_date
        
        return self.data_fetcher.get_data('analytics/production', params=params, ttl=300)
    
    @ErrorHandler.handle_api_error
    def get_defect_data(self, start_date=None, end_date=None, interval='day'):
        """
        Get defect data from the backend.
        
        Parameters:
        - start_date: Start date (ISO format string)
        - end_date: End date (ISO format string)
        - interval: Data interval ('hour', 'day', 'week', 'month')
        
        Returns:
        - Defect data
        """
        params = {'interval': interval}
        if start_date:
            params['start_date'] = start_date
        if end_date:
            params['end_date'] = end_date
        
        return self.data_fetcher.get_data('analytics/defects', params=params, ttl=300)
    
    @ErrorHandler.handle_api_error
    def get_defect_types(self):
        """
        Get list of defect types from the backend.
        
        Returns:
        - List of defect types
        """
        return self.data_fetcher.get_data('analytics/defect-types', ttl=3600)
    
    @ErrorHandler.handle_api_error
    def get_defect_details(self, defect_id):
        """
        Get defect details from the backend.
        
        Parameters:
        - defect_id: Defect ID
        
        Returns:
        - Defect details
        """
        return self.data_fetcher.get_data(f'analytics/defects/{defect_id}', ttl=300)
    
    @ErrorHandler.handle_api_error
    def get_quality_metrics(self, start_date=None, end_date=None):
        """
        Get quality metrics from the backend.
        
        Parameters:
        - start_date: Start date (ISO format string)
        - end_date: End date (ISO format string)
        
        Returns:
        - Quality metrics
        """
        params = {}
        if start_date:
            params['start_date'] = start_date
        if end_date:
            params['end_date'] = end_date
        
        return self.data_fetcher.get_data('analytics/quality-metrics', params=params, ttl=300)
    
    @ErrorHandler.handle_api_error
    def generate_report(self, report_type, start_date, end_date, format='pdf'):
        """
        Generate a report from the backend.
        
        Parameters:
        - report_type: Report type ('production', 'defects', 'quality')
        - start_date: Start date (ISO format string)
        - end_date: End date (ISO format string)
        - format: Report format ('pdf', 'csv', 'xlsx')
        
        Returns:
        - Report generation result with download URL
        """
        return self.data_fetcher.post_data('analytics/reports', json={
            'report_type': report_type,
            'start_date': start_date,
            'end_date': end_date,
            'format': format
        })
    
    @ErrorHandler.handle_api_error
    def download_report(self, report_id, save_path):
        """
        Download a generated report from the backend.
        
        Parameters:
        - report_id: Report ID
        - save_path: Path to save the report
        
        Returns:
        - Path to the downloaded report
        """
        return self.api_client.download_file(f'analytics/reports/{report_id}/download', save_path)

class SettingsBackend:
    """Backend integration for settings views."""
    
    def __init__(self, api_client=None, data_fetcher=None):
        """
        Initialize the settings backend.
        
        Parameters:
        - api_client: APIClient instance
        - data_fetcher: DataFetcher instance
        """
        self.api_client = api_client or APIClient()
        self.data_fetcher = data_fetcher or DataFetcher(api_client=self.api_client)
    
    @ErrorHandler.handle_api_error
    def get_system_settings(self):
        """
        Get system settings from the backend.
        
        Returns:
        - System settings
        """
        return self.data_fetcher.get_data('settings/system', ttl=300)
    
    @ErrorHandler.handle_api_error
    def update_system_settings(self, settings):
        """
        Update system settings in the backend.
        
        Parameters:
        - settings: System settings dictionary
        
        Returns:
        - Updated system settings
        """
        return self.data_fetcher.put_data(
            'settings/system',
            json=settings,
            invalidate_endpoints=['settings/system']
        )
    
    @ErrorHandler.handle_api_error
    def get_camera_settings(self):
        """
        Get global camera settings from the backend.
        
        Returns:
        - Global camera settings
        """
        return self.data_fetcher.get_data('settings/cameras', ttl=300)
    
    @ErrorHandler.handle_api_error
    def update_camera_settings(self, settings):
        """
        Update global camera settings in the backend.
        
        Parameters:
        - settings: Camera settings dictionary
        
        Returns:
        - Updated camera settings
        """
        return self.data_fetcher.put_data(
            'settings/cameras',
            json=settings,
            invalidate_endpoints=['settings/cameras', 'cameras']
        )
    
    @ErrorHandler.handle_api_error
    def get_detection_settings(self):
        """
        Get detection settings from the backend.
        
        Returns:
        - Detection settings
        """
        return self.data_fetcher.get_data('settings/detection', ttl=300)
    
    @ErrorHandler.handle_api_error
    def update_detection_settings(self, settings):
        """
        Update detection settings in the backend.
        
        Parameters:
        - settings: Detection settings dictionary
        
        Returns:
        - Updated detection settings
        """
        return self.data_fetcher.put_data(
            'settings/detection',
            json=settings,
            invalidate_endpoints=['settings/detection']
        )
    
    @ErrorHandler.handle_api_error
    def get_notification_settings(self):
        """
        Get notification settings from the backend.
        
        Returns:
        - Notification settings
        """
        return self.data_fetcher.get_data('settings/notifications', ttl=300)
    
    @ErrorHandler.handle_api_error
    def update_notification_settings(self, settings):
        """
        Update notification settings in the backend.
        
        Parameters:
        - settings: Notification settings dictionary
        
        Returns:
        - Updated notification settings
        """
        return self.data_fetcher.put_data(
            'settings/notifications',
            json=settings,
            invalidate_endpoints=['settings/notifications']
        )
    
    @ErrorHandler.handle_api_error
    def get_user_settings(self):
        """
        Get user settings from the backend.
        
        Returns:
        - User settings
        """
        return self.data_fetcher.get_data('settings/user', ttl=300)
    
    @ErrorHandler.handle_api_error
    def update_user_settings(self, settings):
        """
        Update user settings in the backend.
        
        Parameters:
        - settings: User settings dictionary
        
        Returns:
        - Updated user settings
        """
        return self.data_fetcher.put_data(
            'settings/user',
            json=settings,
            invalidate_endpoints=['settings/user']
        )
    
    @ErrorHandler.handle_api_error
    def backup_system(self):
        """
        Trigger system backup in the backend.
        
        Returns:
        - Backup result with download URL
        """
        return self.data_fetcher.post_data('settings/backup')
    
    @ErrorHandler.handle_api_error
    def restore_system(self, backup_file):
        """
        Restore system from backup in the backend.
        
        Parameters:
        - backup_file: Streamlit UploadedFile object
        
        Returns:
        - Restore result
        """
        # Create form manager for file upload
        form_manager = FormManager(api_client=self.api_client)
        
        return form_manager.handle_file_upload(
            'settings/restore',
            backup_file,
            file_param='backup_file',
            success_message="System restored successfully. The application will restart.",
            error_message="Failed to restore system."
        )

# Main backend integration class
class BackendIntegration:
    """Main class for backend integration."""
    
    def __init__(self, base_url=None):
        """
        Initialize the backend integration.
        
        Parameters:
        - base_url: Base URL for the API
        """
        # Create API client
        self.api_client = APIClient(base_url=base_url)
        
        # Create data fetcher
        self.data_fetcher = DataFetcher(api_client=self.api_client)
        
        # Create realtime updater
        self.realtime_updater = RealtimeUpdater(api_client=self.api_client)
        
        # Create authentication manager
        self.auth_manager = AuthManager(api_client=self.api_client)
        
        # Create form manager
        self.form_manager = FormManager(api_client=self.api_client)
        
        # Create component backends
        self.dashboard = DashboardBackend(
            api_client=self.api_client,
            data_fetcher=self.data_fetcher,
            realtime_updater=self.realtime_updater
        )
        
        self.camera = CameraBackend(
            api_client=self.api_client,
            data_fetcher=self.data_fetcher,
            realtime_updater=self.realtime_updater
        )
        
        self.analytics = AnalyticsBackend(
            api_client=self.api_client,
            data_fetcher=self.data_fetcher
        )
        
        self.settings = SettingsBackend(
            api_client=self.api_client,
            data_fetcher=self.data_fetcher
        )
    
    def start_realtime_updates(self):
        """Start the realtime updater."""
        self.realtime_updater.start()
    
    def stop_realtime_updates(self):
        """Stop the realtime updater."""
        self.realtime_updater.stop()
    
    def process_updates(self):
        """Process any pending updates."""
        self.realtime_updater.process_updates()
    
    def clear_cache(self):
        """Clear the data cache."""
        self.data_fetcher.clear_cache()

# Initialize backend integration
def init_backend(base_url=None):
    """
    Initialize the backend integration.
    
    Parameters:
    - base_url: Base URL for the API
    
    Returns:
    - BackendIntegration instance
    """
    # Check if backend is already initialized in session state
    if 'backend' not in st.session_state:
        st.session_state.backend = BackendIntegration(base_url=base_url)
    
    return st.session_state.backend

# Demo page to showcase backend integration
def render_backend_integration_demo():
    """Render a demo page showcasing backend integration."""
    # Apply design system to the page
    st.set_page_config(
        page_title="OPSC Backend Integration Demo",
        page_icon="🔌",
        layout="wide",
        initial_sidebar_state="expanded"
    )
    
    st.markdown("# Backend Integration Demo")
    
    st.markdown("""
    This page demonstrates the backend integration features of the OPSC Sandwich Quality Inspection System.
    
    Note: This demo uses mock data since it's not connected to a real backend.
    """)
    
    # Mock API server
    class MockAPIServer:
        """Mock API server for demonstration."""
        
        @staticmethod
        def get_dashboard_metrics():
            """Get mock dashboard metrics."""
            return {
                'total_sandwiches': 12458,
                'defect_rate': 1.2,
                'production_rate': 250,
                'quality_score': 98.8
            }
        
        @staticmethod
        def get_production_trends(time_range='day'):
            """Get mock production trends."""
            # Generate mock data based on time range
            if time_range == 'day':
                points = 24
                interval = 'hour'
            elif time_range == 'week':
                points = 7
                interval = 'day'
            elif time_range == 'month':
                points = 30
                interval = 'day'
            else:
                points = 12
                interval = 'month'
            
            data = []
            for i in range(points):
                data.append({
                    'timestamp': (datetime.now() - timedelta(**{f"{interval}s": points - i - 1})).isoformat(),
                    'production': random.randint(200, 300),
                    'defects': random.randint(2, 8)
                })
            
            return data
        
        @staticmethod
        def get_camera_status():
            """Get mock camera status."""
            return {
                'cameras': [
                    {
                        'id': 1,
                        'name': 'Top Camera',
                        'status': 'online',
                        'fps': random.randint(18, 20),
                        'temperature': round(random.uniform(35, 45), 1),
                        'connection_quality': round(random.uniform(0.9, 1.0), 2)
                    },
                    {
                        'id': 2,
                        'name': 'Side Camera 1',
                        'status': 'warning',
                        'fps': random.randint(16, 19),
                        'temperature': round(random.uniform(40, 50), 1),
                        'connection_quality': round(random.uniform(0.7, 0.9), 2)
                    },
                    {
                        'id': 3,
                        'name': 'Side Camera 2',
                        'status': 'online',
                        'fps': random.randint(18, 20),
                        'temperature': round(random.uniform(35, 45), 1),
                        'connection_quality': round(random.uniform(0.85, 1.0), 2)
                    },
                    {
                        'id': 4,
                        'name': 'Bottom Camera',
                        'status': 'online',
                        'fps': random.randint(18, 20),
                        'temperature': round(random.uniform(35, 45), 1),
                        'connection_quality': round(random.uniform(0.8, 1.0), 2)
                    }
                ]
            }
        
        @staticmethod
        def get_system_status():
            """Get mock system status."""
            return {
                'host': {
                    'status': 'online',
                    'cpu_usage': round(random.uniform(20, 40), 1),
                    'memory_usage': round(random.uniform(30, 60), 1),
                    'disk_usage': round(random.uniform(40, 70), 1),
                    'temperature': round(random.uniform(35, 50), 1),
                    'uptime': random.randint(1, 30) * 86400  # 1-30 days in seconds
                },
                'jetson': {
                    'status': 'online',
                    'cpu_usage': round(random.uniform(30, 60), 1),
                    'gpu_usage': round(random.uniform(20, 80), 1),
                    'memory_usage': round(random.uniform(40, 70), 1),
                    'temperature': round(random.uniform(40, 60), 1),
                    'uptime': random.randint(1, 30) * 86400  # 1-30 days in seconds
                },
                'network': {
                    'status': 'online',
                    'latency': round(random.uniform(1, 10), 1),
                    'bandwidth': round(random.uniform(50, 100), 1),
                    'packet_loss': round(random.uniform(0, 0.5), 2)
                },
                'database': {
                    'status': 'online',
                    'size': round(random.uniform(100, 500), 1),
                    'connections': random.randint(1, 10),
                    'queries_per_second': round(random.uniform(10, 50), 1)
                }
            }
    
    # Create tabs for different integration demos
    tab1, tab2, tab3, tab4 = st.tabs(["API Client", "Data Fetching", "Real-time Updates", "Authentication"])
    
    with tab1:
        st.markdown("## API Client")
        
        st.markdown("""
        The API client provides a simple interface for making requests to the backend API.
        It handles authentication, error handling, and request formatting.
        """)
        
        # API client demo
        st.markdown("### API Request Demo")
        
        endpoint = st.text_input("API Endpoint", value="dashboard/metrics")
        
        col1, col2 = st.columns(2)
        
        with col1:
            method = st.selectbox("HTTP Method", ["GET", "POST", "PUT", "DELETE"])
        
        with col2:
            timeout = st.number_input("Timeout (seconds)", value=10, min_value=1, max_value=60)
        
        # JSON data for POST/PUT
        if method in ["POST", "PUT"]:
            json_data = st.text_area("JSON Data", value='{"key": "value"}')
            try:
                json_data = json.loads(json_data)
            except json.JSONDecodeError:
                st.error("Invalid JSON data")
                json_data = None
        else:
            json_data = None
        
        if st.button("Send Request"):
            try:
                # Mock API response based on endpoint
                if endpoint == "dashboard/metrics":
                    response = MockAPIServer.get_dashboard_metrics()
                elif endpoint == "dashboard/production-trends":
                    response = MockAPIServer.get_production_trends()
                elif endpoint == "dashboard/camera-status":
                    response = MockAPIServer.get_camera_status()
                elif endpoint == "dashboard/system-status":
                    response = MockAPIServer.get_system_status()
                else:
                    response = {"message": "Endpoint not implemented in demo"}
                
                st.success("Request successful!")
                st.json(response)
            except Exception as e:
                st.error(f"Request failed: {str(e)}")
        
        # API client code example
        st.markdown("### API Client Code Example")
        
        st.code("""
        # Initialize API client
        api_client = APIClient(base_url="http://localhost:8000/api")
        
        # Set authentication token
        api_client.set_auth_token("your_jwt_token")
        
        # Make GET request
        try:
            response = api_client.get("dashboard/metrics")
            print(response)
        except APIError as e:
            print(f"API error: {e.message}")
            if e.response_json:
                print(f"Details: {e.response_json}")
        
        # Make POST request
        try:
            response = api_client.post("settings/user", json={"theme": "dark"})
            print(response)
        except APIError as e:
            print(f"API error: {e.message}")
        """, language="python")
    
    with tab2:
        st.markdown("## Data Fetching and Caching")
        
        st.markdown("""
        The data fetcher provides a caching layer on top of the API client.
        It caches responses to reduce API calls and improve performance.
        """)
        
        # Data fetcher demo
        st.markdown("### Data Fetching Demo")
        
        endpoint = st.text_input("API Endpoint", value="dashboard/metrics", key="df_endpoint")
        
        col1, col2 = st.columns(2)
        
        with col1:
            ttl = st.number_input("Cache TTL (seconds)", value=30, min_value=1, max_value=3600)
        
        with col2:
            force_refresh = st.checkbox("Force Refresh", value=False)
        
        if st.button("Fetch Data"):
            # Create a progress bar to simulate fetching
            progress_bar = st.progress(0)
            status_text = st.empty()
            
            # Check if in cache (simulated)
            if not force_refresh and random.random() < 0.7:
                status_text.text("Checking cache...")
                time.sleep(0.5)
                progress_bar.progress(50)
                status_text.text("Found in cache!")
                time.sleep(0.5)
                progress_bar.progress(100)
                
                # Mock API response based on endpoint
                if endpoint == "dashboard/metrics":
                    response = MockAPIServer.get_dashboard_metrics()
                elif endpoint == "dashboard/production-trends":
                    response = MockAPIServer.get_production_trends()
                elif endpoint == "dashboard/camera-status":
                    response = MockAPIServer.get_camera_status()
                elif endpoint == "dashboard/system-status":
                    response = MockAPIServer.get_system_status()
                else:
                    response = {"message": "Endpoint not implemented in demo"}
                
                st.success("Data fetched from cache!")
                st.json(response)
            else:
                status_text.text("Cache miss, fetching from API...")
                time.sleep(0.5)
                progress_bar.progress(25)
                status_text.text("Making API request...")
                time.sleep(1)
                progress_bar.progress(75)
                status_text.text("Processing response...")
                time.sleep(0.5)
                progress_bar.progress(100)
                
                # Mock API response based on endpoint
                if endpoint == "dashboard/metrics":
                    response = MockAPIServer.get_dashboard_metrics()
                elif endpoint == "dashboard/production-trends":
                    response = MockAPIServer.get_production_trends()
                elif endpoint == "dashboard/camera-status":
                    response = MockAPIServer.get_camera_status()
                elif endpoint == "dashboard/system-status":
                    response = MockAPIServer.get_system_status()
                else:
                    response = {"message": "Endpoint not implemented in demo"}
                
                st.success("Data fetched from API and cached!")
                st.json(response)
        
        # Data fetcher code example
        st.markdown("### Data Fetcher Code Example")
        
        st.code("""
        # Initialize data fetcher
        data_fetcher = DataFetcher(api_client=api_client)
        
        # Get data with caching
        try:
            # This will use cached data if available and not expired
            metrics = data_fetcher.get_data("dashboard/metrics", ttl=30)
            print(metrics)
            
            # Force refresh from API
            metrics = data_fetcher.get_data("dashboard/metrics", force_refresh=True)
            print(metrics)
            
            # Get data with parameters
            trends = data_fetcher.get_data(
                "dashboard/production-trends",
                params={"time_range": "week"},
                ttl=60
            )
            print(trends)
            
            # Update data and invalidate related cache entries
            data_fetcher.put_data(
                "settings/user",
                json={"theme": "dark"},
                invalidate_endpoints=["settings/user", "settings/system"]
            )
            
            # Clear entire cache
            data_fetcher.clear_cache()
        except APIError as e:
            print(f"API error: {e.message}")
        """, language="python")
    
    with tab3:
        st.markdown("## Real-time Updates")
        
        st.markdown("""
        The real-time updater provides a way to subscribe to updates from the backend.
        It periodically polls the API and calls callbacks when data changes.
        """)
        
        # Real-time updater demo
        st.markdown("### Real-time Updates Demo")
        
        if 'update_active' not in st.session_state:
            st.session_state.update_active = False
            st.session_state.update_data = None
            st.session_state.update_count = 0
            st.session_state.last_update = None
        
        col1, col2 = st.columns(2)
        
        with col1:
            endpoint = st.selectbox(
                "Subscribe to Endpoint",
                ["dashboard/metrics", "dashboard/camera-status", "dashboard/system-status"]
            )
        
        with col2:
            update_interval = st.slider("Update Interval (seconds)", min_value=1, max_value=10, value=3)
        
        # Start/stop updates
        if not st.session_state.update_active:
            if st.button("Start Updates"):
                st.session_state.update_active = True
                st.session_state.update_count = 0
                st.session_state.last_update = datetime.now()
                st.rerun()
        else:
            if st.button("Stop Updates"):
                st.session_state.update_active = False
                st.rerun()
        
        # Display update status
        if st.session_state.update_active:
            status_container = st.empty()
            data_container = st.empty()
            
            # Simulate updates
            current_time = datetime.now()
            time_diff = (current_time - st.session_state.last_update).total_seconds()
            
            if time_diff >= update_interval:
                # Update the data
                if endpoint == "dashboard/metrics":
                    st.session_state.update_data = MockAPIServer.get_dashboard_metrics()
                elif endpoint == "dashboard/camera-status":
                    st.session_state.update_data = MockAPIServer.get_camera_status()
                elif endpoint == "dashboard/system-status":
                    st.session_state.update_data = MockAPIServer.get_system_status()
                
                st.session_state.update_count += 1
                st.session_state.last_update = current_time
            
            # Display status
            status_container.markdown(f"""
            **Update Status:**
            - Active: Yes
            - Endpoint: {endpoint}
            - Interval: {update_interval} seconds
            - Updates Received: {st.session_state.update_count}
            - Last Update: {st.session_state.last_update.strftime('%H:%M:%S')}
            - Next Update: {(st.session_state.last_update + timedelta(seconds=update_interval)).strftime('%H:%M:%S')}
            """)
            
            # Display data
            if st.session_state.update_data:
                data_container.json(st.session_state.update_data)
            
            # Force rerun to simulate updates
            time.sleep(0.1)
            st.rerun()
        
        # Real-time updater code example
        st.markdown("### Real-time Updater Code Example")
        
        st.code("""
        # Initialize real-time updater
        realtime_updater = RealtimeUpdater(api_client=api_client, update_interval=5)
        
        # Define callback function
        def on_metrics_update(data):
            print(f"Received metrics update: {data}")
            # Update UI with new data
            st.session_state.metrics = data
            
        # Start the updater
        realtime_updater.start()
        
        # Subscribe to updates
        subscription_id = realtime_updater.subscribe(
            "dashboard/metrics",
            callback=on_metrics_update
        )
        
        # In the Streamlit app's main loop
        def main():
            # Process any pending updates
            realtime_updater.process_updates()
            
            # Display the metrics
            if 'metrics' in st.session_state:
                st.metric("Total Sandwiches", st.session_state.metrics['total_sandwiches'])
                st.metric("Defect Rate", f"{st.session_state.metrics['defect_rate']}%")
            
            # Unsubscribe when done
            # realtime_updater.unsubscribe(subscription_id)
            
            # Stop the updater when done
            # realtime_updater.stop()
        """, language="python")
    
    with tab4:
        st.markdown("## Authentication")
        
        st.markdown("""
        The authentication manager handles user authentication with the backend.
        It manages login, logout, and permission checking.
        """)
        
        # Authentication demo
        st.markdown("### Authentication Demo")
        
        if 'auth_demo_logged_in' not in st.session_state:
            st.session_state.auth_demo_logged_in = False
            st.session_state.auth_demo_user = None
        
        if not st.session_state.auth_demo_logged_in:
            with st.form("auth_demo_login_form"):
                username = st.text_input("Username")
                password = st.text_input("Password", type="password")
                submit = st.form_submit_button("Log In")
                
                if submit:
                    if username and password:
                        # Simulate successful login
                        st.session_state.auth_demo_logged_in = True
                        st.session_state.auth_demo_user = {
                            'id': 1,
                            'username': username,
                            'email': f"{username}@example.com",
                            'full_name': username.capitalize(),
                            'roles': ['admin'],
                            'permissions': ['view_dashboard', 'edit_settings', 'view_analytics']
                        }
                        st.success("Login successful!")
                        st.rerun()
                    else:
                        st.error("Please enter username and password.")
        else:
            # Display user info
            st.markdown(f"""
            **Logged in as: {st.session_state.auth_demo_user['full_name']}**
            
            User Information:
            - Username: {st.session_state.auth_demo_user['username']}
            - Email: {st.session_state.auth_demo_user['email']}
            - Roles: {', '.join(st.session_state.auth_demo_user['roles'])}
            """)
            
            # Permission check
            st.markdown("### Permission Check")
            
            permission = st.selectbox(
                "Check Permission",
                ["view_dashboard", "edit_settings", "view_analytics", "edit_users", "delete_data"]
            )
            
            if st.button("Check Permission"):
                if permission in st.session_state.auth_demo_user['permissions']:
                    st.success(f"User has permission: {permission}")
                else:
                    st.error(f"User does not have permission: {permission}")
            
            # Logout button
            if st.button("Log Out"):
                st.session_state.auth_demo_logged_in = False
                st.session_state.auth_demo_user = None
                st.success("Logged out successfully!")
                st.rerun()
        
        # Authentication code example
        st.markdown("### Authentication Code Example")
        
        st.code("""
        # Initialize authentication manager
        auth_manager = AuthManager(api_client=api_client)
        
        # Login
        if auth_manager.login(username, password):
            st.success("Login successful!")
        else:
            st.error("Invalid username or password.")
        
        # Check if authenticated
        if auth_manager.is_authenticated():
            # Get current user
            user = auth_manager.get_current_user()
            st.write(f"Logged in as: {user['full_name']}")
            
            # Check permissions
            if auth_manager.has_permission("edit_settings"):
                st.write("You can edit settings.")
            else:
                st.write("You don't have permission to edit settings.")
        
        # Require authentication for a page
        if auth_manager.require_authentication():
            st.write("This is a protected page.")
        
        # Require specific permission for a page
        if auth_manager.require_permission("view_analytics"):
            st.write("This is the analytics page.")
        
        # Logout
        if st.button("Log Out"):
            auth_manager.logout()
            st.success("Logged out successfully!")
        """, language="python")
    
    # Main backend integration demo
    st.markdown("## Complete Backend Integration")
    
    st.markdown("""
    The main `BackendIntegration` class combines all the components into a single interface.
    It provides access to all backend functionality through a simple API.
    """)
    
    # Backend integration code example
    st.code("""
    # Initialize backend integration
    backend = init_backend(base_url="http://localhost:8000/api")
    
    # Start real-time updates
    backend.start_realtime_updates()
    
    # Get dashboard metrics
    metrics = backend.dashboard.get_dashboard_metrics()
    
    # Get camera status
    camera_status = backend.camera.get_camera_status()
    
    # Get production trends
    trends = backend.analytics.get_production_data(
        start_date="2025-01-01",
        end_date="2025-01-31",
        interval="day"
    )
    
    # Update system settings
    backend.settings.update_system_settings({
        "auto_start": True,
        "log_level": "info"
    })
    
    # Process any pending updates
    backend.process_updates()
    
    # Stop real-time updates when done
    backend.stop_realtime_updates()
    """, language="python")
    
    # Implementation details
    st.markdown("## Implementation Details")
    
    st.markdown("""
    The backend integration implementation includes:
    
    1. **API Client**: Handles HTTP requests to the backend API
    2. **Data Fetching and Caching**: Caches API responses to reduce requests
    3. **Real-time Updates**: Provides real-time data updates from the backend
    4. **Authentication**: Manages user authentication and permissions
    5. **Form Submission**: Handles form submissions to the backend
    6. **Error Handling**: Provides consistent error handling and display
    7. **Component-specific Backends**: Specialized backends for different UI components
    
    Each component is designed to be modular and reusable, making it easy to integrate with different parts of the UI.
    """)

if __name__ == "__main__":
    render_backend_integration_demo()
