#!/usr/bin/env python3
"""
Main entry point for the OPSC Sandwich Quality Inspection System.

This script initializes all components of the system and starts the application.

Version: 1.0.0
Last Updated: 2025-04-21
"""

import os
import sys
import time
import logging
import argparse
import yaml
import threading
from pathlib import Path
import cv2
import numpy as np
import streamlit as st

# Add project root to path
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if project_root not in sys.path:
    sys.path.append(project_root)

# Import core components
from src.core.camera.basler_manager import BaslerCameraManager
from src.core.inference.model_manager import ModelManager
from src.core.data.database import DatabaseManager
from src.core.hardware.jetson_monitor import JetsonMonitor
from src.utils.config import ConfigManager
from src.utils.logging import setup_logging

# Setup argument parser
def parse_args():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(description="OPSC Sandwich Quality Inspection System")
    parser.add_argument("--config", type=str, default="config/app.yaml", help="Path to configuration file")
    parser.add_argument("--debug", action="store_true", help="Enable debug mode")
    parser.add_argument("--no-ui", action="store_true", help="Run without UI (headless mode)")
    parser.add_argument("--test", action="store_true", help="Run in test mode")
    return parser.parse_args()

# Main application class
class SandwichInspectionSystem:
    """
    Main application class for the OPSC Sandwich Quality Inspection System.
    
    This class initializes and manages all components of the system, including
    cameras, inference models, database, and UI.
    """
    
    def __init__(self, config_path: str, debug: bool = False, headless: bool = False, test_mode: bool = False):
        """
        Initialize the sandwich inspection system.
        
        Args:
            config_path: Path to configuration file
            debug: Whether to enable debug mode
            headless: Whether to run without UI
            test_mode: Whether to run in test mode
        """
        self.config_path = config_path
        self.debug = debug
        self.headless = headless
        self.test_mode = test_mode
        
        # Setup logging
        log_level = logging.DEBUG if debug else logging.INFO
        self.logger = setup_logging(log_level)
        self.logger.info("Initializing OPSC Sandwich Quality Inspection System")
        
        # Load configuration
        self.config_manager = ConfigManager(config_path)
        self.config = self.config_manager.get_config()
        
        # Initialize components
        self.camera_manager = None
        self.model_manager = None
        self.database_manager = None
        self.jetson_monitor = None
        
        # Initialize system
        self._initialize_system()
    
    def _initialize_system(self):
        """Initialize all system components."""
        try:
            # Initialize hardware monitoring
            self._initialize_hardware_monitoring()
            
            # Initialize camera system
            self._initialize_cameras()
            
            # Initialize inference model
            self._initialize_model()
            
            # Initialize database
            self._initialize_database()
            
            self.logger.info("System initialization complete")
        except Exception as e:
            self.logger.error(f"Error initializing system: {e}")
            raise
    
    def _initialize_hardware_monitoring(self):
        """Initialize hardware monitoring."""
        try:
            # Check if Jetson monitoring is enabled
            if self.config.get("hardware", {}).get("enable_jetson_monitoring", False):
                self.logger.info("Initializing Jetson hardware monitoring")
                self.jetson_monitor = JetsonMonitor(
                    update_interval=self.config.get("hardware", {}).get("monitoring_interval", 5)
                )
                # Start monitoring in a separate thread
                threading.Thread(target=self.jetson_monitor.start_monitoring, daemon=True).start()
        except Exception as e:
            self.logger.error(f"Error initializing hardware monitoring: {e}")
            if not self.test_mode:
                raise
    
    def _initialize_cameras(self):
        """Initialize camera system."""
        try:
            # Get camera configuration
            camera_config = self.config.get("cameras", {})
            
            # Initialize camera manager
            self.logger.info("Initializing camera system")
            self.camera_manager = BaslerCameraManager(
                config_file=os.path.join(os.path.dirname(self.config_path), camera_config.get("config_file", "cameras.yaml")),
                num_cameras=camera_config.get("num_cameras", 4)
            )
            
            # Connect to cameras
            if not self.test_mode:
                self.camera_manager.connect_cameras()
                self.logger.info(f"Connected to {self.camera_manager.get_connected_camera_count()} cameras")
        except Exception as e:
            self.logger.error(f"Error initializing camera system: {e}")
            if not self.test_mode:
                raise
    
    def _initialize_model(self):
        """Initialize inference model."""
        try:
            # Get model configuration
            model_config = self.config.get("model", {})
            
            # Initialize model manager
            self.logger.info("Initializing inference model")
            self.model_manager = ModelManager(
                config_path=os.path.join(os.path.dirname(self.config_path), model_config.get("config_file", "models.yaml")),
                model_type=model_config.get("type", "roboflow"),
                use_local_inference=model_config.get("use_local_inference", True),
                confidence_threshold=model_config.get("confidence_threshold", 0.7),
                overlap_threshold=model_config.get("overlap_threshold", 0.5)
            )
        except Exception as e:
            self.logger.error(f"Error initializing inference model: {e}")
            if not self.test_mode:
                raise
    
    def _initialize_database(self):
        """Initialize database."""
        try:
            # Get database configuration
            db_config = self.config.get("database", {})
            
            # Initialize database manager
            self.logger.info("Initializing database")
            self.database_manager = DatabaseManager(
                db_path=db_config.get("path", "data/database/sandwich_inspection.db"),
                enable_backup=db_config.get("enable_backup", True),
                backup_interval=db_config.get("backup_interval", 86400)  # 24 hours
            )
            
            # Initialize database schema
            self.database_manager.initialize_schema()
        except Exception as e:
            self.logger.error(f"Error initializing database: {e}")
            if not self.test_mode:
                raise
    
    def start(self):
        """Start the sandwich inspection system."""
        try:
            self.logger.info("Starting OPSC Sandwich Quality Inspection System")
            
            if self.headless:
                # Run in headless mode
                self._run_headless()
            else:
                # Run with UI
                self._run_with_ui()
        except KeyboardInterrupt:
            self.logger.info("System shutdown requested")
        except Exception as e:
            self.logger.error(f"Error running system: {e}")
        finally:
            self.shutdown()
    
    def _run_headless(self):
        """Run system in headless mode."""
        self.logger.info("Running in headless mode")
        
        # Start continuous inspection loop
        try:
            while True:
                # Capture images from all cameras
                images = self.camera_manager.capture_images()
                
                # Process each image
                for camera_id, image in images.items():
                    # Perform inference
                    detections = self.model_manager.predict(image)
                    
                    # Log detections
                    for detection in detections:
                        self.logger.info(f"Camera {camera_id}: Detected {detection.defect_type} with confidence {detection.confidence:.2f}")
                    
                    # Save detections to database
                    if detections:
                        self.database_manager.save_detections(camera_id, image, detections)
                
                # Sleep for a short time
                time.sleep(0.1)
        except KeyboardInterrupt:
            self.logger.info("Headless mode interrupted")
    
    def _run_with_ui(self):
        """Run system with UI."""
        self.logger.info("Running with UI")
        
        # Import UI components
        from src.ui.main_dashboard import run_dashboard
        
        # Run dashboard
        run_dashboard(self)
    
    def shutdown(self):
        """Shutdown the system and release resources."""
        self.logger.info("Shutting down system")
        
        # Disconnect cameras
        if self.camera_manager is not None:
            self.camera_manager.disconnect_cameras()
        
        # Stop hardware monitoring
        if self.jetson_monitor is not None:
            self.jetson_monitor.stop_monitoring()
        
        # Close database
        if self.database_manager is not None:
            self.database_manager.close()
        
        self.logger.info("System shutdown complete")


# Entry point
def main():
    """Main entry point."""
    # Parse arguments
    args = parse_args()
    
    # Create and start system
    system = SandwichInspectionSystem(
        config_path=args.config,
        debug=args.debug,
        headless=args.no_ui,
        test_mode=args.test
    )
    
    # Start system
    system.start()


if __name__ == "__main__":
    main()
