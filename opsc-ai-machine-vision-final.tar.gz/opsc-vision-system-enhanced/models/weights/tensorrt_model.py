"""
TensorRT model implementation for sandwich defect detection.
This module provides optimized inference using NVIDIA TensorRT.

Version: 1.0.0
Last Updated: 2025-04-21
"""

import os
import sys
import time
import json
import logging
import numpy as np
from typing import Dict, List, Optional, Tuple, Union, Any
import cv2
from pathlib import Path
import tensorrt as trt
import pycuda.driver as cuda
import pycuda.autoinit
from dataclasses import dataclass, field

# Import detection result class
from .sandwich_defect_model import DetectionResult

# Setup logging
logger = logging.getLogger(__name__)

class TensorRTModel:
    """
    TensorRT model for optimized sandwich defect detection.
    
    This class provides methods to load a TensorRT engine and perform inference
    on sandwich images to detect various types of defects with optimized performance.
    """
    
    def __init__(
        self,
        engine_path: str,
        input_shape: Tuple[int, int] = (640, 640),
        confidence_threshold: float = 0.7,
        nms_threshold: float = 0.5,
        dla_core: int = 0,
        use_dla: bool = True
    ):
        """
        Initialize the TensorRT model.
        
        Args:
            engine_path: Path to TensorRT engine file
            input_shape: Input shape for the model (height, width)
            confidence_threshold: Minimum confidence threshold for detections
            nms_threshold: Non-maximum suppression threshold
            dla_core: DLA core to use (for Jetson devices)
            use_dla: Whether to use DLA acceleration (for Jetson devices)
        """
        self.engine_path = engine_path
        self.input_shape = input_shape
        self.confidence_threshold = confidence_threshold
        self.nms_threshold = nms_threshold
        self.dla_core = dla_core
        self.use_dla = use_dla
        
        # Initialize TensorRT
        self.logger = trt.Logger(trt.Logger.WARNING)
        self.runtime = trt.Runtime(self.logger)
        self.engine = None
        self.context = None
        self.bindings = []
        self.input_idx = None
        self.output_idx = None
        self.stream = cuda.Stream()
        
        # Initialize model
        self.initialized = False
        self.defect_classes = [
            "improper_sealing",
            "filling_leakage",
            "size_inconsistency",
            "mold",
            "holes",
            "destroyed_sandwich",
            "foreign_material"
        ]
        
        # Load model
        self._load_engine()
    
    def _load_engine(self):
        """Load TensorRT engine."""
        try:
            # Check if engine file exists
            if not os.path.exists(self.engine_path):
                raise FileNotFoundError(f"Engine file not found: {self.engine_path}")
            
            # Load engine from file
            with open(self.engine_path, "rb") as f:
                engine_data = f.read()
            
            # Deserialize engine
            self.engine = self.runtime.deserialize_cuda_engine(engine_data)
            
            # Create execution context
            self.context = self.engine.create_execution_context()
            
            # Set DLA core if available and requested
            if self.use_dla and hasattr(self.context, "set_optimization_profile_async"):
                self.context.set_optimization_profile_async(0, self.stream.handle)
                if hasattr(self.context, "set_dla_core"):
                    self.context.set_dla_core(self.dla_core)
            
            # Allocate buffers
            self._allocate_buffers()
            
            # Set initialized flag
            self.initialized = True
            
            logger.info(f"Loaded TensorRT engine: {self.engine_path}")
        except Exception as e:
            logger.error(f"Error loading TensorRT engine: {e}")
            raise
    
    def _allocate_buffers(self):
        """Allocate device buffers for input and output."""
        # Clear existing bindings
        self.bindings = []
        
        # Allocate memory for inputs and outputs
        for i in range(self.engine.num_bindings):
            binding_name = self.engine.get_binding_name(i)
            binding_shape = self.engine.get_binding_shape(i)
            binding_dtype = self.engine.get_binding_dtype(i)
            
            # Convert TensorRT dtype to numpy dtype
            if binding_dtype == trt.DataType.FLOAT:
                np_dtype = np.float32
            elif binding_dtype == trt.DataType.HALF:
                np_dtype = np.float16
            elif binding_dtype == trt.DataType.INT8:
                np_dtype = np.int8
            elif binding_dtype == trt.DataType.INT32:
                np_dtype = np.int32
            else:
                np_dtype = np.float32
            
            # Calculate size
            size = 1
            for dim in binding_shape:
                size *= abs(dim)  # Use abs to handle dynamic dimensions (-1)
            
            # Allocate device memory
            device_mem = cuda.mem_alloc(size * np_dtype().itemsize)
            
            # Add to bindings
            self.bindings.append(device_mem)
            
            # Store input and output indices
            if self.engine.binding_is_input(i):
                self.input_idx = i
            else:
                self.output_idx = i
    
    def predict(self, image: np.ndarray) -> List[DetectionResult]:
        """
        Perform inference on an image to detect sandwich defects.
        
        Args:
            image: Image as numpy array (BGR format)
        
        Returns:
            List of detection results
        """
        if not self.initialized:
            raise RuntimeError("Model not initialized")
        
        try:
            # Preprocess image
            input_data = self._preprocess(image)
            
            # Perform inference
            output_data = self._infer(input_data)
            
            # Postprocess results
            detections = self._postprocess(output_data, image.shape[:2])
            
            return detections
        except Exception as e:
            logger.error(f"Error during prediction: {e}")
            return []
    
    def _preprocess(self, image: np.ndarray) -> np.ndarray:
        """Preprocess image for inference."""
        # Resize image
        resized = cv2.resize(image, (self.input_shape[1], self.input_shape[0]))
        
        # Convert BGR to RGB
        rgb = cv2.cvtColor(resized, cv2.COLOR_BGR2RGB)
        
        # Normalize to [0, 1]
        normalized = rgb.astype(np.float32) / 255.0
        
        # Transpose to NCHW format
        nchw = np.transpose(normalized, (2, 0, 1))
        
        # Add batch dimension
        batched = np.expand_dims(nchw, axis=0)
        
        return batched
    
    def _infer(self, input_data: np.ndarray) -> np.ndarray:
        """Perform inference using TensorRT."""
        # Get input shape
        input_shape = self.engine.get_binding_shape(self.input_idx)
        
        # Handle dynamic batch size
        if input_shape[0] == -1:
            input_shape = (input_data.shape[0],) + input_shape[1:]
            self.context.set_binding_shape(self.input_idx, input_shape)
        
        # Get output shape
        output_shape = self.context.get_binding_shape(self.output_idx)
        
        # Create output array
        output = np.empty(output_shape, dtype=np.float32)
        
        # Copy input data to device
        cuda.memcpy_htod_async(self.bindings[self.input_idx], input_data, self.stream)
        
        # Execute inference
        self.context.execute_async_v2(bindings=self.bindings, stream_handle=self.stream.handle)
        
        # Copy output data to host
        cuda.memcpy_dtoh_async(output, self.bindings[self.output_idx], self.stream)
        
        # Synchronize stream
        self.stream.synchronize()
        
        return output
    
    def _postprocess(self, output_data: np.ndarray, original_shape: Tuple[int, int]) -> List[DetectionResult]:
        """Postprocess model output to get detection results."""
        # Get original image dimensions
        original_height, original_width = original_shape
        
        # Process output data
        # Note: Output format depends on the specific model architecture
        # This example assumes YOLOv5/YOLOv8 format: [batch, num_detections, 6]
        # where 6 = [x, y, w, h, confidence, class]
        
        # Get detections above confidence threshold
        detections = output_data[0]  # First batch
        valid_detections = detections[detections[:, 4] > self.confidence_threshold]
        
        # Apply non-maximum suppression
        # This is a simplified version; actual implementation would depend on the model
        results = []
        for i, detection in enumerate(valid_detections):
            # Extract data
            x, y, w, h, confidence, class_id = detection
            
            # Convert class_id to int
            class_id = int(class_id)
            
            # Skip if class_id is out of range
            if class_id >= len(self.defect_classes):
                continue
            
            # Get class name
            class_name = self.defect_classes[class_id]
            
            # Normalize coordinates
            x_norm = x / self.input_shape[1]
            y_norm = y / self.input_shape[0]
            w_norm = w / self.input_shape[1]
            h_norm = h / self.input_shape[0]
            
            # Create detection result
            result = DetectionResult(
                defect_type=class_name,
                confidence=float(confidence),
                bbox=(x_norm, y_norm, w_norm, h_norm)
            )
            
            # Add to results
            results.append(result)
        
        return results


# Example usage
if __name__ == "__main__":
    # Set up logging
    logging.basicConfig(level=logging.INFO)
    
    # Create model
    engine_path = "path/to/tensorrt/engine.trt"
    if os.path.exists(engine_path):
        model = TensorRTModel(
            engine_path=engine_path,
            input_shape=(640, 640),
            confidence_threshold=0.7,
            nms_threshold=0.5
        )
        
        # Load test image
        image_path = "path/to/test/image.jpg"
        if os.path.exists(image_path):
            # Load image
            image = cv2.imread(image_path)
            
            # Perform prediction
            detections = model.predict(image)
            
            # Print detections
            for detection in detections:
                print(f"Detected {detection.defect_type} with confidence {detection.confidence:.2f}")
        else:
            print(f"Test image not found: {image_path}")
    else:
        print(f"Engine file not found: {engine_path}")
