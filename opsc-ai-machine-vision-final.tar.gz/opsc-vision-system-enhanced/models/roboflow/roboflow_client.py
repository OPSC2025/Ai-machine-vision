"""
Enhanced Roboflow client for OPSC Sandwich Quality Inspection System.
Provides comprehensive functionality for model training, management, and inference.

Version: 1.0.0
Last Updated: 2025-04-22
"""

import os
import sys
import time
import json
import logging
import numpy as np
import cv2
import requests
import base64
import tempfile
import shutil
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union, Any, BinaryIO
from dataclasses import dataclass, field
import datetime
import uuid
import threading
import queue

# Setup logging
logger = logging.getLogger(__name__)

@dataclass
class ModelVersion:
    """Class to store model version information."""
    version_id: int
    created_at: str
    status: str
    metrics: Dict[str, Any] = field(default_factory=dict)
    format: str = "tensorrt"
    size: Optional[int] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert model version to dictionary."""
        return {
            "version_id": self.version_id,
            "created_at": self.created_at,
            "status": self.status,
            "metrics": self.metrics,
            "format": self.format,
            "size": self.size
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ModelVersion':
        """Create model version from dictionary."""
        return cls(
            version_id=data["version_id"],
            created_at=data["created_at"],
            status=data["status"],
            metrics=data.get("metrics", {}),
            format=data.get("format", "tensorrt"),
            size=data.get("size")
        )


@dataclass
class Dataset:
    """Class to store dataset information."""
    dataset_id: str
    name: str
    created_at: str
    image_count: int
    annotation_count: int
    split: Dict[str, int] = field(default_factory=lambda: {"train": 0, "valid": 0, "test": 0})
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert dataset to dictionary."""
        return {
            "dataset_id": self.dataset_id,
            "name": self.name,
            "created_at": self.created_at,
            "image_count": self.image_count,
            "annotation_count": self.annotation_count,
            "split": self.split
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Dataset':
        """Create dataset from dictionary."""
        return cls(
            dataset_id=data["dataset_id"],
            name=data["name"],
            created_at=data["created_at"],
            image_count=data["image_count"],
            annotation_count=data["annotation_count"],
            split=data.get("split", {"train": 0, "valid": 0, "test": 0})
        )


@dataclass
class TrainingJob:
    """Class to store training job information."""
    job_id: str
    model_type: str
    status: str
    created_at: str
    completed_at: Optional[str] = None
    progress: float = 0.0
    epochs: int = 100
    batch_size: int = 16
    learning_rate: float = 0.001
    dataset_id: Optional[str] = None
    version_id: Optional[int] = None
    metrics: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert training job to dictionary."""
        return {
            "job_id": self.job_id,
            "model_type": self.model_type,
            "status": self.status,
            "created_at": self.created_at,
            "completed_at": self.completed_at,
            "progress": self.progress,
            "epochs": self.epochs,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "dataset_id": self.dataset_id,
            "version_id": self.version_id,
            "metrics": self.metrics
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'TrainingJob':
        """Create training job from dictionary."""
        return cls(
            job_id=data["job_id"],
            model_type=data["model_type"],
            status=data["status"],
            created_at=data["created_at"],
            completed_at=data.get("completed_at"),
            progress=data.get("progress", 0.0),
            epochs=data.get("epochs", 100),
            batch_size=data.get("batch_size", 16),
            learning_rate=data.get("learning_rate", 0.001),
            dataset_id=data.get("dataset_id"),
            version_id=data.get("version_id"),
            metrics=data.get("metrics", {})
        )


@dataclass
class ImageAnnotation:
    """Class to store image annotation information."""
    class_name: str
    bbox: Tuple[float, float, float, float]  # x, y, width, height (normalized)
    confidence: float = 1.0
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert annotation to dictionary."""
        return {
            "class": self.class_name,
            "x": self.bbox[0],
            "y": self.bbox[1],
            "width": self.bbox[2],
            "height": self.bbox[3],
            "confidence": self.confidence
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ImageAnnotation':
        """Create annotation from dictionary."""
        return cls(
            class_name=data["class"],
            bbox=(data["x"], data["y"], data["width"], data["height"]),
            confidence=data.get("confidence", 1.0)
        )


class RoboflowClient:
    """
    Enhanced Roboflow client for OPSC Sandwich Quality Inspection System.
    
    Provides comprehensive functionality for model training, management, and inference.
    """
    
    def __init__(
        self,
        api_key: Optional[str] = None,
        workspace: str = "crustless-creations",
        project: str = "sandwich-qc",
        base_url: str = "https://api.roboflow.com"
    ):
        """
        Initialize Roboflow client.
        
        Args:
            api_key: Roboflow API key (if None, will look for ROBOFLOW_API_KEY env var)
            workspace: Roboflow workspace name
            project: Roboflow project name
            base_url: Roboflow API base URL
        """
        self.api_key = api_key or os.environ.get("ROBOFLOW_API_KEY")
        if not self.api_key:
            raise ValueError("Roboflow API key is required")
        
        self.workspace = workspace
        self.project = project
        self.base_url = base_url
        
        # Initialize session
        self.session = requests.Session()
        self.session.headers.update({
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}"
        })
        
        # Initialize cache
        self.cache = {
            "versions": {},
            "datasets": {},
            "jobs": {}
        }
        self.cache_lock = threading.Lock()
        
        # Initialize job monitoring
        self.job_queue = queue.Queue()
        self.job_thread = None
        self.job_thread_running = False
        
        logger.info(f"Initialized Roboflow client for {workspace}/{project}")
    
    def _make_request(self, method: str, endpoint: str, params: Optional[Dict[str, Any]] = None, 
                     data: Optional[Dict[str, Any]] = None, files: Optional[Dict[str, BinaryIO]] = None) -> Dict[str, Any]:
        """
        Make API request to Roboflow.
        
        Args:
            method: HTTP method (GET, POST, PUT, DELETE)
            endpoint: API endpoint
            params: Query parameters
            data: Request data
            files: Files to upload
        
        Returns:
            API response as dictionary
        """
        url = f"{self.base_url}/{endpoint}"
        
        try:
            if files:
                # For file uploads, don't use JSON
                headers = {"Authorization": f"Bearer {self.api_key}"}
                response = requests.request(method, url, params=params, data=data, files=files, headers=headers)
            else:
                # Use session for JSON requests
                response = self.session.request(method, url, params=params, json=data)
            
            # Check response
            response.raise_for_status()
            
            # Parse response
            if response.content:
                return response.json()
            else:
                return {}
        except requests.exceptions.RequestException as e:
            logger.error(f"API request failed: {e}")
            if hasattr(e, "response") and e.response is not None:
                logger.error(f"Response: {e.response.status_code} {e.response.text}")
            raise
    
    # Model Version Management
    
    def get_model_versions(self, force_refresh: bool = False) -> List[ModelVersion]:
        """
        Get all model versions.
        
        Args:
            force_refresh: Whether to force refresh from API
        
        Returns:
            List of model versions
        """
        # Check cache
        if not force_refresh and "versions" in self.cache and self.cache["versions"]:
            return list(self.cache["versions"].values())
        
        # Make API request
        endpoint = f"{self.workspace}/{self.project}/versions"
        response = self._make_request("GET", endpoint)
        
        # Parse response
        versions = []
        for version_data in response.get("versions", []):
            version = ModelVersion(
                version_id=version_data["version"],
                created_at=version_data["created"],
                status=version_data["status"],
                metrics=version_data.get("metrics", {}),
                format=version_data.get("format", "tensorrt"),
                size=version_data.get("size")
            )
            versions.append(version)
            
            # Update cache
            with self.cache_lock:
                self.cache["versions"][version.version_id] = version
        
        return versions
    
    def get_model_version(self, version_id: int, force_refresh: bool = False) -> Optional[ModelVersion]:
        """
        Get specific model version.
        
        Args:
            version_id: Model version ID
            force_refresh: Whether to force refresh from API
        
        Returns:
            Model version if found, None otherwise
        """
        # Check cache
        if not force_refresh and "versions" in self.cache and version_id in self.cache["versions"]:
            return self.cache["versions"][version_id]
        
        # Make API request
        endpoint = f"{self.workspace}/{self.project}/{version_id}"
        try:
            response = self._make_request("GET", endpoint)
            
            # Parse response
            version = ModelVersion(
                version_id=response["version"],
                created_at=response["created"],
                status=response["status"],
                metrics=response.get("metrics", {}),
                format=response.get("format", "tensorrt"),
                size=response.get("size")
            )
            
            # Update cache
            with self.cache_lock:
                self.cache["versions"][version.version_id] = version
            
            return version
        except Exception as e:
            logger.error(f"Error getting model version {version_id}: {e}")
            return None
    
    def export_model(self, version_id: int, format: str = "tensorrt", output_path: Optional[str] = None) -> Optional[str]:
        """
        Export model to local file.
        
        Args:
            version_id: Model version ID
            format: Export format (tensorrt, onnx, tensorflow, etc.)
            output_path: Output directory path (if None, will use temporary directory)
        
        Returns:
            Path to exported model if successful, None otherwise
        """
        try:
            # Make API request to get export URL
            endpoint = f"{self.workspace}/{self.project}/{version_id}/export"
            params = {"format": format}
            response = self._make_request("GET", endpoint, params=params)
            
            # Get export URL
            export_url = response.get("url")
            if not export_url:
                logger.error(f"No export URL found for version {version_id}")
                return None
            
            # Download model
            model_response = requests.get(export_url, stream=True)
            model_response.raise_for_status()
            
            # Determine output path
            if output_path is None:
                output_path = tempfile.mkdtemp()
            else:
                os.makedirs(output_path, exist_ok=True)
            
            # Determine filename
            content_disposition = model_response.headers.get("Content-Disposition", "")
            filename = None
            if "filename=" in content_disposition:
                filename = content_disposition.split("filename=")[1].strip('"')
            
            if not filename:
                filename = f"model_{version_id}_{format}.zip"
            
            # Save model
            model_path = os.path.join(output_path, filename)
            with open(model_path, "wb") as f:
                for chunk in model_response.iter_content(chunk_size=8192):
                    f.write(chunk)
            
            logger.info(f"Exported model version {version_id} to {model_path}")
            return model_path
        except Exception as e:
            logger.error(f"Error exporting model version {version_id}: {e}")
            return None
    
    # Dataset Management
    
    def get_datasets(self, force_refresh: bool = False) -> List[Dataset]:
        """
        Get all datasets.
        
        Args:
            force_refresh: Whether to force refresh from API
        
        Returns:
            List of datasets
        """
        # Check cache
        if not force_refresh and "datasets" in self.cache and self.cache["datasets"]:
            return list(self.cache["datasets"].values())
        
        # Make API request
        endpoint = f"{self.workspace}/{self.project}/datasets"
        response = self._make_request("GET", endpoint)
        
        # Parse response
        datasets = []
        for dataset_data in response.get("datasets", []):
            dataset = Dataset(
                dataset_id=dataset_data["id"],
                name=dataset_data["name"],
                created_at=dataset_data["created"],
                image_count=dataset_data.get("images", 0),
                annotation_count=dataset_data.get("annotations", 0),
                split=dataset_data.get("split", {"train": 0, "valid": 0, "test": 0})
            )
            datasets.append(dataset)
            
            # Update cache
            with self.cache_lock:
                self.cache["datasets"][dataset.dataset_id] = dataset
        
        return datasets
    
    def get_dataset(self, dataset_id: str, force_refresh: bool = False) -> Optional[Dataset]:
        """
        Get specific dataset.
        
        Args:
            dataset_id: Dataset ID
            force_refresh: Whether to force refresh from API
        
        Returns:
            Dataset if found, None otherwise
        """
        # Check cache
        if not force_refresh and "datasets" in self.cache and dataset_id in self.cache["datasets"]:
            return self.cache["datasets"][dataset_id]
        
        # Make API request
        endpoint = f"{self.workspace}/{self.project}/datasets/{dataset_id}"
        try:
            response = self._make_request("GET", endpoint)
            
            # Parse response
            dataset = Dataset(
                dataset_id=response["id"],
                name=response["name"],
                created_at=response["created"],
                image_count=response.get("images", 0),
                annotation_count=response.get("annotations", 0),
                split=response.get("split", {"train": 0, "valid": 0, "test": 0})
            )
            
            # Update cache
            with self.cache_lock:
                self.cache["datasets"][dataset.dataset_id] = dataset
            
            return dataset
        except Exception as e:
            logger.error(f"Error getting dataset {dataset_id}: {e}")
            return None
    
    def create_dataset(self, name: str) -> Optional[Dataset]:
        """
        Create new dataset.
        
        Args:
            name: Dataset name
        
        Returns:
            Created dataset if successful, None otherwise
        """
        try:
            # Make API request
            endpoint = f"{self.workspace}/{self.project}/datasets"
            data = {"name": name}
            response = self._make_request("POST", endpoint, data=data)
            
            # Parse response
            dataset = Dataset(
                dataset_id=response["id"],
                name=response["name"],
                created_at=response["created"],
                image_count=0,
                annotation_count=0
            )
            
            # Update cache
            with self.cache_lock:
                self.cache["datasets"][dataset.dataset_id] = dataset
            
            logger.info(f"Created dataset {name} with ID {dataset.dataset_id}")
            return dataset
        except Exception as e:
            logger.error(f"Error creating dataset {name}: {e}")
            return None
    
    def upload_image(self, dataset_id: str, image_path: str, annotations: Optional[List[ImageAnnotation]] = None, 
                    split: str = "train") -> bool:
        """
        Upload image to dataset.
        
        Args:
            dataset_id: Dataset ID
            image_path: Path to image file
            annotations: List of annotations (optional)
            split: Dataset split (train, valid, test)
        
        Returns:
            True if successful, False otherwise
        """
        try:
            # Prepare files
            with open(image_path, "rb") as f:
                files = {"file": (os.path.basename(image_path), f, "image/jpeg")}
                
                # Prepare data
                data = {"split": split}
                
                # Add annotations if provided
                if annotations:
                    data["annotations"] = json.dumps([a.to_dict() for a in annotations])
                
                # Make API request
                endpoint = f"{self.workspace}/{self.project}/datasets/{dataset_id}/images"
                self._make_request("POST", endpoint, data=data, files=files)
            
            logger.info(f"Uploaded image {image_path} to dataset {dataset_id}")
            return True
        except Exception as e:
            logger.error(f"Error uploading image {image_path} to dataset {dataset_id}: {e}")
            return False
    
    def batch_upload_images(self, dataset_id: str, image_dir: str, annotation_dir: Optional[str] = None, 
                           split: str = "train") -> Tuple[int, int]:
        """
        Upload multiple images to dataset.
        
        Args:
            dataset_id: Dataset ID
            image_dir: Directory containing images
            annotation_dir: Directory containing annotations (optional)
            split: Dataset split (train, valid, test)
        
        Returns:
            Tuple of (success_count, failure_count)
        """
        # Get image files
        image_files = []
        for ext in [".jpg", ".jpeg", ".png"]:
            image_files.extend(list(Path(image_dir).glob(f"*{ext}")))
        
        success_count = 0
        failure_count = 0
        
        for image_file in image_files:
            # Check for annotation file
            annotations = None
            if annotation_dir:
                annotation_file = Path(annotation_dir) / f"{image_file.stem}.json"
                if annotation_file.exists():
                    try:
                        with open(annotation_file, "r") as f:
                            annotation_data = json.load(f)
                        
                        # Parse annotations
                        if isinstance(annotation_data, list):
                            annotations = [ImageAnnotation.from_dict(a) for a in annotation_data]
                        elif "annotations" in annotation_data:
                            annotations = [ImageAnnotation.from_dict(a) for a in annotation_data["annotations"]]
                    except Exception as e:
                        logger.error(f"Error parsing annotation file {annotation_file}: {e}")
            
            # Upload image
            if self.upload_image(dataset_id, str(image_file), annotations, split):
                success_count += 1
            else:
                failure_count += 1
        
        logger.info(f"Batch upload: {success_count} successful, {failure_count} failed")
        return (success_count, failure_count)
    
    # Training Management
    
    def start_training(self, dataset_id: str, model_type: str = "yolov8", epochs: int = 100, 
                      batch_size: int = 16, learning_rate: float = 0.001) -> Optional[TrainingJob]:
        """
        Start model training.
        
        Args:
            dataset_id: Dataset ID
            model_type: Model type (yolov8, fasterrcnn, etc.)
            epochs: Number of training epochs
            batch_size: Training batch size
            learning_rate: Training learning rate
        
        Returns:
            Training job if successful, None otherwise
        """
        try:
            # Make API request
            endpoint = f"{self.workspace}/{self.project}/train"
            data = {
                "dataset_id": dataset_id,
                "model_type": model_type,
                "epochs": epochs,
                "batch_size": batch_size,
                "learning_rate": learning_rate
            }
            response = self._make_request("POST", endpoint, data=data)
            
            # Parse response
            job = TrainingJob(
                job_id=response["job_id"],
                model_type=model_type,
                status="queued",
                created_at=datetime.datetime.now().isoformat(),
                epochs=epochs,
                batch_size=batch_size,
                learning_rate=learning_rate,
                dataset_id=dataset_id
            )
            
            # Update cache
            with self.cache_lock:
                self.cache["jobs"][job.job_id] = job
            
            # Start job monitoring if not already running
            self._ensure_job_monitoring()
            
            # Add job to monitoring queue
            self.job_queue.put(job.job_id)
            
            logger.info(f"Started training job {job.job_id} for dataset {dataset_id}")
            return job
        except Exception as e:
            logger.error(f"Error starting training for dataset {dataset_id}: {e}")
            return None
    
    def get_training_job(self, job_id: str, force_refresh: bool = False) -> Optional[TrainingJob]:
        """
        Get training job status.
        
        Args:
            job_id: Training job ID
            force_refresh: Whether to force refresh from API
        
        Returns:
            Training job if found, None otherwise
        """
        # Check cache
        if not force_refresh and "jobs" in self.cache and job_id in self.cache["jobs"]:
            return self.cache["jobs"][job_id]
        
        # Make API request
        endpoint = f"{self.workspace}/{self.project}/jobs/{job_id}"
        try:
            response = self._make_request("GET", endpoint)
            
            # Parse response
            job = TrainingJob(
                job_id=job_id,
                model_type=response.get("model_type", "unknown"),
                status=response["status"],
                created_at=response.get("created_at", datetime.datetime.now().isoformat()),
                completed_at=response.get("completed_at"),
                progress=response.get("progress", 0.0),
                epochs=response.get("epochs", 100),
                batch_size=response.get("batch_size", 16),
                learning_rate=response.get("learning_rate", 0.001),
                dataset_id=response.get("dataset_id"),
                version_id=response.get("version_id"),
                metrics=response.get("metrics", {})
            )
            
            # Update cache
            with self.cache_lock:
                self.cache["jobs"][job.job_id] = job
            
            return job
        except Exception as e:
            logger.error(f"Error getting training job {job_id}: {e}")
            return None
    
    def _ensure_job_monitoring(self):
        """Ensure job monitoring thread is running."""
        if self.job_thread is None or not self.job_thread.is_alive():
            self.job_thread_running = True
            self.job_thread = threading.Thread(target=self._job_monitoring_thread, daemon=True)
            self.job_thread.start()
            logger.info("Started job monitoring thread")
    
    def _job_monitoring_thread(self):
        """Background thread for monitoring training jobs."""
        logger.info("Job monitoring thread started")
        
        # Set of jobs being monitored
        monitored_jobs = set()
        
        while self.job_thread_running:
            try:
                # Check for new jobs
                try:
                    while True:
                        job_id = self.job_queue.get_nowait()
                        monitored_jobs.add(job_id)
                        logger.info(f"Added job {job_id} to monitoring")
                except queue.Empty:
                    pass
                
                # Check status of monitored jobs
                completed_jobs = set()
                for job_id in monitored_jobs:
                    try:
                        job = self.get_training_job(job_id, force_refresh=True)
                        if job and job.status in ["completed", "failed", "cancelled"]:
                            logger.info(f"Job {job_id} {job.status} with version {job.version_id}")
                            completed_jobs.add(job_id)
                    except Exception as e:
                        logger.error(f"Error monitoring job {job_id}: {e}")
                
                # Remove completed jobs
                monitored_jobs -= completed_jobs
                
                # Sleep if no jobs to monitor
                if not monitored_jobs:
                    time.sleep(10)
                else:
                    time.sleep(30)
            except Exception as e:
                logger.error(f"Error in job monitoring thread: {e}")
                time.sleep(60)
        
        logger.info("Job monitoring thread stopped")
    
    # Inference
    
    def predict(self, image: Union[str, np.ndarray], version_id: Optional[int] = None, 
               confidence_threshold: float = 0.7, overlap_threshold: float = 0.5) -> List[Dict[str, Any]]:
        """
        Perform inference on image.
        
        Args:
            image: Image path or numpy array
            version_id: Model version ID (if None, will use latest version)
            confidence_threshold: Minimum confidence threshold
            overlap_threshold: Overlap threshold for NMS
        
        Returns:
            List of detection results
        """
        try:
            # Get version ID if not provided
            if version_id is None:
                versions = self.get_model_versions()
                if not versions:
                    raise ValueError("No model versions found")
                version_id = max(v.version_id for v in versions)
            
            # Convert image to base64
            if isinstance(image, str):
                with open(image, "rb") as f:
                    image_data = f.read()
                image_base64 = base64.b64encode(image_data).decode("utf-8")
            else:
                # Convert numpy array to JPEG
                _, buffer = cv2.imencode(".jpg", image)
                image_base64 = base64.b64encode(buffer).decode("utf-8")
            
            # Make API request
            endpoint = f"{self.workspace}/{self.project}/{version_id}/predict"
            data = {
                "image": image_base64,
                "confidence": confidence_threshold,
                "overlap": overlap_threshold
            }
            response = self._make_request("POST", endpoint, data=data)
            
            # Parse response
            return response.get("predictions", [])
        except Exception as e:
            logger.error(f"Error performing inference: {e}")
            return []
    
    # Model Evaluation
    
    def evaluate_model(self, version_id: int, dataset_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Evaluate model on dataset.
        
        Args:
            version_id: Model version ID
            dataset_id: Dataset ID (if None, will use test split of training dataset)
        
        Returns:
            Evaluation metrics
        """
        try:
            # Make API request
            endpoint = f"{self.workspace}/{self.project}/{version_id}/evaluate"
            data = {}
            if dataset_id:
                data["dataset_id"] = dataset_id
            
            response = self._make_request("POST", endpoint, data=data)
            
            # Parse response
            return response.get("metrics", {})
        except Exception as e:
            logger.error(f"Error evaluating model {version_id}: {e}")
            return {}
    
    def compare_models(self, version_ids: List[int], dataset_id: Optional[str] = None) -> Dict[str, Dict[str, Any]]:
        """
        Compare multiple model versions.
        
        Args:
            version_ids: List of model version IDs
            dataset_id: Dataset ID for evaluation (if None, will use test split of training dataset)
        
        Returns:
            Dictionary of model metrics keyed by version ID
        """
        results = {}
        for version_id in version_ids:
            metrics = self.evaluate_model(version_id, dataset_id)
            results[str(version_id)] = metrics
        
        return results
    
    # Utility Methods
    
    def clear_cache(self):
        """Clear client cache."""
        with self.cache_lock:
            self.cache = {
                "versions": {},
                "datasets": {},
                "jobs": {}
            }
        logger.info("Cleared client cache")
    
    def stop_job_monitoring(self):
        """Stop job monitoring thread."""
        if self.job_thread and self.job_thread.is_alive():
            self.job_thread_running = False
            self.job_thread.join(timeout=5.0)
            logger.info("Stopped job monitoring thread")


# Example usage
if __name__ == "__main__":
    # Set up logging
    logging.basicConfig(level=logging.INFO)
    
    # Create client
    client = RoboflowClient()
    
    # Get model versions
    versions = client.get_model_versions()
    print(f"Found {len(versions)} model versions")
    
    # Get datasets
    datasets = client.get_datasets()
    print(f"Found {len(datasets)} datasets")
    
    # Perform inference on test image
    image_path = "path/to/test/image.jpg"
    if os.path.exists(image_path):
        predictions = client.predict(image_path)
        print(f"Found {len(predictions)} predictions")
        for pred in predictions:
            print(f"Class: {pred['class']}, Confidence: {pred['confidence']:.2f}")
