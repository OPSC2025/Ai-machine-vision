"""
Roboflow model integration for sandwich defect detection.
This module provides a wrapper for the Roboflow API to detect defects in sandwich images.

Version: 1.0.0
Last Updated: 2025-04-21
"""

import os
import sys
import time
import json
import logging
import numpy as np
from typing import Dict, List, Optional, Tuple, Union, Any
import cv2
from pathlib import Path
import requests
import base64
from dataclasses import dataclass, field

# Setup logging
logger = logging.getLogger(__name__)

@dataclass
class DetectionResult:
    """Class to store detection results for a single defect."""
    defect_type: str
    confidence: float
    bbox: Tuple[float, float, float, float]  # x, y, width, height (normalized)
    image_id: str = ""
    timestamp: float = field(default_factory=time.time)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert detection result to dictionary."""
        return {
            "defect_type": self.defect_type,
            "confidence": self.confidence,
            "bbox": self.bbox,
            "image_id": self.image_id,
            "timestamp": self.timestamp
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'DetectionResult':
        """Create detection result from dictionary."""
        return cls(
            defect_type=data["defect_type"],
            confidence=data["confidence"],
            bbox=data["bbox"],
            image_id=data.get("image_id", ""),
            timestamp=data.get("timestamp", time.time())
        )
    
    def get_absolute_bbox(self, image_width: int, image_height: int) -> Tuple[int, int, int, int]:
        """Convert normalized bbox to absolute pixel coordinates."""
        x, y, w, h = self.bbox
        x_abs = int(x * image_width)
        y_abs = int(y * image_height)
        w_abs = int(w * image_width)
        h_abs = int(h * image_height)
        return (x_abs, y_abs, w_abs, h_abs)


class SandwichDefectModel:
    """
    Wrapper for Roboflow model to detect defects in sandwich images.
    
    This class provides methods to load a model from Roboflow and perform inference
    on sandwich images to detect various types of defects.
    """
    
    def __init__(
        self,
        workspace: str = "crustless-creations",
        project: str = "sandwich-qc",
        version: int = 1,
        api_key: Optional[str] = None,
        model_format: str = "tensorrt",
        local_inference: bool = True,
        local_model_path: Optional[str] = None,
        confidence_threshold: float = 0.7,
        overlap_threshold: float = 0.5
    ):
        """
        Initialize the sandwich defect model.
        
        Args:
            workspace: Roboflow workspace name
            project: Roboflow project name
            version: Roboflow model version
            api_key: Roboflow API key (if None, will look for ROBOFLOW_API_KEY env var)
            model_format: Model format (tensorrt, onnx, tensorflow, etc.)
            local_inference: Whether to use local inference or Roboflow API
            local_model_path: Path to local model files (if None, will use default path)
            confidence_threshold: Minimum confidence threshold for detections
            overlap_threshold: Overlap threshold for non-maximum suppression
        """
        self.workspace = workspace
        self.project = project
        self.version = version
        self.api_key = api_key or os.environ.get("ROBOFLOW_API_KEY")
        self.model_format = model_format
        self.local_inference = local_inference
        self.local_model_path = local_model_path
        self.confidence_threshold = confidence_threshold
        self.overlap_threshold = overlap_threshold
        
        # Initialize model
        self.model = None
        self.initialized = False
        self.defect_classes = [
            "improper_sealing",
            "filling_leakage",
            "size_inconsistency",
            "mold",
            "holes",
            "destroyed_sandwich",
            "foreign_material"
        ]
        
        # Load model
        if self.local_inference:
            self._load_local_model()
        else:
            self._initialize_api()
    
    def _load_local_model(self):
        """Load local model for inference."""
        try:
            # Import roboflow module
            from roboflow import Roboflow
            
            # Check if API key is available
            if not self.api_key:
                raise ValueError("Roboflow API key is required for local inference")
            
            # Initialize Roboflow
            rf = Roboflow(api_key=self.api_key)
            
            # Get project
            project = rf.workspace(self.workspace).project(self.project)
            
            # Get model version
            model = project.version(self.version).model
            
            # Set model
            self.model = model
            self.initialized = True
            
            logger.info(f"Loaded local model: {self.workspace}/{self.project} (version {self.version})")
        except Exception as e:
            logger.error(f"Error loading local model: {e}")
            raise
    
    def _initialize_api(self):
        """Initialize Roboflow API for inference."""
        # Check if API key is available
        if not self.api_key:
            raise ValueError("Roboflow API key is required for API inference")
        
        # Set API URL
        self.api_url = f"https://detect.roboflow.com/{self.project}/{self.version}"
        
        # Set initialized flag
        self.initialized = True
        
        logger.info(f"Initialized Roboflow API: {self.workspace}/{self.project} (version {self.version})")
    
    def predict(self, image: np.ndarray) -> List[DetectionResult]:
        """
        Perform inference on an image to detect sandwich defects.
        
        Args:
            image: Image as numpy array (BGR format)
        
        Returns:
            List of detection results
        """
        if not self.initialized:
            raise RuntimeError("Model not initialized")
        
        try:
            if self.local_inference:
                return self._predict_local(image)
            else:
                return self._predict_api(image)
        except Exception as e:
            logger.error(f"Error during prediction: {e}")
            return []
    
    def _predict_local(self, image: np.ndarray) -> List[DetectionResult]:
        """Perform local inference using Roboflow model."""
        # Convert BGR to RGB
        image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        
        # Get image dimensions
        height, width = image.shape[:2]
        
        # Perform prediction
        predictions = self.model.predict(image_rgb, confidence=self.confidence_threshold, overlap=self.overlap_threshold).json()
        
        # Process predictions
        results = []
        for pred in predictions.get("predictions", []):
            # Get class name
            class_name = pred.get("class", "")
            
            # Skip if class is not in defect classes
            if class_name not in self.defect_classes:
                continue
            
            # Get confidence
            confidence = pred.get("confidence", 0.0)
            
            # Get bounding box (normalized)
            x = pred.get("x", 0) / width
            y = pred.get("y", 0) / height
            w = pred.get("width", 0) / width
            h = pred.get("height", 0) / height
            
            # Create detection result
            result = DetectionResult(
                defect_type=class_name,
                confidence=confidence,
                bbox=(x, y, w, h)
            )
            
            # Add to results
            results.append(result)
        
        return results
    
    def _predict_api(self, image: np.ndarray) -> List[DetectionResult]:
        """Perform inference using Roboflow API."""
        # Convert image to base64
        _, buffer = cv2.imencode(".jpg", image)
        image_base64 = base64.b64encode(buffer).decode("utf-8")
        
        # Get image dimensions
        height, width = image.shape[:2]
        
        # Prepare API request
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}"
        }
        data = {
            "image": image_base64,
            "confidence": self.confidence_threshold,
            "overlap": self.overlap_threshold
        }
        
        # Make API request
        response = requests.post(self.api_url, headers=headers, json=data)
        
        # Check response
        if response.status_code != 200:
            logger.error(f"API request failed: {response.status_code} {response.text}")
            return []
        
        # Parse response
        predictions = response.json()
        
        # Process predictions
        results = []
        for pred in predictions.get("predictions", []):
            # Get class name
            class_name = pred.get("class", "")
            
            # Skip if class is not in defect classes
            if class_name not in self.defect_classes:
                continue
            
            # Get confidence
            confidence = pred.get("confidence", 0.0)
            
            # Get bounding box (normalized)
            x = pred.get("x", 0) / width
            y = pred.get("y", 0) / height
            w = pred.get("width", 0) / width
            h = pred.get("height", 0) / height
            
            # Create detection result
            result = DetectionResult(
                defect_type=class_name,
                confidence=confidence,
                bbox=(x, y, w, h)
            )
            
            # Add to results
            results.append(result)
        
        return results
    
    def visualize_detections(self, image: np.ndarray, detections: List[DetectionResult]) -> np.ndarray:
        """
        Visualize detections on an image.
        
        Args:
            image: Image as numpy array (BGR format)
            detections: List of detection results
        
        Returns:
            Image with visualized detections
        """
        # Create a copy of the image
        vis_image = image.copy()
        
        # Get image dimensions
        height, width = image.shape[:2]
        
        # Define colors for different defect types (BGR format)
        colors = {
            "improper_sealing": (0, 165, 255),     # Orange
            "filling_leakage": (0, 0, 255),        # Red
            "size_inconsistency": (255, 0, 0),     # Blue
            "mold": (0, 255, 0),                   # Green
            "holes": (255, 0, 255),                # Magenta
            "destroyed_sandwich": (0, 255, 255),   # Yellow
            "foreign_material": (255, 255, 0)      # Cyan
        }
        
        # Draw each detection
        for detection in detections:
            # Get absolute bounding box
            x, y, w, h = detection.get_absolute_bbox(width, height)
            
            # Get color for defect type
            color = colors.get(detection.defect_type, (255, 255, 255))
            
            # Draw bounding box
            cv2.rectangle(vis_image, (x - w//2, y - h//2), (x + w//2, y + h//2), color, 2)
            
            # Prepare label text
            label = f"{detection.defect_type}: {detection.confidence:.2f}"
            
            # Get text size
            (text_width, text_height), baseline = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)
            
            # Draw label background
            cv2.rectangle(vis_image, (x - w//2, y - h//2 - text_height - 5), (x - w//2 + text_width, y - h//2), color, -1)
            
            # Draw label text
            cv2.putText(vis_image, label, (x - w//2, y - h//2 - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
        
        return vis_image


# Example usage
if __name__ == "__main__":
    # Set up logging
    logging.basicConfig(level=logging.INFO)
    
    # Create model
    model = SandwichDefectModel(
        workspace="crustless-creations",
        project="sandwich-qc",
        version=1,
        local_inference=False  # Use API for testing
    )
    
    # Load test image
    image_path = "path/to/test/image.jpg"
    if os.path.exists(image_path):
        # Load image
        image = cv2.imread(image_path)
        
        # Perform prediction
        detections = model.predict(image)
        
        # Print detections
        for detection in detections:
            print(f"Detected {detection.defect_type} with confidence {detection.confidence:.2f}")
        
        # Visualize detections
        vis_image = model.visualize_detections(image, detections)
        
        # Save visualization
        cv2.imwrite("detection_result.jpg", vis_image)
    else:
        print(f"Test image not found: {image_path}")
