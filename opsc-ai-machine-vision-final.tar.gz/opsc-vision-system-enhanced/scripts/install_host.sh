#!/bin/bash
# install_host.sh
# Installation script for Host PC component of OPSC Sandwich Quality Inspection System
# Version: 1.0.0
# Last Updated: 2025-04-21

set -e  # Exit on error

# Print colored output
print_info() {
    echo -e "\e[34m[INFO]\e[0m $1"
}

print_success() {
    echo -e "\e[32m[SUCCESS]\e[0m $1"
}

print_error() {
    echo -e "\e[31m[ERROR]\e[0m $1"
}

print_warning() {
    echo -e "\e[33m[WARNING]\e[0m $1"
}

# Check if running as root
if [[ $EUID -eq 0 ]]; then
    print_error "This script should not be run as root. Please run as a regular user with sudo privileges."
    exit 1
fi

# Check for sudo privileges
if ! sudo -v; then
    print_error "This script requires sudo privileges. Please ensure you have sudo access."
    exit 1
fi

# Check for NVIDIA GPU
if ! lspci | grep -i nvidia > /dev/null; then
    print_error "No NVIDIA GPU detected. This system requires an NVIDIA GPU (RTX 4060 or better)."
    exit 1
fi

print_info "Installing OPSC Sandwich Quality Inspection System (Host PC component)..."

# Create installation directory
INSTALL_DIR="/opt/opsc-vision-system"
print_info "Creating installation directory: $INSTALL_DIR"
sudo mkdir -p $INSTALL_DIR
sudo chown $USER:$USER $INSTALL_DIR

# Create data directories
print_info "Creating data directories..."
sudo mkdir -p /var/lib/opsc-vision-system/{database,logs,images,reports,calibration}
sudo chown -R $USER:$USER /var/lib/opsc-vision-system

# Install system dependencies
print_info "Installing system dependencies..."
sudo apt-get update
sudo apt-get install -y \
    python3-pip \
    python3-dev \
    python3-opencv \
    libopencv-dev \
    libglib2.0-0 \
    libsm6 \
    libxext6 \
    libxrender-dev \
    libgl1-mesa-glx \
    wget \
    curl \
    git \
    unzip \
    pkg-config \
    build-essential \
    cmake \
    ffmpeg \
    libavcodec-dev \
    libavformat-dev \
    libswscale-dev \
    docker.io \
    docker-compose

# Add user to docker group
print_info "Adding user to docker group..."
sudo usermod -aG docker $USER
print_warning "You may need to log out and log back in for docker group changes to take effect."

# Install Pylon SDK for Basler cameras
print_info "Installing Pylon SDK for Basler cameras..."
cd /tmp
wget -q https://www.baslerweb.com/fp-1615275617/media/downloads/software/pylon_software/pylon_7.4.0.13389_linux_x86_64_debs.tar.gz
tar -xzf pylon_7.4.0.13389_linux_x86_64_debs.tar.gz
cd pylon_7.4.0.13389_linux_x86_64_debs
sudo apt-get install -y ./pylon_7.4.0.13389-deb0_amd64.deb
cd ~
rm -rf /tmp/pylon*

# Check CUDA installation
print_info "Checking CUDA installation..."
if ! command -v nvcc &> /dev/null; then
    print_info "Installing CUDA..."
    wget https://developer.download.nvidia.com/compute/cuda/repos/ubuntu2204/x86_64/cuda-keyring_1.1-1_all.deb
    sudo dpkg -i cuda-keyring_1.1-1_all.deb
    sudo apt-get update
    sudo apt-get install -y cuda-12-3
    rm cuda-keyring_1.1-1_all.deb
    
    # Set up CUDA environment variables
    echo 'export PATH=/usr/local/cuda/bin:$PATH' | sudo tee -a /etc/profile.d/cuda.sh
    echo 'export LD_LIBRARY_PATH=/usr/local/cuda/lib64:$LD_LIBRARY_PATH' | sudo tee -a /etc/profile.d/cuda.sh
    source /etc/profile.d/cuda.sh
else
    print_info "CUDA is already installed."
fi

# Install TensorRT
print_info "Installing TensorRT..."
pip3 install --user nvidia-tensorrt

# Copy application files
print_info "Copying application files..."
cp -r . $INSTALL_DIR/
cd $INSTALL_DIR

# Create symbolic links for data directories
ln -sf /var/lib/opsc-vision-system/database data/database
ln -sf /var/lib/opsc-vision-system/logs data/logs
ln -sf /var/lib/opsc-vision-system/images data/images
ln -sf /var/lib/opsc-vision-system/reports data/reports
ln -sf /var/lib/opsc-vision-system/calibration data/calibration

# Install Python dependencies
print_info "Installing Python dependencies..."
pip3 install --user -r requirements.txt

# Install the application
print_info "Installing the application..."
pip3 install --user -e .

# Create systemd service
print_info "Creating systemd service..."
sudo tee /etc/systemd/system/opsc-vision-system.service > /dev/null << EOF
[Unit]
Description=OPSC Sandwich Quality Inspection System
After=network.target docker.service
Requires=docker.service

[Service]
Type=simple
User=$USER
WorkingDirectory=$INSTALL_DIR
ExecStart=/usr/bin/python3 -m src.main --config config/app.yaml
Restart=on-failure
RestartSec=5
Environment=PYTHONPATH=$INSTALL_DIR
Environment=DISPLAY=:0

[Install]
WantedBy=multi-user.target
EOF

# Create environment file for service
print_info "Creating environment file..."
sudo tee /etc/opsc-vision-system.env > /dev/null << EOF
ROBOFLOW_API_KEY=your_roboflow_api_key_here
AZURE_STORAGE_CONNECTION_STRING=your_azure_connection_string_here
EOF

print_info "Please update the API keys in /etc/opsc-vision-system.env"

# Enable and start the service
print_info "Enabling and starting the service..."
sudo systemctl daemon-reload
sudo systemctl enable opsc-vision-system.service
sudo systemctl start opsc-vision-system.service

# Create desktop shortcut
print_info "Creating desktop shortcut..."
mkdir -p ~/.local/share/applications
cat > ~/.local/share/applications/opsc-vision-system.desktop << EOF
[Desktop Entry]
Name=OPSC Sandwich Quality Inspection
Comment=AI-powered sandwich quality inspection system
Exec=xdg-open http://localhost:8501
Icon=$INSTALL_DIR/docs/images/logo.png
Terminal=false
Type=Application
Categories=Utility;
EOF

# Run network optimization script
print_info "Running network optimization script..."
sudo $INSTALL_DIR/scripts/setup_network.sh

print_success "Installation complete!"
print_info "The OPSC Sandwich Quality Inspection System is now installed and running."
print_info "You can access the web interface at: http://localhost:8501"
print_info "To check the service status, run: sudo systemctl status opsc-vision-system.service"
print_info "To view logs, run: sudo journalctl -u opsc-vision-system.service"
print_warning "Please update the API keys in /etc/opsc-vision-system.env and restart the service:"
print_warning "sudo systemctl restart opsc-vision-system.service"
