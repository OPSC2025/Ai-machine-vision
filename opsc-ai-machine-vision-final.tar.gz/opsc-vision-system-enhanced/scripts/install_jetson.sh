#!/bin/bash
# install_jetson.sh
# Installation script for Jetson Xavier NX component of OPSC Sandwich Quality Inspection System
# Version: 1.0.0
# Last Updated: 2025-04-21

set -e  # Exit on error

# Print colored output
print_info() {
    echo -e "\e[34m[INFO]\e[0m $1"
}

print_success() {
    echo -e "\e[32m[SUCCESS]\e[0m $1"
}

print_error() {
    echo -e "\e[31m[ERROR]\e[0m $1"
}

print_warning() {
    echo -e "\e[33m[WARNING]\e[0m $1"
}

# Check if running on Jetson device
if ! grep -q "NVIDIA Jetson" /proc/device-tree/model 2>/dev/null; then
    print_error "This script must be run on a Jetson device. Exiting."
    exit 1
fi

# Check if running as root
if [[ $EUID -eq 0 ]]; then
    print_error "This script should not be run as root. Please run as a regular user with sudo privileges."
    exit 1
fi

# Check for sudo privileges
if ! sudo -v; then
    print_error "This script requires sudo privileges. Please ensure you have sudo access."
    exit 1
fi

print_info "Installing OPSC Sandwich Quality Inspection System (Jetson Xavier NX component)..."

# Create installation directory
INSTALL_DIR="/opt/opsc-vision-system"
print_info "Creating installation directory: $INSTALL_DIR"
sudo mkdir -p $INSTALL_DIR
sudo chown $USER:$USER $INSTALL_DIR

# Create data directories
print_info "Creating data directories..."
sudo mkdir -p /var/lib/opsc-vision-system/{logs,models}
sudo chown -R $USER:$USER /var/lib/opsc-vision-system

# Install system dependencies
print_info "Installing system dependencies..."
sudo apt-get update
sudo apt-get install -y \
    python3-pip \
    python3-dev \
    python3-opencv \
    libopencv-dev \
    libglib2.0-0 \
    libsm6 \
    libxext6 \
    libxrender-dev \
    libgl1-mesa-glx \
    wget \
    curl \
    git \
    unzip \
    pkg-config \
    build-essential \
    cmake \
    ffmpeg \
    libavcodec-dev \
    libavformat-dev \
    libswscale-dev \
    jtop \
    docker.io

# Add user to docker group
print_info "Adding user to docker group..."
sudo usermod -aG docker $USER
print_warning "You may need to log out and log back in for docker group changes to take effect."

# Install Docker Compose
print_info "Installing Docker Compose..."
sudo apt-get install -y python3-pip
sudo pip3 install docker-compose

# Set up Jetson power mode
print_info "Setting up Jetson power mode..."
if command -v nvpmodel > /dev/null; then
    sudo nvpmodel -m 0  # Set to MAXN mode for maximum performance
    print_success "Set Jetson power mode to MAXN (maximum performance)."
else
    print_warning "nvpmodel command not found. Unable to set power mode."
fi

# Set up Jetson clock speeds
print_info "Setting up Jetson clock speeds..."
if command -v jetson_clocks > /dev/null; then
    sudo jetson_clocks
    print_success "Set Jetson clocks to maximum performance."
else
    print_warning "jetson_clocks command not found. Unable to set clock speeds."
fi

# Copy application files
print_info "Copying application files..."
mkdir -p $INSTALL_DIR/{models,config}
cp -r models/* $INSTALL_DIR/models/
cp -r config/* $INSTALL_DIR/config/

# Create symbolic links for data directories
ln -sf /var/lib/opsc-vision-system/logs $INSTALL_DIR/logs
ln -sf /var/lib/opsc-vision-system/models $INSTALL_DIR/models/weights

# Install Python dependencies
print_info "Installing Python dependencies..."
pip3 install --user \
    numpy==2.2.4 \
    pyyaml==6.0.2 \
    roboflow==1.1.9 \
    azure-storage-blob==12.19.0 \
    azure-identity==1.15.0 \
    tensorrt

# Create TensorRT model service
print_info "Creating TensorRT model service..."
sudo tee /etc/systemd/system/opsc-tensorrt-service.service > /dev/null << EOF
[Unit]
Description=OPSC TensorRT Inference Service
After=network.target

[Service]
Type=simple
User=$USER
WorkingDirectory=$INSTALL_DIR
ExecStart=/usr/bin/python3 -m models.weights.tensorrt_model --config config/models.yaml
Restart=on-failure
RestartSec=5
Environment=PYTHONPATH=$INSTALL_DIR

[Install]
WantedBy=multi-user.target
EOF

# Create environment file for service
print_info "Creating environment file..."
sudo tee /etc/opsc-vision-system.env > /dev/null << EOF
ROBOFLOW_API_KEY=your_roboflow_api_key_here
AZURE_STORAGE_CONNECTION_STRING=your_azure_connection_string_here
EOF

print_info "Please update the API keys in /etc/opsc-vision-system.env"

# Enable and start the service
print_info "Enabling and starting the service..."
sudo systemctl daemon-reload
sudo systemctl enable opsc-tensorrt-service.service
sudo systemctl start opsc-tensorrt-service.service

# Set up fan control for better cooling
print_info "Setting up fan control..."
if [ -f "/sys/devices/pwm-fan/target_pwm" ]; then
    # Create fan control service
    sudo tee /etc/systemd/system/jetson-fan-control.service > /dev/null << EOF
[Unit]
Description=Jetson Fan Control Service
After=multi-user.target

[Service]
Type=oneshot
ExecStart=/bin/sh -c "echo 255 > /sys/devices/pwm-fan/target_pwm"
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
EOF

    # Enable and start the service
    sudo systemctl enable jetson-fan-control.service
    sudo systemctl start jetson-fan-control.service
    print_success "Fan control service configured and started."
else
    print_warning "Fan control not available on this device."
fi

# Run network optimization script
print_info "Running network optimization script..."
sudo $INSTALL_DIR/scripts/setup_network.sh

# Create model conversion script if it doesn't exist
if [ ! -f "$INSTALL_DIR/models/convert_to_tensorrt.py" ]; then
    print_info "Creating model conversion script..."
    cat > $INSTALL_DIR/models/convert_to_tensorrt.py << EOF
#!/usr/bin/env python3
"""
Convert ONNX models to TensorRT for optimized inference on Jetson.
"""

import os
import sys
import argparse
import tensorrt as trt
import logging

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def build_engine(onnx_file_path, engine_file_path, precision="fp16", workspace_size=1<<30, dla_core=0, use_dla=True):
    """
    Build TensorRT engine from ONNX model.
    
    Args:
        onnx_file_path: Path to ONNX model
        engine_file_path: Path to save TensorRT engine
        precision: Precision mode (fp32, fp16, int8)
        workspace_size: Maximum workspace size
        dla_core: DLA core to use (0 or 1)
        use_dla: Whether to use DLA
    
    Returns:
        bool: True if successful, False otherwise
    """
    try:
        logger.info(f"Building TensorRT engine from {onnx_file_path}")
        logger.info(f"Precision: {precision}, DLA Core: {dla_core if use_dla else 'Not used'}")
        
        # Initialize TensorRT
        TRT_LOGGER = trt.Logger(trt.Logger.INFO)
        builder = trt.Builder(TRT_LOGGER)
        network = builder.create_network(1 << int(trt.NetworkDefinitionCreationFlag.EXPLICIT_BATCH))
        config = builder.create_builder_config()
        config.max_workspace_size = workspace_size
        
        # Set precision
        if precision == "fp16" and builder.platform_has_fast_fp16:
            config.set_flag(trt.BuilderFlag.FP16)
            logger.info("Enabled FP16 precision")
        elif precision == "int8" and builder.platform_has_fast_int8:
            config.set_flag(trt.BuilderFlag.INT8)
            logger.info("Enabled INT8 precision")
        
        # Set DLA if available
        if use_dla and builder.num_DLA_cores > 0:
            config.default_device_type = trt.DeviceType.DLA
            config.DLA_core = dla_core
            logger.info(f"Using DLA core {dla_core}")
        
        # Parse ONNX model
        parser = trt.OnnxParser(network, TRT_LOGGER)
        with open(onnx_file_path, 'rb') as model:
            if not parser.parse(model.read()):
                for error in range(parser.num_errors):
                    logger.error(f"ONNX parse error: {parser.get_error(error)}")
                return False
        
        # Build engine
        logger.info("Building TensorRT engine (this may take a while)...")
        engine = builder.build_engine(network, config)
        if engine is None:
            logger.error("Failed to build TensorRT engine")
            return False
        
        # Save engine
        with open(engine_file_path, 'wb') as f:
            f.write(engine.serialize())
        
        logger.info(f"TensorRT engine saved to {engine_file_path}")
        return True
    
    except Exception as e:
        logger.error(f"Error building TensorRT engine: {e}")
        return False

def main():
    parser = argparse.ArgumentParser(description="Convert ONNX model to TensorRT engine")
    parser.add_argument("--input_model", type=str, required=True, help="Path to input ONNX model")
    parser.add_argument("--output_model", type=str, required=True, help="Path to output TensorRT engine")
    parser.add_argument("--precision", type=str, default="fp16", choices=["fp32", "fp16", "int8"], help="Precision mode")
    parser.add_argument("--workspace_size", type=int, default=1<<30, help="Maximum workspace size in bytes")
    parser.add_argument("--dla_core", type=int, default=0, choices=[0, 1], help="DLA core to use")
    parser.add_argument("--use_dla", action="store_true", help="Use DLA for inference")
    
    args = parser.parse_args()
    
    if not os.path.exists(args.input_model):
        logger.error(f"Input model not found: {args.input_model}")
        return 1
    
    # Create output directory if it doesn't exist
    output_dir = os.path.dirname(args.output_model)
    if output_dir and not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    # Build engine
    success = build_engine(
        args.input_model,
        args.output_model,
        args.precision,
        args.workspace_size,
        args.dla_core,
        args.use_dla
    )
    
    return 0 if success else 1

if __name__ == "__main__":
    sys.exit(main())
EOF
    chmod +x $INSTALL_DIR/models/convert_to_tensorrt.py
fi

print_success "Installation complete!"
print_info "The OPSC Sandwich Quality Inspection System (Jetson component) is now installed and running."
print_info "To check the service status, run: sudo systemctl status opsc-tensorrt-service.service"
print_info "To view logs, run: sudo journalctl -u opsc-tensorrt-service.service"
print_warning "Please update the API keys in /etc/opsc-vision-system.env and restart the service:"
print_warning "sudo systemctl restart opsc-tensorrt-service.service"
print_info "If you need to convert models, use the conversion script:"
print_info "python3 $INSTALL_DIR/models/convert_to_tensorrt.py --input_model=/path/to/model.onnx --output_model=$INSTALL_DIR/models/weights/sandwich_model.trt --use_dla"
