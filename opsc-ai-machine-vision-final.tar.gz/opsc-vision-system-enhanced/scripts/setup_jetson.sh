#!/bin/bash
# setup_jetson.sh
# Setup script for ADLINK DLAP-211-JNX (Jetson Xavier NX) device
# Version: 1.0.0
# Last Updated: 2025-04-21

set -e  # Exit on error

# Print colored output
print_info() {
    echo -e "\e[34m[INFO]\e[0m $1"
}

print_success() {
    echo -e "\e[32m[SUCCESS]\e[0m $1"
}

print_error() {
    echo -e "\e[31m[ERROR]\e[0m $1"
}

print_warning() {
    echo -e "\e[33m[WARNING]\e[0m $1"
}

# Check if running on Jetson device
if ! grep -q "NVIDIA Jetson" /proc/device-tree/model 2>/dev/null; then
    print_error "This script must be run on a Jetson device. Exiting."
    exit 1
fi

# Check if running as root
if [[ $EUID -eq 0 ]]; then
    print_error "This script should not be run as root. Please run as a regular user with sudo privileges."
    exit 1
fi

# Check for sudo privileges
if ! sudo -v; then
    print_error "This script requires sudo privileges. Please ensure you have sudo access."
    exit 1
fi

print_info "Setting up ADLINK DLAP-211-JNX (Jetson Xavier NX) device..."

# Create directories if they don't exist
print_info "Creating directory structure..."
mkdir -p ~/opsc-vision-system/{models,config,data}
mkdir -p ~/opsc-vision-system/models/{roboflow,weights}
mkdir -p ~/opsc-vision-system/data/logs

# Update package lists
print_info "Updating package lists..."
sudo apt-get update

# Install system dependencies
print_info "Installing system dependencies..."
sudo apt-get install -y \
    python3-pip \
    python3-dev \
    python3-opencv \
    libopencv-dev \
    libglib2.0-0 \
    libsm6 \
    libxext6 \
    libxrender-dev \
    libgl1-mesa-glx \
    wget \
    curl \
    git \
    unzip \
    pkg-config \
    build-essential \
    cmake \
    ffmpeg \
    libavcodec-dev \
    libavformat-dev \
    libswscale-dev \
    jtop

# Install Python dependencies
print_info "Installing Python dependencies..."
pip3 install --user \
    numpy==2.2.4 \
    pyyaml==6.0.2 \
    roboflow==1.1.9 \
    azure-storage-blob==12.19.0 \
    azure-identity==1.15.0

# Set up Jetson power mode
print_info "Setting up Jetson power mode..."
if command -v nvpmodel > /dev/null; then
    sudo nvpmodel -m 0  # Set to MAXN mode for maximum performance
    print_success "Set Jetson power mode to MAXN (maximum performance)."
else
    print_warning "nvpmodel command not found. Unable to set power mode."
fi

# Set up Jetson clock speeds
print_info "Setting up Jetson clock speeds..."
if command -v jetson_clocks > /dev/null; then
    sudo jetson_clocks
    print_success "Set Jetson clocks to maximum performance."
else
    print_warning "jetson_clocks command not found. Unable to set clock speeds."
fi

# Set up network configuration for high-throughput
print_info "Setting up network configuration..."
sudo sysctl -w net.core.rmem_max=26214400
sudo sysctl -w net.core.wmem_max=26214400
sudo sysctl -w net.ipv4.tcp_rmem="4096 87380 26214400"
sudo sysctl -w net.ipv4.tcp_wmem="4096 87380 26214400"

# Make these settings persistent
if ! grep -q "net.core.rmem_max" /etc/sysctl.conf; then
    echo "net.core.rmem_max=26214400" | sudo tee -a /etc/sysctl.conf
    echo "net.core.wmem_max=26214400" | sudo tee -a /etc/sysctl.conf
    echo "net.ipv4.tcp_rmem=4096 87380 26214400" | sudo tee -a /etc/sysctl.conf
    echo "net.ipv4.tcp_wmem=4096 87380 26214400" | sudo tee -a /etc/sysctl.conf
fi

# Set up static IP address if not already configured
print_info "Setting up static IP address..."
INTERFACE=$(ip route | grep default | awk '{print $5}')
if [ -n "$INTERFACE" ]; then
    if ! grep -q "static" /etc/network/interfaces.d/$INTERFACE; then
        print_info "Configuring static IP for $INTERFACE..."
        sudo tee /etc/network/interfaces.d/$INTERFACE > /dev/null << EOF
auto $INTERFACE
iface $INTERFACE inet static
    address 192.168.1.101
    netmask 255.255.255.0
    gateway 192.168.1.1
    dns-nameservers 8.8.8.8 8.8.4.4
    mtu 9000
EOF
        print_warning "Network interface configured with static IP. A reboot is required for changes to take effect."
    else
        print_info "Static IP already configured for $INTERFACE."
    fi
else
    print_warning "Could not determine default network interface. Please configure static IP manually."
fi

# Install Docker
print_info "Installing Docker..."
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh
sudo usermod -aG docker $USER
rm get-docker.sh

# Install Docker Compose
print_info "Installing Docker Compose..."
sudo apt-get install -y python3-pip
sudo pip3 install docker-compose

# Set up TensorRT optimization
print_info "Setting up TensorRT optimization..."
if [ -d "/usr/src/tensorrt" ]; then
    print_info "TensorRT samples found. Setting up environment..."
    echo 'export LD_LIBRARY_PATH=/usr/lib/aarch64-linux-gnu:$LD_LIBRARY_PATH' >> ~/.bashrc
else
    print_warning "TensorRT samples not found. Please ensure TensorRT is properly installed."
fi

# Set up environment variables
print_info "Setting up environment variables..."
cat > ~/.opsc-vision-env << EOF
export PYTHONPATH=\$HOME/opsc-vision-system:\$PYTHONPATH
export ROBOFLOW_API_KEY="your_roboflow_api_key_here"
export AZURE_STORAGE_CONNECTION_STRING="your_azure_connection_string_here"
EOF

echo "source ~/.opsc-vision-env" >> ~/.bashrc

# Set up fan control for better cooling
print_info "Setting up fan control..."
if [ -f "/sys/devices/pwm-fan/target_pwm" ]; then
    # Create fan control service
    sudo tee /etc/systemd/system/jetson-fan-control.service > /dev/null << EOF
[Unit]
Description=Jetson Fan Control Service
After=multi-user.target

[Service]
Type=oneshot
ExecStart=/bin/sh -c "echo 255 > /sys/devices/pwm-fan/target_pwm"
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
EOF

    # Enable and start the service
    sudo systemctl enable jetson-fan-control.service
    sudo systemctl start jetson-fan-control.service
    print_success "Fan control service configured and started."
else
    print_warning "Fan control not available on this device."
fi

# Download model weights if they don't exist
print_info "Checking for model weights..."
if [ ! -f ~/opsc-vision-system/models/weights/sandwich_model.trt ]; then
    print_info "Model weights not found. Please download them manually or use the model conversion script."
    print_info "Example: python3 -m opsc-vision-system.models.convert_to_tensorrt --input_model=/path/to/model.onnx --output_model=models/weights/sandwich_model.trt"
fi

print_success "Jetson Xavier NX setup complete!"
print_info "Please log out and log back in for all changes to take effect."
print_info "After logging back in, update the following environment variables in ~/.opsc-vision-env:"
print_info "  - ROBOFLOW_API_KEY: Your Roboflow API key"
print_info "  - AZURE_STORAGE_CONNECTION_STRING: Your Azure Storage connection string"
print_warning "A system reboot is recommended to apply all network and hardware settings."
