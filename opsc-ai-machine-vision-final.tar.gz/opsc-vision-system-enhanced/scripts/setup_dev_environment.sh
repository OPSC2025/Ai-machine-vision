#!/bin/bash
# setup_dev_environment.sh
# Setup development environment for OPSC Sandwich Quality Inspection System
# Version: 1.0.0
# Last Updated: 2025-04-21

set -e  # Exit on error

# Print colored output
print_info() {
    echo -e "\e[34m[INFO]\e[0m $1"
}

print_success() {
    echo -e "\e[32m[SUCCESS]\e[0m $1"
}

print_error() {
    echo -e "\e[31m[ERROR]\e[0m $1"
}

print_warning() {
    echo -e "\e[33m[WARNING]\e[0m $1"
}

# Check if running as root
if [[ $EUID -eq 0 ]]; then
    print_error "This script should not be run as root. Please run as a regular user with sudo privileges."
    exit 1
fi

# Check for sudo privileges
if ! sudo -v; then
    print_error "This script requires sudo privileges. Please ensure you have sudo access."
    exit 1
fi

print_info "Setting up development environment for OPSC Sandwich Quality Inspection System..."

# Create directories if they don't exist
print_info "Creating directory structure..."
mkdir -p ~/opsc-vision-system/{src,config,data,models,docker,scripts,tests,docs}
mkdir -p ~/opsc-vision-system/data/{database,logs,images,reports,calibration}
mkdir -p ~/opsc-vision-system/models/{roboflow,weights}

# Update package lists
print_info "Updating package lists..."
sudo apt-get update

# Install system dependencies
print_info "Installing system dependencies..."
sudo apt-get install -y \
    python3-pip \
    python3-dev \
    python3-opencv \
    libopencv-dev \
    libglib2.0-0 \
    libsm6 \
    libxext6 \
    libxrender-dev \
    libgl1-mesa-glx \
    wget \
    curl \
    git \
    unzip \
    pkg-config \
    build-essential \
    cmake \
    ffmpeg \
    libavcodec-dev \
    libavformat-dev \
    libswscale-dev

# Check if NVIDIA GPU is available
if lspci | grep -i nvidia > /dev/null; then
    print_info "NVIDIA GPU detected. Installing CUDA and TensorRT..."
    
    # Install CUDA
    print_info "Downloading CUDA..."
    wget https://developer.download.nvidia.com/compute/cuda/repos/ubuntu2204/x86_64/cuda-keyring_1.1-1_all.deb
    sudo dpkg -i cuda-keyring_1.1-1_all.deb
    sudo apt-get update
    sudo apt-get install -y cuda-12-3
    
    # Set up CUDA environment variables
    echo 'export PATH=/usr/local/cuda/bin:$PATH' >> ~/.bashrc
    echo 'export LD_LIBRARY_PATH=/usr/local/cuda/lib64:$LD_LIBRARY_PATH' >> ~/.bashrc
    
    # Install TensorRT
    print_info "Installing TensorRT..."
    pip3 install --user nvidia-tensorrt
    
    print_success "CUDA and TensorRT installed successfully."
else
    print_warning "No NVIDIA GPU detected. Skipping CUDA and TensorRT installation."
fi

# Install Pylon SDK for Basler cameras
print_info "Installing Pylon SDK for Basler cameras..."
cd /tmp
wget -q https://www.baslerweb.com/fp-1615275617/media/downloads/software/pylon_software/pylon_7.4.0.13389_linux_x86_64_debs.tar.gz
tar -xzf pylon_7.4.0.13389_linux_x86_64_debs.tar.gz
cd pylon_7.4.0.13389_linux_x86_64_debs
sudo apt-get install -y ./pylon_7.4.0.13389-deb0_amd64.deb
cd ~
rm -rf /tmp/pylon*

# Install Docker
print_info "Installing Docker..."
sudo apt-get install -y apt-transport-https ca-certificates curl software-properties-common
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo apt-key add -
sudo add-apt-repository "deb [arch=amd64] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable"
sudo apt-get update
sudo apt-get install -y docker-ce docker-ce-cli containerd.io

# Install Docker Compose
print_info "Installing Docker Compose..."
sudo curl -L "https://github.com/docker/compose/releases/download/v2.24.0/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# Add user to docker group
print_info "Adding user to docker group..."
sudo usermod -aG docker $USER
print_warning "You may need to log out and log back in for docker group changes to take effect."

# Install Python dependencies
print_info "Installing Python dependencies..."
pip3 install --user \
    numpy==2.2.4 \
    pandas==2.2.3 \
    opencv-python==4.11.0.86 \
    streamlit==1.44.1 \
    plotly==6.0.1 \
    pyyaml==6.0.2 \
    sqlalchemy==2.0.40 \
    pytest==8.0.0 \
    pylint==3.0.3 \
    black==24.3.0 \
    roboflow==1.1.9 \
    azure-storage-blob==12.19.0 \
    azure-identity==1.15.0

# Clone repository if it doesn't exist
if [ ! -d ~/opsc-vision-system/.git ]; then
    print_info "Cloning repository..."
    cd ~
    git clone https://github.com/example/opsc-vision-system.git opsc-vision-system-repo
    cp -r opsc-vision-system-repo/* opsc-vision-system/
    rm -rf opsc-vision-system-repo
fi

# Set up network configuration for development
print_info "Setting up network configuration..."
sudo sysctl -w net.core.rmem_max=26214400
sudo sysctl -w net.core.wmem_max=26214400
sudo sysctl -w net.ipv4.tcp_rmem="4096 87380 26214400"
sudo sysctl -w net.ipv4.tcp_wmem="4096 87380 26214400"

# Make these settings persistent
if ! grep -q "net.core.rmem_max" /etc/sysctl.conf; then
    echo "net.core.rmem_max=26214400" | sudo tee -a /etc/sysctl.conf
    echo "net.core.wmem_max=26214400" | sudo tee -a /etc/sysctl.conf
    echo "net.ipv4.tcp_rmem=4096 87380 26214400" | sudo tee -a /etc/sysctl.conf
    echo "net.ipv4.tcp_wmem=4096 87380 26214400" | sudo tee -a /etc/sysctl.conf
fi

# Set up development environment variables
print_info "Setting up environment variables..."
cat > ~/.opsc-vision-env << EOF
export PYTHONPATH=\$HOME/opsc-vision-system:\$PYTHONPATH
export ROBOFLOW_API_KEY="your_roboflow_api_key_here"
export AZURE_STORAGE_CONNECTION_STRING="your_azure_connection_string_here"
EOF

echo "source ~/.opsc-vision-env" >> ~/.bashrc

# Create a virtual environment
print_info "Creating Python virtual environment..."
pip3 install --user virtualenv
cd ~/opsc-vision-system
python3 -m virtualenv venv
echo "source ~/opsc-vision-system/venv/bin/activate" >> ~/.bashrc

print_success "Development environment setup complete!"
print_info "Please log out and log back in for all changes to take effect."
print_info "After logging back in, update the following environment variables in ~/.opsc-vision-env:"
print_info "  - ROBOFLOW_API_KEY: Your Roboflow API key"
print_info "  - AZURE_STORAGE_CONNECTION_STRING: Your Azure Storage connection string"
