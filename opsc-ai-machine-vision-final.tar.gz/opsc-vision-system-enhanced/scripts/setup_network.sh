#!/bin/bash
# setup_network.sh
# Network optimization script for OPSC Sandwich Quality Inspection System
# Version: 1.0.0
# Last Updated: 2025-04-21

set -e  # Exit on error

# Print colored output
print_info() {
    echo -e "\e[34m[INFO]\e[0m $1"
}

print_success() {
    echo -e "\e[32m[SUCCESS]\e[0m $1"
}

print_error() {
    echo -e "\e[31m[ERROR]\e[0m $1"
}

print_warning() {
    echo -e "\e[33m[WARNING]\e[0m $1"
}

# Check if running as root
if [[ $EUID -ne 0 ]]; then
    print_error "This script must be run as root. Please use sudo."
    exit 1
fi

print_info "Setting up network optimizations for OPSC Sandwich Quality Inspection System..."

# Detect network interfaces
INTERFACES=$(ip -o link show | awk -F': ' '{print $2}' | grep -v "lo" | cut -d@ -f1)
if [ -z "$INTERFACES" ]; then
    print_error "No network interfaces found. Exiting."
    exit 1
fi

# Ask user to select network interface
echo "Available network interfaces:"
select INTERFACE in $INTERFACES; do
    if [ -n "$INTERFACE" ]; then
        break
    else
        print_error "Invalid selection. Please try again."
    fi
done

print_info "Selected network interface: $INTERFACE"

# Check if interface supports jumbo frames
print_info "Checking if interface supports jumbo frames..."
CURRENT_MTU=$(ip link show $INTERFACE | grep -oP 'mtu \K\d+')
print_info "Current MTU: $CURRENT_MTU"

# Set jumbo frames
print_info "Setting jumbo frames (MTU 9000)..."
ip link set $INTERFACE mtu 9000
if [ $? -eq 0 ]; then
    print_success "Successfully set MTU to 9000"
else
    print_warning "Failed to set MTU to 9000. Some switches/routers may not support jumbo frames."
    print_info "Setting MTU to 1500 (standard)..."
    ip link set $INTERFACE mtu 1500
fi

# Make MTU setting persistent
print_info "Making MTU setting persistent..."
if [ -f "/etc/network/interfaces.d/$INTERFACE" ]; then
    # Check if MTU is already configured
    if grep -q "mtu" /etc/network/interfaces.d/$INTERFACE; then
        # Update existing MTU setting
        sed -i "s/mtu [0-9]*/mtu 9000/" /etc/network/interfaces.d/$INTERFACE
    else
        # Add MTU setting
        echo "    mtu 9000" >> /etc/network/interfaces.d/$INTERFACE
    fi
else
    # Create new interface file
    cat > /etc/network/interfaces.d/$INTERFACE << EOF
auto $INTERFACE
iface $INTERFACE inet dhcp
    mtu 9000
EOF
fi

# Optimize network stack parameters
print_info "Optimizing network stack parameters..."

# Set network buffer sizes
print_info "Setting network buffer sizes..."
sysctl -w net.core.rmem_max=26214400
sysctl -w net.core.wmem_max=26214400
sysctl -w net.core.rmem_default=26214400
sysctl -w net.core.wmem_default=26214400
sysctl -w net.ipv4.tcp_rmem="4096 87380 26214400"
sysctl -w net.ipv4.tcp_wmem="4096 87380 26214400"
sysctl -w net.ipv4.udp_mem="4096 87380 26214400"

# Optimize TCP settings
print_info "Optimizing TCP settings..."
sysctl -w net.ipv4.tcp_window_scaling=1
sysctl -w net.ipv4.tcp_timestamps=1
sysctl -w net.ipv4.tcp_sack=1
sysctl -w net.ipv4.tcp_fastopen=3
sysctl -w net.ipv4.tcp_low_latency=1
sysctl -w net.ipv4.tcp_slow_start_after_idle=0
sysctl -w net.ipv4.tcp_mtu_probing=1

# Optimize congestion control
print_info "Setting TCP congestion control to BBR..."
if grep -q "bbr" /proc/sys/net/ipv4/tcp_available_congestion_control; then
    sysctl -w net.ipv4.tcp_congestion_control=bbr
    print_success "Set TCP congestion control to BBR"
else
    print_warning "BBR congestion control not available. Using cubic instead."
    sysctl -w net.ipv4.tcp_congestion_control=cubic
fi

# Make sysctl settings persistent
print_info "Making sysctl settings persistent..."
cat > /etc/sysctl.d/99-network-performance.conf << EOF
# Network buffer sizes
net.core.rmem_max=26214400
net.core.wmem_max=26214400
net.core.rmem_default=26214400
net.core.wmem_default=26214400
net.ipv4.tcp_rmem=4096 87380 26214400
net.ipv4.tcp_wmem=4096 87380 26214400
net.ipv4.udp_mem=4096 87380 26214400

# TCP optimizations
net.ipv4.tcp_window_scaling=1
net.ipv4.tcp_timestamps=1
net.ipv4.tcp_sack=1
net.ipv4.tcp_fastopen=3
net.ipv4.tcp_low_latency=1
net.ipv4.tcp_slow_start_after_idle=0
net.ipv4.tcp_mtu_probing=1
EOF

# Add congestion control if BBR is available
if grep -q "bbr" /proc/sys/net/ipv4/tcp_available_congestion_control; then
    echo "net.ipv4.tcp_congestion_control=bbr" >> /etc/sysctl.d/99-network-performance.conf
else
    echo "net.ipv4.tcp_congestion_control=cubic" >> /etc/sysctl.d/99-network-performance.conf
fi

# Set up QoS for camera traffic
print_info "Setting up QoS for camera traffic..."

# Check if tc is installed
if ! command -v tc &> /dev/null; then
    print_info "Installing traffic control tools..."
    apt-get update
    apt-get install -y iproute2
fi

# Clear existing qdisc
tc qdisc del dev $INTERFACE root 2>/dev/null || true

# Set up HTB qdisc
tc qdisc add dev $INTERFACE root handle 1: htb default 30

# Add main classes
tc class add dev $INTERFACE parent 1: classid 1:1 htb rate 1000mbit

# Add subclasses for different traffic types
tc class add dev $INTERFACE parent 1:1 classid 1:10 htb rate 500mbit ceil 1000mbit prio 1  # Camera traffic
tc class add dev $INTERFACE parent 1:1 classid 1:20 htb rate 300mbit ceil 800mbit prio 2   # Control traffic
tc class add dev $INTERFACE parent 1:1 classid 1:30 htb rate 200mbit ceil 500mbit prio 3   # Other traffic

# Add filters for camera traffic (assuming cameras are on 192.168.1.201-204)
tc filter add dev $INTERFACE parent 1: protocol ip prio 1 u32 match ip dst 192.168.1.201/32 flowid 1:10
tc filter add dev $INTERFACE parent 1: protocol ip prio 1 u32 match ip dst 192.168.1.202/32 flowid 1:10
tc filter add dev $INTERFACE parent 1: protocol ip prio 1 u32 match ip dst 192.168.1.203/32 flowid 1:10
tc filter add dev $INTERFACE parent 1: protocol ip prio 1 u32 match ip dst 192.168.1.204/32 flowid 1:10
tc filter add dev $INTERFACE parent 1: protocol ip prio 1 u32 match ip src 192.168.1.201/32 flowid 1:10
tc filter add dev $INTERFACE parent 1: protocol ip prio 1 u32 match ip src 192.168.1.202/32 flowid 1:10
tc filter add dev $INTERFACE parent 1: protocol ip prio 1 u32 match ip src 192.168.1.203/32 flowid 1:10
tc filter add dev $INTERFACE parent 1: protocol ip prio 1 u32 match ip src 192.168.1.204/32 flowid 1:10

# Add filter for control traffic (assuming Jetson is on 192.168.1.101)
tc filter add dev $INTERFACE parent 1: protocol ip prio 2 u32 match ip dst 192.168.1.101/32 flowid 1:20
tc filter add dev $INTERFACE parent 1: protocol ip prio 2 u32 match ip src 192.168.1.101/32 flowid 1:20

# Make QoS settings persistent
print_info "Making QoS settings persistent..."
cat > /etc/network/if-up.d/qos << EOF
#!/bin/bash
if [ "\$IFACE" = "$INTERFACE" ]; then
    # Clear existing qdisc
    tc qdisc del dev $INTERFACE root 2>/dev/null || true

    # Set up HTB qdisc
    tc qdisc add dev $INTERFACE root handle 1: htb default 30

    # Add main classes
    tc class add dev $INTERFACE parent 1: classid 1:1 htb rate 1000mbit

    # Add subclasses for different traffic types
    tc class add dev $INTERFACE parent 1:1 classid 1:10 htb rate 500mbit ceil 1000mbit prio 1  # Camera traffic
    tc class add dev $INTERFACE parent 1:1 classid 1:20 htb rate 300mbit ceil 800mbit prio 2   # Control traffic
    tc class add dev $INTERFACE parent 1:1 classid 1:30 htb rate 200mbit ceil 500mbit prio 3   # Other traffic

    # Add filters for camera traffic
    tc filter add dev $INTERFACE parent 1: protocol ip prio 1 u32 match ip dst 192.168.1.201/32 flowid 1:10
    tc filter add dev $INTERFACE parent 1: protocol ip prio 1 u32 match ip dst 192.168.1.202/32 flowid 1:10
    tc filter add dev $INTERFACE parent 1: protocol ip prio 1 u32 match ip dst 192.168.1.203/32 flowid 1:10
    tc filter add dev $INTERFACE parent 1: protocol ip prio 1 u32 match ip dst 192.168.1.204/32 flowid 1:10
    tc filter add dev $INTERFACE parent 1: protocol ip prio 1 u32 match ip src 192.168.1.201/32 flowid 1:10
    tc filter add dev $INTERFACE parent 1: protocol ip prio 1 u32 match ip src 192.168.1.202/32 flowid 1:10
    tc filter add dev $INTERFACE parent 1: protocol ip prio 1 u32 match ip src 192.168.1.203/32 flowid 1:10
    tc filter add dev $INTERFACE parent 1: protocol ip prio 1 u32 match ip src 192.168.1.204/32 flowid 1:10

    # Add filter for control traffic
    tc filter add dev $INTERFACE parent 1: protocol ip prio 2 u32 match ip dst 192.168.1.101/32 flowid 1:20
    tc filter add dev $INTERFACE parent 1: protocol ip prio 2 u32 match ip src 192.168.1.101/32 flowid 1:20
fi
EOF

chmod +x /etc/network/if-up.d/qos

# Set up network monitoring
print_info "Setting up network monitoring..."
apt-get install -y iftop nethogs iperf3

# Test network performance
print_info "Testing network performance..."
if command -v iperf3 &> /dev/null; then
    print_info "Starting iperf3 server for testing..."
    iperf3 -s -D
    print_info "You can test network performance from another machine using:"
    print_info "iperf3 -c $(hostname -I | awk '{print $1}')"
fi

print_success "Network optimization complete!"
print_warning "A system reboot is recommended to apply all network settings."
print_info "After reboot, verify jumbo frames with: ip link show $INTERFACE | grep mtu"
print_info "Verify network buffer settings with: sysctl -a | grep -E 'rmem|wmem'"
print_info "Verify QoS settings with: tc -s qdisc show dev $INTERFACE"
