# OPSC Sandwich Quality Inspection System

## Overview

The OPSC Sandwich Quality Inspection System is a comprehensive machine vision solution for automated quality control in sandwich production. The system uses advanced AI and computer vision techniques to detect various defects in sandwiches, ensuring high-quality products reach consumers.

## Key Features

- Real-time defect detection using AI-powered computer vision
- Multi-camera setup for 360° inspection
- High-performance inference using NVIDIA TensorRT optimization
- Distributed processing between host PC and Jetson Xavier NX edge device
- Comprehensive data logging and reporting
- User-friendly Streamlit dashboard interface
- Containerized deployment for easy installation and updates
- Hardware monitoring and verification

## System Architecture

The system consists of the following hardware components:

- **ADLINK DLAP-211-JNX**: Jetson Xavier NX-based edge AI device for real-time inference
- **Host PC**: Intel Core i11 with NVIDIA RTX 4060 for application hosting, UI, and data management
- **Basler acA2500-20gc Cameras (×4)**: GigE Vision cameras for high-quality image capture from multiple angles

## Technology Stack

| Component | Technology | Version | Purpose |
|-----------|------------|---------|---------|
| Frontend UI | Streamlit | 1.44.1 | Low-code, responsive UI framework |
| Computer Vision | OpenCV | 4.11.0.86 | Camera integration and image processing |
| Data Processing | NumPy | 2.2.4 | Efficient array operations |
| Data Analysis | Pandas | 2.2.3 | Data manipulation and analysis |
| Visualization | Plotly | 6.0.1 | Interactive charts and graphs |
| Configuration | PyYAML | 6.0.2 | Configuration file management |
| Database | SQLAlchemy | 2.0.40 | ORM for database operations |
| AI Integration | Roboflow | 1.1.61 | Computer vision model management |
| Deployment | PyInstaller | 6.13.0 | Application packaging |
| Networking | Requests | 2.32.3 | HTTP client for API communication |
| Image Processing | Pillow | 11.2.1 | Advanced image manipulation |
| Reporting | Matplotlib | 3.10.1 | Static visualization for reports |
| Camera SDK | Pylon | 7.4.0 | Basler camera interface |
| GPU Acceleration | CUDA | 12.3 | GPU computing platform |
| Inference Optimization | TensorRT | 8.6.1 | Neural network inference optimizer |
| Containerization | Docker | 26.0 | Application containerization |

## Project Structure

```
opsc-vision-system/
├── src/                           # Source code
│   ├── main.py                    # Application entry point
│   ├── ui/                        # UI components
│   │   ├── main_dashboard.py      # Main interface
│   │   ├── camera_view.py         # Camera feed display
│   │   ├── defect_analysis.py     # Defect visualization and stats
│   │   ├── settings.py            # Configuration interface
│   │   ├── reports.py             # Reporting interface
│   │   └── components/            # Reusable UI components
│   ├── core/                      # Core functionality
│   │   ├── camera/                # Camera management
│   │   │   ├── basler_manager.py  # Basler-specific camera manager
│   │   │   ├── calibration.py     # Camera calibration utilities
│   │   │   └── pylon_wrapper.py   # Pylon SDK wrapper
│   │   ├── inference/             # AI inference
│   │   │   ├── model_manager.py   # Model management
│   │   │   ├── jetson_client.py   # ADLINK Jetson communication
│   │   │   └── preprocessing.py   # Image preprocessing for inference
│   │   ├── data/                  # Data management
│   │   │   ├── database.py        # SQLite database operations
│   │   │   ├── export.py          # Data export utilities
│   │   │   └── archive.py         # Data archiving and cleanup
│   │   └── hardware/              # Hardware management
│   │       ├── jetson_monitor.py  # ADLINK hardware monitoring
│   │       ├── gpu_utils.py       # NVIDIA GPU utilities
│   │       └── system_monitor.py  # System resource monitoring
│   └── utils/                     # Utilities
│       ├── config.py              # Configuration management
│       ├── logging.py             # Logging utilities
│       ├── security.py            # Authentication and security
│       └── network.py             # Network utilities
├── config/                        # Configuration files
│   ├── app.yaml                   # Main application config
│   ├── cameras.yaml               # Camera-specific settings
│   ├── models.yaml                # AI model configuration
│   ├── network.yaml               # Network configuration
│   └── hardware.yaml              # Hardware-specific settings
├── data/                          # Data storage
│   ├── database/                  # SQLite database files
│   ├── logs/                      # Application logs
│   ├── images/                    # Captured defect images
│   └── reports/                   # Generated reports
├── models/                        # AI models
│   ├── roboflow/                  # Roboflow model exports
│   │   └── sandwich_defect_model.py # Roboflow model implementation
│   └── weights/                   # Local model weights
│       └── tensorrt_model.py      # TensorRT model implementation
├── docker/                        # Docker configuration
│   ├── host/                      # Host PC Docker configuration
│   ├── jetson/                    # Jetson Docker configuration
│   └── docker-compose.yml         # Multi-container orchestration
├── scripts/                       # Utility scripts
│   ├── install_host.sh            # Host PC setup script
│   ├── install_jetson.sh          # ADLINK setup script
│   ├── setup_network.sh           # Network configuration
│   └── backup.sh                  # Backup utility
├── tests/                         # Testing scripts
├── docs/                          # Documentation
├── setup.py                       # Installation script
├── requirements.txt               # Dependencies
└── docker-compose.yml             # Docker Compose configuration
```

## Installation

### Prerequisites

- Ubuntu 22.04 LTS or later
- NVIDIA GPU with CUDA support (RTX 4060 or better recommended)
- CUDA 11.7 or later
- cuDNN 8.5 or later
- TensorRT 8.5 or later
- Python 3.10 or later
- Docker and Docker Compose

### Host PC Setup

1. Clone the repository:
   ```bash
   git clone https://github.com/opsc/vision-system.git
   cd vision-system
   ```

2. Run the host setup script:
   ```bash
   ./scripts/install_host.sh
   ```

3. Install Python dependencies:
   ```bash
   pip install -e .
   ```

### Jetson Xavier NX Setup

1. Run the Jetson setup script:
   ```bash
   ./scripts/install_jetson.sh
   ```

2. Configure network settings:
   ```bash
   ./scripts/setup_network.sh
   ```

### Camera Setup

1. Connect the Basler cameras to the network switch.
2. Assign static IP addresses to the cameras (192.168.1.201-204).
3. Configure camera settings using the Pylon Camera Software Suite.

## Usage

### Starting the Application

1. Start the application using Docker Compose:
   ```bash
   docker-compose up -d
   ```

2. Or run directly with Python:
   ```bash
   python -m src.main
   ```

3. Access the web interface at http://localhost:8501

### Configuration

- Edit configuration files in the `config/` directory to customize the system.
- Use the Settings page in the web interface to adjust runtime parameters.

### Monitoring

- Use the Dashboard page to monitor system status and camera feeds.
- Hardware monitoring information is available in the System Status section.

### Reporting

- Access inspection reports from the Reports page.
- Export data in CSV, JSON, or PDF formats.

## Development

### Building from Source

1. Clone the repository:
   ```bash
   git clone https://github.com/opsc/vision-system.git
   cd vision-system
   ```

2. Install development dependencies:
   ```bash
   pip install -e ".[dev]"
   ```

3. Run tests:
   ```bash
   pytest
   ```

### Docker Development

1. Build the Docker images:
   ```bash
   docker-compose build
   ```

2. Run the development environment:
   ```bash
   docker-compose -f docker-compose.yml -f docker-compose.dev.yml up
   ```

## License

This project is proprietary and confidential. Unauthorized copying, transfer, or reproduction of the contents is strictly prohibited.

## Contact

For support or inquiries, contact the OPSC Vision Team at vision@opsc.com.
